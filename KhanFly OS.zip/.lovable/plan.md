# Improvement Plan — All Four Tracks

Scoped, shippable improvements across the four areas you selected. I'll execute top-to-bottom and check in after each track lands.

## Track 1 — Research Hub polish
- **Dashboard upgrade**: add 7-day activity sparkline (sections/sources created), top active projects, latest AI generations feed. Replace plain KPI tiles with trend-aware cards.
- **Project detail UX**: streaming AI generation (incremental section insert as tokens arrive), per-section "Regenerate" + "Expand with AI" inline actions, source picker (select which sources go into prompt), markdown preview toggle per section, autosave indicator.
- **Citations**: extend `research-generate` to emit `sources_used: number[]` per section; render footnote chips linking back to source list.
- **Intelligence page**: add real SWOT generator (AI) per competitor, save to `monitoring_competitors.swot jsonb`.
- **Trends page**: add k-means style keyword clustering (client-side) + 30-day sparkline per keyword from `monitoring_alerts` counts.

## Track 2 — Deep Analytics upgrades
- **Snapshot engine**: `analytics-snapshot` server route at `/api/public/cron/analytics-snapshot` that aggregates daily KPIs into a new `analytics_snapshots` table. Wire pg_cron daily at 02:00 UTC.
- **Insights engine**: `analytics-insights` server fn that runs Lovable AI over the last 7 snapshots + recent events → writes to `analytics_insights` (already exists). Add "Generate insights" button on dashboard.
- **Cross-module page**: real correlation cards (e.g. "Alert spikes → support handoffs +X%", "Posts published → bot conversations +Y%") computed from `platform_events`.
- **Richer charts**: replace bar-only views with area+line combos, add date-range picker (7/30/90d) shared across analytics pages.

## Track 3 — Module AI add-ons
Surgical AI helpers in existing pages, each calling a small server fn:
- **Workforce → Performance**: "AI summary" of an employee's reviews → coaching suggestions.
- **Workforce → Helpdesk**: auto-categorize + suggest reply for open tickets.
- **Monitor → Alerts**: "AI triage" button → severity + suggested action.
- **Monitor → Feed**: bulk sentiment re-score for selected mentions.
- **Content → Posts**: "Improve caption" + "Generate hashtags" inline.
- **Content → Proposals**: AI draft from client + brief.
- **Bots → Knowledge**: AI Q&A test panel against knowledge base.
- **Bots → Builder**: "Suggest next node" based on current flow context.

All helpers go through one shared server fn `ai-assist` with a typed `task` discriminator (cheap, reusable, no per-feature edge functions).

## Track 4 — Visual/design refresh
- **Tokens**: refine `--research`, `--analytics` accents; add subtle elevation tokens, refined focus rings.
- **Typography**: tighten heading scale, add display weight for dashboard hero numbers.
- **Motion**: page-level fade/slide on route change, staggered card entry on dashboards.
- **Card system**: unified `KpiCard` with sparkline, delta chip, trend arrow — replace ad-hoc tiles across all dashboards.
- **Empty states**: branded empty states per module with one-click "seed demo data" where appropriate.

## Technical details
- New table: `analytics_snapshots(org_id, date, module, metrics jsonb)` + RLS by org membership.
- Extend `monitoring_competitors` with `swot jsonb` nullable.
- New server fn: `src/lib/ai-assist.functions.ts` with `task: 'summarize_reviews' | 'triage_alert' | 'improve_caption' | ...`.
- New server route: `src/routes/api/public/cron.analytics-snapshot.ts` guarded by `CRON_SECRET` header.
- Streaming: use Lovable AI Gateway SSE; client appends sections as they arrive via `ReadableStream` reader.
- Shared `KpiCard` in `src/components/ui/kpi-card.tsx`; recharts sparkline.

## Execution order
1. Track 4 foundation (KpiCard + tokens) — unlocks visual consistency for tracks 1–3
2. Track 1 (Research polish, incl. citations + streaming)
3. Track 2 (snapshots + insights + cross-module)
4. Track 3 (shared `ai-assist` + per-page UI hooks)

I'll start with **Track 4 foundation + Track 1**, then check in.
