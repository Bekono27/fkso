/**
 * Playwright E2E smoke tests for KhanFly OS.
 *
 * Setup:  bun add -d @playwright/test && bunx playwright install chromium
 * Run:    bunx playwright test
 *
 * Override target with E2E_BASE_URL=https://… bunx playwright test
 */
import { test, expect, devices } from "@playwright/test";

const BASE = process.env.E2E_BASE_URL
  ?? "https://id-preview--c1e88a60-7e2c-48c7-9f55-48ef06ccc6ba.lovable.app";

const VIEWPORTS = [
  { name: "desktop", ...devices["Desktop Chrome"] },
  { name: "tablet",  ...devices["iPad (gen 7)"] },
  { name: "mobile",  ...devices["iPhone 13"] },
];

for (const vp of VIEWPORTS) {
  test.describe(`[${vp.name}]`, () => {
    test.use(vp);

    test("loads home and shows nav", async ({ page }) => {
      const res = await page.goto(BASE);
      expect(res?.status() ?? 0).toBeLessThan(500);
      // App shell or login screen — either is acceptable, but page must hydrate.
      await expect(page.locator("body")).not.toBeEmpty();
    });

    test("Cmd+K opens global search", async ({ page }) => {
      await page.goto(`${BASE}/dashboard`);
      // If redirected to /login, sign-in not in scope for smoke; skip.
      if (page.url().includes("/login")) test.skip(true, "auth required");
      const isMac = process.platform === "darwin";
      await page.keyboard.press(isMac ? "Meta+K" : "Control+K");
      await expect(
        page.getByPlaceholder(/search/i).or(page.locator('[role="dialog"]'))
      ).toBeVisible({ timeout: 4000 });
    });

    test("module switching between Workforce, Monitor, Content, Bots", async ({ page }) => {
      const modules = ["/workforce", "/monitor", "/content", "/bots"];
      for (const m of modules) {
        const r = await page.goto(`${BASE}${m}`);
        expect(r?.status() ?? 0, `${m}`).toBeLessThan(500);
        await expect(page).toHaveURL(new RegExp(`(${m}|/login)`));
      }
    });
  });
}
