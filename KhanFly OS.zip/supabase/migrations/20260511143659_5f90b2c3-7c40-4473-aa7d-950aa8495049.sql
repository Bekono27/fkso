-- Add triggered_by to platform_events
ALTER TABLE public.platform_events
  ADD COLUMN IF NOT EXISTS triggered_by uuid;

-- search_index for global Cmd+K search
CREATE TABLE IF NOT EXISTS public.search_index (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  module module_source NOT NULL,
  entity_type text NOT NULL,
  entity_id uuid NOT NULL,
  title text NOT NULL,
  subtitle text,
  keywords text,
  url text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (org_id, entity_id)
);

CREATE INDEX IF NOT EXISTS idx_search_index_org ON public.search_index(org_id);
CREATE INDEX IF NOT EXISTS idx_search_index_module ON public.search_index(module);
CREATE INDEX IF NOT EXISTS idx_search_index_search
  ON public.search_index USING gin (to_tsvector('simple', coalesce(title,'') || ' ' || coalesce(subtitle,'') || ' ' || coalesce(keywords,'')));

ALTER TABLE public.search_index ENABLE ROW LEVEL SECURITY;

CREATE POLICY "members read org search"
  ON public.search_index FOR SELECT TO authenticated
  USING (public.is_org_member(auth.uid(), org_id));

CREATE POLICY "members write org search"
  ON public.search_index FOR INSERT TO authenticated
  WITH CHECK (public.is_org_member(auth.uid(), org_id));

CREATE POLICY "members update org search"
  ON public.search_index FOR UPDATE TO authenticated
  USING (public.is_org_member(auth.uid(), org_id));

CREATE POLICY "wf admins delete org search"
  ON public.search_index FOR DELETE TO authenticated
  USING (public.is_workforce_admin(auth.uid(), org_id));

CREATE TRIGGER trg_search_index_touch
  BEFORE UPDATE ON public.search_index
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();