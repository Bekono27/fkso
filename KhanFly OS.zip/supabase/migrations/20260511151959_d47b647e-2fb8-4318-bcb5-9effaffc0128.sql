
-- ============================================================
-- BOT EVENT WRITERS → platform_events
-- ============================================================

CREATE OR REPLACE FUNCTION public.tg_bot_created_event()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO platform_events(org_id, source_module, event_type, payload, triggered_by)
  VALUES (NEW.org_id, 'bots'::module_source, 'bot_created',
          jsonb_build_object('bot_id', NEW.id, 'name', NEW.name, 'status', NEW.status),
          NEW.created_by);
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS tr_bot_created_event ON public.bots;
CREATE TRIGGER tr_bot_created_event
AFTER INSERT ON public.bots
FOR EACH ROW EXECUTE FUNCTION public.tg_bot_created_event();

CREATE OR REPLACE FUNCTION public.tg_bot_conversation_event()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO platform_events(org_id, source_module, event_type, payload)
    VALUES (NEW.org_id, 'bots'::module_source, 'conversation_started',
            jsonb_build_object('conversation_id', NEW.id, 'bot_id', NEW.bot_id,
                               'platform', NEW.platform, 'channel', NEW.channel));
  END IF;
  IF TG_OP = 'UPDATE' AND COALESCE(OLD.lead_captured,false) = false AND NEW.lead_captured = true THEN
    INSERT INTO platform_events(org_id, source_module, event_type, payload)
    VALUES (NEW.org_id, 'bots'::module_source, 'lead_captured',
            jsonb_build_object('conversation_id', NEW.id, 'bot_id', NEW.bot_id,
                               'contact_id', NEW.contact_id));
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS tr_bot_conversation_event ON public.bot_conversations;
CREATE TRIGGER tr_bot_conversation_event
AFTER INSERT OR UPDATE ON public.bot_conversations
FOR EACH ROW EXECUTE FUNCTION public.tg_bot_conversation_event();

CREATE OR REPLACE FUNCTION public.tg_bot_broadcast_event()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF TG_OP = 'UPDATE' AND OLD.status IS DISTINCT FROM NEW.status AND NEW.status = 'sent' THEN
    INSERT INTO platform_events(org_id, source_module, event_type, payload, triggered_by)
    VALUES (NEW.org_id, 'bots'::module_source, 'broadcast_sent',
            jsonb_build_object('broadcast_id', NEW.id, 'name', NEW.name,
                               'recipient_count', NEW.recipient_count,
                               'delivered_count', NEW.delivered_count),
            NEW.created_by);
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS tr_bot_broadcast_event ON public.bot_broadcasts;
CREATE TRIGGER tr_bot_broadcast_event
AFTER UPDATE ON public.bot_broadcasts
FOR EACH ROW EXECUTE FUNCTION public.tg_bot_broadcast_event();

-- ============================================================
-- HANDOFF: event + notify admins
-- ============================================================

CREATE OR REPLACE FUNCTION public.tg_handoff_requested()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_user record;
BEGIN
  INSERT INTO platform_events(org_id, source_module, event_type, payload)
  VALUES (NEW.org_id, 'bots'::module_source, 'handoff_requested',
          jsonb_build_object('handoff_id', NEW.id, 'conversation_id', NEW.conversation_id,
                             'reason', NEW.reason));

  FOR v_user IN
    SELECT DISTINCT user_id FROM user_roles
    WHERE org_id = NEW.org_id AND role IN ('admin'::app_role,'manager'::app_role,'ceo'::app_role)
  LOOP
    INSERT INTO notifications(org_id, user_id, title, body, type, source_module, link)
    VALUES (NEW.org_id, v_user.user_id,
            '🙋 Human handoff requested',
            COALESCE(NEW.reason, 'A bot conversation needs human attention.'),
            'warning', 'bots'::module_source,
            '/bots/chat?handoff=' || NEW.id::text);
  END LOOP;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS tr_handoff_requested ON public.handoff_requests;
CREATE TRIGGER tr_handoff_requested
AFTER INSERT ON public.handoff_requests
FOR EACH ROW EXECUTE FUNCTION public.tg_handoff_requested();

-- ============================================================
-- SEARCH INDEX upserts: bots, bot_contacts, bot_broadcasts
-- ============================================================

CREATE OR REPLACE FUNCTION public.tg_index_bot()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO search_index(org_id, module, entity_type, entity_id, title, subtitle, keywords, url, updated_at)
  VALUES (NEW.org_id, 'bots'::module_source, 'bot', NEW.id,
          COALESCE(NEW.name,'Untitled bot'),
          NEW.description,
          COALESCE(NEW.status,'') || ' bot ' || COALESCE(NEW.emoji,''),
          '/bots/list', now())
  ON CONFLICT (org_id, entity_id) DO UPDATE SET
    title = EXCLUDED.title, subtitle = EXCLUDED.subtitle,
    keywords = EXCLUDED.keywords, updated_at = now();
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS tr_index_bot ON public.bots;
CREATE TRIGGER tr_index_bot
AFTER INSERT OR UPDATE ON public.bots
FOR EACH ROW EXECUTE FUNCTION public.tg_index_bot();

CREATE OR REPLACE FUNCTION public.tg_index_bot_contact()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO search_index(org_id, module, entity_type, entity_id, title, subtitle, keywords, url, updated_at)
  VALUES (NEW.org_id, 'bots'::module_source, 'contact', NEW.id,
          COALESCE(NEW.name, NEW.username, NEW.phone, NEW.email, 'Unknown contact'),
          COALESCE(NEW.email, NEW.phone, NEW.platform::text),
          COALESCE(NEW.platform::text,'') || ' ' || COALESCE(NEW.username,'') || ' ' ||
            COALESCE(NEW.phone,'') || ' ' || COALESCE(NEW.email,'') ||
            CASE WHEN NEW.lead_captured THEN ' lead' ELSE '' END,
          '/bots/contacts', now())
  ON CONFLICT (org_id, entity_id) DO UPDATE SET
    title = EXCLUDED.title, subtitle = EXCLUDED.subtitle,
    keywords = EXCLUDED.keywords, updated_at = now();
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS tr_index_bot_contact ON public.bot_contacts;
CREATE TRIGGER tr_index_bot_contact
AFTER INSERT OR UPDATE ON public.bot_contacts
FOR EACH ROW EXECUTE FUNCTION public.tg_index_bot_contact();

CREATE OR REPLACE FUNCTION public.tg_index_bot_broadcast()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO search_index(org_id, module, entity_type, entity_id, title, subtitle, keywords, url, updated_at)
  VALUES (NEW.org_id, 'bots'::module_source, 'broadcast', NEW.id,
          COALESCE(NEW.name,'Untitled broadcast'),
          COALESCE(NEW.status,'') || ' • ' || COALESCE(NEW.recipient_count,0)::text || ' recipients',
          COALESCE(NEW.platform::text,'') || ' broadcast ' || COALESCE(NEW.status,''),
          '/bots/broadcasts', now())
  ON CONFLICT (org_id, entity_id) DO UPDATE SET
    title = EXCLUDED.title, subtitle = EXCLUDED.subtitle,
    keywords = EXCLUDED.keywords, updated_at = now();
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS tr_index_bot_broadcast ON public.bot_broadcasts;
CREATE TRIGGER tr_index_bot_broadcast
AFTER INSERT OR UPDATE ON public.bot_broadcasts
FOR EACH ROW EXECUTE FUNCTION public.tg_index_bot_broadcast();
