
ALTER TYPE module_source ADD VALUE IF NOT EXISTS 'workforce';
ALTER TYPE module_source ADD VALUE IF NOT EXISTS 'monitor';
ALTER TYPE module_source ADD VALUE IF NOT EXISTS 'content';
