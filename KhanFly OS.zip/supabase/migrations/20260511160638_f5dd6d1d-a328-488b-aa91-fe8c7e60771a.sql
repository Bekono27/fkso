CREATE OR REPLACE FUNCTION public.tg_index_bot()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  INSERT INTO public.search_index(org_id, module, entity_type, entity_id, title, subtitle, keywords, url, updated_at)
  VALUES (
    NEW.org_id,
    'bots'::module_source,
    'bot',
    NEW.id,
    COALESCE(NEW.name, 'Untitled bot'),
    NEW.description,
    COALESCE(NEW.status::text, '') || ' bot ' || COALESCE(NEW.emoji, ''),
    '/bots/list',
    now()
  )
  ON CONFLICT (org_id, entity_id) DO UPDATE SET
    title = EXCLUDED.title,
    subtitle = EXCLUDED.subtitle,
    keywords = EXCLUDED.keywords,
    updated_at = now();
  RETURN NEW;
END $$;