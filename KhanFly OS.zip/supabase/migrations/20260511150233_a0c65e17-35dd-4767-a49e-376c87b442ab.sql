
-- ============================================================
-- FLOWBOT SCHEMA (Step 6A)
-- ============================================================

-- Enums
DO $$ BEGIN
  CREATE TYPE bot_status AS ENUM ('draft','active','paused','archived');
EXCEPTION WHEN duplicate_object THEN null; END $$;

DO $$ BEGIN
  CREATE TYPE bot_platform AS ENUM ('telegram','whatsapp','messenger','instagram','facebook','web','sms');
EXCEPTION WHEN duplicate_object THEN null; END $$;

DO $$ BEGIN
  CREATE TYPE bot_msg_direction AS ENUM ('in','out');
EXCEPTION WHEN duplicate_object THEN null; END $$;

DO $$ BEGIN
  CREATE TYPE bot_resolution AS ENUM ('ai','human','unresolved');
EXCEPTION WHEN duplicate_object THEN null; END $$;

DO $$ BEGIN
  CREATE TYPE handoff_status AS ENUM ('pending','accepted','resolved','cancelled');
EXCEPTION WHEN duplicate_object THEN null; END $$;

DO $$ BEGIN
  CREATE TYPE broadcast_status AS ENUM ('draft','scheduled','sending','sent','failed');
EXCEPTION WHEN duplicate_object THEN null; END $$;

-- Add 'bots' to module_source if not present
DO $$ BEGIN
  ALTER TYPE module_source ADD VALUE IF NOT EXISTS 'bots';
EXCEPTION WHEN others THEN null; END $$;

-- ============================================================
-- TABLES
-- ============================================================

CREATE TABLE IF NOT EXISTS public.bot_template_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  sort_order int DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.bot_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  category_id uuid REFERENCES public.bot_template_categories(id) ON DELETE SET NULL,
  name text NOT NULL,
  description text,
  preview_image text,
  flow_data jsonb NOT NULL DEFAULT '{}'::jsonb,
  is_official boolean DEFAULT true,
  use_count int DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.bots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  status bot_status NOT NULL DEFAULT 'draft',
  template_id uuid REFERENCES public.bot_templates(id) ON DELETE SET NULL,
  template_name text,
  avatar_url text,
  emoji text DEFAULT '🤖',
  settings jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.bot_flows (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  bot_id uuid NOT NULL REFERENCES public.bots(id) ON DELETE CASCADE,
  version int NOT NULL DEFAULT 1,
  name text NOT NULL DEFAULT 'Main',
  is_published boolean DEFAULT false,
  data jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.bot_nodes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  flow_id uuid NOT NULL REFERENCES public.bot_flows(id) ON DELETE CASCADE,
  node_type text NOT NULL,
  position jsonb DEFAULT '{"x":0,"y":0}'::jsonb,
  config jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.bot_edges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  flow_id uuid NOT NULL REFERENCES public.bot_flows(id) ON DELETE CASCADE,
  source_node uuid NOT NULL REFERENCES public.bot_nodes(id) ON DELETE CASCADE,
  target_node uuid NOT NULL REFERENCES public.bot_nodes(id) ON DELETE CASCADE,
  label text,
  condition jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.bot_variables (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  bot_id uuid NOT NULL REFERENCES public.bots(id) ON DELETE CASCADE,
  key text NOT NULL,
  default_value text,
  scope text DEFAULT 'bot',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (bot_id, key)
);

CREATE TABLE IF NOT EXISTS public.bot_channels (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  bot_id uuid NOT NULL REFERENCES public.bots(id) ON DELETE CASCADE,
  platform bot_platform NOT NULL,
  external_id text,
  display_name text,
  credentials jsonb DEFAULT '{}'::jsonb,
  is_active boolean DEFAULT true,
  webhook_url text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.bot_contacts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  platform bot_platform,
  external_id text,
  name text,
  username text,
  phone text,
  email text,
  avatar_url text,
  attributes jsonb DEFAULT '{}'::jsonb,
  conversation_count int DEFAULT 0,
  lead_captured boolean DEFAULT false,
  last_seen_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.bot_contact_tags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  contact_id uuid NOT NULL REFERENCES public.bot_contacts(id) ON DELETE CASCADE,
  tag text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.bot_contact_attributes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  contact_id uuid NOT NULL REFERENCES public.bot_contacts(id) ON DELETE CASCADE,
  key text NOT NULL,
  value text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.bot_conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  bot_id uuid REFERENCES public.bots(id) ON DELETE SET NULL,
  contact_id uuid REFERENCES public.bot_contacts(id) ON DELETE SET NULL,
  channel_id uuid REFERENCES public.bot_channels(id) ON DELETE SET NULL,
  platform bot_platform,
  channel text,
  status text DEFAULT 'open',
  resolved_by bot_resolution,
  lead_captured boolean DEFAULT false,
  last_message_at timestamptz,
  message_count int DEFAULT 0,
  satisfaction_score int,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.bot_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  conversation_id uuid REFERENCES public.bot_conversations(id) ON DELETE CASCADE,
  direction bot_msg_direction NOT NULL,
  sender text,
  content text,
  media_url text,
  metadata jsonb DEFAULT '{}'::jsonb,
  ai_confidence numeric,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.bot_broadcasts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  bot_id uuid REFERENCES public.bots(id) ON DELETE SET NULL,
  name text NOT NULL,
  message text,
  message_preview text,
  platform bot_platform,
  status broadcast_status DEFAULT 'draft',
  segment jsonb DEFAULT '{}'::jsonb,
  recipient_count int DEFAULT 0,
  delivered_count int DEFAULT 0,
  scheduled_at timestamptz,
  sent_at timestamptz,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.bot_broadcast_recipients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  broadcast_id uuid NOT NULL REFERENCES public.bot_broadcasts(id) ON DELETE CASCADE,
  contact_id uuid REFERENCES public.bot_contacts(id) ON DELETE SET NULL,
  status text DEFAULT 'pending',
  delivered_at timestamptz,
  error_message text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.automation_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  bot_id uuid REFERENCES public.bots(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  trigger_type text NOT NULL,
  active boolean DEFAULT true,
  config jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.automation_triggers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  rule_id uuid NOT NULL REFERENCES public.automation_rules(id) ON DELETE CASCADE,
  event text NOT NULL,
  config jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.automation_actions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  rule_id uuid NOT NULL REFERENCES public.automation_rules(id) ON DELETE CASCADE,
  action_type text NOT NULL,
  config jsonb DEFAULT '{}'::jsonb,
  sort_order int DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.knowledge_base_sources (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  bot_id uuid REFERENCES public.bots(id) ON DELETE CASCADE,
  source_type text NOT NULL,
  name text NOT NULL,
  url text,
  status text DEFAULT 'pending',
  item_count int DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.knowledge_base_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  source_id uuid REFERENCES public.knowledge_base_sources(id) ON DELETE CASCADE,
  title text,
  question text,
  answer text,
  category text DEFAULT 'general',
  tags text[] DEFAULT '{}',
  embedding_status text DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.live_chat_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  conversation_id uuid REFERENCES public.bot_conversations(id) ON DELETE CASCADE,
  agent_id uuid,
  status text DEFAULT 'active',
  started_at timestamptz NOT NULL DEFAULT now(),
  ended_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.handoff_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  conversation_id uuid REFERENCES public.bot_conversations(id) ON DELETE CASCADE,
  bot_id uuid REFERENCES public.bots(id) ON DELETE SET NULL,
  reason text,
  status handoff_status NOT NULL DEFAULT 'pending',
  accepted_by uuid,
  accepted_at timestamptz,
  resolved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.bot_analytics_daily (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  bot_id uuid REFERENCES public.bots(id) ON DELETE CASCADE,
  date date NOT NULL,
  conversations int DEFAULT 0,
  ai_resolved int DEFAULT 0,
  human_handoffs int DEFAULT 0,
  leads_captured int DEFAULT 0,
  avg_response_seconds numeric,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (bot_id, date)
);

CREATE TABLE IF NOT EXISTS public.webhook_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  channel_id uuid REFERENCES public.bot_channels(id) ON DELETE SET NULL,
  platform bot_platform,
  request_method text,
  request_headers jsonb,
  request_body jsonb,
  response_status int,
  response_body jsonb,
  error_message text,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ============================================================
-- INDEXES
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_bots_org ON public.bots(org_id, status);
CREATE INDEX IF NOT EXISTS idx_bot_flows_org ON public.bot_flows(org_id, bot_id);
CREATE INDEX IF NOT EXISTS idx_bot_nodes_flow ON public.bot_nodes(flow_id);
CREATE INDEX IF NOT EXISTS idx_bot_edges_flow ON public.bot_edges(flow_id);
CREATE INDEX IF NOT EXISTS idx_bot_channels_org ON public.bot_channels(org_id, bot_id);
CREATE INDEX IF NOT EXISTS idx_bot_conversations_org ON public.bot_conversations(org_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_bot_messages_conv ON public.bot_messages(conversation_id, created_at);
CREATE INDEX IF NOT EXISTS idx_bot_contacts_org ON public.bot_contacts(org_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_bot_broadcasts_org ON public.bot_broadcasts(org_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_handoff_pending ON public.handoff_requests(org_id, status);
CREATE INDEX IF NOT EXISTS idx_bot_analytics_bot_date ON public.bot_analytics_daily(bot_id, date DESC);
CREATE INDEX IF NOT EXISTS idx_kb_items_org ON public.knowledge_base_items(org_id);
CREATE INDEX IF NOT EXISTS idx_automation_rules_org ON public.automation_rules(org_id, active);
CREATE INDEX IF NOT EXISTS idx_webhook_logs_org ON public.webhook_logs(org_id, created_at DESC);

-- ============================================================
-- RLS
-- ============================================================
DO $$
DECLARE t text;
DECLARE bots_tables text[] := ARRAY[
  'bots','bot_flows','bot_nodes','bot_edges','bot_variables','bot_templates',
  'bot_template_categories','bot_channels','bot_conversations','bot_messages',
  'bot_contacts','bot_contact_tags','bot_contact_attributes','bot_broadcasts',
  'bot_broadcast_recipients','automation_rules','automation_triggers',
  'automation_actions','knowledge_base_items','knowledge_base_sources',
  'live_chat_sessions','handoff_requests','bot_analytics_daily','webhook_logs'
];
BEGIN
  FOREACH t IN ARRAY bots_tables LOOP
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
  END LOOP;
END $$;

-- Standard org-scoped policies (members view, admins manage)
DO $$
DECLARE t text;
DECLARE bots_tables text[] := ARRAY[
  'bots','bot_flows','bot_nodes','bot_edges','bot_variables','bot_templates',
  'bot_template_categories','bot_channels','bot_broadcasts',
  'bot_broadcast_recipients','automation_rules','automation_triggers',
  'automation_actions','knowledge_base_items','knowledge_base_sources',
  'live_chat_sessions','handoff_requests','bot_analytics_daily',
  'bot_contact_tags','bot_contact_attributes'
];
BEGIN
  FOREACH t IN ARRAY bots_tables LOOP
    EXECUTE format('DROP POLICY IF EXISTS "bots members view" ON public.%I', t);
    EXECUTE format('CREATE POLICY "bots members view" ON public.%I FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id))', t);
    EXECUTE format('DROP POLICY IF EXISTS "bots admins manage" ON public.%I', t);
    EXECUTE format('CREATE POLICY "bots admins manage" ON public.%I FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id))', t);
    EXECUTE format('DROP POLICY IF EXISTS "bots members insert" ON public.%I', t);
    EXECUTE format('CREATE POLICY "bots members insert" ON public.%I FOR INSERT TO authenticated WITH CHECK (is_org_member(auth.uid(), org_id))', t);
  END LOOP;
END $$;

-- Webhook-friendly: bot_conversations, bot_messages, bot_contacts (allow public insert)
ALTER TABLE public.bot_conversations ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "bots members view conv" ON public.bot_conversations;
CREATE POLICY "bots members view conv" ON public.bot_conversations FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
DROP POLICY IF EXISTS "bots admins manage conv" ON public.bot_conversations;
CREATE POLICY "bots admins manage conv" ON public.bot_conversations FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));
DROP POLICY IF EXISTS "webhook insert conv" ON public.bot_conversations;
CREATE POLICY "webhook insert conv" ON public.bot_conversations FOR INSERT WITH CHECK (true);

DROP POLICY IF EXISTS "bots members view msg" ON public.bot_messages;
CREATE POLICY "bots members view msg" ON public.bot_messages FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
DROP POLICY IF EXISTS "bots admins manage msg" ON public.bot_messages;
CREATE POLICY "bots admins manage msg" ON public.bot_messages FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));
DROP POLICY IF EXISTS "webhook insert msg" ON public.bot_messages;
CREATE POLICY "webhook insert msg" ON public.bot_messages FOR INSERT WITH CHECK (true);

DROP POLICY IF EXISTS "bots members view contact" ON public.bot_contacts;
CREATE POLICY "bots members view contact" ON public.bot_contacts FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
DROP POLICY IF EXISTS "bots admins manage contact" ON public.bot_contacts;
CREATE POLICY "bots admins manage contact" ON public.bot_contacts FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));
DROP POLICY IF EXISTS "webhook insert contact" ON public.bot_contacts;
CREATE POLICY "webhook insert contact" ON public.bot_contacts FOR INSERT WITH CHECK (true);

-- webhook_logs: admins only
DROP POLICY IF EXISTS "wlogs admins" ON public.webhook_logs;
CREATE POLICY "wlogs admins" ON public.webhook_logs FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));
DROP POLICY IF EXISTS "wlogs webhook insert" ON public.webhook_logs;
CREATE POLICY "wlogs webhook insert" ON public.webhook_logs FOR INSERT WITH CHECK (true);

-- ============================================================
-- updated_at triggers
-- ============================================================
DO $$
DECLARE t text;
DECLARE tt text[] := ARRAY['bots','bot_flows','bot_channels','bot_contacts','bot_conversations','bot_broadcasts','automation_rules','knowledge_base_items','knowledge_base_sources','bot_templates'];
BEGIN
  FOREACH t IN ARRAY tt LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS trg_touch_updated_at ON public.%I', t);
    EXECUTE format('CREATE TRIGGER trg_touch_updated_at BEFORE UPDATE ON public.%I FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at()', t);
  END LOOP;
END $$;

-- ============================================================
-- Auto-provisioning: seed bots defaults on new org
-- ============================================================
CREATE OR REPLACE FUNCTION public.seed_bots_defaults()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  cat_sales uuid; cat_support uuid; cat_ecom uuid; cat_general uuid;
  demo_bot_id uuid; demo_flow_id uuid;
  n1 uuid; n2 uuid; n3 uuid;
BEGIN
  -- Categories
  INSERT INTO public.bot_template_categories (org_id, name, sort_order) VALUES
    (NEW.id, 'Sales', 1) RETURNING id INTO cat_sales;
  INSERT INTO public.bot_template_categories (org_id, name, sort_order) VALUES
    (NEW.id, 'Support', 2) RETURNING id INTO cat_support;
  INSERT INTO public.bot_template_categories (org_id, name, sort_order) VALUES
    (NEW.id, 'E-commerce', 3) RETURNING id INTO cat_ecom;
  INSERT INTO public.bot_template_categories (org_id, name, sort_order) VALUES
    (NEW.id, 'General', 4) RETURNING id INTO cat_general;

  -- 8 templates
  INSERT INTO public.bot_templates (org_id, category_id, name, description) VALUES
    (NEW.id, cat_support, 'Customer Support', 'Handle FAQs and route to human agent'),
    (NEW.id, cat_sales, 'Lead Generation', 'Qualify leads and capture contact info'),
    (NEW.id, cat_support, 'FAQ Bot', 'Answer common questions instantly'),
    (NEW.id, cat_ecom, 'Order Tracking', 'Look up order status by number'),
    (NEW.id, cat_sales, 'Appointment Booking', 'Schedule meetings and consultations'),
    (NEW.id, cat_ecom, 'Product Catalog', 'Browse products by category'),
    (NEW.id, cat_general, 'Feedback Collection', 'Gather customer feedback and ratings'),
    (NEW.id, cat_general, 'Welcome & Onboarding', 'Greet new users and explain features');

  -- Demo bot
  INSERT INTO public.bots (org_id, name, status, description, emoji)
  VALUES (NEW.id, 'My First Bot', 'draft', 'A starter bot — open in builder to customize.', '🤖')
  RETURNING id INTO demo_bot_id;

  -- Demo flow with 3 nodes
  INSERT INTO public.bot_flows (org_id, bot_id, name, is_published)
  VALUES (NEW.id, demo_bot_id, 'Welcome Flow', false)
  RETURNING id INTO demo_flow_id;

  INSERT INTO public.bot_nodes (org_id, flow_id, node_type, position, config)
  VALUES (NEW.id, demo_flow_id, 'start', '{"x":100,"y":100}'::jsonb, '{"label":"Start"}'::jsonb)
  RETURNING id INTO n1;

  INSERT INTO public.bot_nodes (org_id, flow_id, node_type, position, config)
  VALUES (NEW.id, demo_flow_id, 'message', '{"x":300,"y":100}'::jsonb, '{"text":"👋 Hi! I''m your assistant. How can I help today?"}'::jsonb)
  RETURNING id INTO n2;

  INSERT INTO public.bot_nodes (org_id, flow_id, node_type, position, config)
  VALUES (NEW.id, demo_flow_id, 'end', '{"x":500,"y":100}'::jsonb, '{"label":"End"}'::jsonb)
  RETURNING id INTO n3;

  INSERT INTO public.bot_edges (org_id, flow_id, source_node, target_node)
  VALUES (NEW.id, demo_flow_id, n1, n2), (NEW.id, demo_flow_id, n2, n3);

  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_seed_bots_defaults ON public.organizations;
CREATE TRIGGER trg_seed_bots_defaults
AFTER INSERT ON public.organizations
FOR EACH ROW EXECUTE FUNCTION public.seed_bots_defaults();

-- Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.handoff_requests;
ALTER PUBLICATION supabase_realtime ADD TABLE public.bot_messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.bot_conversations;
