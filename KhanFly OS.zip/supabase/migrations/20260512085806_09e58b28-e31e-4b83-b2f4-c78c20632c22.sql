
-- =========================================================
-- RESEARCH MODULE
-- =========================================================
CREATE TABLE public.research_projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  title text NOT NULL,
  type text NOT NULL DEFAULT 'custom',
  status text NOT NULL DEFAULT 'draft',
  outline jsonb NOT NULL DEFAULT '[]'::jsonb,
  data_sources jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_research_projects_org ON public.research_projects(org_id, created_at DESC);

CREATE TABLE public.research_sections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES public.research_projects(id) ON DELETE CASCADE,
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  title text NOT NULL,
  content text NOT NULL DEFAULT '',
  order_index int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_research_sections_project ON public.research_sections(project_id, order_index);

CREATE TABLE public.research_sources (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES public.research_projects(id) ON DELETE CASCADE,
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  type text NOT NULL,
  url text,
  content_summary text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  added_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_research_sources_project ON public.research_sources(project_id);

CREATE TABLE public.research_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  type text NOT NULL,
  title text NOT NULL,
  content text NOT NULL DEFAULT '',
  params jsonb NOT NULL DEFAULT '{}'::jsonb,
  generated_at timestamptz NOT NULL DEFAULT now(),
  file_url text,
  public_link text UNIQUE,
  password_hash text,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_research_reports_org ON public.research_reports(org_id, generated_at DESC);

-- =========================================================
-- ANALYTICS MODULE
-- =========================================================
CREATE TABLE public.analytics_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  module text NOT NULL,
  snapshot_date date NOT NULL,
  metrics jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (org_id, module, snapshot_date)
);
CREATE INDEX idx_analytics_snapshots_org_date ON public.analytics_snapshots(org_id, snapshot_date DESC);

CREATE TABLE public.analytics_insights (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text NOT NULL DEFAULT '',
  type text NOT NULL DEFAULT 'insight',
  severity text NOT NULL DEFAULT 'info',
  modules_involved text[] NOT NULL DEFAULT '{}',
  supporting_data jsonb NOT NULL DEFAULT '{}'::jsonb,
  dismissed boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_analytics_insights_org ON public.analytics_insights(org_id, created_at DESC);

CREATE TABLE public.analytics_goals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  module text NOT NULL,
  title text NOT NULL,
  description text DEFAULT '',
  metric_key text NOT NULL,
  target_value numeric NOT NULL DEFAULT 0,
  current_value numeric NOT NULL DEFAULT 0,
  unit text DEFAULT 'count',
  deadline date,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_analytics_goals_org ON public.analytics_goals(org_id);

-- =========================================================
-- updated_at triggers
-- =========================================================
CREATE TRIGGER tg_research_projects_touch BEFORE UPDATE ON public.research_projects
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER tg_research_sections_touch BEFORE UPDATE ON public.research_sections
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER tg_analytics_goals_touch BEFORE UPDATE ON public.analytics_goals
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- =========================================================
-- RLS
-- =========================================================
ALTER TABLE public.research_projects   ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.research_sections   ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.research_sources    ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.research_reports    ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.analytics_snapshots ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.analytics_insights  ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.analytics_goals     ENABLE ROW LEVEL SECURITY;

-- Generic helpers reused: public.is_org_member(uid,org), public.is_workforce_admin(uid,org)

-- research_projects
CREATE POLICY rp_select ON public.research_projects FOR SELECT
  USING (public.is_org_member(auth.uid(), org_id));
CREATE POLICY rp_insert ON public.research_projects FOR INSERT
  WITH CHECK (public.is_org_member(auth.uid(), org_id));
CREATE POLICY rp_update ON public.research_projects FOR UPDATE
  USING (public.is_workforce_admin(auth.uid(), org_id) OR created_by = auth.uid());
CREATE POLICY rp_delete ON public.research_projects FOR DELETE
  USING (public.is_workforce_admin(auth.uid(), org_id) OR created_by = auth.uid());

-- research_sections
CREATE POLICY rs_select ON public.research_sections FOR SELECT
  USING (public.is_org_member(auth.uid(), org_id));
CREATE POLICY rs_insert ON public.research_sections FOR INSERT
  WITH CHECK (public.is_org_member(auth.uid(), org_id));
CREATE POLICY rs_update ON public.research_sections FOR UPDATE
  USING (public.is_org_member(auth.uid(), org_id));
CREATE POLICY rs_delete ON public.research_sections FOR DELETE
  USING (public.is_workforce_admin(auth.uid(), org_id));

-- research_sources
CREATE POLICY rsrc_select ON public.research_sources FOR SELECT
  USING (public.is_org_member(auth.uid(), org_id));
CREATE POLICY rsrc_insert ON public.research_sources FOR INSERT
  WITH CHECK (public.is_org_member(auth.uid(), org_id));
CREATE POLICY rsrc_delete ON public.research_sources FOR DELETE
  USING (public.is_org_member(auth.uid(), org_id));

-- research_reports
CREATE POLICY rr_select ON public.research_reports FOR SELECT
  USING (public.is_org_member(auth.uid(), org_id));
CREATE POLICY rr_insert ON public.research_reports FOR INSERT
  WITH CHECK (public.is_org_member(auth.uid(), org_id));
CREATE POLICY rr_update ON public.research_reports FOR UPDATE
  USING (public.is_workforce_admin(auth.uid(), org_id) OR created_by = auth.uid());
CREATE POLICY rr_delete ON public.research_reports FOR DELETE
  USING (public.is_workforce_admin(auth.uid(), org_id) OR created_by = auth.uid());

-- analytics_snapshots
CREATE POLICY as_select ON public.analytics_snapshots FOR SELECT
  USING (public.is_org_member(auth.uid(), org_id));
CREATE POLICY as_insert ON public.analytics_snapshots FOR INSERT
  WITH CHECK (public.is_workforce_admin(auth.uid(), org_id));
CREATE POLICY as_update ON public.analytics_snapshots FOR UPDATE
  USING (public.is_workforce_admin(auth.uid(), org_id));

-- analytics_insights
CREATE POLICY ai_select ON public.analytics_insights FOR SELECT
  USING (public.is_org_member(auth.uid(), org_id));
CREATE POLICY ai_insert ON public.analytics_insights FOR INSERT
  WITH CHECK (public.is_org_member(auth.uid(), org_id));
CREATE POLICY ai_update ON public.analytics_insights FOR UPDATE
  USING (public.is_org_member(auth.uid(), org_id));
CREATE POLICY ai_delete ON public.analytics_insights FOR DELETE
  USING (public.is_workforce_admin(auth.uid(), org_id));

-- analytics_goals
CREATE POLICY ag_select ON public.analytics_goals FOR SELECT
  USING (public.is_org_member(auth.uid(), org_id));
CREATE POLICY ag_insert ON public.analytics_goals FOR INSERT
  WITH CHECK (public.is_workforce_admin(auth.uid(), org_id));
CREATE POLICY ag_update ON public.analytics_goals FOR UPDATE
  USING (public.is_workforce_admin(auth.uid(), org_id) OR created_by = auth.uid());
CREATE POLICY ag_delete ON public.analytics_goals FOR DELETE
  USING (public.is_workforce_admin(auth.uid(), org_id));
