
-- Retry: same migration, but normalize join tables to have created_at

ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'project_manager';

DO $$ BEGIN CREATE TYPE public.attendance_method AS ENUM ('nfc','wifi','manual','gps','qr'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE public.event_type AS ENUM ('clock_in','clock_out','break_start','break_end'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE public.task_status AS ENUM ('todo','in_progress','in_review','completed','cancelled'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE public.task_priority AS ENUM ('low','medium','high','urgent'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE public.leave_type AS ENUM ('annual','sick','personal','maternity','paternity','unpaid','public_holiday','other'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE public.leave_status AS ENUM ('pending','approved','rejected','cancelled'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE public.session_status AS ENUM ('active','completed','incomplete'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE public.device_type AS ENUM ('nfc_reader','wifi_router','qr_station'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE OR REPLACE FUNCTION public.is_workforce_admin(_user_id uuid, _org_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public AS $$
  SELECT public.has_role(_user_id,_org_id,'admin'::app_role)
      OR public.has_role(_user_id,_org_id,'ceo'::app_role)
      OR public.has_role(_user_id,_org_id,'manager'::app_role);
$$;

CREATE TABLE public.employees (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  full_name text NOT NULL, email text, phone text, position text,
  department_id uuid, avatar_url text, nfc_card_id text, employee_code text,
  is_active boolean NOT NULL DEFAULT true,
  hire_date date, salary numeric(12,2), work_hours_per_day numeric(4,2) DEFAULT 8.0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(org_id, employee_code), UNIQUE(org_id, nfc_card_id)
);
ALTER TABLE public.employees ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.get_employee_id(_user_id uuid, _org_id uuid)
RETURNS uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public AS $$
  SELECT id FROM public.employees WHERE user_id=_user_id AND org_id=_org_id LIMIT 1;
$$;

CREATE POLICY "wf members view employees" ON public.employees FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id) AND is_active = true);
CREATE POLICY "wf self view employee" ON public.employees FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "wf admins manage employees" ON public.employees FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));
CREATE POLICY "wf self update employee" ON public.employees FOR UPDATE TO authenticated USING (user_id = auth.uid());

CREATE TABLE public.departments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  name text NOT NULL, description text,
  manager_id uuid REFERENCES public.employees(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(org_id, name)
);
ALTER TABLE public.departments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.employees ADD CONSTRAINT employees_dept_fk FOREIGN KEY (department_id) REFERENCES public.departments(id) ON DELETE SET NULL;
CREATE POLICY "wf members view depts" ON public.departments FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
CREATE POLICY "wf admins manage depts" ON public.departments FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.device_keys (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  name text NOT NULL, device_type device_type NOT NULL,
  mac_address text, location text,
  api_key text NOT NULL DEFAULT encode(gen_random_bytes(32),'hex'),
  is_active boolean NOT NULL DEFAULT true, last_heartbeat timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.device_keys ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf admins manage devices" ON public.device_keys FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.attendance_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  employee_id uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  event_type event_type NOT NULL,
  method attendance_method NOT NULL DEFAULT 'manual',
  device_id uuid REFERENCES public.device_keys(id),
  latitude numeric(10,7), longitude numeric(10,7), location_accuracy numeric(6,2),
  notes text, created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.attendance_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf own attendance" ON public.attendance_events FOR SELECT TO authenticated USING (employee_id = get_employee_id(auth.uid(), org_id));
CREATE POLICY "wf admins view attendance" ON public.attendance_events FOR SELECT TO authenticated USING (is_workforce_admin(auth.uid(), org_id));
CREATE POLICY "wf own attendance insert" ON public.attendance_events FOR INSERT TO authenticated WITH CHECK (employee_id = get_employee_id(auth.uid(), org_id));
CREATE POLICY "wf admins manage attendance" ON public.attendance_events FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.work_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  employee_id uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  clock_in timestamptz NOT NULL, clock_out timestamptz,
  break_minutes integer DEFAULT 0, total_minutes integer, overtime_minutes integer DEFAULT 0,
  status session_status NOT NULL DEFAULT 'active',
  clock_in_method attendance_method, clock_out_method attendance_method,
  clock_in_device_id uuid REFERENCES public.device_keys(id),
  clock_out_device_id uuid REFERENCES public.device_keys(id),
  notes text, date date NOT NULL DEFAULT CURRENT_DATE,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.work_sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf own sessions" ON public.work_sessions FOR SELECT TO authenticated USING (employee_id = get_employee_id(auth.uid(), org_id));
CREATE POLICY "wf admins view sessions" ON public.work_sessions FOR SELECT TO authenticated USING (is_workforce_admin(auth.uid(), org_id));
CREATE POLICY "wf own sessions manage" ON public.work_sessions FOR ALL TO authenticated USING (employee_id = get_employee_id(auth.uid(), org_id)) WITH CHECK (employee_id = get_employee_id(auth.uid(), org_id));
CREATE POLICY "wf admins manage sessions" ON public.work_sessions FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.leave_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  employee_id uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  leave_type leave_type NOT NULL,
  start_date date NOT NULL, end_date date NOT NULL,
  reason text, status leave_status NOT NULL DEFAULT 'pending',
  reviewed_by uuid REFERENCES public.employees(id), reviewed_at timestamptz, review_notes text,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.leave_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf own leave" ON public.leave_requests FOR SELECT TO authenticated USING (employee_id = get_employee_id(auth.uid(), org_id));
CREATE POLICY "wf own leave insert" ON public.leave_requests FOR INSERT TO authenticated WITH CHECK (employee_id = get_employee_id(auth.uid(), org_id));
CREATE POLICY "wf own pending leave update" ON public.leave_requests FOR UPDATE TO authenticated USING (employee_id = get_employee_id(auth.uid(), org_id) AND status='pending');
CREATE POLICY "wf admins manage leave" ON public.leave_requests FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.leave_balances (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  employee_id uuid REFERENCES public.employees(id) ON DELETE CASCADE,
  leave_type leave_type NOT NULL,
  total_days numeric(6,2) NOT NULL DEFAULT 0,
  used_days numeric(6,2) NOT NULL DEFAULT 0,
  year integer NOT NULL DEFAULT EXTRACT(YEAR FROM now()),
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(org_id, employee_id, leave_type, year)
);
ALTER TABLE public.leave_balances ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf own balance" ON public.leave_balances FOR SELECT TO authenticated USING (employee_id IS NULL OR employee_id = get_employee_id(auth.uid(), org_id) OR is_workforce_admin(auth.uid(), org_id));
CREATE POLICY "wf admins manage balance" ON public.leave_balances FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.salary_components (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  name text NOT NULL, component_type text NOT NULL DEFAULT 'allowance',
  amount numeric(12,2), is_percentage boolean DEFAULT false,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.salary_components ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf admins manage salary comps" ON public.salary_components FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.payroll_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  employee_id uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  month integer NOT NULL, year integer NOT NULL,
  base_salary numeric DEFAULT 0, total_work_hours numeric DEFAULT 0,
  overtime_hours numeric DEFAULT 0, overtime_pay numeric DEFAULT 0,
  transport_bonus numeric DEFAULT 0, skill_bonus numeric DEFAULT 0,
  quality_bonus numeric DEFAULT 0, attendance_bonus numeric DEFAULT 0,
  gross_salary numeric DEFAULT 0, social_insurance numeric DEFAULT 0,
  income_tax numeric DEFAULT 0, net_salary numeric DEFAULT 0,
  status text NOT NULL DEFAULT 'draft',
  approved_by uuid REFERENCES public.employees(id), approved_at timestamptz, notes text,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(org_id, employee_id, month, year)
);
ALTER TABLE public.payroll_records ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf own payroll" ON public.payroll_records FOR SELECT TO authenticated USING (employee_id = get_employee_id(auth.uid(), org_id));
CREATE POLICY "wf admins manage payroll" ON public.payroll_records FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.payroll_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  payroll_id uuid NOT NULL REFERENCES public.payroll_records(id) ON DELETE CASCADE,
  component_id uuid REFERENCES public.salary_components(id),
  label text NOT NULL, amount numeric(12,2) NOT NULL DEFAULT 0,
  item_type text NOT NULL DEFAULT 'allowance',
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.payroll_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf payroll items via record" ON public.payroll_items FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM payroll_records p WHERE p.id = payroll_id AND (p.employee_id = get_employee_id(auth.uid(), payroll_items.org_id) OR is_workforce_admin(auth.uid(), payroll_items.org_id))));
CREATE POLICY "wf admins manage payroll items" ON public.payroll_items FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.shifts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  name text NOT NULL, start_time time NOT NULL, end_time time NOT NULL,
  shift_type text NOT NULL DEFAULT 'morning',
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.shifts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf members view shifts" ON public.shifts FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
CREATE POLICY "wf admins manage shifts" ON public.shifts FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.shift_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  shift_id uuid NOT NULL REFERENCES public.shifts(id) ON DELETE CASCADE,
  employee_id uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  shift_date date NOT NULL, status text NOT NULL DEFAULT 'scheduled', notes text,
  created_by uuid REFERENCES public.employees(id),
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.shift_assignments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf own shift assigns" ON public.shift_assignments FOR SELECT TO authenticated USING (employee_id = get_employee_id(auth.uid(), org_id));
CREATE POLICY "wf admins manage shift assigns" ON public.shift_assignments FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.workforce_projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  name text NOT NULL, description text,
  status text NOT NULL DEFAULT 'active',
  start_date date, end_date date,
  manager_id uuid REFERENCES public.employees(id),
  department_id uuid REFERENCES public.departments(id),
  budget numeric DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.workforce_projects ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf members view projects" ON public.workforce_projects FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
CREATE POLICY "wf admins manage projects" ON public.workforce_projects FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.workforce_project_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  project_id uuid NOT NULL REFERENCES public.workforce_projects(id) ON DELETE CASCADE,
  employee_id uuid NOT NULL REFERENCES public.employees(id),
  role text DEFAULT 'member',
  joined_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(project_id, employee_id)
);
ALTER TABLE public.workforce_project_members ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf members view proj members" ON public.workforce_project_members FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
CREATE POLICY "wf admins manage proj members" ON public.workforce_project_members FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.workforce_tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  project_id uuid REFERENCES public.workforce_projects(id) ON DELETE SET NULL,
  title text NOT NULL, description text,
  assigned_to uuid REFERENCES public.employees(id),
  assigned_by uuid REFERENCES public.employees(id),
  department_id uuid REFERENCES public.departments(id),
  priority task_priority NOT NULL DEFAULT 'medium',
  status task_status NOT NULL DEFAULT 'todo',
  category text,
  due_date timestamptz, started_at timestamptz, completed_at timestamptz,
  estimated_hours numeric(6,2), actual_hours numeric(6,2),
  completion_percentage integer DEFAULT 0,
  parent_task_id uuid REFERENCES public.workforce_tasks(id),
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.workforce_tasks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf members view tasks" ON public.workforce_tasks FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
CREATE POLICY "wf members create tasks" ON public.workforce_tasks FOR INSERT TO authenticated WITH CHECK (is_org_member(auth.uid(), org_id) AND assigned_by = get_employee_id(auth.uid(), org_id));
CREATE POLICY "wf assignee update task" ON public.workforce_tasks FOR UPDATE TO authenticated USING (assigned_to = get_employee_id(auth.uid(), org_id) OR assigned_by = get_employee_id(auth.uid(), org_id));
CREATE POLICY "wf admins manage tasks" ON public.workforce_tasks FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.workforce_task_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  task_id uuid NOT NULL REFERENCES public.workforce_tasks(id) ON DELETE CASCADE,
  author_id uuid NOT NULL REFERENCES public.employees(id),
  content text NOT NULL, created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.workforce_task_comments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf members view task comments" ON public.workforce_task_comments FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
CREATE POLICY "wf members add task comments" ON public.workforce_task_comments FOR INSERT TO authenticated WITH CHECK (author_id = get_employee_id(auth.uid(), org_id));

CREATE TABLE public.helpdesk_tickets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  title text NOT NULL, description text, category text DEFAULT 'general',
  priority task_priority NOT NULL DEFAULT 'medium',
  status text NOT NULL DEFAULT 'open',
  reporter_id uuid REFERENCES public.employees(id),
  assignee_id uuid REFERENCES public.employees(id),
  resolved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.helpdesk_tickets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf own tickets" ON public.helpdesk_tickets FOR SELECT TO authenticated USING (reporter_id = get_employee_id(auth.uid(), org_id) OR assignee_id = get_employee_id(auth.uid(), org_id));
CREATE POLICY "wf admins view tickets" ON public.helpdesk_tickets FOR SELECT TO authenticated USING (is_workforce_admin(auth.uid(), org_id));
CREATE POLICY "wf members create tickets" ON public.helpdesk_tickets FOR INSERT TO authenticated WITH CHECK (is_org_member(auth.uid(), org_id) AND reporter_id = get_employee_id(auth.uid(), org_id));
CREATE POLICY "wf admins manage tickets" ON public.helpdesk_tickets FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.helpdesk_ticket_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  ticket_id uuid NOT NULL REFERENCES public.helpdesk_tickets(id) ON DELETE CASCADE,
  author_id uuid NOT NULL REFERENCES public.employees(id),
  content text NOT NULL, created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.helpdesk_ticket_comments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf ticket comments view" ON public.helpdesk_ticket_comments FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
CREATE POLICY "wf ticket comments insert" ON public.helpdesk_ticket_comments FOR INSERT TO authenticated WITH CHECK (author_id = get_employee_id(auth.uid(), org_id));

CREATE TABLE public.assets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  name text NOT NULL, asset_tag text, category text DEFAULT 'general',
  serial_number text, status text NOT NULL DEFAULT 'available',
  purchase_date date, purchase_cost numeric(12,2), notes text,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(org_id, asset_tag)
);
ALTER TABLE public.assets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf members view assets" ON public.assets FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
CREATE POLICY "wf admins manage assets" ON public.assets FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.asset_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  asset_id uuid NOT NULL REFERENCES public.assets(id) ON DELETE CASCADE,
  employee_id uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  assigned_at timestamptz NOT NULL DEFAULT now(), returned_at timestamptz, notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.asset_assignments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf members view asset assigns" ON public.asset_assignments FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
CREATE POLICY "wf admins manage asset assigns" ON public.asset_assignments FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.courses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  title text NOT NULL, description text, category text DEFAULT 'general',
  duration_minutes integer DEFAULT 0, cover_url text,
  is_published boolean NOT NULL DEFAULT false,
  created_by uuid REFERENCES public.employees(id),
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.courses ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf members view courses" ON public.courses FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id) AND (is_published OR is_workforce_admin(auth.uid(), org_id)));
CREATE POLICY "wf admins manage courses" ON public.courses FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.course_enrollments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  course_id uuid NOT NULL REFERENCES public.courses(id) ON DELETE CASCADE,
  employee_id uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  enrolled_at timestamptz NOT NULL DEFAULT now(),
  progress integer DEFAULT 0, completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(course_id, employee_id)
);
ALTER TABLE public.course_enrollments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf own enrollments" ON public.course_enrollments FOR SELECT TO authenticated USING (employee_id = get_employee_id(auth.uid(), org_id) OR is_workforce_admin(auth.uid(), org_id));
CREATE POLICY "wf own enrollment manage" ON public.course_enrollments FOR ALL TO authenticated USING (employee_id = get_employee_id(auth.uid(), org_id) OR is_workforce_admin(auth.uid(), org_id)) WITH CHECK (employee_id = get_employee_id(auth.uid(), org_id) OR is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.announcements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  title text NOT NULL, content text NOT NULL,
  author_id uuid REFERENCES public.employees(id),
  priority text DEFAULT 'normal', expires_at timestamptz,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf members view announcements" ON public.announcements FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id) AND is_active);
CREATE POLICY "wf admins manage announcements" ON public.announcements FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.kudos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  receiver_id uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  message text NOT NULL, category text NOT NULL DEFAULT 'teamwork',
  emoji text DEFAULT '🌟',
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.kudos ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf members view kudos" ON public.kudos FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
CREATE POLICY "wf members give kudos" ON public.kudos FOR INSERT TO authenticated WITH CHECK (sender_id = get_employee_id(auth.uid(), org_id));

CREATE TABLE public.polls (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  question text NOT NULL, options jsonb NOT NULL DEFAULT '[]',
  created_by uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  is_active boolean NOT NULL DEFAULT true, expires_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.polls ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf members view polls" ON public.polls FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id) AND is_active);
CREATE POLICY "wf members create polls" ON public.polls FOR INSERT TO authenticated WITH CHECK (created_by = get_employee_id(auth.uid(), org_id));
CREATE POLICY "wf admins manage polls" ON public.polls FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.poll_votes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  poll_id uuid NOT NULL REFERENCES public.polls(id) ON DELETE CASCADE,
  voter_id uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  selected_option integer NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(poll_id, voter_id)
);
ALTER TABLE public.poll_votes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf own votes" ON public.poll_votes FOR SELECT TO authenticated USING (voter_id = get_employee_id(auth.uid(), org_id));
CREATE POLICY "wf admins view votes" ON public.poll_votes FOR SELECT TO authenticated USING (is_workforce_admin(auth.uid(), org_id));
CREATE POLICY "wf members vote" ON public.poll_votes FOR INSERT TO authenticated WITH CHECK (voter_id = get_employee_id(auth.uid(), org_id));

CREATE TABLE public.performance_reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  reviewer_id uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  reviewee_id uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  review_type text NOT NULL DEFAULT 'manager', period text NOT NULL,
  overall_rating integer DEFAULT 0,
  strengths text, improvements text, goals text, comments text,
  status text NOT NULL DEFAULT 'draft',
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.performance_reviews ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf own reviews" ON public.performance_reviews FOR SELECT TO authenticated USING (reviewer_id = get_employee_id(auth.uid(), org_id) OR reviewee_id = get_employee_id(auth.uid(), org_id) OR is_workforce_admin(auth.uid(), org_id));
CREATE POLICY "wf reviewer create" ON public.performance_reviews FOR INSERT TO authenticated WITH CHECK (reviewer_id = get_employee_id(auth.uid(), org_id));
CREATE POLICY "wf reviewer update" ON public.performance_reviews FOR UPDATE TO authenticated USING (reviewer_id = get_employee_id(auth.uid(), org_id));
CREATE POLICY "wf admins manage reviews" ON public.performance_reviews FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.kpi_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  employee_id uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  metric_name text NOT NULL,
  target_value numeric NOT NULL DEFAULT 0, current_value numeric NOT NULL DEFAULT 0,
  unit text DEFAULT '%',
  period_start date NOT NULL, period_end date NOT NULL,
  category text DEFAULT 'general', notes text,
  created_by uuid REFERENCES public.employees(id),
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.kpi_records ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf own kpis" ON public.kpi_records FOR SELECT TO authenticated USING (employee_id = get_employee_id(auth.uid(), org_id));
CREATE POLICY "wf admins manage kpis" ON public.kpi_records FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.okr_goals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  parent_id uuid REFERENCES public.okr_goals(id) ON DELETE CASCADE,
  owner_id uuid REFERENCES public.employees(id),
  title text NOT NULL, description text,
  level text NOT NULL DEFAULT 'team',
  progress integer NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'in_progress', period text,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.okr_goals ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf members view okrs" ON public.okr_goals FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
CREATE POLICY "wf admins manage okrs" ON public.okr_goals FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));
CREATE POLICY "wf owner update okr" ON public.okr_goals FOR UPDATE TO authenticated USING (owner_id = get_employee_id(auth.uid(), org_id));

CREATE TABLE public.mood_checkins (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  employee_id uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  mood_score integer NOT NULL DEFAULT 3,
  energy_level integer DEFAULT 3, stress_level integer DEFAULT 3,
  notes text, is_anonymous boolean DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.mood_checkins ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf own mood" ON public.mood_checkins FOR ALL TO authenticated USING (employee_id = get_employee_id(auth.uid(), org_id)) WITH CHECK (employee_id = get_employee_id(auth.uid(), org_id));
CREATE POLICY "wf admins view mood" ON public.mood_checkins FOR SELECT TO authenticated USING (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.chat_channels (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  name text NOT NULL, description text, type text DEFAULT 'group',
  created_by uuid REFERENCES public.employees(id),
  is_archived boolean DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.chat_channels ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.chat_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  channel_id uuid NOT NULL REFERENCES public.chat_channels(id) ON DELETE CASCADE,
  employee_id uuid NOT NULL REFERENCES public.employees(id),
  role text DEFAULT 'member',
  joined_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(channel_id, employee_id)
);
ALTER TABLE public.chat_members ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  channel_id uuid NOT NULL REFERENCES public.chat_channels(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES public.employees(id),
  content text NOT NULL, is_edited boolean DEFAULT false,
  reply_to uuid REFERENCES public.chat_messages(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.is_chat_member(_user_id uuid, _channel_id uuid, _org_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public AS $$
  SELECT EXISTS (
    SELECT 1 FROM chat_members cm
    WHERE cm.channel_id = _channel_id
      AND cm.employee_id = public.get_employee_id(_user_id, _org_id)
  );
$$;

CREATE POLICY "wf channel by member or creator" ON public.chat_channels FOR SELECT TO authenticated USING (
  is_org_member(auth.uid(), org_id)
  AND (created_by = get_employee_id(auth.uid(), org_id) OR is_chat_member(auth.uid(), id, org_id))
);
CREATE POLICY "wf create channel" ON public.chat_channels FOR INSERT TO authenticated WITH CHECK (is_org_member(auth.uid(), org_id) AND created_by = get_employee_id(auth.uid(), org_id));
CREATE POLICY "wf admins manage channels" ON public.chat_channels FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE POLICY "wf members view co-members" ON public.chat_members FOR SELECT TO authenticated USING (is_chat_member(auth.uid(), channel_id, org_id));
CREATE POLICY "wf join group channel" ON public.chat_members FOR INSERT TO authenticated WITH CHECK (
  employee_id = get_employee_id(auth.uid(), org_id)
  AND EXISTS (SELECT 1 FROM chat_channels cc WHERE cc.id=channel_id AND (cc.type='group' OR cc.created_by = get_employee_id(auth.uid(), org_id)))
);
CREATE POLICY "wf admins manage chat members" ON public.chat_members FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE POLICY "wf chat msg view" ON public.chat_messages FOR SELECT TO authenticated USING (is_chat_member(auth.uid(), channel_id, org_id));
CREATE POLICY "wf chat msg send" ON public.chat_messages FOR INSERT TO authenticated WITH CHECK (sender_id = get_employee_id(auth.uid(), org_id) AND is_chat_member(auth.uid(), channel_id, org_id));

CREATE TABLE public.workforce_documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  title text NOT NULL, description text, category text DEFAULT 'general',
  file_path text NOT NULL, file_name text NOT NULL,
  file_size bigint DEFAULT 0, mime_type text,
  is_shared boolean DEFAULT false,
  uploaded_by uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  department_id uuid REFERENCES public.departments(id),
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.workforce_documents ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf docs view" ON public.workforce_documents FOR SELECT TO authenticated USING (
  is_org_member(auth.uid(), org_id) AND (is_shared OR uploaded_by = get_employee_id(auth.uid(), org_id) OR is_workforce_admin(auth.uid(), org_id))
);
CREATE POLICY "wf docs upload" ON public.workforce_documents FOR INSERT TO authenticated WITH CHECK (uploaded_by = get_employee_id(auth.uid(), org_id));
CREATE POLICY "wf admins manage docs" ON public.workforce_documents FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.workforce_expenses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  employee_id uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  category text NOT NULL DEFAULT 'other',
  amount numeric NOT NULL, currency text DEFAULT 'MNT',
  description text, receipt_url text,
  expense_date date NOT NULL DEFAULT CURRENT_DATE,
  status text NOT NULL DEFAULT 'pending',
  reviewed_by uuid REFERENCES public.employees(id), reviewed_at timestamptz, review_notes text,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.workforce_expenses ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf own expenses" ON public.workforce_expenses FOR SELECT TO authenticated USING (employee_id = get_employee_id(auth.uid(), org_id));
CREATE POLICY "wf own expenses insert" ON public.workforce_expenses FOR INSERT TO authenticated WITH CHECK (employee_id = get_employee_id(auth.uid(), org_id));
CREATE POLICY "wf own pending update" ON public.workforce_expenses FOR UPDATE TO authenticated USING (employee_id = get_employee_id(auth.uid(), org_id) AND status='pending');
CREATE POLICY "wf admins manage expenses" ON public.workforce_expenses FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.workforce_company_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  title text NOT NULL, description text,
  start_date timestamptz NOT NULL, end_date timestamptz, location text,
  event_type text DEFAULT 'meeting', is_all_day boolean DEFAULT false,
  created_by uuid REFERENCES public.employees(id),
  department_id uuid REFERENCES public.departments(id),
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.workforce_company_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf members view events" ON public.workforce_company_events FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
CREATE POLICY "wf create events" ON public.workforce_company_events FOR INSERT TO authenticated WITH CHECK (created_by = get_employee_id(auth.uid(), org_id));
CREATE POLICY "wf admins manage events" ON public.workforce_company_events FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.workforce_onboarding_checklists (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  employee_id uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  title text NOT NULL DEFAULT 'New employee checklist',
  status text NOT NULL DEFAULT 'in_progress', due_date date,
  assigned_by uuid REFERENCES public.employees(id),
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.workforce_onboarding_checklists ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf own onboarding" ON public.workforce_onboarding_checklists FOR SELECT TO authenticated USING (employee_id = get_employee_id(auth.uid(), org_id) OR is_workforce_admin(auth.uid(), org_id));
CREATE POLICY "wf own onboarding update" ON public.workforce_onboarding_checklists FOR UPDATE TO authenticated USING (employee_id = get_employee_id(auth.uid(), org_id));
CREATE POLICY "wf admins manage onboarding" ON public.workforce_onboarding_checklists FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.workforce_onboarding_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  checklist_id uuid NOT NULL REFERENCES public.workforce_onboarding_checklists(id) ON DELETE CASCADE,
  title text NOT NULL, description text,
  is_completed boolean NOT NULL DEFAULT false, completed_at timestamptz,
  sort_order integer DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.workforce_onboarding_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf onboarding items view" ON public.workforce_onboarding_items FOR SELECT TO authenticated USING (
  EXISTS (SELECT 1 FROM workforce_onboarding_checklists c WHERE c.id=checklist_id AND (c.employee_id = get_employee_id(auth.uid(), workforce_onboarding_items.org_id) OR is_workforce_admin(auth.uid(), workforce_onboarding_items.org_id)))
);
CREATE POLICY "wf onboarding items update" ON public.workforce_onboarding_items FOR UPDATE TO authenticated USING (
  EXISTS (SELECT 1 FROM workforce_onboarding_checklists c WHERE c.id=checklist_id AND c.employee_id = get_employee_id(auth.uid(), workforce_onboarding_items.org_id))
);
CREATE POLICY "wf admins manage onboarding items" ON public.workforce_onboarding_items FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.workforce_monthly_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  employee_id uuid NOT NULL REFERENCES public.employees(id),
  month integer NOT NULL, year integer NOT NULL,
  summary text, ai_analysis text,
  attendance_data jsonb DEFAULT '{}', task_data jsonb DEFAULT '{}', kpi_data jsonb DEFAULT '{}',
  recommendations text, generated_by text DEFAULT 'manual',
  status text NOT NULL DEFAULT 'draft',
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(org_id, employee_id, month, year)
);
ALTER TABLE public.workforce_monthly_reports ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf own reports" ON public.workforce_monthly_reports FOR SELECT TO authenticated USING (employee_id = get_employee_id(auth.uid(), org_id) OR is_workforce_admin(auth.uid(), org_id));
CREATE POLICY "wf admins manage reports" ON public.workforce_monthly_reports FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.workforce_meeting_rooms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  name text NOT NULL, capacity integer NOT NULL DEFAULT 10,
  location text, floor integer DEFAULT 1,
  amenities text[] DEFAULT '{}',
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.workforce_meeting_rooms ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf members view rooms" ON public.workforce_meeting_rooms FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
CREATE POLICY "wf admins manage rooms" ON public.workforce_meeting_rooms FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.workforce_room_bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  room_id uuid NOT NULL REFERENCES public.workforce_meeting_rooms(id) ON DELETE CASCADE,
  booked_by uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  title text NOT NULL,
  start_time timestamptz NOT NULL, end_time timestamptz NOT NULL,
  attendees integer DEFAULT 1, notes text, status text NOT NULL DEFAULT 'confirmed',
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.workforce_room_bookings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf members view bookings" ON public.workforce_room_bookings FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
CREATE POLICY "wf book rooms" ON public.workforce_room_bookings FOR INSERT TO authenticated WITH CHECK (booked_by = get_employee_id(auth.uid(), org_id));
CREATE POLICY "wf own booking update" ON public.workforce_room_bookings FOR UPDATE TO authenticated USING (booked_by = get_employee_id(auth.uid(), org_id));
CREATE POLICY "wf own booking delete" ON public.workforce_room_bookings FOR DELETE TO authenticated USING (booked_by = get_employee_id(auth.uid(), org_id));
CREATE POLICY "wf admins manage bookings" ON public.workforce_room_bookings FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.workforce_approval_workflows (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  name text NOT NULL, entity_type text NOT NULL,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(org_id, entity_type)
);
ALTER TABLE public.workforce_approval_workflows ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf members view wf" ON public.workforce_approval_workflows FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
CREATE POLICY "wf admins manage wf" ON public.workforce_approval_workflows FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.workforce_approval_steps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  workflow_id uuid NOT NULL REFERENCES public.workforce_approval_workflows(id) ON DELETE CASCADE,
  step_order integer NOT NULL, step_name text NOT NULL,
  required_role app_role NOT NULL,
  is_optional boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(workflow_id, step_order)
);
ALTER TABLE public.workforce_approval_steps ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf members view steps" ON public.workforce_approval_steps FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
CREATE POLICY "wf admins manage steps" ON public.workforce_approval_steps FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.workforce_approval_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  workflow_id uuid NOT NULL REFERENCES public.workforce_approval_workflows(id),
  entity_type text NOT NULL, entity_id uuid NOT NULL,
  requester_id uuid NOT NULL REFERENCES public.employees(id),
  current_step integer NOT NULL DEFAULT 1, total_steps integer NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.workforce_approval_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf own requests" ON public.workforce_approval_requests FOR SELECT TO authenticated USING (requester_id = get_employee_id(auth.uid(), org_id) OR is_workforce_admin(auth.uid(), org_id));
CREATE POLICY "wf own requests insert" ON public.workforce_approval_requests FOR INSERT TO authenticated WITH CHECK (requester_id = get_employee_id(auth.uid(), org_id));
CREATE POLICY "wf admins manage requests" ON public.workforce_approval_requests FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id)) WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.workforce_approval_actions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  request_id uuid NOT NULL REFERENCES public.workforce_approval_requests(id) ON DELETE CASCADE,
  step_order integer NOT NULL, step_name text NOT NULL, action text NOT NULL,
  acted_by uuid NOT NULL REFERENCES public.employees(id),
  comments text, created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.workforce_approval_actions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf actions view" ON public.workforce_approval_actions FOR SELECT TO authenticated USING (acted_by = get_employee_id(auth.uid(), org_id) OR is_workforce_admin(auth.uid(), org_id));
CREATE POLICY "wf admins act" ON public.workforce_approval_actions FOR INSERT TO authenticated WITH CHECK (is_workforce_admin(auth.uid(), org_id));

CREATE TABLE public.audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  source_module module_source NOT NULL DEFAULT 'core',
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  action text NOT NULL, table_name text, record_id uuid,
  old_values jsonb, new_values jsonb,
  ip_address text, user_agent text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "wf admins view audit" ON public.audit_log FOR SELECT TO authenticated USING (is_workforce_admin(auth.uid(), org_id));
CREATE POLICY "wf members insert audit" ON public.audit_log FOR INSERT TO authenticated WITH CHECK (is_org_member(auth.uid(), org_id));

DO $$ DECLARE t text; BEGIN
  FOR t IN SELECT unnest(ARRAY[
    'employees','departments','device_keys','work_sessions','leave_requests','leave_balances',
    'salary_components','payroll_records','shifts','shift_assignments','workforce_projects',
    'workforce_tasks','helpdesk_tickets','assets','courses','performance_reviews','kpi_records',
    'okr_goals','chat_channels','workforce_documents','workforce_expenses','workforce_company_events',
    'workforce_onboarding_checklists','workforce_monthly_reports','workforce_meeting_rooms',
    'workforce_approval_workflows','workforce_approval_requests'
  ]) LOOP
    EXECUTE format('CREATE TRIGGER trg_%I_touch BEFORE UPDATE ON public.%I FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();', t, t);
  END LOOP;
END $$;

DO $$ DECLARE t text; BEGIN
  FOR t IN SELECT unnest(ARRAY[
    'employees','departments','device_keys','attendance_events','work_sessions',
    'leave_requests','leave_balances','salary_components','payroll_records','payroll_items',
    'shifts','shift_assignments','workforce_projects','workforce_project_members',
    'workforce_tasks','workforce_task_comments','helpdesk_tickets','helpdesk_ticket_comments',
    'assets','asset_assignments','courses','course_enrollments','announcements','kudos',
    'polls','poll_votes','performance_reviews','kpi_records','okr_goals','mood_checkins',
    'chat_channels','chat_members','chat_messages','workforce_documents','workforce_expenses',
    'workforce_company_events','workforce_onboarding_checklists','workforce_onboarding_items',
    'workforce_monthly_reports','workforce_meeting_rooms','workforce_room_bookings',
    'workforce_approval_workflows','workforce_approval_steps','workforce_approval_requests',
    'workforce_approval_actions','audit_log'
  ]) LOOP
    EXECUTE format('CREATE INDEX idx_%I_org_created ON public.%I (org_id, created_at DESC);', t, t);
  END LOOP;
END $$;

CREATE INDEX idx_employees_user ON public.employees(user_id);
CREATE INDEX idx_employees_dept ON public.employees(org_id, department_id);
CREATE INDEX idx_work_sessions_emp_date ON public.work_sessions(employee_id, date);
CREATE INDEX idx_attendance_emp ON public.attendance_events(employee_id);
CREATE INDEX idx_leave_emp ON public.leave_requests(employee_id);
CREATE INDEX idx_payroll_emp ON public.payroll_records(employee_id);
CREATE INDEX idx_tasks_assigned ON public.workforce_tasks(assigned_to);
CREATE INDEX idx_chat_msg_channel ON public.chat_messages(channel_id, created_at DESC);

ALTER PUBLICATION supabase_realtime ADD TABLE public.attendance_events;
ALTER PUBLICATION supabase_realtime ADD TABLE public.work_sessions;
ALTER PUBLICATION supabase_realtime ADD TABLE public.workforce_tasks;
ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.announcements;
ALTER PUBLICATION supabase_realtime ADD TABLE public.kudos;

CREATE OR REPLACE FUNCTION public.seed_org_defaults()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
  INSERT INTO public.departments (org_id, name, description) VALUES (NEW.id, 'General', 'Default department');
  INSERT INTO public.shifts (org_id, name, start_time, end_time, shift_type) VALUES (NEW.id, 'Standard 9–6', '09:00', '18:00', 'morning');
  INSERT INTO public.leave_balances (org_id, leave_type, total_days, year) VALUES
    (NEW.id, 'annual', 15, EXTRACT(YEAR FROM now())::int),
    (NEW.id, 'sick', 10, EXTRACT(YEAR FROM now())::int),
    (NEW.id, 'personal', 3, EXTRACT(YEAR FROM now())::int),
    (NEW.id, 'public_holiday', 0, EXTRACT(YEAR FROM now())::int);
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_seed_org_defaults ON public.organizations;
CREATE TRIGGER trg_seed_org_defaults AFTER INSERT ON public.organizations FOR EACH ROW EXECUTE FUNCTION public.seed_org_defaults();

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE
  new_org_id uuid; org_slug text; user_name text; default_dept uuid;
BEGIN
  user_name := COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1));
  org_slug := lower(regexp_replace(user_name || '-' || substr(NEW.id::text, 1, 8), '[^a-z0-9-]+', '-', 'g'));
  INSERT INTO public.organizations (name, slug) VALUES (user_name || '''s Workspace', org_slug) RETURNING id INTO new_org_id;
  INSERT INTO public.profiles (id, email, full_name, org_id) VALUES (NEW.id, NEW.email, user_name, new_org_id);
  INSERT INTO public.user_roles (user_id, org_id, role) VALUES (NEW.id, new_org_id, 'admin');
  SELECT id INTO default_dept FROM public.departments WHERE org_id = new_org_id AND name = 'General' LIMIT 1;
  INSERT INTO public.employees (org_id, user_id, full_name, email, department_id, is_active, hire_date)
  VALUES (new_org_id, NEW.id, user_name, NEW.email, default_dept, true, CURRENT_DATE);
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
