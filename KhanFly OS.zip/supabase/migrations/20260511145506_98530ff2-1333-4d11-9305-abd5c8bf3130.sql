
-- ===== ENUMS =====
DO $$ BEGIN
  CREATE TYPE alert_severity AS ENUM ('low','medium','high','critical');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE alert_status AS ENUM ('active','acknowledged','resolved','dismissed');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE sentiment_label AS ENUM ('positive','neutral','negative');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE social_platform AS ENUM ('facebook','instagram','twitter','tiktok','youtube','linkedin','web','news','other');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- ===== TABLES =====
CREATE TABLE IF NOT EXISTS public.monitoring_keywords (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  term text NOT NULL,
  variations text[] DEFAULT '{}',
  category text DEFAULT 'general',
  is_active boolean NOT NULL DEFAULT true,
  mention_count_total integer NOT NULL DEFAULT 0,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.monitoring_sources (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  platform social_platform NOT NULL,
  handle text NOT NULL,
  url text,
  display_name text,
  is_active boolean NOT NULL DEFAULT true,
  last_synced_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.monitoring_competitors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  name text NOT NULL,
  handle text,
  platform social_platform,
  url text,
  follower_count integer DEFAULT 0,
  engagement_avg numeric DEFAULT 0,
  last_post_at timestamptz,
  active boolean NOT NULL DEFAULT true,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.monitoring_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  source_id uuid REFERENCES public.monitoring_sources(id) ON DELETE SET NULL,
  platform social_platform NOT NULL,
  source_name text,
  source_url text,
  author text,
  content text NOT NULL,
  sentiment sentiment_label,
  sentiment_score numeric,
  matched_keyword text,
  matched_keyword_id uuid REFERENCES public.monitoring_keywords(id) ON DELETE SET NULL,
  engagement integer DEFAULT 0,
  posted_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.monitoring_alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  severity alert_severity NOT NULL DEFAULT 'medium',
  status alert_status NOT NULL DEFAULT 'active',
  triggered_keyword text,
  source_platform social_platform,
  source_url text,
  source_post_id uuid REFERENCES public.monitoring_posts(id) ON DELETE SET NULL,
  sentiment_score numeric,
  resolved_by uuid,
  resolved_at timestamptz,
  resolution_hours numeric,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.monitoring_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  title text NOT NULL,
  type text DEFAULT 'brand',
  period text,
  summary text,
  data jsonb DEFAULT '{}'::jsonb,
  file_url text,
  generated_by uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.ai_agents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  name text NOT NULL,
  agent_type text NOT NULL DEFAULT 'sentiment',
  description text,
  config jsonb NOT NULL DEFAULT '{}'::jsonb,
  is_active boolean NOT NULL DEFAULT true,
  last_run_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.sentiment_scores (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  date date NOT NULL,
  score numeric NOT NULL DEFAULT 50,
  positive_count integer DEFAULT 0,
  neutral_count integer DEFAULT 0,
  negative_count integer DEFAULT 0,
  mention_count integer DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(org_id, date)
);

CREATE TABLE IF NOT EXISTS public.sentiment_mentions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  post_id uuid REFERENCES public.monitoring_posts(id) ON DELETE CASCADE,
  date date NOT NULL DEFAULT CURRENT_DATE,
  sentiment sentiment_label NOT NULL,
  score numeric,
  source_platform social_platform,
  source_url text,
  content_preview text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.page_analysis_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  page_url text NOT NULL,
  page_name text,
  overall_score integer DEFAULT 0,
  recommendations jsonb DEFAULT '[]'::jsonb,
  raw_analysis jsonb DEFAULT '{}'::jsonb,
  analyzed_by uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.keyword_mentions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  keyword_id uuid REFERENCES public.monitoring_keywords(id) ON DELETE CASCADE,
  keyword_term text NOT NULL,
  date date NOT NULL DEFAULT CURRENT_DATE,
  count integer NOT NULL DEFAULT 1,
  platform social_platform,
  url text,
  sample_post_id uuid REFERENCES public.monitoring_posts(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.competitor_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  competitor_id uuid NOT NULL REFERENCES public.monitoring_competitors(id) ON DELETE CASCADE,
  platform social_platform,
  url text,
  content text,
  engagement integer DEFAULT 0,
  posted_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.alert_notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  alert_id uuid NOT NULL REFERENCES public.monitoring_alerts(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  channel text DEFAULT 'in_app',
  sent_at timestamptz NOT NULL DEFAULT now()
);

-- ===== INDEXES =====
CREATE INDEX IF NOT EXISTS idx_monitoring_posts_org ON public.monitoring_posts(org_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_monitoring_alerts_org ON public.monitoring_alerts(org_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_monitoring_alerts_status ON public.monitoring_alerts(org_id, status, severity);
CREATE INDEX IF NOT EXISTS idx_monitoring_keywords_org ON public.monitoring_keywords(org_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_monitoring_competitors_org ON public.monitoring_competitors(org_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_monitoring_sources_org ON public.monitoring_sources(org_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_monitoring_reports_org ON public.monitoring_reports(org_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_ai_agents_org ON public.ai_agents(org_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_sentiment_scores_org ON public.sentiment_scores(org_id, date DESC);
CREATE INDEX IF NOT EXISTS idx_sentiment_mentions_org ON public.sentiment_mentions(org_id, date DESC);
CREATE INDEX IF NOT EXISTS idx_page_analysis_org ON public.page_analysis_results(org_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_keyword_mentions_org ON public.keyword_mentions(org_id, date DESC);
CREATE INDEX IF NOT EXISTS idx_competitor_posts_org ON public.competitor_posts(org_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_alert_notifications_org ON public.alert_notifications(org_id, sent_at DESC);

-- ===== ENABLE RLS =====
ALTER TABLE public.monitoring_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.monitoring_alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.monitoring_keywords ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.monitoring_competitors ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.monitoring_sources ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.monitoring_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_agents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sentiment_scores ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sentiment_mentions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.page_analysis_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.keyword_mentions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.competitor_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.alert_notifications ENABLE ROW LEVEL SECURITY;

-- ===== RLS POLICIES =====
-- Pattern: members read, members insert telemetry, workforce admins manage everything

-- monitoring_keywords (admins manage; members view)
CREATE POLICY "monitor members view keywords" ON public.monitoring_keywords
  FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
CREATE POLICY "monitor admins manage keywords" ON public.monitoring_keywords
  FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id))
  WITH CHECK (is_workforce_admin(auth.uid(), org_id));

-- monitoring_sources
CREATE POLICY "monitor members view sources" ON public.monitoring_sources
  FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
CREATE POLICY "monitor admins manage sources" ON public.monitoring_sources
  FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id))
  WITH CHECK (is_workforce_admin(auth.uid(), org_id));

-- monitoring_competitors
CREATE POLICY "monitor members view competitors" ON public.monitoring_competitors
  FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
CREATE POLICY "monitor admins manage competitors" ON public.monitoring_competitors
  FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id))
  WITH CHECK (is_workforce_admin(auth.uid(), org_id));

-- monitoring_posts
CREATE POLICY "monitor members view posts" ON public.monitoring_posts
  FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
CREATE POLICY "monitor members insert posts" ON public.monitoring_posts
  FOR INSERT TO authenticated WITH CHECK (is_org_member(auth.uid(), org_id));
CREATE POLICY "monitor admins manage posts" ON public.monitoring_posts
  FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id))
  WITH CHECK (is_workforce_admin(auth.uid(), org_id));

-- monitoring_alerts
CREATE POLICY "monitor members view alerts" ON public.monitoring_alerts
  FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
CREATE POLICY "monitor members insert alerts" ON public.monitoring_alerts
  FOR INSERT TO authenticated WITH CHECK (is_org_member(auth.uid(), org_id));
CREATE POLICY "monitor admins manage alerts" ON public.monitoring_alerts
  FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id))
  WITH CHECK (is_workforce_admin(auth.uid(), org_id));

-- monitoring_reports
CREATE POLICY "monitor members view reports" ON public.monitoring_reports
  FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
CREATE POLICY "monitor admins manage reports" ON public.monitoring_reports
  FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id))
  WITH CHECK (is_workforce_admin(auth.uid(), org_id));

-- ai_agents
CREATE POLICY "monitor members view agents" ON public.ai_agents
  FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
CREATE POLICY "monitor admins manage agents" ON public.ai_agents
  FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id))
  WITH CHECK (is_workforce_admin(auth.uid(), org_id));

-- sentiment_scores
CREATE POLICY "monitor members view scores" ON public.sentiment_scores
  FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
CREATE POLICY "monitor members insert scores" ON public.sentiment_scores
  FOR INSERT TO authenticated WITH CHECK (is_org_member(auth.uid(), org_id));
CREATE POLICY "monitor admins manage scores" ON public.sentiment_scores
  FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id))
  WITH CHECK (is_workforce_admin(auth.uid(), org_id));

-- sentiment_mentions
CREATE POLICY "monitor members view mentions" ON public.sentiment_mentions
  FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
CREATE POLICY "monitor members insert mentions" ON public.sentiment_mentions
  FOR INSERT TO authenticated WITH CHECK (is_org_member(auth.uid(), org_id));
CREATE POLICY "monitor admins manage mentions" ON public.sentiment_mentions
  FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id))
  WITH CHECK (is_workforce_admin(auth.uid(), org_id));

-- page_analysis_results
CREATE POLICY "monitor members view page analysis" ON public.page_analysis_results
  FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
CREATE POLICY "monitor members insert page analysis" ON public.page_analysis_results
  FOR INSERT TO authenticated WITH CHECK (is_org_member(auth.uid(), org_id));
CREATE POLICY "monitor admins manage page analysis" ON public.page_analysis_results
  FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id))
  WITH CHECK (is_workforce_admin(auth.uid(), org_id));

-- keyword_mentions
CREATE POLICY "monitor members view kw mentions" ON public.keyword_mentions
  FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
CREATE POLICY "monitor members insert kw mentions" ON public.keyword_mentions
  FOR INSERT TO authenticated WITH CHECK (is_org_member(auth.uid(), org_id));
CREATE POLICY "monitor admins manage kw mentions" ON public.keyword_mentions
  FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id))
  WITH CHECK (is_workforce_admin(auth.uid(), org_id));

-- competitor_posts
CREATE POLICY "monitor members view comp posts" ON public.competitor_posts
  FOR SELECT TO authenticated USING (is_org_member(auth.uid(), org_id));
CREATE POLICY "monitor members insert comp posts" ON public.competitor_posts
  FOR INSERT TO authenticated WITH CHECK (is_org_member(auth.uid(), org_id));
CREATE POLICY "monitor admins manage comp posts" ON public.competitor_posts
  FOR ALL TO authenticated USING (is_workforce_admin(auth.uid(), org_id))
  WITH CHECK (is_workforce_admin(auth.uid(), org_id));

-- alert_notifications
CREATE POLICY "monitor self view alert notifs" ON public.alert_notifications
  FOR SELECT TO authenticated USING (user_id = auth.uid() OR is_workforce_admin(auth.uid(), org_id));
CREATE POLICY "monitor members insert alert notifs" ON public.alert_notifications
  FOR INSERT TO authenticated WITH CHECK (is_org_member(auth.uid(), org_id));

-- ===== TIMESTAMP TRIGGERS =====
CREATE TRIGGER tr_monitoring_keywords_touch BEFORE UPDATE ON public.monitoring_keywords
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER tr_monitoring_sources_touch BEFORE UPDATE ON public.monitoring_sources
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER tr_monitoring_competitors_touch BEFORE UPDATE ON public.monitoring_competitors
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER tr_monitoring_alerts_touch BEFORE UPDATE ON public.monitoring_alerts
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER tr_ai_agents_touch BEFORE UPDATE ON public.ai_agents
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- ===== AUTO-PROVISION ON NEW ORG =====
CREATE OR REPLACE FUNCTION public.seed_monitor_defaults()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Default keywords (org name, бренд, review)
  INSERT INTO public.monitoring_keywords (org_id, term, category) VALUES
    (NEW.id, NEW.name, 'brand'),
    (NEW.id, 'бренд', 'general'),
    (NEW.id, 'review', 'general');

  -- One empty competitor slot
  INSERT INTO public.monitoring_competitors (org_id, name, active)
  VALUES (NEW.id, 'Add your first competitor', false);

  -- Sentiment baseline for today
  INSERT INTO public.sentiment_scores (org_id, date, score)
  VALUES (NEW.id, CURRENT_DATE, 50)
  ON CONFLICT DO NOTHING;

  -- Default AI agent
  INSERT INTO public.ai_agents (org_id, name, agent_type, description, is_active)
  VALUES (NEW.id, 'Sentiment Analyzer', 'sentiment',
          'Default agent that classifies mentions as positive, neutral, or negative.', true);

  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS tr_seed_monitor_defaults ON public.organizations;
CREATE TRIGGER tr_seed_monitor_defaults
  AFTER INSERT ON public.organizations
  FOR EACH ROW EXECUTE FUNCTION public.seed_monitor_defaults();

-- ===== CROSS-MODULE: high/critical alert -> workforce task + manager notifications =====
CREATE OR REPLACE FUNCTION public.handle_high_severity_alert()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_task_id uuid;
  v_priority task_priority;
  v_user record;
BEGIN
  IF NEW.severity NOT IN ('high','critical') THEN
    RETURN NEW;
  END IF;

  v_priority := CASE WHEN NEW.severity = 'critical' THEN 'urgent'::task_priority
                     ELSE 'high'::task_priority END;

  INSERT INTO public.workforce_tasks (
    org_id, title, description, priority, status,
    due_date, source_module, source_id, created_by
  ) VALUES (
    NEW.org_id,
    'Crisis response: ' || NEW.title,
    'OmniSight detected a ' || NEW.severity::text || ' brand alert.' || E'\n\n' ||
    'Source: ' || COALESCE(NEW.source_platform::text, 'unknown') || E'\n' ||
    'Keyword: ' || COALESCE(NEW.triggered_keyword, '—') || E'\n' ||
    'URL: ' || COALESCE(NEW.source_url, '—') || E'\n\n' ||
    'Action required within 2 hours.',
    v_priority,
    'todo',
    (now() + interval '2 hours')::date,
    'monitor'::module_source,
    NEW.id,
    NULL
  ) RETURNING id INTO v_task_id;

  -- Notify managers / admins / ceos
  FOR v_user IN
    SELECT DISTINCT user_id FROM public.user_roles
    WHERE org_id = NEW.org_id
      AND role IN ('admin'::app_role, 'ceo'::app_role, 'manager'::app_role)
  LOOP
    INSERT INTO public.notifications (org_id, user_id, title, body, type, source_module, link)
    VALUES (
      NEW.org_id,
      v_user.user_id,
      '🚨 Brand Alert: ' || NEW.severity::text || ' — ' || NEW.title,
      'A crisis response task has been created automatically.',
      CASE WHEN NEW.severity = 'critical' THEN 'danger' ELSE 'warning' END,
      'monitor'::module_source,
      '/workforce/projects?task=' || v_task_id::text
    );
  END LOOP;

  -- Audit event
  INSERT INTO public.platform_events (org_id, source_module, event_type, payload)
  VALUES (NEW.org_id, 'monitor'::module_source, 'alert_to_task',
          jsonb_build_object('alert_id', NEW.id, 'task_id', v_task_id, 'severity', NEW.severity));

  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS tr_alert_to_task ON public.monitoring_alerts;
CREATE TRIGGER tr_alert_to_task
  AFTER INSERT ON public.monitoring_alerts
  FOR EACH ROW EXECUTE FUNCTION public.handle_high_severity_alert();

-- ===== REALTIME =====
ALTER PUBLICATION supabase_realtime ADD TABLE public.monitoring_posts;
ALTER PUBLICATION supabase_realtime ADD TABLE public.monitoring_alerts;
ALTER PUBLICATION supabase_realtime ADD TABLE public.sentiment_mentions;
