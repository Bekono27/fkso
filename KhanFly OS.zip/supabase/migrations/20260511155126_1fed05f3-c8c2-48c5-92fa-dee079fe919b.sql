
CREATE TABLE public.webhook_endpoints (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  url text NOT NULL,
  secret text NOT NULL DEFAULT encode(gen_random_bytes(24), 'hex'),
  event_types text[] NOT NULL DEFAULT '{}',
  active boolean NOT NULL DEFAULT true,
  last_delivery_at timestamptz,
  last_status int,
  last_error text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_webhook_endpoints_org_active ON public.webhook_endpoints(org_id, active);
ALTER TABLE public.webhook_endpoints ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admins manage webhooks"
  ON public.webhook_endpoints FOR ALL TO authenticated
  USING (public.is_workforce_admin(auth.uid(), org_id))
  WITH CHECK (public.is_workforce_admin(auth.uid(), org_id));

CREATE TRIGGER trg_webhook_endpoints_touch
  BEFORE UPDATE ON public.webhook_endpoints
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
