
ALTER TABLE public.platform_events
  ADD COLUMN IF NOT EXISTS attempts integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS last_error text,
  ADD COLUMN IF NOT EXISTS processed_at timestamptz,
  ADD COLUMN IF NOT EXISTS next_retry_at timestamptz NOT NULL DEFAULT now();

CREATE INDEX IF NOT EXISTS idx_platform_events_pending
  ON public.platform_events (next_retry_at)
  WHERE processed = false AND attempts < 5;
