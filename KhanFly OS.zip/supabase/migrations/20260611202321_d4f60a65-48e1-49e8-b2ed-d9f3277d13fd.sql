
-- =============================================================
-- DigiLend Mongolian banking layer (stub)
-- =============================================================

-- 1) mn_payment_config -----------------------------------------
CREATE TABLE public.mn_payment_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  provider text NOT NULL DEFAULT 'qpay' CHECK (provider IN ('qpay','khanbank','golomt','manual')),
  environment text NOT NULL DEFAULT 'sandbox' CHECK (environment IN ('sandbox','production')),
  merchant_id text,
  qpay_invoice_code text,
  khanbank_account_number text,
  active boolean NOT NULL DEFAULT false,

  -- EWA parameters (MNT)
  ewa_limit_percent numeric NOT NULL DEFAULT 50,
  ewa_max_per_month int NOT NULL DEFAULT 3,
  ewa_max_per_day int NOT NULL DEFAULT 1,
  ewa_fee_percent numeric NOT NULL DEFAULT 1.5,
  ewa_min_amount numeric NOT NULL DEFAULT 50000,
  ewa_max_amount numeric NOT NULL DEFAULT 5000000,

  -- Compliance
  frc_license_number text,
  frc_license_expiry date,
  aml_single_threshold numeric NOT NULL DEFAULT 5000000,
  aml_daily_threshold numeric NOT NULL DEFAULT 10000000,

  -- Enabled banks
  enabled_banks text[] NOT NULL DEFAULT ARRAY['Khan Bank','Golomt Bank','TDB','XacBank','State Bank'],

  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (org_id)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.mn_payment_config TO authenticated;
GRANT ALL ON public.mn_payment_config TO service_role;
ALTER TABLE public.mn_payment_config ENABLE ROW LEVEL SECURITY;

CREATE POLICY "mn_payment_config view by org members"
  ON public.mn_payment_config FOR SELECT TO authenticated
  USING (public.is_org_member(auth.uid(), org_id));

CREATE POLICY "mn_payment_config write by managers"
  ON public.mn_payment_config FOR ALL TO authenticated
  USING (public.is_workforce_admin(auth.uid(), org_id))
  WITH CHECK (public.is_workforce_admin(auth.uid(), org_id));

CREATE TRIGGER trg_mn_payment_config_updated
  BEFORE UPDATE ON public.mn_payment_config
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


-- 2) mn_bank_accounts ------------------------------------------
CREATE TABLE public.mn_bank_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  entity_type text NOT NULL CHECK (entity_type IN ('employee','employer')),
  entity_id uuid,
  bank_name text NOT NULL CHECK (bank_name IN (
    'Khan Bank','Golomt Bank','TDB','XacBank','State Bank','Bogd Bank','MobiFinance','Other'
  )),
  bank_code text,
  account_number text NOT NULL,
  account_last4 text GENERATED ALWAYS AS (RIGHT(account_number, 4)) STORED,
  account_name text,
  qpay_id text,
  is_primary boolean NOT NULL DEFAULT true,
  verified boolean NOT NULL DEFAULT false,
  verified_at timestamptz,
  verified_name text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_mn_bank_accounts_org ON public.mn_bank_accounts(org_id);
CREATE INDEX idx_mn_bank_accounts_entity ON public.mn_bank_accounts(org_id, entity_type, entity_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.mn_bank_accounts TO authenticated;
GRANT ALL ON public.mn_bank_accounts TO service_role;
ALTER TABLE public.mn_bank_accounts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "mn_bank_accounts view by org members"
  ON public.mn_bank_accounts FOR SELECT TO authenticated
  USING (public.is_org_member(auth.uid(), org_id));

CREATE POLICY "mn_bank_accounts write by managers"
  ON public.mn_bank_accounts FOR ALL TO authenticated
  USING (public.is_workforce_admin(auth.uid(), org_id))
  WITH CHECK (public.is_workforce_admin(auth.uid(), org_id));

CREATE TRIGGER trg_mn_bank_accounts_updated
  BEFORE UPDATE ON public.mn_bank_accounts
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


-- 3) ulu_transactions ------------------------------------------
CREATE TABLE public.ulu_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  employee_id uuid REFERENCES public.employees(id) ON DELETE SET NULL,
  amount numeric NOT NULL,
  fee numeric NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'MNT',
  status text NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending','approved','flagged','completed','failed','rejected','cancelled')),
  provider text CHECK (provider IN ('qpay','khanbank','manual')),
  qpay_invoice_id text,
  qpay_qr_text text,
  payment_reference text,
  description text,
  flag_reason text,
  requested_at timestamptz NOT NULL DEFAULT now(),
  approved_at timestamptz,
  processed_at timestamptz,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_ulu_transactions_org ON public.ulu_transactions(org_id, status);
CREATE INDEX idx_ulu_transactions_employee ON public.ulu_transactions(employee_id);
CREATE INDEX idx_ulu_transactions_qpay ON public.ulu_transactions(qpay_invoice_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.ulu_transactions TO authenticated;
GRANT ALL ON public.ulu_transactions TO service_role;
ALTER TABLE public.ulu_transactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "ulu_transactions view by org members"
  ON public.ulu_transactions FOR SELECT TO authenticated
  USING (public.is_org_member(auth.uid(), org_id));

CREATE POLICY "ulu_transactions write by managers"
  ON public.ulu_transactions FOR ALL TO authenticated
  USING (public.is_workforce_admin(auth.uid(), org_id))
  WITH CHECK (public.is_workforce_admin(auth.uid(), org_id));

CREATE TRIGGER trg_ulu_transactions_updated
  BEFORE UPDATE ON public.ulu_transactions
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
