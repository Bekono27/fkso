
-- ============================================================
-- ENUMS
-- ============================================================
DO $$ BEGIN
  CREATE TYPE smm_client_status AS ENUM ('active','paused','churned','prospect');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE smm_project_status AS ENUM ('planning','active','on_hold','completed','cancelled');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE smm_post_status AS ENUM ('draft','review','approved','scheduled','published','failed');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE smm_post_platform AS ENUM ('facebook','instagram','twitter','linkedin','tiktok','youtube','telegram','threads','other');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE smm_proposal_status AS ENUM ('draft','sent','viewed','accepted','rejected','expired');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE smm_invoice_status AS ENUM ('draft','sent','viewed','partial','paid','overdue','cancelled');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- ============================================================
-- TABLES
-- ============================================================
CREATE TABLE IF NOT EXISTS public.smm_clients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  name text NOT NULL,
  company text,
  email text,
  phone text,
  website text,
  status smm_client_status NOT NULL DEFAULT 'prospect',
  monthly_retainer numeric(12,2) DEFAULT 0,
  notes text,
  tags text[] DEFAULT '{}',
  account_manager uuid REFERENCES auth.users(id),
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.smm_projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  client_id uuid REFERENCES public.smm_clients(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  status smm_project_status NOT NULL DEFAULT 'planning',
  budget numeric(12,2),
  start_date date,
  end_date date,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.smm_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  client_id uuid REFERENCES public.smm_clients(id) ON DELETE CASCADE,
  project_id uuid REFERENCES public.smm_projects(id) ON DELETE SET NULL,
  title text,
  caption text,
  platform smm_post_platform NOT NULL DEFAULT 'instagram',
  status smm_post_status NOT NULL DEFAULT 'draft',
  scheduled_at timestamptz,
  published_at timestamptz,
  media_urls text[] DEFAULT '{}',
  hashtags text[] DEFAULT '{}',
  assigned_to uuid REFERENCES auth.users(id),
  approval_required boolean DEFAULT true,
  approved_by uuid REFERENCES auth.users(id),
  approved_at timestamptz,
  external_post_id text,
  metrics jsonb DEFAULT '{}'::jsonb,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_smm_posts_org_sched ON public.smm_posts(org_id, scheduled_at);
CREATE INDEX IF NOT EXISTS idx_smm_posts_client ON public.smm_posts(client_id);
CREATE INDEX IF NOT EXISTS idx_smm_posts_status ON public.smm_posts(status);

CREATE TABLE IF NOT EXISTS public.smm_proposals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  client_id uuid REFERENCES public.smm_clients(id) ON DELETE CASCADE,
  title text NOT NULL,
  body text,
  amount numeric(12,2) DEFAULT 0,
  currency text DEFAULT 'USD',
  status smm_proposal_status NOT NULL DEFAULT 'draft',
  approval_token text UNIQUE DEFAULT replace(gen_random_uuid()::text,'-',''),
  sent_at timestamptz,
  viewed_at timestamptz,
  responded_at timestamptz,
  expires_at timestamptz,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_smm_proposals_token ON public.smm_proposals(approval_token);

CREATE TABLE IF NOT EXISTS public.smm_invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  client_id uuid REFERENCES public.smm_clients(id) ON DELETE CASCADE,
  project_id uuid REFERENCES public.smm_projects(id) ON DELETE SET NULL,
  number text NOT NULL,
  status smm_invoice_status NOT NULL DEFAULT 'draft',
  amount numeric(12,2) NOT NULL DEFAULT 0,
  amount_paid numeric(12,2) NOT NULL DEFAULT 0,
  currency text DEFAULT 'USD',
  issue_date date DEFAULT CURRENT_DATE,
  due_date date,
  paid_at timestamptz,
  line_items jsonb DEFAULT '[]'::jsonb,
  notes text,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (org_id, number)
);
CREATE INDEX IF NOT EXISTS idx_smm_invoices_org_status ON public.smm_invoices(org_id, status);

CREATE TABLE IF NOT EXISTS public.smm_payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  invoice_id uuid NOT NULL REFERENCES public.smm_invoices(id) ON DELETE CASCADE,
  amount numeric(12,2) NOT NULL,
  paid_at timestamptz NOT NULL DEFAULT now(),
  method text,
  reference text,
  notes text,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_smm_payments_inv ON public.smm_payments(invoice_id);

-- ============================================================
-- updated_at touchers
-- ============================================================
DO $$ DECLARE t text; BEGIN
  FOR t IN SELECT unnest(ARRAY['smm_clients','smm_projects','smm_posts','smm_proposals','smm_invoices']) LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS tr_touch_%I ON public.%I;', t, t);
    EXECUTE format('CREATE TRIGGER tr_touch_%I BEFORE UPDATE ON public.%I FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();', t, t);
  END LOOP;
END $$;

-- ============================================================
-- RLS
-- ============================================================
ALTER TABLE public.smm_clients   ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.smm_projects  ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.smm_posts     ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.smm_proposals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.smm_invoices  ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.smm_payments  ENABLE ROW LEVEL SECURITY;

DO $$ DECLARE t text; BEGIN
  FOR t IN SELECT unnest(ARRAY['smm_clients','smm_projects','smm_posts','smm_proposals','smm_invoices','smm_payments']) LOOP
    EXECUTE format('DROP POLICY IF EXISTS "%s members read" ON public.%I;', t, t);
    EXECUTE format('CREATE POLICY "%s members read" ON public.%I FOR SELECT TO authenticated USING (public.is_org_member(auth.uid(), org_id));', t, t);

    EXECUTE format('DROP POLICY IF EXISTS "%s admins manage" ON public.%I;', t, t);
    EXECUTE format('CREATE POLICY "%s admins manage" ON public.%I TO authenticated USING (public.is_workforce_admin(auth.uid(), org_id)) WITH CHECK (public.is_workforce_admin(auth.uid(), org_id));', t, t);
  END LOOP;
END $$;

-- Public approval flow: allow anon SELECT/UPDATE on a proposal via approval_token
DROP POLICY IF EXISTS "public read by token" ON public.smm_proposals;
CREATE POLICY "public read by token" ON public.smm_proposals
FOR SELECT TO anon USING (approval_token IS NOT NULL);

DROP POLICY IF EXISTS "public respond by token" ON public.smm_proposals;
CREATE POLICY "public respond by token" ON public.smm_proposals
FOR UPDATE TO anon USING (approval_token IS NOT NULL) WITH CHECK (approval_token IS NOT NULL);

-- ============================================================
-- AUTO-SEED for new organizations
-- ============================================================
CREATE OR REPLACE FUNCTION public.seed_smm_defaults()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE demo_client uuid;
BEGIN
  INSERT INTO public.smm_clients (org_id, name, company, status, monthly_retainer)
  VALUES (NEW.id, 'Sample Client', 'Acme Co.', 'prospect', 0)
  RETURNING id INTO demo_client;

  INSERT INTO public.smm_posts (org_id, client_id, title, caption, platform, status, scheduled_at)
  VALUES (NEW.id, demo_client, 'Welcome post',
          '👋 Hello world — your first scheduled post.',
          'instagram', 'draft', now() + interval '1 day');
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS tr_seed_smm_defaults ON public.organizations;
CREATE TRIGGER tr_seed_smm_defaults
AFTER INSERT ON public.organizations
FOR EACH ROW EXECUTE FUNCTION public.seed_smm_defaults();

-- ============================================================
-- platform_events: client_created, post_published, proposal_sent, invoice_paid
-- ============================================================
CREATE OR REPLACE FUNCTION public.tg_smm_client_event()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO platform_events(org_id, source_module, event_type, payload, triggered_by)
  VALUES (NEW.org_id, 'content'::module_source, 'client_created',
          jsonb_build_object('client_id', NEW.id, 'name', NEW.name, 'status', NEW.status),
          NEW.created_by);
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS tr_smm_client_event ON public.smm_clients;
CREATE TRIGGER tr_smm_client_event AFTER INSERT ON public.smm_clients
FOR EACH ROW EXECUTE FUNCTION public.tg_smm_client_event();

CREATE OR REPLACE FUNCTION public.tg_smm_post_event()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF TG_OP = 'UPDATE' AND OLD.status IS DISTINCT FROM NEW.status AND NEW.status = 'published' THEN
    INSERT INTO platform_events(org_id, source_module, event_type, payload)
    VALUES (NEW.org_id, 'content'::module_source, 'post_published',
            jsonb_build_object('post_id', NEW.id, 'platform', NEW.platform, 'client_id', NEW.client_id));
  END IF;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS tr_smm_post_event ON public.smm_posts;
CREATE TRIGGER tr_smm_post_event AFTER UPDATE ON public.smm_posts
FOR EACH ROW EXECUTE FUNCTION public.tg_smm_post_event();

CREATE OR REPLACE FUNCTION public.tg_smm_proposal_event()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF TG_OP = 'UPDATE' AND OLD.status IS DISTINCT FROM NEW.status THEN
    IF NEW.status = 'sent' THEN
      INSERT INTO platform_events(org_id, source_module, event_type, payload)
      VALUES (NEW.org_id, 'content'::module_source, 'proposal_sent',
              jsonb_build_object('proposal_id', NEW.id, 'client_id', NEW.client_id, 'amount', NEW.amount));
    ELSIF NEW.status = 'accepted' THEN
      INSERT INTO platform_events(org_id, source_module, event_type, payload)
      VALUES (NEW.org_id, 'content'::module_source, 'proposal_accepted',
              jsonb_build_object('proposal_id', NEW.id, 'client_id', NEW.client_id, 'amount', NEW.amount));
    END IF;
  END IF;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS tr_smm_proposal_event ON public.smm_proposals;
CREATE TRIGGER tr_smm_proposal_event AFTER UPDATE ON public.smm_proposals
FOR EACH ROW EXECUTE FUNCTION public.tg_smm_proposal_event();

CREATE OR REPLACE FUNCTION public.tg_smm_invoice_event()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF TG_OP = 'UPDATE' AND OLD.status IS DISTINCT FROM NEW.status AND NEW.status = 'paid' THEN
    INSERT INTO platform_events(org_id, source_module, event_type, payload)
    VALUES (NEW.org_id, 'content'::module_source, 'invoice_paid',
            jsonb_build_object('invoice_id', NEW.id, 'client_id', NEW.client_id,
                               'amount', NEW.amount, 'number', NEW.number));
  END IF;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS tr_smm_invoice_event ON public.smm_invoices;
CREATE TRIGGER tr_smm_invoice_event AFTER UPDATE ON public.smm_invoices
FOR EACH ROW EXECUTE FUNCTION public.tg_smm_invoice_event();

-- ============================================================
-- search_index upserts
-- ============================================================
CREATE OR REPLACE FUNCTION public.tg_index_smm_client()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO search_index(org_id, module, entity_type, entity_id, title, subtitle, keywords, url, updated_at)
  VALUES (NEW.org_id, 'content'::module_source, 'client', NEW.id,
          NEW.name, COALESCE(NEW.company, NEW.email),
          COALESCE(NEW.status::text,'') || ' ' || COALESCE(NEW.email,'') || ' ' || COALESCE(NEW.company,''),
          '/content/clients', now())
  ON CONFLICT (org_id, entity_id) DO UPDATE SET
    title=EXCLUDED.title, subtitle=EXCLUDED.subtitle, keywords=EXCLUDED.keywords, updated_at=now();
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS tr_index_smm_client ON public.smm_clients;
CREATE TRIGGER tr_index_smm_client AFTER INSERT OR UPDATE ON public.smm_clients
FOR EACH ROW EXECUTE FUNCTION public.tg_index_smm_client();

CREATE OR REPLACE FUNCTION public.tg_index_smm_project()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO search_index(org_id, module, entity_type, entity_id, title, subtitle, keywords, url, updated_at)
  VALUES (NEW.org_id, 'content'::module_source, 'project', NEW.id,
          NEW.name, NEW.description,
          COALESCE(NEW.status::text,'') || ' project',
          '/content', now())
  ON CONFLICT (org_id, entity_id) DO UPDATE SET
    title=EXCLUDED.title, subtitle=EXCLUDED.subtitle, keywords=EXCLUDED.keywords, updated_at=now();
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS tr_index_smm_project ON public.smm_projects;
CREATE TRIGGER tr_index_smm_project AFTER INSERT OR UPDATE ON public.smm_projects
FOR EACH ROW EXECUTE FUNCTION public.tg_index_smm_project();

CREATE OR REPLACE FUNCTION public.tg_index_smm_post()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO search_index(org_id, module, entity_type, entity_id, title, subtitle, keywords, url, updated_at)
  VALUES (NEW.org_id, 'content'::module_source, 'post', NEW.id,
          COALESCE(NEW.title, LEFT(COALESCE(NEW.caption,'Untitled post'), 60)),
          COALESCE(NEW.platform::text,'') || ' • ' || COALESCE(NEW.status::text,''),
          COALESCE(NEW.platform::text,'') || ' ' || COALESCE(NEW.status::text,'') || ' ' || COALESCE(array_to_string(NEW.hashtags,' '),''),
          '/content/calendar', now())
  ON CONFLICT (org_id, entity_id) DO UPDATE SET
    title=EXCLUDED.title, subtitle=EXCLUDED.subtitle, keywords=EXCLUDED.keywords, updated_at=now();
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS tr_index_smm_post ON public.smm_posts;
CREATE TRIGGER tr_index_smm_post AFTER INSERT OR UPDATE ON public.smm_posts
FOR EACH ROW EXECUTE FUNCTION public.tg_index_smm_post();

CREATE OR REPLACE FUNCTION public.tg_index_smm_proposal()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO search_index(org_id, module, entity_type, entity_id, title, subtitle, keywords, url, updated_at)
  VALUES (NEW.org_id, 'content'::module_source, 'proposal', NEW.id,
          NEW.title, COALESCE(NEW.status::text,'') || ' • ' || COALESCE(NEW.amount,0)::text || ' ' || COALESCE(NEW.currency,''),
          COALESCE(NEW.status::text,'') || ' proposal ' || COALESCE(NEW.currency,''),
          '/content/proposals', now())
  ON CONFLICT (org_id, entity_id) DO UPDATE SET
    title=EXCLUDED.title, subtitle=EXCLUDED.subtitle, keywords=EXCLUDED.keywords, updated_at=now();
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS tr_index_smm_proposal ON public.smm_proposals;
CREATE TRIGGER tr_index_smm_proposal AFTER INSERT OR UPDATE ON public.smm_proposals
FOR EACH ROW EXECUTE FUNCTION public.tg_index_smm_proposal();

CREATE OR REPLACE FUNCTION public.tg_index_smm_invoice()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO search_index(org_id, module, entity_type, entity_id, title, subtitle, keywords, url, updated_at)
  VALUES (NEW.org_id, 'content'::module_source, 'invoice', NEW.id,
          'Invoice ' || NEW.number,
          COALESCE(NEW.status::text,'') || ' • ' || NEW.amount::text || ' ' || COALESCE(NEW.currency,''),
          COALESCE(NEW.status::text,'') || ' invoice ' || NEW.number,
          '/content/invoices', now())
  ON CONFLICT (org_id, entity_id) DO UPDATE SET
    title=EXCLUDED.title, subtitle=EXCLUDED.subtitle, keywords=EXCLUDED.keywords, updated_at=now();
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS tr_index_smm_invoice ON public.smm_invoices;
CREATE TRIGGER tr_index_smm_invoice AFTER INSERT OR UPDATE ON public.smm_invoices
FOR EACH ROW EXECUTE FUNCTION public.tg_index_smm_invoice();

-- Auto-update invoice status from payments
CREATE OR REPLACE FUNCTION public.tg_apply_smm_payment()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_total numeric; v_amount numeric;
BEGIN
  SELECT COALESCE(SUM(amount),0) INTO v_total FROM public.smm_payments WHERE invoice_id = NEW.invoice_id;
  SELECT amount INTO v_amount FROM public.smm_invoices WHERE id = NEW.invoice_id;
  UPDATE public.smm_invoices
    SET amount_paid = v_total,
        status = CASE
          WHEN v_total >= COALESCE(v_amount,0) THEN 'paid'::smm_invoice_status
          WHEN v_total > 0 THEN 'partial'::smm_invoice_status
          ELSE status
        END,
        paid_at = CASE WHEN v_total >= COALESCE(v_amount,0) THEN now() ELSE paid_at END
  WHERE id = NEW.invoice_id;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS tr_apply_smm_payment ON public.smm_payments;
CREATE TRIGGER tr_apply_smm_payment AFTER INSERT ON public.smm_payments
FOR EACH ROW EXECUTE FUNCTION public.tg_apply_smm_payment();

-- Backfill seed data for any pre-existing organizations
INSERT INTO public.smm_clients (org_id, name, company, status, monthly_retainer)
SELECT o.id, 'Sample Client', 'Acme Co.', 'prospect', 0
FROM public.organizations o
LEFT JOIN public.smm_clients c ON c.org_id = o.id
WHERE c.id IS NULL;
