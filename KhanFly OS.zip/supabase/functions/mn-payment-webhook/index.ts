// QPay webhook receiver — marks ulu_transactions as completed.
// External callback (QPay calls this URL). No app auth.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "*",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
};

const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...CORS, "content-type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });

  const url = new URL(req.url);
  const txnId = url.searchParams.get("txn");
  let payload: Record<string, unknown> = {};
  try {
    if (req.method === "POST") payload = await req.json();
  } catch { /* QPay sometimes pings GET */ }

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  const invoiceId = (payload.invoice_id as string) ?? null;
  const paymentStatus = (payload.payment_status as string) ?? "PAID";
  const paymentId = (payload.payment_id as string) ?? null;
  const paidAmount = (payload.paid_amount as number) ?? null;
  const paidDate = (payload.paid_date as string) ?? new Date().toISOString();
  const wallet = (payload.payment_wallet as string) ?? "QPay";

  // Match by qpay_invoice_id, fall back to ?txn=
  let query = supabase.from("ulu_transactions").select("id, org_id, amount, status");
  if (invoiceId) query = query.eq("qpay_invoice_id", invoiceId);
  else if (txnId) query = query.eq("id", txnId);
  else return json({ error: "no invoice_id or txn" }, 400);

  const { data: txn, error } = await query.maybeSingle();
  if (error || !txn) return json({ error: "transaction not found" }, 404);

  const isPaid = paymentStatus === "PAID";
  await supabase
    .from("ulu_transactions")
    .update({
      status: isPaid ? "completed" : "failed",
      payment_reference: paymentId,
      processed_at: paidDate,
    })
    .eq("id", txn.id);

  await supabase.from("platform_events").insert({
    org_id: txn.org_id,
    source_module: "workforce",
    event_type: isPaid ? "ulu_payment_completed" : "ulu_payment_failed",
    payload: { transaction_id: txn.id, invoice_id: invoiceId, wallet, amount: paidAmount },
  });

  return json({ ok: true });
});
