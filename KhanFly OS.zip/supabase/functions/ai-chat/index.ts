// Lovable AI Gateway proxy for the in-app assistant.
// Streams Server-Sent Events back to the client (OpenAI-compatible SSE).
// Accepts: { messages, system?, model?, stream? = true }

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "method not allowed" }), {
      status: 405, headers: { ...CORS, "content-type": "application/json" },
    });
  }

  try {
    const apiKey = Deno.env.get("LOVABLE_API_KEY");
    if (!apiKey) {
      return new Response(JSON.stringify({ error: "LOVABLE_API_KEY not configured" }), {
        status: 500, headers: { ...CORS, "content-type": "application/json" },
      });
    }

    const { messages = [], system, model = "google/gemini-2.5-flash", stream = true } =
      await req.json();
    const fullMessages = system ? [{ role: "system", content: system }, ...messages] : messages;

    const upstream = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "content-type": "application/json" },
      body: JSON.stringify({ model, messages: fullMessages, stream }),
    });

    if (!upstream.ok) {
      const errText = await upstream.text();
      console.error("AI gateway error", upstream.status, errText);
      const status = upstream.status;
      const msg = status === 429 ? "Rate limited. Try again shortly."
        : status === 402 ? "AI credits exhausted. Add funds in Settings → Workspace → Usage."
        : "AI gateway error";
      return new Response(JSON.stringify({ error: msg, detail: errText }), {
        status, headers: { ...CORS, "content-type": "application/json" },
      });
    }

    if (!stream) {
      const data = await upstream.json();
      const reply = data?.choices?.[0]?.message?.content ?? "(no response)";
      return new Response(JSON.stringify({ reply }), {
        headers: { ...CORS, "content-type": "application/json" },
      });
    }

    // Pass through SSE stream untouched.
    return new Response(upstream.body, {
      headers: {
        ...CORS,
        "content-type": "text/event-stream",
        "cache-control": "no-cache",
        "connection": "keep-alive",
      },
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("ai-chat exception", msg);
    return new Response(JSON.stringify({ error: msg }), {
      status: 500, headers: { ...CORS, "content-type": "application/json" },
    });
  }
});
