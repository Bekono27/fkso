// Generates research sections for a project using Lovable AI Gateway.
// POST modes:
//   { project_id, prompt, context?, source_ids?: string[] } -> generate full report
//   { project_id, regenerate_section_id, prompt? }          -> regenerate one section
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SYSTEM = `You are a senior research analyst. Produce a structured research report as JSON.
Respond by calling the "emit_report" tool with an array of 4-8 sections.
Each section has:
- title (concise)
- content (markdown, 2-5 paragraphs, with bullet lists where useful, factual and specific)
- citations (array of source numbers — 1-based indices into the provided sources list — that informed this section; empty if none)
Cover: executive summary, market overview, key trends, competitive landscape, opportunities, risks, recommendations.`;

const REGEN_SYSTEM = `You are a senior research analyst. Rewrite the given research section to be sharper, more specific, and better organized.
Respond by calling "emit_section" with { title, content, citations }. Keep the same topic.`;

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...CORS, "content-type": "application/json" } });

async function callGateway(apiKey: string, body: unknown) {
  const upstream = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!upstream.ok) {
    const t = await upstream.text();
    const status = upstream.status;
    const msg = status === 429 ? "Rate limited. Try again shortly."
      : status === 402 ? "AI credits exhausted. Add funds in Settings → Workspace → Usage."
      : "AI gateway error";
    throw new Response(JSON.stringify({ error: msg, detail: t }), {
      status, headers: { ...CORS, "content-type": "application/json" },
    });
  }
  return upstream.json();
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
  if (req.method !== "POST") return json({ error: "method not allowed" }, 405);

  try {
    const apiKey = Deno.env.get("LOVABLE_API_KEY");
    if (!apiKey) throw new Error("LOVABLE_API_KEY not configured");
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const authHeader = req.headers.get("Authorization") ?? "";
    const userClient = createClient(SUPABASE_URL, Deno.env.get("SUPABASE_ANON_KEY") ?? Deno.env.get("SUPABASE_PUBLISHABLE_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: userData } = await userClient.auth.getUser();
    if (!userData?.user) return json({ error: "unauthorized" }, 401);
    const admin = createClient(SUPABASE_URL, SERVICE_KEY);

    const payload = await req.json();
    const { project_id, prompt, context, source_ids, regenerate_section_id } = payload ?? {};
    if (!project_id) throw new Error("project_id required");

    const { data: project, error: pErr } = await admin
      .from("research_projects")
      .select("id, org_id, title, type")
      .eq("id", project_id)
      .single();
    if (pErr || !project) throw new Error("project not found");

    const { data: member } = await admin
      .from("user_roles")
      .select("user_id")
      .eq("org_id", project.org_id)
      .eq("user_id", userData.user.id)
      .limit(1)
      .maybeSingle();
    if (!member) return json({ error: "forbidden" }, 403);

    // Load referenced sources (numbered for citation index)
    let sourcesArr: Array<{ id: string; type: string; url: string | null; content_summary: string | null }> = [];
    if (Array.isArray(source_ids) && source_ids.length) {
      const { data: srcs } = await admin
        .from("research_sources")
        .select("id, type, url, content_summary")
        .eq("project_id", project_id)
        .in("id", source_ids);
      sourcesArr = srcs ?? [];
    } else {
      const { data: srcs } = await admin
        .from("research_sources")
        .select("id, type, url, content_summary")
        .eq("project_id", project_id)
        .limit(20);
      sourcesArr = srcs ?? [];
    }
    const sourcesBlock = sourcesArr.length
      ? sourcesArr.map((s, i) => `[${i + 1}] (${s.type}) ${s.url ?? ""} — ${s.content_summary ?? ""}`).join("\n")
      : "(no sources provided)";

    // --- Regenerate single section ---
    if (regenerate_section_id) {
      const { data: sec, error: sErr } = await admin
        .from("research_sections")
        .select("id, title, content, order_index")
        .eq("id", regenerate_section_id)
        .eq("project_id", project_id)
        .single();
      if (sErr || !sec) throw new Error("section not found");

      const userMsg = `Project: ${project.title}\nType: ${project.type}\nSection title: ${sec.title}\n` +
        `Current content:\n${sec.content}\n\n` +
        (prompt ? `Rewrite focus: ${prompt}\n\n` : "") +
        `Available sources:\n${sourcesBlock}`;

      const data = await callGateway(apiKey, {
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: REGEN_SYSTEM },
          { role: "user", content: userMsg },
        ],
        tools: [{
          type: "function",
          function: {
            name: "emit_section",
            description: "Emit the rewritten section.",
            parameters: {
              type: "object",
              properties: {
                title: { type: "string" },
                content: { type: "string" },
                citations: { type: "array", items: { type: "integer" } },
              },
              required: ["title", "content", "citations"],
              additionalProperties: false,
            },
          },
        }],
        tool_choice: { type: "function", function: { name: "emit_section" } },
      });
      const args = JSON.parse(data?.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments ?? "{}");
      const citedIds = (args.citations ?? [])
        .map((n: number) => sourcesArr[n - 1]?.id)
        .filter(Boolean);
      const { data: updated, error: uErr } = await admin
        .from("research_sections")
        .update({
          title: (args.title ?? sec.title).slice(0, 280),
          content: args.content ?? sec.content,
          metadata: { citations: citedIds },
        } as any)
        .eq("id", sec.id)
        .select("*")
        .single();
      if (uErr) throw uErr;
      return json({ section: updated });
    }

    // --- Full report generation ---
    if (!prompt) throw new Error("prompt required");
    const userMsg = `Project: ${project.title}\nType: ${project.type}\nResearch focus: ${prompt}\n\n` +
      `Numbered sources (cite by number):\n${sourcesBlock}` +
      (context ? `\n\nExtra context:\n${context}` : "");

    const data = await callGateway(apiKey, {
      model: "google/gemini-2.5-flash",
      messages: [
        { role: "system", content: SYSTEM },
        { role: "user", content: userMsg },
      ],
      tools: [{
        type: "function",
        function: {
          name: "emit_report",
          description: "Emit the research report sections.",
          parameters: {
            type: "object",
            properties: {
              sections: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    title: { type: "string" },
                    content: { type: "string" },
                    citations: { type: "array", items: { type: "integer" } },
                  },
                  required: ["title", "content", "citations"],
                  additionalProperties: false,
                },
              },
            },
            required: ["sections"],
            additionalProperties: false,
          },
        },
      }],
      tool_choice: { type: "function", function: { name: "emit_report" } },
    });

    const args = JSON.parse(data?.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments ?? "{}");
    const sections: Array<{ title: string; content: string; citations?: number[] }> = args?.sections ?? [];
    if (!sections.length) throw new Error("AI returned no sections");

    const { data: existing } = await admin
      .from("research_sections")
      .select("order_index")
      .eq("project_id", project_id)
      .order("order_index", { ascending: false })
      .limit(1);
    let nextOrder = (existing?.[0]?.order_index ?? -1) + 1;

    const rows = sections.map((s) => ({
      project_id,
      org_id: project.org_id,
      title: s.title.slice(0, 280),
      content: s.content,
      order_index: nextOrder++,
      metadata: {
        citations: (s.citations ?? [])
          .map((n) => sourcesArr[n - 1]?.id)
          .filter(Boolean),
      },
    }));
    const { data: inserted, error: iErr } = await admin
      .from("research_sections")
      .insert(rows as any)
      .select("*");
    if (iErr) throw iErr;

    await admin.from("research_projects")
      .update({ status: "in_progress", updated_at: new Date().toISOString() })
      .eq("id", project_id);

    return json({ sections: inserted });
  } catch (e) {
    if (e instanceof Response) return e;
    const msg = e instanceof Error ? e.message : String(e);
    console.error("research-generate error", msg);
    return json({ error: msg }, 500);
  }
});
