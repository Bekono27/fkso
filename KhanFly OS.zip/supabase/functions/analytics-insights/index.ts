// Generates cross-module AI insights from recent snapshots + platform events.
// POST { } -> writes 3-6 insight rows into analytics_insights for the user's org.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...CORS, "content-type": "application/json" } });

const SYSTEM = `You are a senior business analyst. Given recent multi-module KPI snapshots and platform events, surface 3-6 concrete insights.
Each insight should be specific, actionable, and explain the cross-module correlation (e.g. "Monitor alerts spiked 60% after content_post_published — investigate negative sentiment").
Call "emit_insights" with the list.`;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
  if (req.method !== "POST") return json({ error: "method not allowed" }, 405);
  try {
    const apiKey = Deno.env.get("LOVABLE_API_KEY");
    if (!apiKey) throw new Error("LOVABLE_API_KEY not configured");
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const userClient = createClient(
      SUPABASE_URL,
      Deno.env.get("SUPABASE_ANON_KEY") ?? Deno.env.get("SUPABASE_PUBLISHABLE_KEY")!,
      { global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } } },
    );
    const { data: userData } = await userClient.auth.getUser();
    if (!userData?.user) return json({ error: "unauthorized" }, 401);

    const admin = createClient(SUPABASE_URL, SERVICE_KEY);
    const { data: roles } = await admin.from("user_roles").select("org_id").eq("user_id", userData.user.id).limit(1);
    const org_id = roles?.[0]?.org_id;
    if (!org_id) return json({ error: "no org" }, 400);

    const since = new Date(Date.now() - 14 * 86400000).toISOString();
    const [snaps, events] = await Promise.all([
      admin.from("analytics_snapshots").select("module, snapshot_date, metrics").eq("org_id", org_id).gte("snapshot_date", since.slice(0, 10)),
      admin.from("platform_events").select("source_module, event_type, created_at").eq("org_id", org_id).gte("created_at", since).limit(500),
    ]);
    const ctx = {
      snapshots: snaps.data ?? [],
      events: (events.data ?? []).slice(0, 200),
    };

    const upstream = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "content-type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: SYSTEM },
          { role: "user", content: `Org data (last 14d):\n${JSON.stringify(ctx)}` },
        ],
        tools: [{
          type: "function",
          function: {
            name: "emit_insights",
            parameters: {
              type: "object",
              properties: {
                insights: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      title: { type: "string" },
                      description: { type: "string" },
                      type: { type: "string", enum: ["correlation", "trend", "anomaly", "recommendation"] },
                      severity: { type: "string", enum: ["info", "warning", "critical"] },
                      modules_involved: { type: "array", items: { type: "string" } },
                    },
                    required: ["title", "description", "type", "severity", "modules_involved"],
                    additionalProperties: false,
                  },
                },
              },
              required: ["insights"],
              additionalProperties: false,
            },
          },
        }],
        tool_choice: { type: "function", function: { name: "emit_insights" } },
      }),
    });
    if (!upstream.ok) {
      const t = await upstream.text();
      return json({ error: "AI gateway error", detail: t }, upstream.status);
    }
    const data = await upstream.json();
    const args = JSON.parse(data?.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments ?? "{}");
    const insights = (args.insights ?? []) as any[];
    if (!insights.length) return json({ inserted: 0 });

    const rows = insights.map((i) => ({
      org_id,
      title: i.title,
      description: i.description,
      type: i.type,
      severity: i.severity,
      modules_involved: i.modules_involved ?? [],
      dismissed: false,
    }));
    const { error } = await admin.from("analytics_insights").insert(rows);
    if (error) throw error;
    return json({ inserted: rows.length });
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("analytics-insights error", msg);
    return json({ error: msg }, 500);
  }
});
