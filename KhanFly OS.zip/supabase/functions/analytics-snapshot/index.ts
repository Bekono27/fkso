// Daily snapshot writer. Called by pg_cron at /api/public/cron/analytics-snapshot
// Aggregates KPIs per org into analytics_snapshots(date, module, metrics).
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const admin = createClient(SUPABASE_URL, SERVICE_KEY);

    const today = new Date().toISOString().slice(0, 10);
    const since = new Date(Date.now() - 86400000).toISOString();

    const { data: orgs } = await admin.from("organizations").select("id");
    let total = 0;
    for (const o of orgs ?? []) {
      const orgId = (o as any).id;
      const [emp, mon, post, conv, alert, lead] = await Promise.all([
        admin.from("employees").select("id", { count: "exact", head: true }).eq("org_id", orgId).eq("is_active", true),
        admin.from("monitoring_posts").select("id", { count: "exact", head: true }).eq("org_id", orgId).gte("created_at", since),
        admin.from("smm_posts").select("id", { count: "exact", head: true }).eq("org_id", orgId).gte("created_at", since),
        admin.from("bot_conversations").select("id", { count: "exact", head: true }).eq("org_id", orgId).gte("created_at", since),
        admin.from("monitoring_alerts").select("id", { count: "exact", head: true }).eq("org_id", orgId).gte("created_at", since),
        admin.from("bot_contacts").select("id", { count: "exact", head: true }).eq("org_id", orgId).eq("lead_captured", true).gte("created_at", since),
      ]);
      const rows = [
        { org_id: orgId, snapshot_date: today, module: "workforce", metrics: { active_employees: emp.count ?? 0 } },
        { org_id: orgId, snapshot_date: today, module: "monitor", metrics: { mentions_24h: mon.count ?? 0, alerts_24h: alert.count ?? 0 } },
        { org_id: orgId, snapshot_date: today, module: "content", metrics: { posts_24h: post.count ?? 0 } },
        { org_id: orgId, snapshot_date: today, module: "bots", metrics: { conversations_24h: conv.count ?? 0, leads_24h: lead.count ?? 0 } },
      ];
      const { error } = await admin.from("analytics_snapshots").upsert(rows, { onConflict: "org_id,snapshot_date,module" });
      if (error) console.error("snapshot upsert error", orgId, error.message);
      else total += rows.length;
    }
    return new Response(JSON.stringify({ ok: true, snapshots: total }), {
      headers: { ...CORS, "content-type": "application/json" },
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("analytics-snapshot error", msg);
    return new Response(JSON.stringify({ error: msg }), { status: 500, headers: { ...CORS, "content-type": "application/json" } });
  }
});
