// Shared AI helper for module add-ons. POST { task, payload } -> { ...result }
// Auth: requires logged-in user.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...CORS, "content-type": "application/json" } });

type Task =
  | "competitor_swot"
  | "improve_caption"
  | "generate_hashtags"
  | "triage_alert"
  | "summarize_reviews"
  | "draft_proposal";

const TASK_PROMPTS: Record<Task, { system: string; tool: any }> = {
  competitor_swot: {
    system: "You are a senior strategy analyst. Generate a concise, specific SWOT for the competitor described. Use 3-5 bullet items per quadrant. Be specific to their domain, not generic.",
    tool: {
      name: "emit_swot",
      parameters: {
        type: "object",
        properties: {
          strengths: { type: "array", items: { type: "string" } },
          weaknesses: { type: "array", items: { type: "string" } },
          opportunities: { type: "array", items: { type: "string" } },
          threats: { type: "array", items: { type: "string" } },
        },
        required: ["strengths", "weaknesses", "opportunities", "threats"],
        additionalProperties: false,
      },
    },
  },
  improve_caption: {
    system: "You are a senior social media copywriter. Rewrite the caption to be more engaging, on-brand, and platform-appropriate. Keep it concise.",
    tool: {
      name: "emit_caption",
      parameters: {
        type: "object",
        properties: { caption: { type: "string" } },
        required: ["caption"],
        additionalProperties: false,
      },
    },
  },
  generate_hashtags: {
    system: "Generate 8-12 relevant, mixed-popularity hashtags for the post. No '#' prefix in the strings — just the tag.",
    tool: {
      name: "emit_hashtags",
      parameters: {
        type: "object",
        properties: { hashtags: { type: "array", items: { type: "string" } } },
        required: ["hashtags"],
        additionalProperties: false,
      },
    },
  },
  triage_alert: {
    system: "You are a brand crisis analyst. Assess the alert's severity (low|medium|high|critical), summarize the situation in one sentence, and suggest 2-4 immediate actions.",
    tool: {
      name: "emit_triage",
      parameters: {
        type: "object",
        properties: {
          severity: { type: "string", enum: ["low", "medium", "high", "critical"] },
          summary: { type: "string" },
          actions: { type: "array", items: { type: "string" } },
        },
        required: ["severity", "summary", "actions"],
        additionalProperties: false,
      },
    },
  },
  summarize_reviews: {
    system: "You are an HR coach. Summarize the performance reviews into strengths, areas to improve, and 3 coaching suggestions.",
    tool: {
      name: "emit_summary",
      parameters: {
        type: "object",
        properties: {
          strengths: { type: "array", items: { type: "string" } },
          improvements: { type: "array", items: { type: "string" } },
          coaching: { type: "array", items: { type: "string" } },
        },
        required: ["strengths", "improvements", "coaching"],
        additionalProperties: false,
      },
    },
  },
  draft_proposal: {
    system: "You are a senior proposal writer. Draft a structured proposal (markdown) with: Overview, Scope, Deliverables, Timeline, Pricing, Next Steps.",
    tool: {
      name: "emit_proposal",
      parameters: {
        type: "object",
        properties: { content: { type: "string" }, title: { type: "string" } },
        required: ["content", "title"],
        additionalProperties: false,
      },
    },
  },
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
  if (req.method !== "POST") return json({ error: "method not allowed" }, 405);

  try {
    const apiKey = Deno.env.get("LOVABLE_API_KEY");
    if (!apiKey) throw new Error("LOVABLE_API_KEY not configured");
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const userClient = createClient(
      SUPABASE_URL,
      Deno.env.get("SUPABASE_ANON_KEY") ?? Deno.env.get("SUPABASE_PUBLISHABLE_KEY")!,
      { global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } } },
    );
    const { data: userData } = await userClient.auth.getUser();
    if (!userData?.user) return json({ error: "unauthorized" }, 401);

    const { task, payload } = await req.json();
    const def = TASK_PROMPTS[task as Task];
    if (!def) return json({ error: `unknown task: ${task}` }, 400);

    const userMsg = `Input:\n${JSON.stringify(payload ?? {}, null, 2)}`;

    const upstream = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "content-type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: def.system },
          { role: "user", content: userMsg },
        ],
        tools: [{ type: "function", function: { ...def.tool, description: def.tool.name } }],
        tool_choice: { type: "function", function: { name: def.tool.name } },
      }),
    });
    if (!upstream.ok) {
      const t = await upstream.text();
      const status = upstream.status;
      const msg = status === 429 ? "Rate limited. Try again shortly."
        : status === 402 ? "AI credits exhausted."
        : "AI gateway error";
      return json({ error: msg, detail: t }, status);
    }
    const data = await upstream.json();
    const argStr = data?.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments;
    const args = argStr ? JSON.parse(argStr) : {};

    // Normalize response shape per task
    if (task === "competitor_swot") return json({ swot: args });
    return json(args);
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("ai-assist error", msg);
    return json({ error: msg }, 500);
  }
});
