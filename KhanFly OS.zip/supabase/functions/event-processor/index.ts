// Event processor: claims a batch of unprocessed platform_events,
// fans them out to (a) analytics_events rollup and (b) outgoing webhook
// subscriptions with HMAC-signed POSTs, then marks processed=true.
// Failures retry with exponential backoff.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const MAX_ATTEMPTS = 5;
const BATCH_SIZE = 25;
const WEBHOOK_TIMEOUT_MS = 8000;

type EventRow = {
  id: string;
  org_id: string;
  source_module: string;
  event_type: string;
  payload: Record<string, unknown>;
  attempts: number;
  triggered_at?: string;
};

type WebhookEndpoint = {
  id: string;
  url: string;
  secret: string;
  event_types: string[];
};

async function hmacSha256Hex(secret: string, body: string): Promise<string> {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    "raw", enc.encode(secret),
    { name: "HMAC", hash: "SHA-256" }, false, ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, enc.encode(body));
  return Array.from(new Uint8Array(sig)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function deliverWebhook(ep: WebhookEndpoint, ev: EventRow, client: ReturnType<typeof createClient>) {
  const body = JSON.stringify({
    id: ev.id,
    type: ev.event_type,
    module: ev.source_module,
    org_id: ev.org_id,
    payload: ev.payload,
    occurred_at: ev.triggered_at ?? new Date().toISOString(),
  });
  const signature = await hmacSha256Hex(ep.secret, body);
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), WEBHOOK_TIMEOUT_MS);
  let status = 0;
  let errMsg: string | null = null;
  try {
    const r = await fetch(ep.url, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-khanfly-event": ev.event_type,
        "x-khanfly-signature": `sha256=${signature}`,
      },
      body, signal: ctrl.signal,
    });
    status = r.status;
    if (!r.ok) errMsg = `HTTP ${r.status}`;
  } catch (e) {
    errMsg = e instanceof Error ? e.message : String(e);
  } finally {
    clearTimeout(t);
  }
  await client.from("webhook_endpoints").update({
    last_delivery_at: new Date().toISOString(),
    last_status: status || null,
    last_error: errMsg,
  }).eq("id", ep.id);
  if (errMsg) throw new Error(`webhook ${ep.url} → ${errMsg}`);
}

async function handleEvent(client: ReturnType<typeof createClient>, ev: EventRow) {
  // 1) analytics rollup (idempotent insert per platform_event id via dedupe key in properties)
  const { error: aErr } = await client.from("analytics_events").insert({
    org_id: ev.org_id,
    module: ev.source_module,
    event_name: ev.event_type,
    properties: { ...ev.payload, _platform_event_id: ev.id },
  });
  if (aErr && !/duplicate/i.test(aErr.message)) {
    throw new Error(`analytics insert: ${aErr.message}`);
  }

  // 2) webhook fan-out: active endpoints whose event_types is empty (= all) or matches.
  const { data: endpoints, error: eErr } = await client
    .from("webhook_endpoints")
    .select("id, url, secret, event_types")
    .eq("org_id", ev.org_id)
    .eq("active", true);
  if (eErr) throw new Error(`webhooks lookup: ${eErr.message}`);

  const matching = (endpoints ?? []).filter((ep: WebhookEndpoint) =>
    !ep.event_types?.length || ep.event_types.includes(ev.event_type)
  );

  // Deliver in parallel; aggregate failures so one bad endpoint retries the whole event.
  const results = await Promise.allSettled(
    matching.map((ep: WebhookEndpoint) => deliverWebhook(ep, ev, client))
  );
  const failures = results.filter((r) => r.status === "rejected") as PromiseRejectedResult[];
  if (failures.length) {
    throw new Error(failures.map((f) => String(f.reason)).join("; "));
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });

  const url = Deno.env.get("SUPABASE_URL")!;
  const key = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const client = createClient(url, key, { auth: { persistSession: false } });

  const { data: events, error: fetchErr } = await client
    .from("platform_events")
    .select("id, org_id, source_module, event_type, payload, attempts, triggered_at")
    .eq("processed", false)
    .lt("attempts", MAX_ATTEMPTS)
    .lte("next_retry_at", new Date().toISOString())
    .order("triggered_at", { ascending: true })
    .limit(BATCH_SIZE);

  if (fetchErr) {
    console.error("fetch error", fetchErr);
    return new Response(JSON.stringify({ error: fetchErr.message }), {
      status: 500, headers: { ...CORS, "content-type": "application/json" },
    });
  }

  let ok = 0, failed = 0;
  for (const ev of (events ?? []) as EventRow[]) {
    try {
      await handleEvent(client, ev);
      await client.from("platform_events").update({
        processed: true,
        processed_at: new Date().toISOString(),
        attempts: ev.attempts + 1,
        last_error: null,
      }).eq("id", ev.id);
      ok++;
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      const nextAttempts = ev.attempts + 1;
      const backoffSec = Math.min(7200, 30 * Math.pow(4, nextAttempts - 1));
      const nextRetry = new Date(Date.now() + backoffSec * 1000).toISOString();
      await client.from("platform_events").update({
        attempts: nextAttempts,
        last_error: msg.slice(0, 500),
        next_retry_at: nextRetry,
      }).eq("id", ev.id);
      failed++;
      console.error(`event ${ev.id} failed (attempt ${nextAttempts})`, msg);
    }
  }

  return new Response(JSON.stringify({ claimed: events?.length ?? 0, ok, failed }), {
    headers: { ...CORS, "content-type": "application/json" },
  });
});
