import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { MonitorPage, MonitorSkeleton } from "./page-shell";
import { Card, CardContent } from "@/components/ui/card";

export type Column = { key: string; label: string; render?: (row: any) => React.ReactNode };

export function MonitorList({
  title, description, table, columns, orderBy = "created_at", ascending = false,
  emptyMessage = "Nothing here yet.", filter, actions,
}: {
  title: string; description?: string; table: string; columns: Column[];
  orderBy?: string; ascending?: boolean; emptyMessage?: string;
  filter?: (q: any) => any;
  actions?: React.ReactNode;
}) {
  const { org } = useAuth();
  const [rows, setRows] = useState<any[] | null>(null);
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    if (!org?.id) return;
    let q = supabase.from(table as any).select("*").eq("org_id", org.id).order(orderBy, { ascending });
    if (filter) q = filter(q);
    q.limit(200).then(({ data }) => setRows(data ?? []));
  }, [org?.id, table, orderBy, ascending, filter, reloadKey]);

  if (rows === null) return <MonitorSkeleton />;

  return (
    <MonitorPage title={title} description={description} actions={
      actions ? <span onClick={() => setTimeout(() => setReloadKey((k) => k + 1), 400)}>{actions}</span> : undefined
    }>
      <Card>
        <CardContent className="p-0">
          {rows.length === 0 ? (
            <div className="p-10 text-center text-sm text-muted-foreground">{emptyMessage}</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/40 text-xs uppercase tracking-wider text-muted-foreground">
                  <tr>{columns.map((c) => <th key={c.key} className="text-left px-4 py-2.5 font-medium">{c.label}</th>)}</tr>
                </thead>
                <tbody className="divide-y">
                  {rows.map((r) => (
                    <tr key={r.id} className="hover:bg-muted/20">
                      {columns.map((c) => <td key={c.key} className="px-4 py-2.5">{c.render ? c.render(r) : (r[c.key] ?? "—")}</td>)}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </MonitorPage>
  );
}

export function SeverityBadge({ value }: { value: string | null | undefined }) {
  if (!value) return <span className="text-muted-foreground">—</span>;
  const color =
    value === "critical" ? "#dc2626" :
    value === "high" ? "#f97316" :
    value === "medium" ? "#f59e0b" : "#7F77DD";
  return <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium" style={{ background: `${color}22`, color }}>{value}</span>;
}

export function SentimentBadge({ value }: { value: string | null | undefined }) {
  if (!value) return <span className="text-muted-foreground">—</span>;
  const map: Record<string, { label: string; color: string }> = {
    positive: { label: "😊 Positive", color: "#16a34a" },
    neutral: { label: "😐 Neutral", color: "#71717a" },
    negative: { label: "😠 Negative", color: "#dc2626" },
  };
  const m = map[value] ?? { label: value, color: "#71717a" };
  return <span className="inline-flex items-center px-2 py-0.5 rounded text-xs" style={{ background: `${m.color}22`, color: m.color }}>{m.label}</span>;
}

export function timeAgo(iso: string | null | undefined) {
  if (!iso) return "—";
  const s = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}
