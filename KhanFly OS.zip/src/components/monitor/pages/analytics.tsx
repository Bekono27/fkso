import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { MonitorPage, MonitorSkeleton } from "../page-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  LineChart, Line, XAxis, YAxis, ReferenceLine, Tooltip, ResponsiveContainer,
  BarChart, Bar, Legend, PieChart, Pie, Cell,
} from "recharts";

const SENTIMENT_COLORS: Record<string, string> = {
  positive: "#16a34a", neutral: "#a1a1aa", negative: "#dc2626", unknown: "#71717a",
};

export default function AnalyticsPage() {
  const { org } = useAuth();
  const [trend, setTrend] = useState<any[] | null>(null);
  const [posts, setPosts] = useState<any[]>([]);
  const [keywords, setKeywords] = useState<any[]>([]);

  useEffect(() => {
    if (!org?.id) return;
    const since = new Date(Date.now() - 29 * 86400000).toISOString().split("T")[0];
    Promise.all([
      supabase.from("sentiment_scores").select("date,score,positive_count,neutral_count,negative_count,mention_count")
        .eq("org_id", org.id).gte("date", since).order("date"),
      supabase.from("monitoring_posts").select("platform,sentiment,matched_keyword,created_at")
        .eq("org_id", org.id).gte("created_at", new Date(Date.now() - 29 * 86400000).toISOString()).limit(1000),
      supabase.from("monitoring_keywords").select("term,mention_count_total").eq("org_id", org.id).eq("is_active", true),
    ]).then(([t, p, k]) => {
      setTrend(t.data ?? []);
      setPosts(p.data ?? []);
      setKeywords(k.data ?? []);
    });
  }, [org?.id]);

  if (trend === null) return <MonitorSkeleton />;

  // Aggregations
  const totalMentions = posts.length;
  const platformCounts: Record<string, number> = {};
  const sentimentCounts: Record<string, number> = { positive: 0, neutral: 0, negative: 0, unknown: 0 };
  posts.forEach((p) => {
    platformCounts[p.platform ?? "unknown"] = (platformCounts[p.platform ?? "unknown"] ?? 0) + 1;
    const s = p.sentiment ?? "unknown";
    sentimentCounts[s] = (sentimentCounts[s] ?? 0) + 1;
  });
  const platformData = Object.entries(platformCounts).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  const sentimentData = Object.entries(sentimentCounts).filter(([, v]) => v > 0).map(([name, value]) => ({ name, value }));
  const topKeywords = [...keywords].sort((a, b) => (b.mention_count_total ?? 0) - (a.mention_count_total ?? 0)).slice(0, 8);
  const latestScore = trend.length ? trend[trend.length - 1].score : null;
  const avgScore = trend.length ? Math.round(trend.reduce((s, r) => s + (r.score ?? 0), 0) / trend.length) : null;

  return (
    <MonitorPage title="Analytics" description="Brand sentiment over the last 30 days">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          ["Mentions (30d)", totalMentions.toLocaleString()],
          ["Sentiment today", latestScore != null ? `${latestScore}/100` : "—"],
          ["Avg sentiment", avgScore != null ? `${avgScore}/100` : "—"],
          ["Active keywords", keywords.length],
        ].map(([label, val]) => (
          <Card key={label as string}>
            <CardContent className="p-4">
              <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
              <div className="text-2xl font-semibold mt-1" style={{ color: "var(--monitor)" }}>{val}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Sentiment score</CardTitle></CardHeader>
        <CardContent>
          {trend.length === 0 ? (
            <div className="text-sm text-muted-foreground text-center p-6">No data yet.</div>
          ) : (
            <div className="h-72"><ResponsiveContainer width="100%" height="100%">
              <LineChart data={trend} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <XAxis dataKey="date" fontSize={11} tickFormatter={(d) => d.slice(5)} />
                <YAxis domain={[0, 100]} fontSize={11} />
                <Tooltip contentStyle={{ fontSize: 12 }} />
                <ReferenceLine y={50} stroke="#999" strokeDasharray="3 3" />
                <Line type="monotone" dataKey="score" stroke="var(--monitor)" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer></div>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-base">Mention breakdown</CardTitle></CardHeader>
          <CardContent>
            {trend.length === 0 ? (
              <div className="text-sm text-muted-foreground text-center p-6">No data yet.</div>
            ) : (
              <div className="h-64"><ResponsiveContainer width="100%" height="100%">
                <BarChart data={trend} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <XAxis dataKey="date" fontSize={11} tickFormatter={(d) => d.slice(5)} />
                  <YAxis fontSize={11} />
                  <Tooltip contentStyle={{ fontSize: 12 }} />
                  <Legend />
                  <Bar dataKey="positive_count" stackId="a" fill="#16a34a" name="Positive" />
                  <Bar dataKey="neutral_count" stackId="a" fill="#a1a1aa" name="Neutral" />
                  <Bar dataKey="negative_count" stackId="a" fill="#dc2626" name="Negative" />
                </BarChart>
              </ResponsiveContainer></div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Sentiment mix (30d)</CardTitle></CardHeader>
          <CardContent>
            {sentimentData.length === 0 ? (
              <div className="text-sm text-muted-foreground text-center p-6">No mentions yet.</div>
            ) : (
              <div className="h-64"><ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={sentimentData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                    {sentimentData.map((entry) => (
                      <Cell key={entry.name} fill={SENTIMENT_COLORS[entry.name] ?? "#71717a"} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ fontSize: 12 }} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer></div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-base">Top platforms (30d)</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {platformData.length === 0 ? (
              <div className="text-sm text-muted-foreground text-center p-6">No mentions yet.</div>
            ) : platformData.slice(0, 8).map((p) => {
              const pct = totalMentions ? Math.round((p.value / totalMentions) * 100) : 0;
              return (
                <div key={p.name}>
                  <div className="flex justify-between text-sm">
                    <span className="font-medium capitalize">{p.name}</span>
                    <span className="text-muted-foreground">{p.value} · {pct}%</span>
                  </div>
                  <div className="h-1.5 bg-muted rounded-full overflow-hidden mt-1">
                    <div className="h-full rounded-full" style={{ width: `${pct}%`, background: "var(--monitor)" }} />
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Top keywords</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {topKeywords.length === 0 ? (
              <div className="text-sm text-muted-foreground text-center p-6">No keyword data yet.</div>
            ) : topKeywords.map((k) => {
              const max = topKeywords[0]?.mention_count_total ?? 1;
              const pct = Math.round(((k.mention_count_total ?? 0) / Math.max(1, max)) * 100);
              return (
                <div key={k.term}>
                  <div className="flex justify-between text-sm">
                    <span className="font-medium">{k.term}</span>
                    <span className="text-muted-foreground">{k.mention_count_total ?? 0}</span>
                  </div>
                  <div className="h-1.5 bg-muted rounded-full overflow-hidden mt-1">
                    <div className="h-full rounded-full" style={{ width: `${pct}%`, background: "var(--monitor)" }} />
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>
      </div>
    </MonitorPage>
  );
}
