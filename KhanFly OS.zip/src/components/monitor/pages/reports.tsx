import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { MonitorPage, MonitorSkeleton } from "../page-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, Sparkles, FileText } from "lucide-react";
import { toast } from "sonner";

const REPORT_TYPES = [
  { type: "brand_health", title: "Brand Health Report", description: "Overall sentiment, share of voice, key themes." },
  { type: "alert_summary", title: "Alert Summary", description: "Critical alerts and recommended responses." },
  { type: "sentiment_trend", title: "Sentiment Trend", description: "How sentiment moved over the period." },
  { type: "competitor_analysis", title: "Competitor Analysis", description: "Tracked competitors vs your brand." },
];

export default function ReportsPage() {
  const { org, user: authUser } = useAuth();
  const [reports, setReports] = useState<any[] | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  async function load() {
    if (!org?.id) return;
    const { data } = await supabase
      .from("monitoring_reports")
      .select("*")
      .eq("org_id", org.id)
      .order("created_at", { ascending: false })
      .limit(30);
    setReports(data ?? []);
  }
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [org?.id]);

  async function generate(rt: typeof REPORT_TYPES[number]) {
    if (!org?.id) return;
    setBusy(rt.type);
    try {
      // Pull recent context
      const since = new Date(Date.now() - 30 * 24 * 3600 * 1000).toISOString();
      const [mentions, alerts, scores, competitors] = await Promise.all([
        supabase.from("monitoring_posts").select("content,sentiment,source_platform,created_at").eq("org_id", org.id).gte("created_at", since).limit(50),
        supabase.from("monitoring_alerts").select("title,severity,status,created_at").eq("org_id", org.id).gte("created_at", since).limit(20),
        supabase.from("sentiment_scores").select("date,score").eq("org_id", org.id).gte("date", since.slice(0, 10)).order("date"),
        supabase.from("monitoring_competitors").select("name,handle,follower_count,engagement_avg").eq("org_id", org.id).limit(10),
      ]);

      const system = `You write concise, executive-style brand monitoring reports in well-formatted Markdown. Use clear headings, bullet points, and a final "Recommended actions" section.`;
      const user = `Generate a ${rt.title} for the past 30 days.

Mentions (${mentions.data?.length ?? 0}):
${(mentions.data ?? []).slice(0, 20).map((m: any) => `- [${m.sentiment ?? "?"}] ${(m.content ?? "").slice(0, 140)}`).join("\n") || "(none)"}

Alerts (${alerts.data?.length ?? 0}):
${(alerts.data ?? []).map((a: any) => `- ${a.severity}: ${a.title} (${a.status})`).join("\n") || "(none)"}

Sentiment scores: ${(scores.data ?? []).map((s: any) => `${s.date}=${s.score}`).join(", ") || "(none)"}

Competitors: ${(competitors.data ?? []).map((c: any) => `${c.name} (${c.follower_count ?? 0} followers)`).join(", ") || "(none)"}

Write the full report now.`;

      const { data, error } = await supabase.functions.invoke("ai-chat", {
        body: { system, messages: [{ role: "user", content: user }], stream: false },
      });
      if (error) throw error;
      const summary = (data as any)?.reply ?? "(empty)";

      const { error: insErr } = await supabase.from("monitoring_reports").insert({
        org_id: org.id,
        title: `${rt.title} — ${new Date().toLocaleDateString()}`,
        type: rt.type,
        period: "last_30_days",
        summary,
        data: { generated_at: new Date().toISOString() },
        generated_by: authUser?.id ?? null,
      } as any);
      if (insErr) throw insErr;
      toast.success(`${rt.title} generated`);
      load();
    } catch (e: any) {
      toast.error("Generation failed", { description: e.message });
    } finally {
      setBusy(null);
    }
  }

  function download(r: any) {
    const blob = new Blob([`# ${r.title}\n\n${r.summary ?? ""}`], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${r.title.replace(/[^a-z0-9]+/gi, "-").toLowerCase()}.md`;
    a.click();
    URL.revokeObjectURL(url);
  }

  if (reports === null) return <MonitorSkeleton />;

  return (
    <MonitorPage title="Reports" description="AI-generated brand health reports">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {REPORT_TYPES.map((rt) => (
          <Card key={rt.type}>
            <CardHeader>
              <CardTitle className="text-base">{rt.title}</CardTitle>
              <p className="text-xs text-muted-foreground">{rt.description}</p>
            </CardHeader>
            <CardContent>
              <Button
                size="sm"
                onClick={() => generate(rt)}
                disabled={busy === rt.type}
                style={{ background: "var(--monitor)", color: "white" }}
              >
                {busy === rt.type ? <Loader2 className="h-4 w-4 animate-spin mr-1.5" /> : <Sparkles className="h-4 w-4 mr-1.5" />}
                Generate
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Generated reports</CardTitle></CardHeader>
        <CardContent className="p-0">
          {reports.length === 0 ? (
            <div className="p-6 text-sm text-muted-foreground">No reports yet — generate your first one above.</div>
          ) : (
            <div className="divide-y">
              {reports.map((r) => (
                <div key={r.id} className="p-4 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-sm font-medium flex items-center gap-2">
                      <FileText className="h-4 w-4 text-muted-foreground" />
                      <span className="truncate">{r.title}</span>
                    </div>
                    <div className="text-xs text-muted-foreground">{r.type} · {new Date(r.created_at).toLocaleString()}</div>
                  </div>
                  <Button size="sm" variant="outline" onClick={() => download(r)}>Download .md</Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </MonitorPage>
  );
}
