import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { MonitorPage, MonitorSkeleton } from "../page-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { EmptyState } from "@/components/empty-state";
import { Search, Trash2 } from "lucide-react";
import { indexEntity } from "@/lib/monitor";
import { toast } from "sonner";

const SEED_TERMS = ["pricing", "support", "review", "competitor", "launch"];

export default function KeywordsPage() {
  const { org } = useAuth();
  const [rows, setRows] = useState<any[] | null>(null);
  const [term, setTerm] = useState("");
  const [seeding, setSeeding] = useState(false);

  const load = async () => {
    if (!org?.id) return;
    const { data } = await supabase.from("monitoring_keywords").select("*").eq("org_id", org.id).order("created_at", { ascending: false });
    setRows(data ?? []);
  };
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [org?.id]);

  const add = async () => {
    if (!org?.id || !term.trim()) return;
    const { data, error } = await supabase.from("monitoring_keywords").insert({ org_id: org.id, term: term.trim() }).select().single();
    if (error) return toast.error(error.message);
    if (data) {
      await indexEntity({
        org_id: org.id, module: "monitor", entity_type: "keyword", entity_id: data.id,
        title: data.term, subtitle: `Keyword · ${data.mention_count_total ?? 0} mentions`,
        keywords: data.term, url: "/monitor/keywords",
      });
    }
    setTerm("");
    toast.success("Keyword added");
    load();
  };

  const seedDemo = async () => {
    if (!org?.id) return;
    setSeeding(true);
    try {
      const payload = SEED_TERMS.map((t) => ({ org_id: org.id, term: t, category: "general" }));
      const { error } = await supabase.from("monitoring_keywords").insert(payload as any);
      if (error) throw error;
      toast.success(`Added ${SEED_TERMS.length} sample keywords`);
      load();
    } catch (e: any) {
      toast.error(e.message ?? "Failed to seed");
    } finally { setSeeding(false); }
  };

  const toggleActive = async (k: any) => {
    const { error } = await supabase.from("monitoring_keywords").update({ is_active: !k.is_active }).eq("id", k.id);
    if (error) return toast.error(error.message);
    toast.success(k.is_active ? "Keyword paused" : "Keyword activated");
    load();
  };

  const remove = async (k: any) => {
    if (!confirm(`Delete keyword "${k.term}"?`)) return;
    const { error } = await supabase.from("monitoring_keywords").delete().eq("id", k.id);
    if (error) return toast.error(error.message);
    toast.success("Keyword deleted");
    load();
  };

  if (rows === null) return <MonitorSkeleton />;
  return (
    <MonitorPage title="Keywords" description={`${rows.length} tracked · ${rows.filter((k) => k.is_active).length} active`}
      actions={<div className="flex gap-2"><Input placeholder="Add keyword…" value={term} onChange={(e) => setTerm(e.target.value)} onKeyDown={(e) => e.key === "Enter" && add()} className="w-48" />
        <Button style={{ background: "var(--monitor)", color: "white" }} onClick={add}>Add</Button></div>}>
      <Card><CardContent className="p-0">
        {rows.length === 0 ? (
          <EmptyState
            icon={Search}
            accent="var(--monitor)"
            title="No keywords yet"
            description="Add the terms you want OmniSight to track across the web — your brand name, products, competitors, or industry topics."
            actionLabel="Seed 5 sample keywords"
            onAction={seedDemo}
            secondaryLabel="I'll add my own"
            onSecondary={() => document.querySelector<HTMLInputElement>('input[placeholder="Add keyword…"]')?.focus()}
            busy={seeding}
          />
        ) : (
          <table className="w-full text-sm">
            <thead className="bg-muted/40 text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="text-left px-4 py-2.5">Term</th>
                <th className="text-left px-4 py-2.5">Category</th>
                <th className="text-left px-4 py-2.5">Mentions</th>
                <th className="text-left px-4 py-2.5">Status</th>
                <th className="text-right px-4 py-2.5">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {rows.map((k) => (
                <tr key={k.id} className="hover:bg-muted/20">
                  <td className="px-4 py-2.5 font-medium">{k.term}</td>
                  <td className="px-4 py-2.5">{k.category ?? "—"}</td>
                  <td className="px-4 py-2.5">{k.mention_count_total ?? 0}</td>
                  <td className="px-4 py-2.5">
                    <span className={k.is_active ? "text-green-600" : "text-muted-foreground"}>
                      {k.is_active ? "🟢 Active" : "⏸ Paused"}
                    </span>
                  </td>
                  <td className="px-4 py-2.5 text-right space-x-1">
                    <Button size="sm" variant="ghost" onClick={() => toggleActive(k)}>
                      {k.is_active ? "Pause" : "Activate"}
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => remove(k)} className="text-destructive">
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </CardContent></Card>
    </MonitorPage>
  );
}
