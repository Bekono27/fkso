import { useEffect, useMemo, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { MonitorPage, MonitorSkeleton } from "../page-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { SentimentBadge, timeAgo } from "../list";

const SENTIMENTS = ["all", "positive", "neutral", "negative"] as const;

export default function FeedPage() {
  const { org } = useAuth();
  const [rows, setRows] = useState<any[] | null>(null);
  const [search, setSearch] = useState("");
  const [sentiment, setSentiment] = useState<(typeof SENTIMENTS)[number]>("all");
  const [platform, setPlatform] = useState<string>("all");

  useEffect(() => {
    if (!org?.id) return;
    const orgId = org.id;
    const load = () => supabase.from("monitoring_posts").select("*").eq("org_id", orgId)
      .order("created_at", { ascending: false }).limit(300).then(({ data }) => setRows(data ?? []));
    load();
    const ch = supabase.channel("monitor-feed-" + orgId)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "monitoring_posts", filter: `org_id=eq.${orgId}` }, load)
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [org?.id]);

  const platforms = useMemo(() => {
    const s = new Set<string>();
    (rows ?? []).forEach((r) => r.platform && s.add(r.platform));
    return ["all", ...Array.from(s).sort()];
  }, [rows]);

  const visible = useMemo(() => {
    const q = search.trim().toLowerCase();
    return (rows ?? []).filter((p) => {
      if (sentiment !== "all" && p.sentiment !== sentiment) return false;
      if (platform !== "all" && p.platform !== platform) return false;
      if (q && !(`${p.content ?? ""} ${p.author ?? ""} ${p.matched_keyword ?? ""} ${p.source_name ?? ""}`.toLowerCase().includes(q))) return false;
      return true;
    });
  }, [rows, search, sentiment, platform]);

  if (rows === null) return <MonitorSkeleton />;

  return (
    <MonitorPage title="Live feed" description={`${visible.length} of ${rows.length} mentions`}>
      <div className="flex flex-wrap gap-2 items-center">
        <Input placeholder="Search content, author, keyword…" value={search} onChange={(e) => setSearch(e.target.value)} className="w-72" />
        <div className="flex gap-1">
          {SENTIMENTS.map((s) => (
            <Button key={s} size="sm" variant={sentiment === s ? "default" : "outline"} className="h-7 capitalize" onClick={() => setSentiment(s)}>{s}</Button>
          ))}
        </div>
        <select
          value={platform}
          onChange={(e) => setPlatform(e.target.value)}
          className="h-8 rounded-md border bg-background px-2 text-sm capitalize"
        >
          {platforms.map((p) => <option key={p} value={p}>{p}</option>)}
        </select>
        {(search || sentiment !== "all" || platform !== "all") && (
          <Button size="sm" variant="ghost" onClick={() => { setSearch(""); setSentiment("all"); setPlatform("all"); }}>Clear</Button>
        )}
      </div>

      <Card><CardContent className="p-0">
        {visible.length === 0 ? (
          <div className="p-10 text-center text-sm text-muted-foreground">No mentions match this view.</div>
        ) : (
          <div className="divide-y">
            {visible.map((p) => (
              <div key={p.id} className="p-4 hover:bg-muted/30">
                <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
                  <span className="font-medium capitalize">{p.platform}</span> · <span>{p.source_name ?? p.author ?? "unknown"}</span> · <span>{timeAgo(p.created_at)}</span>
                </div>
                <div className="text-sm whitespace-pre-wrap">{p.content}</div>
                <div className="flex items-center gap-2 mt-2 flex-wrap">
                  <SentimentBadge value={p.sentiment} />
                  {p.matched_keyword && <span className="text-[11px] px-1.5 py-0.5 rounded" style={{ background: "color-mix(in oklab, var(--monitor) 18%, transparent)", color: "var(--monitor)" }}>{p.matched_keyword}</span>}
                  {p.engagement_count != null && <span className="text-[11px] text-muted-foreground">💬 {p.engagement_count}</span>}
                  {p.source_url && <a href={p.source_url} target="_blank" rel="noreferrer" className="text-[11px] text-muted-foreground hover:underline ml-auto">Open source ↗</a>}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent></Card>
    </MonitorPage>
  );
}
