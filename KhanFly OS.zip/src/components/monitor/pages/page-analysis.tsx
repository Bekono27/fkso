import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { MonitorPage, MonitorSkeleton } from "../page-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Loader2, Sparkles } from "lucide-react";
import { toast } from "sonner";

export default function PageAnalysisPage() {
  const { org, user: authUser } = useAuth();
  const [history, setHistory] = useState<any[] | null>(null);
  const [pageUrl, setPageUrl] = useState("");
  const [pageName, setPageName] = useState("");
  const [pasted, setPasted] = useState("");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{ score: number; analysis: string } | null>(null);

  async function load() {
    if (!org?.id) return;
    const { data } = await supabase
      .from("page_analysis_results")
      .select("*")
      .eq("org_id", org.id)
      .order("created_at", { ascending: false })
      .limit(20);
    setHistory(data ?? []);
  }
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [org?.id]);

  async function analyze() {
    if (!org?.id) return;
    if (!pageUrl.trim() && !pasted.trim()) {
      toast.error("Add a page URL or paste content to analyze");
      return;
    }
    setBusy(true);
    setResult(null);
    try {
      const system = `You analyze social media pages. Reply in this exact format:
SCORE: <integer 0-100>
SUMMARY: <one-paragraph overview>
STRENGTHS:
- <bullet>
- <bullet>
WEAKNESSES:
- <bullet>
- <bullet>
RECOMMENDATIONS:
- <prioritized action>
- <prioritized action>
- <prioritized action>`;
      const user = pasted.trim()
        ? `Analyze this page content:\nURL: ${pageUrl || "(not provided)"}\nName: ${pageName || "(not provided)"}\n\nContent / posts:\n${pasted}`
        : `Analyze this page based on the URL alone (you don't have live access — make general assumptions about typical pages of this kind):\nURL: ${pageUrl}\nName: ${pageName || "(unknown)"}`;

      const { data, error } = await supabase.functions.invoke("ai-chat", {
        body: { system, messages: [{ role: "user", content: user }], stream: false },
      });
      if (error) throw error;
      const reply: string = (data as any)?.reply ?? "";
      const scoreMatch = reply.match(/SCORE:\s*(\d+)/i);
      const score = scoreMatch ? Math.max(0, Math.min(100, parseInt(scoreMatch[1], 10))) : 50;
      setResult({ score, analysis: reply });
    } catch (e: any) {
      toast.error("Analysis failed", { description: e.message });
    } finally {
      setBusy(false);
    }
  }

  async function save() {
    if (!org?.id || !result) return;
    const { error } = await supabase.from("page_analysis_results").insert({
      org_id: org.id,
      page_url: pageUrl || "n/a",
      page_name: pageName || null,
      overall_score: result.score,
      raw_analysis: { text: result.analysis },
      analyzed_by: authUser?.id ?? null,
    } as any);
    if (error) return toast.error(error.message);
    toast.success("Analysis saved");
    load();
  }

  return (
    <MonitorPage title="Page analysis" description="AI-powered audit of any social page">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle className="text-base">Analyze a page</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <div>
              <Label>Page URL</Label>
              <Input value={pageUrl} onChange={(e) => setPageUrl(e.target.value)} placeholder="https://facebook.com/yourbrand" />
            </div>
            <div>
              <Label>Page name (optional)</Label>
              <Input value={pageName} onChange={(e) => setPageName(e.target.value)} placeholder="Your Brand Co." />
            </div>
            <div>
              <Label>Paste recent posts (optional, improves accuracy)</Label>
              <Textarea rows={5} value={pasted} onChange={(e) => setPasted(e.target.value)} placeholder="Paste 5–10 recent post captions, follower counts, engagement…" />
            </div>
            <Button onClick={analyze} disabled={busy} style={{ background: "var(--monitor)", color: "white" }}>
              {busy ? <Loader2 className="h-4 w-4 animate-spin mr-1.5" /> : <Sparkles className="h-4 w-4 mr-1.5" />}
              Analyze
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center justify-between">
              <span>Result</span>
              {result && <span className="text-2xl font-bold" style={{ color: "var(--monitor)" }}>{result.score}/100</span>}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!result ? (
              <p className="text-sm text-muted-foreground">Run an analysis to see structured recommendations.</p>
            ) : (
              <div className="space-y-3">
                <pre className="text-xs whitespace-pre-wrap font-sans">{result.analysis}</pre>
                <Button size="sm" onClick={save}>Save to history</Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">History</CardTitle></CardHeader>
        <CardContent className="p-0">
          {history === null ? (
            <div className="p-6 text-sm text-muted-foreground">Loading…</div>
          ) : history.length === 0 ? (
            <div className="p-6 text-sm text-muted-foreground">No saved analyses yet.</div>
          ) : (
            <div className="divide-y">
              {history.map((r) => (
                <div key={r.id} className="p-4 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-sm font-medium truncate">{r.page_name || r.page_url}</div>
                    <div className="text-xs text-muted-foreground">{new Date(r.created_at).toLocaleString()}</div>
                  </div>
                  <div className="text-lg font-semibold" style={{ color: "var(--monitor)" }}>{r.overall_score ?? 0}/100</div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </MonitorPage>
  );
}
