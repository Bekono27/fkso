import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { MonitorPage, MonitorSkeleton } from "../page-shell";
import { QuickCreate } from "@/components/quick-create";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Play, Loader2 } from "lucide-react";
import { toast } from "sonner";

const AGENT_ICONS: Record<string, string> = {
  sentiment: "🧠",
  threat: "🚨",
  trend: "📈",
  competitor: "🏆",
  report: "📄",
};

export default function AgentsPage() {
  const { org } = useAuth();
  const [agents, setAgents] = useState<any[] | null>(null);
  const [running, setRunning] = useState<string | null>(null);

  async function load() {
    if (!org?.id) return;
    const { data } = await supabase
      .from("ai_agents")
      .select("*")
      .eq("org_id", org.id)
      .order("created_at", { ascending: false });
    setAgents(data ?? []);
  }
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [org?.id]);

  async function toggleActive(a: any, value: boolean) {
    const { error } = await supabase.from("ai_agents").update({ is_active: value }).eq("id", a.id);
    if (error) toast.error(error.message); else load();
  }

  async function runAgent(a: any) {
    if (!org?.id) return;
    setRunning(a.id);
    try {
      // Pull recent mentions to feed into the agent
      const { data: mentions } = await supabase
        .from("monitoring_posts")
        .select("content, source_platform, sentiment, created_at")
        .eq("org_id", org.id)
        .order("created_at", { ascending: false })
        .limit(20);

      const system = `You are a brand-monitoring AI agent named "${a.name}" of type "${a.agent_type}". ${a.description ?? ""}\nReply with a concise actionable summary (max 5 bullet points) based on the mentions provided.`;
      const user = `Recent mentions (${mentions?.length ?? 0}):\n${
        (mentions ?? []).map((m: any, i: number) => `${i + 1}. [${m.source_platform ?? "?"}] ${m.sentiment ?? ""} — ${(m.content ?? "").slice(0, 200)}`).join("\n") || "No mentions yet."
      }\n\nProduce your analysis now.`;

      const { data, error } = await supabase.functions.invoke("ai-chat", {
        body: { system, messages: [{ role: "user", content: user }], stream: false },
      });
      if (error) throw error;
      const reply = (data as any)?.reply ?? "No response.";

      await supabase.from("ai_agents").update({ last_run_at: new Date().toISOString() }).eq("id", a.id);
      load();

      toast.success(`${a.name} finished`, {
        description: reply.length > 220 ? reply.slice(0, 220) + "…" : reply,
        duration: 12000,
      });
    } catch (e: any) {
      toast.error(`${a.name} failed`, { description: e.message });
    } finally {
      setRunning(null);
    }
  }

  if (agents === null) return <MonitorSkeleton />;

  return (
    <MonitorPage
      title="AI Agents"
      description="Configured monitoring agents"
      actions={
        <QuickCreate
          table="ai_agents"
          title="New AI agent"
          buttonLabel="Add agent"
          buttonStyle={{ background: "var(--monitor)", color: "white" }}
          fields={[
            { key: "name", label: "Name", required: true, placeholder: "Threat Detector" },
            { key: "agent_type", label: "Type", placeholder: "sentiment / threat / trend / competitor / report", required: true },
            { key: "description", label: "Instructions", type: "textarea" },
          ]}
          defaults={{ is_active: true, config: {} }}
          onCreated={() => load()}
        />
      }
    >
      {agents.length === 0 ? (
        <Card><CardContent className="p-10 text-center text-sm text-muted-foreground">No agents yet.</CardContent></Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {agents.map((a) => (
            <Card key={a.id}>
              <CardContent className="p-5 space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">{AGENT_ICONS[a.agent_type] ?? "🤖"}</span>
                      <span className="font-medium">{a.name}</span>
                      <Badge variant="outline" className="text-[10px] uppercase">{a.agent_type}</Badge>
                    </div>
                    {a.description && <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{a.description}</p>}
                  </div>
                  <Switch checked={a.is_active} onCheckedChange={(v) => toggleActive(a, v)} />
                </div>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>Last run: {a.last_run_at ? new Date(a.last_run_at).toLocaleString() : "never"}</span>
                  <Button
                    size="sm"
                    onClick={() => runAgent(a)}
                    disabled={running === a.id || !a.is_active}
                    style={{ background: "var(--monitor)", color: "white" }}
                  >
                    {running === a.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Play className="h-3.5 w-3.5" />}
                    Run now
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </MonitorPage>
  );
}
