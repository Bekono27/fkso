import { MonitorList, timeAgo } from "../list";
import { QuickCreate } from "@/components/quick-create";

export default function CompetitorsPage() {
  return (
    <MonitorList
      title="Competitors"
      description="Profiles you're tracking"
      table="monitoring_competitors"
      actions={
        <QuickCreate
          table="monitoring_competitors"
          title="Track a competitor"
          buttonLabel="Add competitor"
          buttonStyle={{ background: "var(--monitor)", color: "white" }}
          fields={[
            { key: "name", label: "Name", required: true },
            { key: "handle", label: "Handle / username", placeholder: "@brand" },
            { key: "url", label: "Profile URL", type: "url" },
            { key: "notes", label: "Notes", type: "textarea" },
          ]}
          defaults={{ active: true }}
        />
      }
      columns={[
        { key: "name", label: "Name" },
        { key: "platform", label: "Platform" },
        { key: "handle", label: "Handle" },
        { key: "follower_count", label: "Followers", render: (r) => (r.follower_count ?? 0).toLocaleString() },
        { key: "last_post_at", label: "Last post", render: (r) => timeAgo(r.last_post_at) },
        { key: "active", label: "Status", render: (r) => r.active ? "Active" : "Paused" },
      ]}
      emptyMessage="No competitors tracked yet."
    />
  );
}
