import { useEffect, useMemo, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { MonitorPage, MonitorSkeleton } from "../page-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { SeverityBadge, timeAgo } from "../list";
import { writeEvent } from "@/lib/monitor";
import { toast } from "sonner";

const SEVERITIES = ["all", "critical", "high", "medium", "low"] as const;
const STATUSES = ["all", "active", "acknowledged", "resolved"] as const;

export default function AlertsPage() {
  const { org, user } = useAuth();
  const [rows, setRows] = useState<any[] | null>(null);
  const [sev, setSev] = useState<(typeof SEVERITIES)[number]>("all");
  const [status, setStatus] = useState<(typeof STATUSES)[number]>("active");
  const [reload, setReload] = useState(0);

  useEffect(() => {
    if (!org?.id) return;
    supabase.from("monitoring_alerts").select("*").eq("org_id", org.id)
      .order("created_at", { ascending: false }).limit(300)
      .then(({ data }) => setRows(data ?? []));
  }, [org?.id, reload]);

  const counts = useMemo(() => {
    const c = { all: rows?.length ?? 0, critical: 0, high: 0, medium: 0, low: 0, active: 0, acknowledged: 0, resolved: 0 };
    (rows ?? []).forEach((a) => {
      if (c[a.severity as keyof typeof c] !== undefined) (c as any)[a.severity]++;
      if (c[a.status as keyof typeof c] !== undefined) (c as any)[a.status]++;
    });
    return c;
  }, [rows]);

  const visible = useMemo(() => (rows ?? []).filter((a) =>
    (sev === "all" || a.severity === sev) && (status === "all" || a.status === status)
  ), [rows, sev, status]);

  const updateStatus = async (a: any, newStatus: "acknowledged" | "resolved") => {
    if (!org?.id) return;
    const patch: any = { status: newStatus };
    if (newStatus === "resolved") {
      const resolvedAt = new Date();
      patch.resolved_by = user?.id;
      patch.resolved_at = resolvedAt.toISOString();
      patch.resolution_hours = (resolvedAt.getTime() - new Date(a.created_at).getTime()) / 3600000;
    }
    const { error } = await supabase.from("monitoring_alerts").update(patch).eq("id", a.id);
    if (error) return toast.error(error.message);
    if (newStatus === "resolved") {
      await writeEvent(org.id, "monitor", "alert_resolved", {
        alert_id: a.id, title: a.title, resolved_by: user?.id, time_to_resolve_hours: patch.resolution_hours,
      }, user?.id);
    }
    toast.success(newStatus === "resolved" ? "Alert resolved" : "Acknowledged");
    setReload((k) => k + 1);
  };

  if (rows === null) return <MonitorSkeleton />;

  return (
    <MonitorPage
      title="Alerts"
      description={`${counts.active} active · ${counts.critical} critical · ${counts.high} high`}
    >
      <div className="flex flex-wrap gap-2 items-center">
        <span className="text-xs uppercase tracking-wider text-muted-foreground mr-1">Severity</span>
        {SEVERITIES.map((s) => (
          <Button key={s} size="sm" variant={sev === s ? "default" : "outline"} onClick={() => setSev(s)} className="capitalize h-7">
            {s} <span className="ml-1.5 opacity-60">{counts[s]}</span>
          </Button>
        ))}
        <span className="text-xs uppercase tracking-wider text-muted-foreground ml-3 mr-1">Status</span>
        {STATUSES.map((s) => (
          <Button key={s} size="sm" variant={status === s ? "default" : "outline"} onClick={() => setStatus(s)} className="capitalize h-7">
            {s} <span className="ml-1.5 opacity-60">{counts[s] ?? 0}</span>
          </Button>
        ))}
      </div>

      <Card><CardContent className="p-0">
        {visible.length === 0 ? (
          <div className="p-10 text-center text-sm text-muted-foreground">No alerts in this view.</div>
        ) : (
          <div className="divide-y">
            {visible.map((a) => (
              <div key={a.id} className="p-4 flex items-center gap-3">
                <SeverityBadge value={a.severity} />
                <div className="flex-1 min-w-0">
                  <div className="font-medium truncate">{a.title}</div>
                  <div className="text-xs text-muted-foreground">
                    {a.source_platform ?? "—"} · {a.triggered_keyword ?? "—"} · {timeAgo(a.created_at)} · <span className="capitalize">{a.status}</span>
                    {a.resolution_hours != null && status === "resolved" && (
                      <> · resolved in {Math.round(a.resolution_hours * 10) / 10}h</>
                    )}
                  </div>
                </div>
                {a.source_url && (
                  <a href={a.source_url} target="_blank" rel="noreferrer" className="text-xs text-muted-foreground hover:underline">Open ↗</a>
                )}
                {a.status === "active" && (
                  <Button size="sm" variant="outline" onClick={() => updateStatus(a, "acknowledged")}>Acknowledge</Button>
                )}
                {a.status !== "resolved" && (
                  <Button size="sm" style={{ background: "var(--monitor)", color: "white" }} onClick={() => updateStatus(a, "resolved")}>Resolve</Button>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent></Card>
    </MonitorPage>
  );
}
