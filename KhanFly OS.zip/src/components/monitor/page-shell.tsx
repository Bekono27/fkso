import type { ReactNode } from "react";
import { ModuleHero } from "@/components/module-hero";

export function MonitorPage({
  title, description, actions, children, hero,
}: { title: string; description?: string; actions?: ReactNode; children: ReactNode; hero?: boolean }) {
  return (
    <div className="p-4 sm:p-6 space-y-5 sm:space-y-6 animate-page-in">
      {hero ? (
        <ModuleHero moduleKey="monitor" title={title} description={description} actions={actions} />
      ) : (
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3 sm:gap-4">
          <div>
            <h1 className="text-xl sm:text-2xl font-semibold tracking-tight" style={{ color: "var(--monitor)" }}>{title}</h1>
            {description && <p className="text-sm text-muted-foreground mt-1">{description}</p>}
          </div>
          {actions && <div className="flex items-center gap-2 flex-wrap">{actions}</div>}
        </div>
      )}
      {children}
    </div>
  );
}

export function MonitorSkeleton() {
  return (
    <div className="p-6 space-y-4">
      <div className="h-8 w-48 bg-muted rounded animate-pulse" />
      <div className="h-32 rounded animate-pulse" style={{ background: "color-mix(in oklab, var(--monitor) 12%, transparent)" }} />
      <div className="h-32 rounded animate-pulse" style={{ background: "color-mix(in oklab, var(--monitor) 8%, transparent)" }} />
    </div>
  );
}
