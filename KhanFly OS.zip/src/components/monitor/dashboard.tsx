import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Activity, Bell, AtSign, TrendingUp, TrendingDown, Minus, Shield } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { MonitorPage } from "./page-shell";
import { SentimentBadge, SeverityBadge, timeAgo } from "./list";
import { todayISO } from "@/lib/workforce";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LineChart, Line, XAxis, YAxis, ReferenceLine, Tooltip, ResponsiveContainer, Area, ComposedChart } from "recharts";

const PURPLE = "var(--monitor)";

function MetricCard({ label, value, sub, icon: Icon, to, accent = PURPLE, bgTint }:
  { label: string; value: string | number; sub?: string; icon: any; to?: string; accent?: string; bgTint?: string }) {
  const inner = (
    <Card className="hover:shadow-md transition-shadow cursor-pointer h-full" style={bgTint ? { background: bgTint } : undefined}>
      <CardContent className="p-5">
        <div className="flex items-start justify-between">
          <div>
            <div className="text-xs text-muted-foreground uppercase tracking-wider">{label}</div>
            <div className="text-3xl font-bold mt-2" style={{ color: accent }}>{value}</div>
            {sub && <div className="text-xs text-muted-foreground mt-1">{sub}</div>}
          </div>
          <div className="rounded-lg p-2" style={{ background: `color-mix(in oklab, ${accent} 14%, transparent)`, color: accent }}>
            <Icon className="h-5 w-5" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
  return to ? <Link to={to}>{inner}</Link> : inner;
}

export default function MonitorDashboard() {
  const { org } = useAuth();
  const orgId = org?.id;

  const [todayScore, setTodayScore] = useState<number | null>(null);
  const [yScore, setYScore] = useState<number | null>(null);
  const [alerts, setAlerts] = useState<any[]>([]);
  const [mentionsBreakdown, setMentionsBreakdown] = useState({ pos: 0, neu: 0, neg: 0, total: 0 });
  const [feed, setFeed] = useState<any[]>([]);
  const [trend, setTrend] = useState<{ date: string; score: number; mentions: number }[]>([]);
  const [topKw, setTopKw] = useState<{ keyword_term: string; count: number }[]>([]);
  const [weekAvg, setWeekAvg] = useState<number | null>(null);
  const [todayAvg, setTodayAvg] = useState<number | null>(null);

  const today = todayISO();

  const loadAll = async () => {
    if (!orgId) return;
    const yesterday = new Date(Date.now() - 86400000).toISOString().split("T")[0];
    const fortnight = new Date(Date.now() - 13 * 86400000).toISOString().split("T")[0];
    const weekStart = new Date(Date.now() - 6 * 86400000).toISOString().split("T")[0];

    const [ts, ys, al, ms, fd, sc, kw, week] = await Promise.all([
      supabase.from("sentiment_scores").select("score").eq("org_id", orgId).eq("date", today).maybeSingle(),
      supabase.from("sentiment_scores").select("score").eq("org_id", orgId).eq("date", yesterday).maybeSingle(),
      supabase.from("monitoring_alerts").select("id,title,severity,source_platform,triggered_keyword,created_at,status")
        .eq("org_id", orgId).eq("status", "active").order("created_at", { ascending: false }),
      supabase.from("sentiment_mentions").select("sentiment").eq("org_id", orgId).eq("date", today),
      supabase.from("monitoring_posts").select("*").eq("org_id", orgId).order("created_at", { ascending: false }).limit(10),
      supabase.from("sentiment_scores").select("date,score,mention_count").eq("org_id", orgId).gte("date", fortnight).order("date"),
      supabase.from("keyword_mentions").select("keyword_term,count").eq("org_id", orgId).eq("date", today).order("count", { ascending: false }).limit(8),
      supabase.from("sentiment_scores").select("score").eq("org_id", orgId).gte("date", weekStart),
    ]);

    setTodayScore(ts.data?.score ?? null);
    setYScore(ys.data?.score ?? null);
    setAlerts(al.data ?? []);
    const mentions = ms.data ?? [];
    const breakdown = { pos: 0, neu: 0, neg: 0, total: mentions.length };
    mentions.forEach((m: any) => {
      if (m.sentiment === "positive") breakdown.pos++;
      else if (m.sentiment === "negative") breakdown.neg++;
      else breakdown.neu++;
    });
    setMentionsBreakdown(breakdown);
    setFeed(fd.data ?? []);
    setTrend((sc.data ?? []).map((r: any) => ({ date: r.date, score: Number(r.score), mentions: r.mention_count ?? 0 })));
    setTopKw(kw.data ?? []);

    const wkRows = week.data ?? [];
    if (wkRows.length) setWeekAvg(wkRows.reduce((s: number, r: any) => s + Number(r.score), 0) / wkRows.length);
    if (ts.data) setTodayAvg(Number(ts.data.score));
  };

  useEffect(() => {
    loadAll();
    if (!orgId) return;
    const ch = supabase.channel("monitor-dashboard-" + orgId)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "monitoring_posts", filter: `org_id=eq.${orgId}` }, () => loadAll())
      .on("postgres_changes", { event: "*", schema: "public", table: "monitoring_alerts", filter: `org_id=eq.${orgId}` }, () => loadAll())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orgId]);

  // Card 1 — brand score colour
  const score = todayScore ?? 0;
  const scoreBg =
    score > 70 ? "color-mix(in oklab, #16a34a 8%, transparent)" :
    score >= 40 ? "color-mix(in oklab, #f59e0b 8%, transparent)" :
    todayScore !== null ? "color-mix(in oklab, #ef4444 10%, transparent)" : undefined;
  const scoreDelta = (todayScore ?? 0) - (yScore ?? 0);
  const scoreSub = yScore != null && todayScore != null
    ? `${scoreDelta >= 0 ? "↑ +" : "↓ "}${Math.abs(scoreDelta).toFixed(1)} vs yesterday`
    : "no baseline yet";

  // Card 2
  const critCount = alerts.filter((a) => a.severity === "critical").length;
  const highCount = alerts.filter((a) => a.severity === "high").length;
  const medCount = alerts.filter((a) => a.severity === "medium").length;
  const lowCount = alerts.filter((a) => a.severity === "low").length;
  const alertColor = critCount > 0 ? "#dc2626" : highCount > 0 ? "#f97316" : alerts.length === 0 ? "#16a34a" : PURPLE;

  // Card 4 — trend
  let trendLabel = "→ Neutral", TrendIcon = Minus, trendColor = "#71717a";
  if (todayAvg !== null && weekAvg !== null) {
    const d = todayAvg - weekAvg;
    if (d > 2) { trendLabel = "↑ Positive"; TrendIcon = TrendingUp; trendColor = "#16a34a"; }
    else if (d < -2) { trendLabel = "↓ Negative"; TrendIcon = TrendingDown; trendColor = "#dc2626"; }
  }

  // Group alerts by severity
  const grouped: Record<string, any[]> = { critical: [], high: [], medium: [], low: [] };
  alerts.forEach((a) => { (grouped[a.severity] ?? grouped.low).push(a); });

  const maxKw = Math.max(1, ...topKw.map((k) => k.count));

  return (
    <MonitorPage hero title="Brand Monitor" description="Live mentions, sentiment and alerts across channels.">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard label="Brand score" value={todayScore != null ? Math.round(todayScore) : "—"} sub={scoreSub} icon={Activity} to="/monitor/analytics" bgTint={scoreBg} />
        <MetricCard label="Active alerts" value={alerts.length} sub={`${critCount} critical · ${highCount} high · ${medCount + lowCount} medium`} icon={Bell} to="/monitor/alerts" accent={alertColor} />
        <MetricCard label="Mentions today" value={mentionsBreakdown.total} sub={`${mentionsBreakdown.pos} positive · ${mentionsBreakdown.neu} neutral · ${mentionsBreakdown.neg} negative`} icon={AtSign} to="/monitor/feed" />
        <MetricCard label="Sentiment trend" value={trendLabel} sub={`Based on ${mentionsBreakdown.total} mentions today`} icon={TrendIcon} to="/monitor/analytics" accent={trendColor} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Live feed */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              Live mentions
              <span className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="max-h-96 overflow-y-auto divide-y">
              {feed.length === 0 && <div className="p-6 text-sm text-muted-foreground text-center">No mentions yet — they'll stream in here.</div>}
              {feed.map((p: any) => (
                <Link key={p.id} to="/monitor/feed" className="block px-4 py-3 hover:bg-muted/40">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <span className="font-medium">{p.platform}</span>
                    <span>·</span>
                    <span className="truncate">{p.source_name ?? p.author ?? "unknown"}</span>
                    <span>·</span>
                    <span>{timeAgo(p.created_at)}</span>
                  </div>
                  <div className="text-sm mt-1 line-clamp-2">{(p.content ?? "").slice(0, 160)}</div>
                  <div className="flex items-center gap-2 mt-1.5">
                    <SentimentBadge value={p.sentiment} />
                    {p.matched_keyword && (
                      <span className="text-[11px] px-1.5 py-0.5 rounded" style={{ background: "color-mix(in oklab, var(--monitor) 18%, transparent)", color: PURPLE }}>
                        {p.matched_keyword}
                      </span>
                    )}
                  </div>
                </Link>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Alerts */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center justify-between">
              <span>Alerts</span>
              <Link to="/monitor/keywords"><Button size="sm" variant="outline">+ New keyword</Button></Link>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {alerts.length === 0 && (
              <div className="flex items-center gap-2 text-sm text-green-600">
                <Shield className="h-5 w-5" /> No active alerts — brand is safe.
              </div>
            )}
            {(["critical", "high", "medium", "low"] as const).map((sev) => {
              const items = grouped[sev];
              if (items.length === 0) return null;
              const dot = sev === "critical" ? "🔴" : sev === "high" ? "🟠" : sev === "medium" ? "🟡" : "⚪";
              return (
                <div key={sev}>
                  <div className="text-[11px] uppercase tracking-wider text-muted-foreground mb-2">{dot} {sev} ({items.length})</div>
                  <div className="space-y-1.5">
                    {items.slice(0, 5).map((a: any) => (
                      <div key={a.id} className="border rounded-md p-2.5 text-sm flex items-center justify-between gap-2">
                        <div className="min-w-0">
                          <div className="font-medium truncate">{a.title}</div>
                          <div className="text-[11px] text-muted-foreground">{a.source_platform ?? "—"} · {timeAgo(a.created_at)}</div>
                        </div>
                        <Link to="/monitor/alerts"><Button size="sm" variant="outline">View</Button></Link>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-base">Sentiment — last 14 days</CardTitle></CardHeader>
          <CardContent>
            {trend.length === 0 ? (
              <div className="text-sm text-muted-foreground p-6 text-center">No sentiment history yet.</div>
            ) : (
              <div className="h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart data={trend} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                    <XAxis dataKey="date" fontSize={11} tickFormatter={(d) => d.slice(5)} />
                    <YAxis domain={[0, 100]} fontSize={11} />
                    <Tooltip contentStyle={{ fontSize: 12 }} />
                    <ReferenceLine y={50} stroke="#999" strokeDasharray="3 3" />
                    <Area type="monotone" dataKey="score" stroke="none" fill="var(--monitor)" fillOpacity={0.1} />
                    <Line type="monotone" dataKey="score" stroke="var(--monitor)" strokeWidth={2} dot={false} />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Top keywords today</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {topKw.length === 0 && <div className="text-sm text-muted-foreground p-4 text-center">No keyword hits today.</div>}
            {topKw.map((k) => (
              <div key={k.keyword_term} className="flex items-center gap-3 text-sm">
                <div className="w-32 truncate font-medium">{k.keyword_term}</div>
                <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full rounded-full" style={{ width: `${(k.count / maxKw) * 100}%`, background: PURPLE }} />
                </div>
                <div className="w-10 text-right text-xs text-muted-foreground">{k.count}</div>
              </div>
            ))}
            <Link to="/monitor/keywords" className="text-xs text-muted-foreground hover:underline block pt-2">→ Manage keywords</Link>
          </CardContent>
        </Card>
      </div>
    </MonitorPage>
  );
}
