import type { ReactNode } from "react";
import { MODULES, type ModuleKey } from "@/lib/modules";

export function ModuleHero({
  moduleKey,
  title,
  description,
  actions,
}: {
  moduleKey: ModuleKey;
  title: string;
  description?: string;
  actions?: ReactNode;
}) {
  const mod = MODULES.find((m) => m.key === moduleKey)!;
  const Icon = mod.icon;
  const accent = `var(--${mod.accent})`;
  const dateStr = new Date().toLocaleDateString(undefined, {
    weekday: "long",
    month: "long",
    day: "numeric",
  });

  return (
    <div
      className="relative overflow-hidden rounded-2xl border p-5 sm:p-6 md:p-7"
      style={{
        background: `radial-gradient(120% 80% at 0% 0%, color-mix(in oklab, ${accent} 18%, transparent), transparent 60%), radial-gradient(80% 60% at 100% 100%, color-mix(in oklab, ${accent} 10%, transparent), transparent 60%), var(--card)`,
      }}
    >
      <div aria-hidden className="absolute inset-0 surface-grid opacity-30 pointer-events-none" />
      <div className="relative flex flex-col md:flex-row md:items-end md:justify-between gap-4">
        <div className="flex items-start gap-3 sm:gap-3.5 min-w-0">
          <span
            className="shrink-0 h-10 w-10 sm:h-11 sm:w-11 rounded-xl flex items-center justify-center ring-1 ring-black/5 shadow-sm"
            style={{
              background: `linear-gradient(135deg, ${accent}, color-mix(in oklab, ${accent} 60%, black))`,
              color: "white",
            }}
          >
            <Icon className="h-5 w-5" />
          </span>
          <div className="min-w-0">
            <div className="text-[10px] sm:text-[11px] uppercase tracking-[0.16em] sm:tracking-[0.18em] text-muted-foreground font-medium flex items-center gap-1.5 sm:gap-2 flex-wrap">
              <span className="live-dot" /> <span className="truncate">{dateStr}</span>
              <span className="text-muted-foreground/40 hidden sm:inline">·</span>
              <span style={{ color: accent }} className="hidden sm:inline">{mod.origin}</span>
            </div>
            <h1 className="text-xl sm:text-2xl md:text-3xl font-semibold tracking-tight mt-1.5 break-words" style={{ color: accent }}>
              {title}
            </h1>
            {description && (
              <p className="text-sm text-muted-foreground mt-1 max-w-xl">{description}</p>
            )}
          </div>
        </div>
        {actions && <div className="flex items-center gap-2 flex-wrap md:flex-nowrap md:shrink-0">{actions}</div>}
      </div>
    </div>
  );
}
