import { useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter,
} from "@/components/ui/dialog";
import { Plus } from "lucide-react";
import { toast } from "sonner";

export type QCField = {
  key: string;
  label: string;
  type?: "text" | "email" | "url" | "number" | "textarea";
  required?: boolean;
  placeholder?: string;
};

export function QuickCreate({
  table,
  title,
  fields,
  defaults,
  onCreated,
  buttonLabel = "Add",
  buttonStyle,
  triggerVariant = "default",
}: {
  table: string;
  title: string;
  fields: QCField[];
  /** Extra columns merged into the insert (e.g. status defaults). */
  defaults?: Record<string, unknown>;
  onCreated?: (row: any) => void;
  buttonLabel?: string;
  buttonStyle?: React.CSSProperties;
  triggerVariant?: "default" | "outline";
}) {
  const { org } = useAuth();
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [values, setValues] = useState<Record<string, string>>({});

  const reset = () => setValues({});

  async function submit() {
    if (!org?.id) return;
    for (const f of fields) {
      if (f.required && !values[f.key]?.toString().trim()) {
        toast.error(`${f.label} is required`);
        return;
      }
    }
    setBusy(true);
    const payload: any = { org_id: org.id, ...(defaults ?? {}) };
    for (const f of fields) {
      const raw = values[f.key];
      if (raw === undefined || raw === "") continue;
      payload[f.key] = f.type === "number" ? Number(raw) : raw;
    }
    const { data, error } = await supabase.from(table as any).insert(payload).select().single();
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success(`${title} created`);
    setOpen(false);
    reset();
    onCreated?.(data);
  }

  return (
    <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) reset(); }}>
      <DialogTrigger asChild>
        <Button variant={triggerVariant} style={buttonStyle} className="gap-1.5">
          <Plus className="h-4 w-4" />
          {buttonLabel}
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>{title}</DialogTitle></DialogHeader>
        <div className="space-y-3">
          {fields.map((f) => (
            <div key={f.key}>
              <Label>
                {f.label}
                {f.required && <span className="text-destructive ml-0.5">*</span>}
              </Label>
              {f.type === "textarea" ? (
                <Textarea
                  rows={3}
                  placeholder={f.placeholder}
                  value={values[f.key] ?? ""}
                  onChange={(e) => setValues({ ...values, [f.key]: e.target.value })}
                />
              ) : (
                <Input
                  type={f.type === "number" ? "number" : f.type === "email" ? "email" : f.type === "url" ? "url" : "text"}
                  placeholder={f.placeholder}
                  value={values[f.key] ?? ""}
                  onChange={(e) => setValues({ ...values, [f.key]: e.target.value })}
                />
              )}
            </div>
          ))}
        </div>
        <DialogFooter>
          <Button onClick={submit} disabled={busy}>
            {busy ? "Saving…" : "Create"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
