import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";

const MODULES = [
  { label: "Workforce", accent: "var(--workforce)" },
  { label: "Monitor", accent: "var(--monitor)" },
  { label: "Content", accent: "var(--content)" },
  { label: "Bots", accent: "var(--bots)" },
  { label: "Research", accent: "var(--research)" },
  { label: "Analytics", accent: "var(--analytics)" },
];

export function AuthLayout({
  children,
  eyebrow,
  title,
  subtitle,
}: {
  children: ReactNode;
  eyebrow?: string;
  title: string;
  subtitle?: string;
}) {
  return (
    <div className="grid min-h-dvh lg:grid-cols-[1.05fr_1fr] bg-background">
      {/* Brand panel */}
      <div className="relative hidden lg:flex flex-col justify-between p-12 overflow-hidden text-primary-foreground bg-[var(--primary)]">
        {/* animated mesh */}
        <div aria-hidden className="absolute inset-0 opacity-90">
          <div className="absolute -top-32 -left-24 h-[420px] w-[420px] rounded-full blur-3xl opacity-50"
               style={{ background: "var(--research)", animation: "auth-float 14s ease-in-out infinite" }} />
          <div className="absolute top-1/3 -right-24 h-[480px] w-[480px] rounded-full blur-3xl opacity-40"
               style={{ background: "var(--analytics)", animation: "auth-float 18s ease-in-out infinite reverse" }} />
          <div className="absolute -bottom-32 left-1/4 h-[380px] w-[380px] rounded-full blur-3xl opacity-40"
               style={{ background: "var(--workforce)", animation: "auth-float 16s ease-in-out infinite" }} />
        </div>
        <div aria-hidden className="absolute inset-0 opacity-[0.08]"
             style={{ backgroundImage: "linear-gradient(var(--primary-foreground) 1px, transparent 1px), linear-gradient(90deg, var(--primary-foreground) 1px, transparent 1px)", backgroundSize: "32px 32px" }} />

        <div className="relative">
          <Link to="/login" className="flex items-center gap-2.5">
            <div className="h-10 w-10 rounded-xl bg-primary-foreground/15 backdrop-blur-sm flex items-center justify-center font-bold text-base ring-1 ring-primary-foreground/20">K</div>
            <div className="leading-tight">
              <div className="font-semibold tracking-tight">KhanFly OS</div>
              <div className="text-[11px] text-primary-foreground/60">Unified company platform</div>
            </div>
          </Link>
        </div>

        <div className="relative max-w-lg space-y-6">
          <span className="inline-flex items-center gap-2 text-[11px] uppercase tracking-[0.18em] text-primary-foreground/70">
            <span className="h-px w-8 bg-primary-foreground/40" />
            One login, one brain
          </span>
          <h1 className="text-[2.75rem] leading-[1.05] font-semibold tracking-tight">
            Run your entire company from a <span className="italic text-primary-foreground/90">single</span> operating system.
          </h1>
          <p className="text-primary-foreground/75 text-[15px] leading-relaxed max-w-md">
            Workforce, brand monitoring, content production, chatbots, research and analytics — connected by one database and one AI brain.
          </p>
        </div>

        <div className="relative flex flex-wrap gap-2">
          {MODULES.map((m) => (
            <span
              key={m.label}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] bg-primary-foreground/10 ring-1 ring-primary-foreground/15 backdrop-blur-sm"
            >
              <span className="h-1.5 w-1.5 rounded-full" style={{ background: m.accent }} />
              {m.label}
            </span>
          ))}
        </div>
      </div>

      {/* Form panel */}
      <div className="flex items-center justify-center p-6 sm:p-10">
        <div className="w-full max-w-sm animate-page-in">
          <div className="space-y-1.5 mb-8">
            {eyebrow && (
              <div className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground font-medium">{eyebrow}</div>
            )}
            <h2 className="text-3xl font-semibold tracking-tight">{title}</h2>
            {subtitle && <p className="text-sm text-muted-foreground">{subtitle}</p>}
          </div>
          {children}
        </div>
      </div>
    </div>
  );
}
