import type { ReactNode } from "react";
import { ModuleHero } from "@/components/module-hero";

export function ContentPage({
  title, description, actions, children, hero,
}: { title: string; description?: string; actions?: ReactNode; children: ReactNode; hero?: boolean }) {
  return (
    <div className="p-4 sm:p-6 space-y-5 sm:space-y-6 animate-page-in">
      {hero ? (
        <ModuleHero moduleKey="content" title={title} description={description} actions={actions} />
      ) : (
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3 sm:gap-4">
          <div>
            <h1 className="text-xl sm:text-2xl font-semibold tracking-tight" style={{ color: "var(--content)" }}>{title}</h1>
            {description && <p className="text-sm text-muted-foreground mt-1">{description}</p>}
          </div>
          {actions && <div className="flex items-center gap-2 flex-wrap">{actions}</div>}
        </div>
      )}
      {children}
    </div>
  );
}

export function ContentSkeleton() {
  return (
    <div className="p-6 space-y-4">
      <div className="h-8 w-48 bg-muted rounded animate-pulse" />
      <div className="h-32 rounded animate-pulse" style={{ background: "color-mix(in oklab, var(--content) 12%, transparent)" }} />
      <div className="h-32 rounded animate-pulse" style={{ background: "color-mix(in oklab, var(--content) 8%, transparent)" }} />
    </div>
  );
}

export function ContentStatusPill({ value }: { value: string | null | undefined }) {
  const map: Record<string, { label: string; color: string }> = {
    draft: { label: "📝 Draft", color: "#71717a" },
    scheduled: { label: "🗓 Scheduled", color: "var(--content)" },
    published: { label: "✓ Published", color: "#16a34a" },
    review: { label: "👀 Review", color: "#f59e0b" },
    approved: { label: "✓ Approved", color: "#16a34a" },
    failed: { label: "✗ Failed", color: "#dc2626" },
    sent: { label: "📤 Sent", color: "var(--content)" },
    viewed: { label: "👁 Viewed", color: "#f59e0b" },
    accepted: { label: "✓ Accepted", color: "#16a34a" },
    rejected: { label: "✗ Rejected", color: "#dc2626" },
    paid: { label: "💰 Paid", color: "#16a34a" },
    partial: { label: "◐ Partial", color: "#f59e0b" },
    overdue: { label: "⏰ Overdue", color: "#dc2626" },
    active: { label: "🟢 Active", color: "#16a34a" },
    prospect: { label: "🔍 Prospect", color: "#71717a" },
    paused: { label: "⏸ Paused", color: "#f59e0b" },
    churned: { label: "💔 Churned", color: "#dc2626" },
  };
  const m = value ? (map[value] ?? { label: value, color: "#71717a" }) : null;
  if (!m) return <span className="text-muted-foreground">—</span>;
  return (
    <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium"
      style={{ background: `color-mix(in oklab, ${m.color} 18%, transparent)`, color: m.color }}>
      {m.label}
    </span>
  );
}
