import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Users, Calendar, FileText, Wallet, Plus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { ContentPage, ContentStatusPill } from "./page-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { getContentSummary } from "@/lib/content";

const TEAL = "var(--content)";

function MetricCard({ label, value, sub, icon: Icon, to }:
  { label: string; value: string | number; sub?: string; icon: any; to?: string }) {
  const inner = (
    <Card className="hover:shadow-md transition-shadow cursor-pointer h-full">
      <CardContent className="p-5">
        <div className="flex items-start justify-between">
          <div>
            <div className="text-xs text-muted-foreground uppercase tracking-wider">{label}</div>
            <div className="text-3xl font-bold mt-2" style={{ color: TEAL }}>{value}</div>
            {sub && <div className="text-xs text-muted-foreground mt-1">{sub}</div>}
          </div>
          <div className="rounded-lg p-2" style={{ background: `color-mix(in oklab, ${TEAL} 14%, transparent)`, color: TEAL }}>
            <Icon className="h-5 w-5" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
  return to ? <Link to={to}>{inner}</Link> : inner;
}

export default function ContentDashboard() {
  const { org } = useAuth();
  const orgId = org?.id;
  const [summary, setSummary] = useState<any>(null);
  const [upcomingPosts, setUpcomingPosts] = useState<any[]>([]);
  const [recentInvoices, setRecentInvoices] = useState<any[]>([]);

  useEffect(() => {
    if (!orgId) return;
    getContentSummary(orgId).then(setSummary);
    supabase.from("smm_posts").select("id,title,caption,platform,status,scheduled_at,client_id")
      .eq("org_id", orgId).in("status", ["scheduled", "review"])
      .order("scheduled_at", { ascending: true }).limit(8)
      .then(({ data }) => setUpcomingPosts(data ?? []));
    supabase.from("smm_invoices").select("id,number,amount,amount_paid,status,due_date,client_id")
      .eq("org_id", orgId).order("issue_date", { ascending: false }).limit(6)
      .then(({ data }) => setRecentInvoices(data ?? []));

    const ch = supabase.channel(`content-dash-${orgId}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "smm_posts", filter: `org_id=eq.${orgId}` },
        () => getContentSummary(orgId).then(setSummary))
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [orgId]);

  const s = summary;
  return (
    <ContentPage hero title="Content Studio" description="SMM agency operations: clients, calendar, proposals & invoicing"
      actions={<Link to="/content/calendar"><Button style={{ background: TEAL, color: "white" }}><Plus className="h-4 w-4 mr-1" /> New Post</Button></Link>}>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <MetricCard label="Active clients" value={s?.active_clients ?? "—"} sub={`of ${s?.total_clients ?? 0} total`} icon={Users} to="/content/clients" />
        <MetricCard label="Scheduled posts" value={s?.posts_scheduled ?? "—"} sub={`${s?.posts_published_this_week ?? 0} published this week`} icon={Calendar} to="/content/calendar" />
        <MetricCard label="Open proposals" value={s?.open_proposals ?? "—"} sub={s ? `$${Number(s.open_proposals_value).toLocaleString()} pipeline` : ""} icon={FileText} to="/content/proposals" />
        <MetricCard label="Unpaid invoices" value={s?.unpaid_invoices ?? "—"} sub={s ? `$${Number(s.unpaid_total).toLocaleString()} outstanding` : ""} icon={Wallet} to="/content/invoices" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between"><CardTitle className="text-sm">Upcoming posts</CardTitle>
            <Link to="/content/calendar" className="text-xs text-muted-foreground hover:text-foreground">View calendar →</Link>
          </CardHeader>
          <CardContent className="p-0">
            {upcomingPosts.length === 0 ? (
              <div className="p-8 text-center text-sm text-muted-foreground">No upcoming posts. Create your first one →</div>
            ) : (
              <ul className="divide-y">
                {upcomingPosts.map((p) => (
                  <li key={p.id} className="px-4 py-3 flex items-center gap-3">
                    <div className="text-xs text-muted-foreground w-20 shrink-0">{p.scheduled_at ? new Date(p.scheduled_at).toLocaleDateString() : "—"}</div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium truncate">{p.title || p.caption?.slice(0, 60) || "Untitled post"}</div>
                      <div className="text-xs text-muted-foreground">{p.platform}</div>
                    </div>
                    <ContentStatusPill value={p.status} />
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between"><CardTitle className="text-sm">Recent invoices</CardTitle>
            <Link to="/content/invoices" className="text-xs text-muted-foreground hover:text-foreground">View all →</Link>
          </CardHeader>
          <CardContent className="p-0">
            {recentInvoices.length === 0 ? (
              <div className="p-8 text-center text-sm text-muted-foreground">No invoices yet.</div>
            ) : (
              <ul className="divide-y">
                {recentInvoices.map((i) => (
                  <li key={i.id} className="px-4 py-3 flex items-center gap-3">
                    <div className="text-xs font-mono text-muted-foreground w-24 shrink-0">{i.number}</div>
                    <div className="flex-1 text-sm">${Number(i.amount).toLocaleString()}</div>
                    <ContentStatusPill value={i.status} />
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>
    </ContentPage>
  );
}
