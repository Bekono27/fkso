import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { ContentPage, ContentSkeleton, ContentStatusPill } from "./page-shell";
import { Card, CardContent } from "@/components/ui/card";

export type ContentColumn = { key: string; label: string; render?: (row: any) => React.ReactNode };

export function ContentList({
  title, description, table, columns, orderBy = "created_at", ascending = false,
  emptyMessage = "Nothing here yet.", actions,
}: {
  title: string; description?: string; table: string; columns: ContentColumn[];
  orderBy?: string; ascending?: boolean; emptyMessage?: string; actions?: React.ReactNode;
}) {
  const { org } = useAuth();
  const [rows, setRows] = useState<any[] | null>(null);
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    if (!org?.id) return;
    supabase.from(table as any).select("*").eq("org_id", org.id)
      .order(orderBy, { ascending }).limit(200)
      .then(({ data }) => setRows(data ?? []));
  }, [org?.id, table, orderBy, ascending, reloadKey]);

  if (rows === null) return <ContentSkeleton />;

  return (
    <ContentPage title={title} description={description} actions={
      actions ? <span onClick={() => setTimeout(() => setReloadKey((k) => k + 1), 400)}>{actions}</span> : undefined
    }>
      <Card>
        <CardContent className="p-0">
          {rows.length === 0 ? (
            <div className="p-10 text-center text-sm text-muted-foreground">{emptyMessage}</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/40 text-xs uppercase tracking-wider text-muted-foreground">
                  <tr>{columns.map((c) => <th key={c.key} className="text-left px-4 py-2.5 font-medium">{c.label}</th>)}</tr>
                </thead>
                <tbody className="divide-y">
                  {rows.map((r) => (
                    <tr key={r.id} className="hover:bg-muted/20">
                      {columns.map((c) => <td key={c.key} className="px-4 py-2.5">{c.render ? c.render(r) : (r[c.key] ?? "—")}</td>)}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </ContentPage>
  );
}

export { ContentStatusPill };
