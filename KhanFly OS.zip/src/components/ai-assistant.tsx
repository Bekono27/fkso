import { useEffect, useRef, useState } from "react";
import { useRouterState } from "@tanstack/react-router";
import { Sparkles, X, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import { useAuth } from "@/lib/auth-context";
import { moduleFromPath } from "@/lib/modules";
import { buildPlatformContext } from "@/lib/platform-context";
import { supabase } from "@/integrations/supabase/client";

type Msg = { role: "user" | "assistant"; content: string };

export function AIAssistantPanel() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [context, setContext] = useState<string>("");
  const { org } = useAuth();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const activeMod = moduleFromPath(pathname);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "j") {
        e.preventDefault();
        setOpen((v) => !v);
      }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, []);

  useEffect(() => {
    if (!open || !org?.id) return;
    buildPlatformContext(org.id, activeMod?.key ?? "core").then(setContext);
  }, [open, org?.id, activeMod?.key]);

  useEffect(() => { scrollRef.current?.scrollTo({ top: 999999 }); }, [messages, loading]);

  const send = async () => {
    if (!input.trim() || loading) return;
    const userMsg: Msg = { role: "user", content: input };
    const next = [...messages, userMsg];
    setMessages([...next, { role: "assistant", content: "" }]);
    setInput("");
    setLoading(true);
    try {
      const { data: sess } = await supabase.auth.getSession();
      const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-chat`;
      const res = await fetch(url, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
          authorization: `Bearer ${sess.session?.access_token ?? import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({
          messages: next,
          stream: true,
          system:
            `You are KhanFly OS Assistant, helping the user with their ${activeMod?.label ?? "platform"} work. ` +
            `Keep answers concise and actionable.\n\nCURRENT PLATFORM STATE:\n${context}`,
        }),
      });
      if (!res.ok || !res.body) throw new Error(`AI ${res.status}`);

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buf = "";
      let acc = "";
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += decoder.decode(value, { stream: true });
        const lines = buf.split("\n");
        buf = lines.pop() ?? "";
        for (const line of lines) {
          const t = line.trim();
          if (!t.startsWith("data:")) continue;
          const payload = t.slice(5).trim();
          if (payload === "[DONE]") continue;
          try {
            const json = JSON.parse(payload);
            const delta = json?.choices?.[0]?.delta?.content ?? "";
            if (delta) {
              acc += delta;
              setMessages((cur) => {
                const copy = [...cur];
                copy[copy.length - 1] = { role: "assistant", content: acc };
                return copy;
              });
            }
          } catch { /* skip non-JSON keepalives */ }
        }
      }
      if (!acc) {
        setMessages((cur) => {
          const copy = [...cur];
          copy[copy.length - 1] = { role: "assistant", content: "(no response)" };
          return copy;
        });
      }
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      setMessages((cur) => {
        const copy = [...cur];
        copy[copy.length - 1] = { role: "assistant", content: `(AI error: ${msg})` };
        return copy;
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetContent side="right" className="w-full sm:max-w-md flex flex-col p-0">
        <div className="px-4 py-3 border-b flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-primary" />
          <div className="font-semibold text-sm">AI Assistant</div>
          {activeMod && <span className="text-xs text-muted-foreground">· {activeMod.label}</span>}
          <button onClick={() => setOpen(false)} className="ml-auto text-muted-foreground hover:text-foreground"><X className="h-4 w-4" /></button>
        </div>

        <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
          {messages.length === 0 && (
            <div className="text-sm text-muted-foreground space-y-2">
              <p>Ask anything about your {activeMod?.label.toLowerCase() ?? "workspace"} — leave requests, alerts, posts, bots, revenue.</p>
              {context && <details className="text-xs"><summary className="cursor-pointer">Context loaded</summary>
                <pre className="mt-2 whitespace-pre-wrap text-[10px] bg-muted p-2 rounded max-h-48 overflow-y-auto">{context}</pre>
              </details>}
            </div>
          )}
          {messages.map((m, i) => (
            <div key={i} className={`text-sm ${m.role === "user" ? "text-right" : ""}`}>
              <div className={`inline-block rounded-lg px-3 py-2 max-w-[85%] ${
                m.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted"
              }`}>{m.content}</div>
            </div>
          ))}
          {loading && <div className="text-xs text-muted-foreground">Thinking…</div>}
        </div>

        <div className="border-t p-3 flex gap-2">
          <input
            value={input} onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter") send(); }}
            placeholder="Ask anything…"
            className="flex-1 text-sm rounded-md border bg-background px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <Button size="icon" onClick={send} disabled={loading || !input.trim()}><Send className="h-4 w-4" /></Button>
        </div>
        <div className="px-3 pb-2 text-[10px] text-muted-foreground text-center">⌘J to toggle</div>
      </SheetContent>
    </Sheet>
  );
}
