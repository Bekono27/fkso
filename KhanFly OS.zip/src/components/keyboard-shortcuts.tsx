import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

const SHORTCUTS: { keys: string[]; label: string }[] = [
  { keys: ["⌘", "K"], label: "Open global search" },
  { keys: ["⌘", "J"], label: "Toggle AI assistant" },
  { keys: ["?"], label: "Show this shortcuts overlay" },
  { keys: ["G", "D"], label: "Go to Dashboard" },
  { keys: ["G", "W"], label: "Go to Workforce" },
  { keys: ["G", "M"], label: "Go to Monitor" },
  { keys: ["G", "C"], label: "Go to Content" },
  { keys: ["G", "B"], label: "Go to Bots" },
  { keys: ["Esc"], label: "Close dialogs / panels" },
];

const NAV: Record<string, string> = {
  d: "/dashboard",
  w: "/workforce",
  m: "/monitor",
  c: "/content",
  b: "/bots",
};

export function KeyboardShortcuts() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    let lastG = 0;
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      const typing = tag === "INPUT" || tag === "TEXTAREA" || (e.target as HTMLElement | null)?.isContentEditable;
      if (typing) return;

      // ? overlay
      if (e.key === "?" || (e.shiftKey && e.key === "/")) {
        e.preventDefault();
        setOpen((v) => !v);
        return;
      }

      // g + key navigation
      if (e.key.toLowerCase() === "g") { lastG = Date.now(); return; }
      if (Date.now() - lastG < 1500) {
        const dest = NAV[e.key.toLowerCase()];
        if (dest) { lastG = 0; window.location.assign(dest); }
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Keyboard shortcuts</DialogTitle>
        </DialogHeader>
        <ul className="divide-y text-sm">
          {SHORTCUTS.map((s) => (
            <li key={s.label} className="flex items-center justify-between py-2.5">
              <span className="text-muted-foreground">{s.label}</span>
              <span className="flex gap-1">
                {s.keys.map((k) => (
                  <kbd key={k} className="rounded border bg-muted px-1.5 py-0.5 text-[11px] font-mono">{k}</kbd>
                ))}
              </span>
            </li>
          ))}
        </ul>
        <p className="text-[11px] text-muted-foreground text-center pt-1">Press <kbd className="border rounded px-1">?</kbd> any time to reopen.</p>
      </DialogContent>
    </Dialog>
  );
}
