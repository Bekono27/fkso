import { useEffect, useState } from "react";
import { useRouterState } from "@tanstack/react-router";
import { Plus, X } from "lucide-react";
import { moduleFromPath, MODULES } from "@/lib/modules";
import { QuickCreate, type QCField } from "@/components/quick-create";

type Recipe = {
  key: string;
  label: string;
  module: string;
  accent: string;
  table: string;
  title: string;
  fields: QCField[];
  defaults?: Record<string, unknown>;
};

const RECIPES: Record<string, Recipe[]> = {
  workforce: [
    {
      key: "task",
      label: "Task",
      module: "workforce",
      accent: "var(--workforce)",
      table: "workforce_tasks",
      title: "New task",
      fields: [
        { key: "title", label: "Title", required: true },
        { key: "description", label: "Description", type: "textarea" },
        { key: "due_date", label: "Due date", placeholder: "YYYY-MM-DD" },
      ],
      defaults: { status: "todo", priority: "medium" },
    },
    {
      key: "project",
      label: "Project",
      module: "workforce",
      accent: "var(--workforce)",
      table: "workforce_projects",
      title: "New project",
      fields: [
        { key: "name", label: "Name", required: true },
        { key: "description", label: "Description", type: "textarea" },
      ],
      defaults: { status: "active" },
    },
    {
      key: "announcement",
      label: "Announcement",
      module: "workforce",
      accent: "var(--workforce)",
      table: "announcements",
      title: "New announcement",
      fields: [
        { key: "title", label: "Title", required: true },
        { key: "body", label: "Body", type: "textarea", required: true },
      ],
    },
  ],
  monitor: [
    {
      key: "keyword",
      label: "Keyword",
      module: "monitor",
      accent: "var(--monitor)",
      table: "monitoring_keywords",
      title: "Track new keyword",
      fields: [
        { key: "term", label: "Keyword", required: true },
        { key: "category", label: "Category", placeholder: "brand · product · general" },
      ],
    },
    {
      key: "competitor",
      label: "Competitor",
      module: "monitor",
      accent: "var(--monitor)",
      table: "monitoring_competitors",
      title: "Add competitor",
      fields: [
        { key: "name", label: "Name", required: true },
        { key: "website", label: "Website", type: "url" },
      ],
      defaults: { active: true },
    },
  ],
  content: [
    {
      key: "client",
      label: "Client",
      module: "content",
      accent: "var(--content)",
      table: "smm_clients",
      title: "New client",
      fields: [
        { key: "name", label: "Name", required: true },
        { key: "company", label: "Company" },
        { key: "email", label: "Email", type: "email" },
      ],
      defaults: { status: "prospect" },
    },
    {
      key: "post",
      label: "Post",
      module: "content",
      accent: "var(--content)",
      table: "smm_posts",
      title: "New post",
      fields: [
        { key: "title", label: "Title" },
        { key: "caption", label: "Caption", type: "textarea", required: true },
        { key: "platform", label: "Platform", placeholder: "instagram · facebook · x" },
      ],
      defaults: { status: "draft" },
    },
  ],
  bots: [
    {
      key: "bot",
      label: "Bot",
      module: "bots",
      accent: "var(--bots)",
      table: "bots",
      title: "New bot",
      fields: [
        { key: "name", label: "Name", required: true },
        { key: "description", label: "Description", type: "textarea" },
        { key: "emoji", label: "Emoji", placeholder: "🤖" },
      ],
      defaults: { status: "draft" },
    },
  ],
};

export function QuickCreateFab() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const activeMod = moduleFromPath(pathname);
  const [open, setOpen] = useState(false);

  // Close on route change
  useEffect(() => setOpen(false), [pathname]);

  // Hide on auth, approval, portal routes
  if (
    pathname.startsWith("/login") ||
    pathname.startsWith("/signup") ||
    pathname.startsWith("/forgot-password") ||
    pathname.startsWith("/reset-password") ||
    pathname.startsWith("/approval") ||
    pathname.startsWith("/portal")
  ) {
    return null;
  }

  const moduleKey = activeMod?.key ?? "workforce";
  const recipes = RECIPES[moduleKey] ?? RECIPES.workforce;
  const accent = activeMod ? `var(--${activeMod.accent})` : "var(--primary)";

  return (
    <>
      {/* Backdrop */}
      {open && (
        <div
          className="fixed inset-0 z-40 bg-background/40 backdrop-blur-[2px] animate-in fade-in duration-150"
          onClick={() => setOpen(false)}
        />
      )}

      <div className="fixed bottom-[calc(env(safe-area-inset-bottom)+5rem)] md:bottom-6 right-4 md:right-6 z-50 flex flex-col items-end gap-2.5">
        {open && (
          <div className="flex flex-col items-end gap-2 animate-in slide-in-from-bottom-2 fade-in duration-200">
            {recipes.map((r) => (
              <div
                key={r.key}
                className="flex items-center gap-2.5"
              >
                <div className="px-2.5 py-1 rounded-md bg-card border text-xs font-medium shadow-sm">
                  {r.label}
                </div>
                <div className="rounded-full shadow-lg">
                  <QuickCreate
                    table={r.table}
                    title={r.title}
                    fields={r.fields}
                    defaults={r.defaults}
                    buttonLabel=""
                    buttonStyle={{
                      background: r.accent,
                      color: "white",
                      borderRadius: 9999,
                      height: 40,
                      width: 40,
                      padding: 0,
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        )}

        <button
          onClick={() => setOpen((v) => !v)}
          aria-label={open ? "Close quick create" : "Quick create"}
          className="h-14 w-14 rounded-full text-white shadow-xl ring-1 ring-black/10 flex items-center justify-center transition-all hover:scale-105 active:scale-95"
          style={{
            background: `linear-gradient(135deg, ${accent}, color-mix(in oklab, ${accent} 60%, black))`,
            boxShadow: `0 12px 32px -8px color-mix(in oklab, ${accent} 55%, transparent)`,
          }}
        >
          {open ? <X className="h-5 w-5" /> : <Plus className="h-6 w-6" />}
        </button>
      </div>
    </>
  );
}
