import type { ReactNode } from "react";

export function EwaPage({
  title, description, actions, children,
}: {
  title: string;
  description?: string;
  actions?: ReactNode;
  children: ReactNode;
}) {
  return (
    <div className="p-4 sm:p-6 space-y-5 sm:space-y-6 animate-page-in">
      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3 sm:gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-semibold tracking-tight" style={{ color: "var(--digilend)" }}>{title}</h1>
          {description && <p className="text-sm text-muted-foreground mt-1">{description}</p>}
        </div>
        {actions && <div className="flex items-center gap-2 flex-wrap">{actions}</div>}
      </div>
      {children}
    </div>
  );
}

export const MNT = (n: number | string | null | undefined) =>
  `₮${Number(n ?? 0).toLocaleString("en-US")}`;

export const STATUS_TONE: Record<string, string> = {
  pending: "#f59e0b",
  approved: "#0ea5e9",
  flagged: "#f97316",
  completed: "#16a34a",
  failed: "#ef4444",
  rejected: "#ef4444",
  cancelled: "#6b7280",
};
