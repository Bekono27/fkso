import { Link, useRouterState } from "@tanstack/react-router";
import { LayoutDashboard, Settings, LogOut, Search, CalendarDays,
  Home, Clock, Wallet, Users, Palmtree, ClipboardList, MessageSquare,
  LifeBuoy, Laptop, GraduationCap, Trophy, Megaphone, BarChart3,
  Radio, Bell, Search as SearchIcon, Trophy as TrophyIcon, Bot, ScanLine, FileText,
  Puzzle, Zap, BookOpen, Sparkles, FlaskConical, FolderKanban, TrendingUp, Target, Link2,
  PlusCircle, ListChecks, Building2,
} from "lucide-react";
import { MODULES, moduleFromPath, type ModuleDef } from "@/lib/modules";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { GlobalSearch } from "@/components/global-search";
import { AIAssistantPanel } from "@/components/ai-assistant";
import { NotificationsBell } from "@/components/notifications-bell";
import { MobileTabBar } from "@/components/mobile-tab-bar";
import { KeyboardShortcuts } from "@/components/keyboard-shortcuts";
import { OnboardingTour } from "@/components/onboarding-tour";
import { QuickCreateFab } from "@/components/quick-create-fab";
import type { ReactNode, ComponentType } from "react";

type NavItem = { label: string; to: string; icon: ComponentType<{ className?: string }> };

const MODULE_NAV: Record<ModuleDef["key"], NavItem[]> = {
  workforce: [
    { label: "Overview", to: "/workforce/dashboard", icon: Home },
    { label: "Attendance", to: "/workforce/attendance", icon: Clock },
    { label: "Payroll", to: "/workforce/payroll", icon: Wallet },
    { label: "Employees", to: "/workforce/employees", icon: Users },
    { label: "Leave", to: "/workforce/leave", icon: Palmtree },
    { label: "Projects", to: "/workforce/projects", icon: ClipboardList },
    { label: "Chat", to: "/workforce/chat", icon: MessageSquare },
    { label: "Helpdesk", to: "/workforce/helpdesk", icon: LifeBuoy },
    { label: "Assets", to: "/workforce/assets", icon: Laptop },
    { label: "E-Learning", to: "/workforce/elearning", icon: GraduationCap },
    { label: "Performance", to: "/workforce/performance", icon: Trophy },
    { label: "Announcements", to: "/workforce/announcements", icon: Megaphone },
    { label: "Reports", to: "/workforce/reports", icon: BarChart3 },
  ],
  monitor: [
    { label: "Overview", to: "/monitor/dashboard", icon: Home },
    { label: "Live Feed", to: "/monitor/feed", icon: Radio },
    { label: "Alerts", to: "/monitor/alerts", icon: Bell },
    { label: "Keywords", to: "/monitor/keywords", icon: SearchIcon },
    { label: "Competitors", to: "/monitor/competitors", icon: TrophyIcon },
    { label: "AI Agents", to: "/monitor/agents", icon: Bot },
    { label: "Analytics", to: "/monitor/analytics", icon: BarChart3 },
    { label: "Page Analysis", to: "/monitor/page-analysis", icon: ScanLine },
    { label: "Reports", to: "/monitor/reports", icon: FileText },
  ],
  content: [
    { label: "Overview", to: "/content/dashboard", icon: Home },
    { label: "Calendar", to: "/content/calendar", icon: ClipboardList },
    { label: "Clients", to: "/content/clients", icon: Users },
    { label: "Proposals", to: "/content/proposals", icon: FileText },
    { label: "Invoices", to: "/content/invoices", icon: Wallet },
  ],
  bots: [
    { label: "Overview", to: "/bots/dashboard", icon: Home },
    { label: "My Bots", to: "/bots/list", icon: Bot },
    { label: "Templates", to: "/bots/templates", icon: Puzzle },
    { label: "Live Chat", to: "/bots/chat", icon: MessageSquare },
    { label: "Contacts", to: "/bots/contacts", icon: Users },
    { label: "Broadcasts", to: "/bots/broadcasts", icon: Megaphone },
    { label: "Automation", to: "/bots/automation", icon: Zap },
    { label: "Knowledge Base", to: "/bots/knowledge", icon: BookOpen },
    { label: "Analytics", to: "/bots/analytics", icon: BarChart3 },
  ],
  research: [
    { label: "Overview", to: "/research/dashboard", icon: Home },
    { label: "Projects", to: "/research/projects", icon: FolderKanban },
    { label: "Intelligence", to: "/research/intelligence", icon: TrophyIcon },
    { label: "Trends", to: "/research/trends", icon: TrendingUp },
    { label: "Audience", to: "/research/audience", icon: Users },
    { label: "Reports", to: "/research/reports", icon: FileText },
  ],
  analytics: [
    { label: "Overview", to: "/analytics/dashboard", icon: Home },
    { label: "Workforce", to: "/analytics/workforce", icon: Users },
    { label: "Monitor", to: "/analytics/monitor", icon: Radio },
    { label: "Content", to: "/analytics/content", icon: CalendarDays },
    { label: "Bots", to: "/analytics/bots", icon: Bot },
    { label: "Cross-module", to: "/analytics/cross-module", icon: Link2 },
  ],
  digilend: [
    { label: "Overview", to: "/ewa/dashboard", icon: Home },
    { label: "Шинэ урьдчилгаа", to: "/ewa/request", icon: PlusCircle },
    { label: "Гүйлгээ", to: "/ewa/transactions", icon: ListChecks },
    { label: "Ажилчид", to: "/ewa/employees", icon: Users },
    { label: "Банкны данс", to: "/ewa/bank-accounts", icon: Building2 },
  ],
};

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const activeMod = moduleFromPath(pathname);
  const { profile, org, signOut } = useAuth();
  const moduleSettings = (org?.settings as any)?.modules ?? {};
  const visibleModules = MODULES.filter((m) => moduleSettings[m.key] !== false);
  const subnav = activeMod ? MODULE_NAV[activeMod.key] : null;

  const accentVar = activeMod ? `var(--${activeMod.accent})` : undefined;

  return (
    <div className="flex min-h-screen md:h-screen md:overflow-hidden w-full bg-background">
      {/* Sidebar */}
      <aside className="hidden md:flex md:h-screen md:sticky md:top-0 w-[252px] shrink-0 border-r bg-sidebar text-sidebar-foreground flex-col">
        <div className="px-4 py-4 border-b border-sidebar-border">
          <Link to="/dashboard" className="flex items-center gap-2.5 group">
            <div
              className="h-9 w-9 rounded-xl flex items-center justify-center font-bold text-white shadow-sm ring-1 ring-black/5 transition-transform group-hover:scale-105"
              style={{ background: accentVar ? `linear-gradient(135deg, ${accentVar}, color-mix(in oklab, ${accentVar} 65%, black))` : "var(--primary)" }}
            >
              K
            </div>
            <div className="leading-tight">
              <div className="font-semibold text-sm tracking-tight">KhanFly OS</div>
              <div className="text-[11px] text-muted-foreground truncate max-w-[150px]">{org?.name ?? "Workspace"}</div>
            </div>
          </Link>
        </div>

        <div className="flex-1 overflow-y-auto px-2 py-3">
          <nav className="space-y-0.5">
            <Link
              to="/dashboard"
              className="flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm hover:bg-sidebar-accent transition-colors"
              activeProps={{ className: "bg-sidebar-accent font-medium" }}
              activeOptions={{ exact: true }}
            >
              <LayoutDashboard className="h-4 w-4" />
              Executive
            </Link>
          </nav>

          <div className="px-3 pt-4 pb-1.5 text-[10px] uppercase tracking-[0.14em] text-muted-foreground/80 font-medium">Modules</div>
          <nav className="space-y-0.5">
            {visibleModules.map((m) => {
              const isActive = activeMod?.key === m.key;
              const Icon = m.icon;
              return (
                <Link
                  key={m.key}
                  to={m.basePath}
                  className="group relative flex items-center gap-2.5 rounded-lg px-2.5 py-1.5 text-sm hover:bg-sidebar-accent transition-all"
                  style={isActive ? { background: `color-mix(in oklab, var(--${m.accent}) 12%, transparent)` } : undefined}
                >
                  {isActive && (
                    <span aria-hidden className="absolute left-0 top-2 bottom-2 w-[3px] rounded-r"
                      style={{ background: `var(--${m.accent})` }} />
                  )}
                  <span
                    className="flex h-7 w-7 items-center justify-center rounded-md transition-transform group-hover:scale-105"
                    style={{
                      background: isActive
                        ? `linear-gradient(135deg, var(--${m.accent}), color-mix(in oklab, var(--${m.accent}) 70%, black))`
                        : `color-mix(in oklab, var(--${m.accent}) 16%, transparent)`,
                      color: isActive ? "white" : `var(--${m.accent})`,
                      boxShadow: isActive ? `0 4px 14px -4px color-mix(in oklab, var(--${m.accent}) 60%, transparent)` : undefined,
                    }}
                  >
                    <Icon className="h-3.5 w-3.5" />
                  </span>
                  <div className="flex-1 leading-tight min-w-0">
                    <div className={isActive ? "font-medium truncate" : "truncate"}>{m.label}</div>
                    <div className="text-[10px] text-muted-foreground truncate">{m.origin}</div>
                  </div>
                </Link>
              );
            })}
          </nav>

          {subnav && (
            <>
              <div className="px-3 pt-5 pb-1.5 text-[10px] uppercase tracking-[0.14em] text-muted-foreground/80 font-medium flex items-center gap-1.5">
                <span className="h-1 w-1 rounded-full" style={{ background: `var(--${activeMod!.accent})` }} />
                {activeMod!.label}
              </div>
              <nav className="space-y-px">
                {subnav.map((item) => {
                  const active = pathname === item.to || pathname.startsWith(item.to + "/");
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.to}
                      to={item.to}
                      className="flex items-center gap-2 text-[13px] rounded-md hover:bg-sidebar-accent transition-colors"
                      style={{
                        padding: "6px 12px 6px 14px",
                        borderLeft: `2px solid ${active ? `var(--${activeMod!.accent})` : "transparent"}`,
                        color: active ? `var(--${activeMod!.accent})` : "var(--muted-foreground)",
                        fontWeight: active ? 600 : 400,
                        background: active ? `color-mix(in oklab, var(--${activeMod!.accent}) 8%, transparent)` : undefined,
                      }}
                    >
                      <Icon className="h-3.5 w-3.5 opacity-80" />
                      {item.label}
                    </Link>
                  );
                })}
              </nav>
            </>
          )}
        </div>

        <div className="border-t border-sidebar-border p-2">
          <Link to="/settings" className="flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm hover:bg-sidebar-accent transition-colors">
            <Settings className="h-4 w-4" />
            Settings
          </Link>
        </div>
      </aside>

      {/* Main column */}
      <div className="flex-1 flex flex-col min-w-0 md:overflow-hidden">
        <header className="h-14 border-b bg-background/80 backdrop-blur-md shrink-0 z-30 flex items-center px-3 sm:px-4 gap-1.5 sm:gap-3">
          <div className="text-sm truncate flex items-center gap-2 min-w-0 flex-1 sm:flex-initial">
            {activeMod ? (
              <>
                <span className="h-1.5 w-1.5 rounded-full shrink-0" style={{ background: `var(--${activeMod.accent})` }} />
                <Link to={activeMod.basePath} className="font-medium hover:underline underline-offset-4 truncate" style={{ color: `var(--${activeMod.accent})` }}>{activeMod.label}</Link>
                <span className="text-muted-foreground/40 hidden sm:inline">/</span>
                <span className="text-muted-foreground capitalize hidden sm:inline truncate">{pathname.split("/").filter(Boolean).slice(1).join(" / ") || "Overview"}</span>
              </>
            ) : pathname === "/dashboard" ? (
              <span className="font-medium truncate">Executive</span>
            ) : (
              <span className="text-muted-foreground truncate">{pathname}</span>
            )}
          </div>
          <div className="hidden sm:block flex-1" />
          <button
            onClick={() => window.dispatchEvent(new KeyboardEvent("keydown", { key: "k", metaKey: true }))}
            className="hidden md:flex items-center gap-2 text-xs text-muted-foreground border rounded-lg px-3 py-1.5 hover:bg-accent hover:border-foreground/20 transition-colors min-w-[200px]">
            <Search className="h-3.5 w-3.5" />
            <span className="flex-1 text-left">Search anything…</span>
            <kbd className="text-[10px] border rounded px-1.5 py-0.5 font-mono bg-muted/50">⌘K</kbd>
          </button>
          <button
            aria-label="Search"
            onClick={() => window.dispatchEvent(new KeyboardEvent("keydown", { key: "k", metaKey: true }))}
            className="md:hidden h-9 w-9 inline-flex items-center justify-center rounded-md hover:bg-accent">
            <Search className="h-4 w-4" />
          </button>
          <Button
            variant="ghost" size="sm"
            onClick={() => window.dispatchEvent(new KeyboardEvent("keydown", { key: "j", metaKey: true }))}
            className="gap-1.5 rounded-lg h-9 px-2 sm:px-3"
            aria-label="AI assistant">
            <Sparkles className="h-4 w-4 sm:h-3.5 sm:w-3.5" style={{ color: "var(--analytics)" }} />
            <span className="hidden sm:inline text-xs">AI</span>
            <kbd className="hidden md:inline text-[10px] border rounded px-1 ml-1 font-mono bg-muted/50">⌘J</kbd>
          </Button>
          <NotificationsBell />
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex items-center gap-2 rounded-full border pl-1 pr-1 sm:pr-3 py-1 hover:bg-accent hover:border-foreground/20 transition-colors">
                <div
                  className="h-7 w-7 rounded-full text-primary-foreground text-xs flex items-center justify-center font-medium"
                  style={{ background: accentVar ? `linear-gradient(135deg, ${accentVar}, color-mix(in oklab, ${accentVar} 60%, black))` : "var(--primary)" }}
                >
                  {(profile?.full_name ?? profile?.email ?? "?").slice(0, 1).toUpperCase()}
                </div>
                <span className="text-xs hidden sm:inline max-w-[140px] truncate">{profile?.full_name ?? profile?.email}</span>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel className="font-normal">
                <div className="text-xs text-muted-foreground">Signed in as</div>
                <div className="text-sm truncate">{profile?.email}</div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild><Link to="/settings">Settings</Link></DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => signOut()}><LogOut className="h-4 w-4 mr-2" /> Sign out</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </header>

        <main className="flex-1 overflow-y-auto pb-20 md:pb-0">
          {children}
        </main>
      </div>
      <MobileTabBar />
      <GlobalSearch />
      <AIAssistantPanel />
      <KeyboardShortcuts />
      <OnboardingTour />
      <QuickCreateFab />
    </div>
  );
}


