import { useEffect, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Sparkles, Briefcase, Eye, CalendarDays, Bot, Search, ArrowRight } from "lucide-react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth-context";

const KEY = "kf_onboarded_v1";

const STEPS = [
  {
    icon: Sparkles,
    accent: "var(--primary)",
    title: "Welcome to KhanFly OS",
    body: "Four powerful modules in one workspace. We've seeded a demo organization, employee, client, bot, and keyword so you can explore right away.",
  },
  { icon: Briefcase, accent: "var(--workforce)", title: "Workforce — TimeFlow", body: "Attendance, payroll, leave, employees, projects, performance. Your HR + ops cockpit." },
  { icon: Eye, accent: "var(--monitor)", title: "Monitor — OmniSight", body: "Brand listening across the web. AI sentiment scoring + alerts that auto-create tasks for high severity." },
  { icon: CalendarDays, accent: "var(--content)", title: "Content — SMM Agency", body: "Calendar, AI captions, client portal, proposals, invoices. Run a content agency end-to-end." },
  { icon: Bot, accent: "var(--bots)", title: "Bots — FlowBot", body: "No-code chatbot builder, broadcasts, contacts, knowledge base. Deploy across channels." },
  {
    icon: Sparkles,
    accent: "var(--primary)",
    title: "AI assistant + search, anywhere",
    body: "Press ⌘K for global search across every entity. Press ⌘J to chat with the AI assistant about whatever module you're in. Press ? to see all shortcuts.",
  },
];

export function OnboardingTour() {
  const { user, loading } = useAuth();
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    if (loading || !user) return;
    if (typeof localStorage !== "undefined" && !localStorage.getItem(KEY)) {
      setTimeout(() => setOpen(true), 700);
    }
  }, [user, loading]);

  const finish = () => {
    localStorage.setItem(KEY, "1");
    setOpen(false);
  };
  const next = () => (step < STEPS.length - 1 ? setStep(step + 1) : finish());
  const cur = STEPS[step];
  const Icon = cur.icon;

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) finish(); }}>
      <DialogContent className="max-w-lg p-0 overflow-hidden">
        <div className="h-1.5 bg-muted">
          <div className="h-full transition-all" style={{ width: `${((step + 1) / STEPS.length) * 100}%`, background: cur.accent }} />
        </div>
        <div className="p-7">
          <div
            className="h-14 w-14 rounded-2xl flex items-center justify-center mb-5"
            style={{ background: `color-mix(in oklab, ${cur.accent} 16%, transparent)`, color: cur.accent }}
          >
            <Icon className="h-7 w-7" />
          </div>
          <h2 className="text-xl font-semibold mb-2">{cur.title}</h2>
          <p className="text-sm text-muted-foreground leading-relaxed">{cur.body}</p>

          {step === STEPS.length - 1 && (
            <div className="mt-5 grid grid-cols-2 gap-2 text-xs">
              <button
                onClick={() => { finish(); window.dispatchEvent(new KeyboardEvent("keydown", { key: "k", metaKey: true })); }}
                className="flex items-center gap-2 rounded-md border px-3 py-2 hover:bg-accent"
              >
                <Search className="h-3.5 w-3.5" /> Try ⌘K search
              </button>
              <button
                onClick={() => { finish(); window.dispatchEvent(new KeyboardEvent("keydown", { key: "j", metaKey: true })); }}
                className="flex items-center gap-2 rounded-md border px-3 py-2 hover:bg-accent"
              >
                <Sparkles className="h-3.5 w-3.5" /> Try ⌘J AI
              </button>
            </div>
          )}

          <div className="mt-6 flex items-center justify-between">
            <button onClick={finish} className="text-xs text-muted-foreground hover:underline">Skip tour</button>
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">{step + 1} / {STEPS.length}</span>
              <Button onClick={next} style={{ background: cur.accent, color: "white" }}>
                {step < STEPS.length - 1 ? <>Next <ArrowRight className="h-4 w-4 ml-1" /></> : "Get started"}
              </Button>
            </div>
          </div>

          {step > 0 && step < STEPS.length - 1 && (
            <button
              onClick={() => { finish(); navigate({ to: STEPS[step].title.toLowerCase().includes("workforce") ? "/workforce" : STEPS[step].title.toLowerCase().includes("monitor") ? "/monitor" : STEPS[step].title.toLowerCase().includes("content") ? "/content" : "/bots" } as any); }}
              className="mt-3 text-xs text-muted-foreground hover:underline"
            >
              Jump to this module →
            </button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
