import { useEffect, useMemo, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { WorkforcePage, PageSkeleton } from "../page-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { QuickCreate } from "@/components/quick-create";
import { Search, Laptop, CheckCircle2, UserPlus, Wrench } from "lucide-react";
import { toast } from "sonner";

const STATUS = ["all", "available", "assigned", "maintenance", "retired"] as const;

const statusTone = (s: string) => {
  if (s === "assigned") return "var(--workforce)";
  if (s === "available") return "#10b981";
  if (s === "maintenance") return "#f59e0b";
  if (s === "retired") return "#64748b";
  return "var(--muted-foreground)";
};

export default function AssetsPage() {
  const { org } = useAuth();
  const [rows, setRows] = useState<any[] | null>(null);
  const [employees, setEmployees] = useState<any[]>([]);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<(typeof STATUS)[number]>("all");
  const [reload, setReload] = useState(0);
  const [assigning, setAssigning] = useState<any | null>(null);
  const [pickEmp, setPickEmp] = useState<string>("");

  useEffect(() => {
    if (!org?.id) return;
    supabase.from("assets").select("*").eq("org_id", org.id).order("created_at", { ascending: false }).limit(500)
      .then(({ data }) => setRows(data ?? []));
    supabase.from("employees").select("id, full_name").eq("org_id", org.id).order("full_name")
      .then(({ data }) => setEmployees(data ?? []));
  }, [org?.id, reload]);

  const empName = (id: string | null | undefined) => employees.find((e) => e.id === id)?.full_name ?? "—";

  const assign = async () => {
    if (!assigning || !pickEmp) return;
    const { error } = await supabase.from("assets").update({
      assigned_to: pickEmp, assigned_at: new Date().toISOString(), status: "assigned",
    } as any).eq("id", assigning.id);
    if (error) return toast.error(error.message);
    toast.success(`Assigned to ${empName(pickEmp)}`);
    setAssigning(null); setPickEmp("");
    setReload((k) => k + 1);
  };

  const returnAsset = async (a: any) => {
    const { error } = await supabase.from("assets").update({
      assigned_to: null, assigned_at: null, status: "available",
    } as any).eq("id", a.id);
    if (error) return toast.error(error.message);
    toast.success("Marked available");
    setReload((k) => k + 1);
  };

  const setStatus = async (a: any, status: string) => {
    const { error } = await supabase.from("assets").update({ status } as any).eq("id", a.id);
    if (error) return toast.error(error.message);
    setReload((k) => k + 1);
  };

  if (rows === null) return <PageSkeleton />;

  const counts = {
    all: rows.length,
    available: rows.filter((r) => r.status === "available").length,
    assigned: rows.filter((r) => r.status === "assigned").length,
    maintenance: rows.filter((r) => r.status === "maintenance").length,
    retired: rows.filter((r) => r.status === "retired").length,
  };
  const totalValue = rows.reduce((s, r) => s + Number(r.purchase_cost ?? 0), 0);

  const visible = useMemo(() => {
    let r = filter === "all" ? rows : rows.filter((x) => x.status === filter);
    if (search.trim()) {
      const q = search.toLowerCase();
      r = r.filter((x) =>
        x.name.toLowerCase().includes(q) ||
        (x.asset_tag ?? "").toLowerCase().includes(q) ||
        (x.serial_number ?? "").toLowerCase().includes(q) ||
        (x.category ?? "").toLowerCase().includes(q)
      );
    }
    return r;
  }, [rows, filter, search]);

  return (
    <WorkforcePage
      title="Assets"
      description={`${counts.all} items · ${counts.assigned} assigned · ${counts.available} available`}
      actions={
        <QuickCreate
          table="assets"
          title="New asset"
          buttonLabel="Add asset"
          buttonStyle={{ background: "var(--workforce)", color: "white" }}
          fields={[
            { key: "name", label: "Name", required: true, placeholder: "MacBook Pro 14" },
            { key: "category", label: "Category", placeholder: "laptop / phone / monitor" },
            { key: "asset_tag", label: "Asset tag", placeholder: "KF-001" },
            { key: "serial_number", label: "Serial #" },
          ]}
          defaults={{ status: "available" }}
          onCreated={() => setReload((k) => k + 1)}
        />
      }
    >
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatTile icon={<Laptop className="h-4 w-4" />} label="Total" value={counts.all} tone="var(--workforce)" />
        <StatTile icon={<UserPlus className="h-4 w-4" />} label="Assigned" value={counts.assigned} tone="var(--workforce)" />
        <StatTile icon={<CheckCircle2 className="h-4 w-4" />} label="Available" value={counts.available} tone="#10b981" />
        <StatTile icon={<Wrench className="h-4 w-4" />} label="Value" value={totalValue ? `$${(totalValue / 1000).toFixed(1)}k` : "—"} tone="#8b5cf6" />
      </div>

      <div className="flex flex-wrap items-center gap-2">
        {STATUS.map((s) => (
          <Button key={s} size="sm" variant={filter === s ? "default" : "outline"} className="capitalize h-8" onClick={() => setFilter(s)}>
            {s} <span className="ml-1.5 opacity-60">{counts[s]}</span>
          </Button>
        ))}
        <div className="relative ml-auto w-64">
          <Search className="h-3.5 w-3.5 absolute left-2.5 top-2.5 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search name, tag, serial…" className="h-8 pl-8" />
        </div>
      </div>

      <Card><CardContent className="p-0">
        {visible.length === 0 ? (
          <div className="p-10 text-center text-sm text-muted-foreground">No assets in this view.</div>
        ) : (
          <div className="divide-y">
            {visible.map((a) => {
              const tone = statusTone(a.status);
              return (
                <div key={a.id} className="flex items-center gap-3 px-4 py-3 hover:bg-muted/30">
                  <div className="h-9 w-9 rounded-md flex items-center justify-center" style={{ background: `color-mix(in oklab, ${tone} 14%, transparent)`, color: tone }}>
                    <Laptop className="h-4 w-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-sm truncate">{a.name}</div>
                    <div className="text-[11px] text-muted-foreground">
                      {a.category ?? "—"} · {a.asset_tag ?? "no tag"} {a.serial_number && <>· SN {a.serial_number}</>}
                    </div>
                    {a.assigned_to && (
                      <div className="text-[11px] mt-0.5" style={{ color: "var(--workforce)" }}>
                        Assigned to {empName(a.assigned_to)}{a.assigned_at && <> · {new Date(a.assigned_at).toLocaleDateString()}</>}
                      </div>
                    )}
                  </div>
                  <Badge variant="outline" className="capitalize" style={{ background: `color-mix(in oklab, ${tone} 14%, transparent)`, color: tone, borderColor: "transparent" }}>
                    {a.status}
                  </Badge>
                  <div className="flex gap-1.5">
                    {a.assigned_to ? (
                      <Button size="sm" variant="outline" onClick={() => returnAsset(a)}>Return</Button>
                    ) : (
                      <Button size="sm" style={{ background: "var(--workforce)", color: "white" }} onClick={() => { setAssigning(a); setPickEmp(""); }}>
                        <UserPlus className="h-3.5 w-3.5 mr-1" /> Assign
                      </Button>
                    )}
                    <Select value={a.status} onValueChange={(v) => setStatus(a, v)}>
                      <SelectTrigger className="h-8 w-[130px]"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="available">Available</SelectItem>
                        <SelectItem value="assigned">Assigned</SelectItem>
                        <SelectItem value="maintenance">Maintenance</SelectItem>
                        <SelectItem value="retired">Retired</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent></Card>

      <Dialog open={!!assigning} onOpenChange={(o) => !o && setAssigning(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Assign {assigning?.name}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="text-xs text-muted-foreground">Pick an employee to hand this asset over to.</div>
            <Select value={pickEmp} onValueChange={setPickEmp}>
              <SelectTrigger><SelectValue placeholder="Select employee…" /></SelectTrigger>
              <SelectContent>
                {employees.map((e) => <SelectItem key={e.id} value={e.id}>{e.full_name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAssigning(null)}>Cancel</Button>
            <Button onClick={assign} disabled={!pickEmp}>Assign</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </WorkforcePage>
  );
}

function StatTile({ icon, label, value, tone }: { icon: React.ReactNode; label: string; value: number | string; tone: string }) {
  return (
    <Card>
      <CardContent className="p-3 flex items-center gap-3">
        <div className="h-8 w-8 rounded-md flex items-center justify-center" style={{ background: `color-mix(in oklab, ${tone} 14%, transparent)`, color: tone }}>
          {icon}
        </div>
        <div className="min-w-0">
          <div className="text-[11px] text-muted-foreground uppercase tracking-wide">{label}</div>
          <div className="text-lg font-semibold leading-tight">{value}</div>
        </div>
      </CardContent>
    </Card>
  );
}
