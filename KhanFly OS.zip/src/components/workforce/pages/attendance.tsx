import { useEffect, useMemo, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { WorkforcePage, PageSkeleton } from "../page-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { todayISO } from "@/lib/workforce";
import { Clock, Users, Timer, LogIn, LogOut, Search } from "lucide-react";
import { toast } from "sonner";

const fmtTime = (iso: string) => new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
const fmtElapsed = (ms: number) => {
  const m = Math.floor(ms / 60000);
  const h = Math.floor(m / 60);
  return `${h}h ${m % 60}m`;
};

export default function AttendancePage() {
  const { org, user } = useAuth();
  const [empId, setEmpId] = useState<string | null>(null);
  const [active, setActive] = useState<any | null>(null);
  const [today, setToday] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [now, setNow] = useState(Date.now());

  // ticking clock for active session
  useEffect(() => {
    if (!active) return;
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, [active]);

  const load = async () => {
    if (!org?.id || !user?.id) return;
    const { data: e } = await supabase.from("employees").select("id").eq("org_id", org.id).eq("user_id", user.id).maybeSingle();
    setEmpId(e?.id ?? null);
    const { data: act } = await supabase.from("work_sessions")
      .select("*").eq("org_id", org.id).eq("employee_id", e?.id ?? "")
      .eq("date", todayISO()).is("clock_out", null).maybeSingle();
    setActive(act);
    const { data: list } = await supabase.from("work_sessions")
      .select("*,employees!inner(full_name)").eq("org_id", org.id).eq("date", todayISO())
      .order("clock_in", { ascending: false }).limit(100);
    setToday(list ?? []);
    setLoading(false);
  };
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [org?.id, user?.id]);

  useEffect(() => {
    if (!org?.id) return;
    const ch = supabase.channel("attendance-" + org.id)
      .on("postgres_changes", { event: "*", schema: "public", table: "work_sessions", filter: `org_id=eq.${org.id}` }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
    // eslint-disable-next-line
  }, [org?.id]);

  const clockIn = async () => {
    if (!org?.id || !empId) return toast.error("No employee profile");
    const { error } = await supabase.from("work_sessions").insert({
      org_id: org.id, employee_id: empId, date: todayISO(),
      clock_in: new Date().toISOString(), status: "active", clock_in_method: "manual",
    } as any);
    if (error) return toast.error(error.message);
    toast.success("Clocked in");
    load();
  };
  const clockOut = async () => {
    if (!active) return;
    const t = new Date();
    const total = Math.round((t.getTime() - new Date(active.clock_in).getTime()) / 60000);
    const { error } = await supabase.from("work_sessions").update({
      clock_out: t.toISOString(), status: "completed",
      total_minutes: total, clock_out_method: "manual",
    } as any).eq("id", active.id);
    if (error) return toast.error(error.message);
    toast.success("Clocked out");
    load();
  };

  const stats = useMemo(() => {
    const activeNow = today.filter((s) => !s.clock_out).length;
    const completed = today.filter((s) => s.clock_out).length;
    const totalMin = today.reduce((sum, s) => sum + (s.total_minutes ?? 0), 0);
    return { activeNow, completed, totalHours: (totalMin / 60).toFixed(1) };
  }, [today]);

  const visible = useMemo(() => {
    if (!search.trim()) return today;
    const q = search.toLowerCase();
    return today.filter((s) => (s.employees?.full_name ?? "").toLowerCase().includes(q));
  }, [today, search]);

  if (loading) return <PageSkeleton />;

  return (
    <WorkforcePage
      title="Attendance"
      description={`${stats.activeNow} clocked in · ${stats.completed} finished · ${stats.totalHours}h total today`}
      actions={
        active ? (
          <Button onClick={clockOut} variant="destructive"><LogOut className="h-4 w-4 mr-1.5" /> Clock out</Button>
        ) : (
          <Button onClick={clockIn} style={{ background: "var(--workforce)", color: "white" }}>
            <LogIn className="h-4 w-4 mr-1.5" /> Clock in
          </Button>
        )
      }
    >
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatTile icon={<Users className="h-4 w-4" />} label="Active now" value={stats.activeNow} tone="var(--workforce)" />
        <StatTile icon={<Clock className="h-4 w-4" />} label="Completed" value={stats.completed} tone="#0ea5e9" />
        <StatTile icon={<Timer className="h-4 w-4" />} label="Hours today" value={`${stats.totalHours}h`} tone="#8b5cf6" />
        <StatTile icon={<Users className="h-4 w-4" />} label="Sessions" value={today.length} tone="#64748b" />
      </div>

      {active && (
        <Card className="border-l-4" style={{ borderLeftColor: "var(--workforce)" }}>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="absolute inline-flex h-full w-full rounded-full opacity-75 animate-ping" style={{ background: "var(--workforce)" }} />
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5" style={{ background: "var(--workforce)" }} />
                </span>
                Active session
              </CardTitle>
              <div className="text-xl font-mono font-semibold" style={{ color: "var(--workforce)" }}>
                {fmtElapsed(now - new Date(active.clock_in).getTime())}
              </div>
            </div>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground pt-0">
            Started {fmtTime(active.clock_in)}
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between gap-2">
            <CardTitle className="text-base">Today's clock activity</CardTitle>
            <div className="relative w-56">
              <Search className="h-3.5 w-3.5 absolute left-2.5 top-2.5 text-muted-foreground" />
              <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search employee…" className="h-8 pl-8" />
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {visible.length === 0 ? (
            <div className="p-8 text-center text-sm text-muted-foreground">No clock events today.</div>
          ) : (
            <table className="w-full text-sm">
              <thead className="text-xs uppercase tracking-wider text-muted-foreground bg-muted/40">
                <tr>
                  <th className="text-left px-4 py-2">Employee</th>
                  <th className="text-left px-4 py-2">Clock in</th>
                  <th className="text-left px-4 py-2">Clock out</th>
                  <th className="text-left px-4 py-2">Hours</th>
                  <th className="text-left px-4 py-2">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {visible.map((s: any) => {
                  const isActive = !s.clock_out;
                  const liveMin = isActive ? Math.floor((now - new Date(s.clock_in).getTime()) / 60000) : (s.total_minutes ?? 0);
                  return (
                    <tr key={s.id} className="hover:bg-muted/30">
                      <td className="px-4 py-2 font-medium">{s.employees?.full_name}</td>
                      <td className="px-4 py-2 font-mono text-xs">{fmtTime(s.clock_in)}</td>
                      <td className="px-4 py-2 font-mono text-xs">{s.clock_out ? fmtTime(s.clock_out) : "—"}</td>
                      <td className="px-4 py-2 font-mono text-xs">{(liveMin / 60).toFixed(1)}h</td>
                      <td className="px-4 py-2">
                        {isActive ? (
                          <span className="inline-flex items-center gap-1.5 text-xs px-2 py-0.5 rounded-full" style={{ background: "color-mix(in oklab, var(--workforce) 14%, transparent)", color: "var(--workforce)" }}>
                            <span className="h-1.5 w-1.5 rounded-full animate-pulse" style={{ background: "var(--workforce)" }} />
                            Active
                          </span>
                        ) : (
                          <span className="text-xs text-muted-foreground">Done</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </CardContent>
      </Card>
    </WorkforcePage>
  );
}

function StatTile({ icon, label, value, tone }: { icon: React.ReactNode; label: string; value: number | string; tone: string }) {
  return (
    <Card>
      <CardContent className="p-3 flex items-center gap-3">
        <div className="h-8 w-8 rounded-md flex items-center justify-center" style={{ background: `color-mix(in oklab, ${tone} 14%, transparent)`, color: tone }}>
          {icon}
        </div>
        <div className="min-w-0">
          <div className="text-[11px] text-muted-foreground uppercase tracking-wide">{label}</div>
          <div className="text-lg font-semibold leading-tight">{value}</div>
        </div>
      </CardContent>
    </Card>
  );
}
