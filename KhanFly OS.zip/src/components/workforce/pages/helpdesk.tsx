import { useEffect, useMemo, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { WorkforcePage, PageSkeleton } from "../page-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { writeEvent, indexEntity } from "@/lib/workforce";
import { QuickCreate } from "@/components/quick-create";
import { Search, Clock, AlertCircle, CheckCircle2, RotateCcw } from "lucide-react";
import { toast } from "sonner";

const STATUS_FILTERS = ["all", "open", "in_progress", "resolved"] as const;
const PRIORITIES = ["low", "medium", "high", "urgent"] as const;

const priorityColor = (p: string) => {
  if (p === "urgent") return { bg: "color-mix(in oklab, #ef4444 24%, transparent)", fg: "#b91c1c" };
  if (p === "high") return { bg: "color-mix(in oklab, #f59e0b 22%, transparent)", fg: "#b45309" };
  if (p === "medium") return { bg: "color-mix(in oklab, var(--workforce) 14%, transparent)", fg: "var(--workforce)" };
  return { bg: "color-mix(in oklab, var(--workforce) 8%, transparent)", fg: "var(--muted-foreground)" };
};

export default function HelpdeskPage() {
  const { org, user } = useAuth();
  const [rows, setRows] = useState<any[] | null>(null);
  const [employees, setEmployees] = useState<any[]>([]);
  const [filter, setFilter] = useState<(typeof STATUS_FILTERS)[number]>("all");
  const [priorityFilter, setPriorityFilter] = useState<string>("all");
  const [search, setSearch] = useState("");
  const [reload, setReload] = useState(0);
  const [active, setActive] = useState<any | null>(null);

  useEffect(() => {
    if (!org?.id) return;
    supabase.from("helpdesk_tickets").select("*").eq("org_id", org.id)
      .order("created_at", { ascending: false }).limit(200)
      .then(({ data }) => setRows(data ?? []));
    supabase.from("employees").select("id, full_name").eq("org_id", org.id)
      .then(({ data }) => setEmployees(data ?? []));
  }, [org?.id, reload]);

  const empName = (id: string | null | undefined) => employees.find((e) => e.id === id)?.full_name ?? "Unassigned";

  const updateStatus = async (t: any, status: string) => {
    if (!org?.id) return;
    const patch: any = { status };
    if (status === "resolved") patch.resolved_at = new Date().toISOString();
    if (status === "open") patch.resolved_at = null;
    const { error } = await supabase.from("helpdesk_tickets").update(patch).eq("id", t.id);
    if (error) return toast.error(error.message);
    if (status === "resolved") {
      const hours = (Date.now() - new Date(t.created_at).getTime()) / 3600000;
      await writeEvent(org.id, "workforce", "ticket_resolved", {
        ticket_id: t.id, title: t.title, resolved_by: user?.id, resolution_time_hours: Math.round(hours * 10) / 10,
      }, user?.id);
      await indexEntity({
        org_id: org.id, module: "workforce", entity_type: "ticket", entity_id: t.id,
        title: t.title, subtitle: `${t.priority} · resolved`, keywords: t.description ?? "",
        url: `/workforce/helpdesk`,
      });
    }
    toast.success(status === "resolved" ? "Ticket resolved" : `Marked ${status.replace("_", " ")}`);
    setReload((k) => k + 1);
    if (active?.id === t.id) setActive({ ...active, ...patch });
  };

  const patchTicket = async (t: any, patch: Record<string, any>) => {
    const { error } = await supabase.from("helpdesk_tickets").update(patch as any).eq("id", t.id);
    if (error) return toast.error(error.message);
    setActive((a: any) => (a?.id === t.id ? { ...a, ...patch } : a));
    setReload((k) => k + 1);
  };

  if (rows === null) return <PageSkeleton />;
  const counts = {
    all: rows.length,
    open: rows.filter((t) => t.status === "open").length,
    in_progress: rows.filter((t) => t.status === "in_progress").length,
    resolved: rows.filter((t) => t.status === "resolved").length,
  };

  const visible = useMemo(() => {
    let r = filter === "all" ? rows : rows.filter((t) => t.status === filter);
    if (priorityFilter !== "all") r = r.filter((t) => t.priority === priorityFilter);
    if (search.trim()) {
      const q = search.toLowerCase();
      r = r.filter((t) => t.title.toLowerCase().includes(q) || (t.description ?? "").toLowerCase().includes(q));
    }
    return r;
  }, [rows, filter, priorityFilter, search]);

  // average resolution time
  const resolved = rows.filter((t) => t.status === "resolved" && t.resolved_at);
  const avgHours = resolved.length
    ? resolved.reduce((s, t) => s + (new Date(t.resolved_at).getTime() - new Date(t.created_at).getTime()) / 3600000, 0) / resolved.length
    : 0;

  return (
    <WorkforcePage
      title="Helpdesk"
      description={`${counts.open} open · ${counts.in_progress} in progress · ${counts.resolved} resolved`}
      actions={
        <QuickCreate
          table="helpdesk_tickets"
          title="New ticket"
          buttonLabel="New ticket"
          buttonStyle={{ background: "var(--workforce)", color: "white" }}
          fields={[
            { key: "title", label: "Title", required: true },
            { key: "description", label: "Description", type: "textarea" },
            { key: "category", label: "Category", placeholder: "IT, HR, Facilities…" },
          ]}
          defaults={{ status: "open", priority: "medium", reporter_id: user?.id }}
          onCreated={() => setReload((k) => k + 1)}
        />
      }
    >
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatTile icon={<AlertCircle className="h-4 w-4" />} label="Open" value={counts.open} tone="#ef4444" />
        <StatTile icon={<Clock className="h-4 w-4" />} label="In progress" value={counts.in_progress} tone="#f59e0b" />
        <StatTile icon={<CheckCircle2 className="h-4 w-4" />} label="Resolved" value={counts.resolved} tone="var(--workforce)" />
        <StatTile icon={<Clock className="h-4 w-4" />} label="Avg resolve" value={avgHours ? `${avgHours.toFixed(1)}h` : "—"} tone="var(--workforce)" />
      </div>

      <div className="flex flex-wrap items-center gap-2">
        {STATUS_FILTERS.map((s) => (
          <Button
            key={s}
            size="sm"
            variant={filter === s ? "default" : "outline"}
            onClick={() => setFilter(s)}
            className="capitalize h-8"
          >
            {s.replace("_", " ")} <span className="ml-1.5 opacity-60">{counts[s]}</span>
          </Button>
        ))}
        <div className="h-6 w-px bg-border mx-1" />
        <Select value={priorityFilter} onValueChange={setPriorityFilter}>
          <SelectTrigger className="h-8 w-[130px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All priorities</SelectItem>
            {PRIORITIES.map((p) => <SelectItem key={p} value={p} className="capitalize">{p}</SelectItem>)}
          </SelectContent>
        </Select>
        <div className="relative ml-auto">
          <Search className="h-3.5 w-3.5 absolute left-2.5 top-2.5 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search tickets…" className="h-8 pl-8 w-56" />
        </div>
      </div>

      <Card><CardContent className="p-0">
        {visible.length === 0 ? (
          <div className="p-10 text-center text-sm text-muted-foreground">No tickets in this view.</div>
        ) : (
          <div className="divide-y">
            {visible.map((t) => {
              const pc = priorityColor(t.priority);
              return (
                <div key={t.id} className="flex items-start gap-3 px-4 py-3 hover:bg-muted/30 cursor-pointer" onClick={() => setActive(t)}>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-sm truncate">{t.title}</div>
                    {t.description && <div className="text-xs text-muted-foreground line-clamp-1 mt-0.5">{t.description}</div>}
                    <div className="text-[11px] text-muted-foreground mt-1">
                      {t.category ?? "—"} · {empName(t.assignee_id)} · {new Date(t.created_at).toLocaleDateString()}
                    </div>
                  </div>
                  <Badge variant="outline" className="capitalize" style={{ background: pc.bg, color: pc.fg, borderColor: "transparent" }}>{t.priority}</Badge>
                  <Badge variant="outline" className="capitalize">{t.status.replace("_", " ")}</Badge>
                  <div className="flex gap-1" onClick={(e) => e.stopPropagation()}>
                    {t.status === "open" && (
                      <Button size="sm" variant="outline" onClick={() => updateStatus(t, "in_progress")}>Start</Button>
                    )}
                    {t.status !== "resolved" ? (
                      <Button size="sm" style={{ background: "var(--workforce)", color: "white" }} onClick={() => updateStatus(t, "resolved")}>Resolve</Button>
                    ) : (
                      <Button size="sm" variant="outline" onClick={() => updateStatus(t, "open")}>
                        <RotateCcw className="h-3 w-3 mr-1" /> Reopen
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent></Card>

      <Dialog open={!!active} onOpenChange={(o) => !o && setActive(null)}>
        <DialogContent className="max-w-lg">
          {active && (
            <>
              <DialogHeader><DialogTitle>{active.title}</DialogTitle></DialogHeader>
              <div className="space-y-3">
                <div>
                  <Label>Description</Label>
                  <Textarea
                    rows={4}
                    value={active.description ?? ""}
                    onChange={(e) => setActive({ ...active, description: e.target.value })}
                    onBlur={() => patchTicket(active, { description: active.description })}
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>Priority</Label>
                    <Select value={active.priority} onValueChange={(v) => patchTicket(active, { priority: v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {PRIORITIES.map((p) => <SelectItem key={p} value={p} className="capitalize">{p}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Status</Label>
                    <Select value={active.status} onValueChange={(v) => updateStatus(active, v)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="open">Open</SelectItem>
                        <SelectItem value="in_progress">In progress</SelectItem>
                        <SelectItem value="resolved">Resolved</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <Label>Assignee</Label>
                  <Select
                    value={active.assignee_id ?? "unassigned"}
                    onValueChange={(v) => patchTicket(active, { assignee_id: v === "unassigned" ? null : v })}
                  >
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="unassigned">Unassigned</SelectItem>
                      {employees.map((e) => <SelectItem key={e.id} value={e.id}>{e.full_name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="text-[11px] text-muted-foreground">
                  Created {new Date(active.created_at).toLocaleString()}
                  {active.resolved_at && <> · Resolved {new Date(active.resolved_at).toLocaleString()}</>}
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setActive(null)}>Close</Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </WorkforcePage>
  );
}

function StatTile({ icon, label, value, tone }: { icon: React.ReactNode; label: string; value: number | string; tone: string }) {
  return (
    <Card>
      <CardContent className="p-3 flex items-center gap-3">
        <div className="h-8 w-8 rounded-md flex items-center justify-center" style={{ background: `color-mix(in oklab, ${tone} 14%, transparent)`, color: tone }}>
          {icon}
        </div>
        <div className="min-w-0">
          <div className="text-[11px] text-muted-foreground uppercase tracking-wide">{label}</div>
          <div className="text-lg font-semibold leading-tight">{value}</div>
        </div>
      </CardContent>
    </Card>
  );
}
