import { useEffect, useMemo, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { WorkforcePage, PageSkeleton } from "../page-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { QuickCreate } from "@/components/quick-create";
import { Search, BookOpen, GraduationCap, CheckCircle2, Clock, Eye, EyeOff, PlayCircle } from "lucide-react";
import { toast } from "sonner";

const TABS = ["all", "published", "drafts", "my"] as const;

export default function ELearningPage() {
  const { org, user, roles } = useAuth();
  const isAdmin = roles.includes("admin") || roles.includes("ceo") || roles.includes("manager");
  const [courses, setCourses] = useState<any[] | null>(null);
  const [enrollments, setEnrollments] = useState<any[]>([]);
  const [empId, setEmpId] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [tab, setTab] = useState<(typeof TABS)[number]>("published");
  const [reload, setReload] = useState(0);
  const [editing, setEditing] = useState<any | null>(null);

  useEffect(() => {
    if (!org?.id) return;
    supabase.from("courses").select("*").eq("org_id", org.id).order("created_at", { ascending: false }).limit(500)
      .then(({ data }) => setCourses(data ?? []));
    supabase.from("course_enrollments").select("*").eq("org_id", org.id)
      .then(({ data }) => setEnrollments(data ?? []));
    if (user?.id) {
      supabase.from("employees").select("id").eq("org_id", org.id).eq("user_id", user.id).maybeSingle()
        .then(({ data }) => setEmpId(data?.id ?? null));
    }
  }, [org?.id, user?.id, reload]);

  const enroll = async (c: any) => {
    if (!org?.id || !empId) return toast.error("No employee profile");
    const { error } = await supabase.from("course_enrollments").insert({
      org_id: org.id, employee_id: empId, course_id: c.id, progress: 0,
    } as any);
    if (error) return toast.error(error.message);
    toast.success(`Enrolled in ${c.title}`);
    setReload((k) => k + 1);
  };

  const updateProgress = async (en: any, progress: number) => {
    const patch: any = { progress };
    if (progress >= 100) patch.completed_at = new Date().toISOString();
    const { error } = await supabase.from("course_enrollments").update(patch).eq("id", en.id);
    if (error) return toast.error(error.message);
    if (progress >= 100) toast.success("Course completed");
    setReload((k) => k + 1);
  };

  const togglePublish = async (c: any) => {
    const { error } = await supabase.from("courses").update({ is_published: !c.is_published } as any).eq("id", c.id);
    if (error) return toast.error(error.message);
    setReload((k) => k + 1);
  };

  const saveCourse = async () => {
    if (!editing) return;
    const { id, ...patch } = editing;
    const { error } = await supabase.from("courses").update(patch).eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Saved");
    setEditing(null);
    setReload((k) => k + 1);
  };

  if (courses === null) return <PageSkeleton />;

  const myEnrollments = enrollments.filter((e) => e.employee_id === empId);
  const enrollmentByCourse = (cid: string) => myEnrollments.find((e) => e.course_id === cid);
  const enrollmentCount = (cid: string) => enrollments.filter((e) => e.course_id === cid).length;

  const counts = {
    all: courses.length,
    published: courses.filter((c) => c.is_published).length,
    drafts: courses.filter((c) => !c.is_published).length,
    my: myEnrollments.length,
  };
  const completed = myEnrollments.filter((e) => e.completed_at).length;

  const visible = useMemo(() => {
    let r = courses;
    if (tab === "published") r = r.filter((c) => c.is_published);
    else if (tab === "drafts") r = r.filter((c) => !c.is_published);
    else if (tab === "my") r = r.filter((c) => myEnrollments.some((e) => e.course_id === c.id));
    if (search.trim()) {
      const q = search.toLowerCase();
      r = r.filter((c) => c.title.toLowerCase().includes(q) || (c.category ?? "").toLowerCase().includes(q));
    }
    return r;
  }, [courses, tab, search, myEnrollments]);

  return (
    <WorkforcePage
      title="E-Learning"
      description={`${counts.published} live · ${counts.my} enrolled · ${completed} completed`}
      actions={
        isAdmin && (
          <QuickCreate
            table="courses"
            title="New course"
            buttonLabel="Add course"
            buttonStyle={{ background: "var(--workforce)", color: "white" }}
            fields={[
              { key: "title", label: "Title", required: true },
              { key: "category", label: "Category", placeholder: "onboarding / safety / sales" },
              { key: "duration_minutes", label: "Duration (minutes)", type: "number" },
              { key: "description", label: "Description", type: "textarea" },
            ]}
            defaults={{ is_published: false }}
            onCreated={() => setReload((k) => k + 1)}
          />
        )
      }
    >
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatTile icon={<BookOpen className="h-4 w-4" />} label="Courses" value={counts.all} tone="var(--workforce)" />
        <StatTile icon={<Eye className="h-4 w-4" />} label="Published" value={counts.published} tone="#10b981" />
        <StatTile icon={<GraduationCap className="h-4 w-4" />} label="My enrollments" value={counts.my} tone="#8b5cf6" />
        <StatTile icon={<CheckCircle2 className="h-4 w-4" />} label="My completions" value={completed} tone="var(--workforce)" />
      </div>

      <div className="flex flex-wrap items-center gap-2">
        {TABS.map((t) => (
          <Button key={t} size="sm" variant={tab === t ? "default" : "outline"} className="capitalize h-8" onClick={() => setTab(t)}>
            {t === "my" ? "My courses" : t} <span className="ml-1.5 opacity-60">{counts[t]}</span>
          </Button>
        ))}
        <div className="relative ml-auto w-64">
          <Search className="h-3.5 w-3.5 absolute left-2.5 top-2.5 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search courses…" className="h-8 pl-8" />
        </div>
      </div>

      {visible.length === 0 ? (
        <Card><CardContent className="p-10 text-center text-sm text-muted-foreground">No courses in this view.</CardContent></Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {visible.map((c) => {
            const en = enrollmentByCourse(c.id);
            const totalEnrolled = enrollmentCount(c.id);
            return (
              <Card key={c.id} className="overflow-hidden flex flex-col">
                <div className="h-24 relative" style={{ background: "linear-gradient(135deg, color-mix(in oklab, var(--workforce) 35%, transparent), color-mix(in oklab, var(--workforce) 12%, transparent))" }}>
                  {c.cover_url && <img src={c.cover_url} alt={c.title} className="absolute inset-0 w-full h-full object-cover" />}
                  <div className="absolute top-2 right-2 flex gap-1">
                    {c.is_published ? (
                      <Badge className="bg-emerald-500/90 hover:bg-emerald-500 text-white text-[10px]">Live</Badge>
                    ) : (
                      <Badge variant="outline" className="bg-background/80 text-[10px]">Draft</Badge>
                    )}
                  </div>
                  <BookOpen className="absolute bottom-2 left-2 h-6 w-6 text-white/80" />
                </div>
                <CardContent className="p-3 flex-1 flex flex-col">
                  <div className="font-medium text-sm leading-tight line-clamp-2">{c.title}</div>
                  <div className="text-[11px] text-muted-foreground mt-1 flex items-center gap-2">
                    {c.category && <span className="capitalize">{c.category}</span>}
                    {c.duration_minutes ? <span className="inline-flex items-center gap-1"><Clock className="h-3 w-3" /> {c.duration_minutes}m</span> : null}
                    <span className="inline-flex items-center gap-1"><GraduationCap className="h-3 w-3" /> {totalEnrolled}</span>
                  </div>
                  {c.description && <p className="text-xs text-muted-foreground mt-2 line-clamp-2">{c.description}</p>}

                  {en && (
                    <div className="mt-3">
                      <div className="flex items-center justify-between text-[11px] text-muted-foreground mb-1">
                        <span>Progress</span>
                        <span>{en.progress ?? 0}%</span>
                      </div>
                      <Progress value={en.progress ?? 0} className="h-1.5" />
                    </div>
                  )}

                  <div className="mt-3 flex gap-1.5 flex-wrap">
                    {!en ? (
                      <Button size="sm" disabled={!c.is_published} className="flex-1" style={{ background: "var(--workforce)", color: "white" }} onClick={() => enroll(c)}>
                        <PlayCircle className="h-3.5 w-3.5 mr-1" /> Enroll
                      </Button>
                    ) : en.completed_at ? (
                      <Button size="sm" variant="outline" className="flex-1" disabled>
                        <CheckCircle2 className="h-3.5 w-3.5 mr-1" /> Completed
                      </Button>
                    ) : (
                      <>
                        <Button size="sm" variant="outline" className="flex-1" onClick={() => updateProgress(en, Math.min(100, (en.progress ?? 0) + 25))}>
                          +25%
                        </Button>
                        <Button size="sm" style={{ background: "var(--workforce)", color: "white" }} onClick={() => updateProgress(en, 100)}>
                          Finish
                        </Button>
                      </>
                    )}
                    {isAdmin && (
                      <>
                        <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => togglePublish(c)} title={c.is_published ? "Unpublish" : "Publish"}>
                          {c.is_published ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => setEditing({ ...c })}>Edit</Button>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent>
          {editing && (
            <>
              <DialogHeader><DialogTitle>Edit course</DialogTitle></DialogHeader>
              <div className="space-y-3">
                <div><Label>Title</Label><Input value={editing.title} onChange={(e) => setEditing({ ...editing, title: e.target.value })} /></div>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label>Category</Label><Input value={editing.category ?? ""} onChange={(e) => setEditing({ ...editing, category: e.target.value })} /></div>
                  <div><Label>Duration (min)</Label><Input type="number" value={editing.duration_minutes ?? 0} onChange={(e) => setEditing({ ...editing, duration_minutes: Number(e.target.value) })} /></div>
                </div>
                <div><Label>Cover URL</Label><Input value={editing.cover_url ?? ""} onChange={(e) => setEditing({ ...editing, cover_url: e.target.value })} placeholder="https://…" /></div>
                <div><Label>Description</Label><Textarea rows={4} value={editing.description ?? ""} onChange={(e) => setEditing({ ...editing, description: e.target.value })} /></div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setEditing(null)}>Cancel</Button>
                <Button onClick={saveCourse}>Save</Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </WorkforcePage>
  );
}

function StatTile({ icon, label, value, tone }: { icon: React.ReactNode; label: string; value: number | string; tone: string }) {
  return (
    <Card>
      <CardContent className="p-3 flex items-center gap-3">
        <div className="h-8 w-8 rounded-md flex items-center justify-center" style={{ background: `color-mix(in oklab, ${tone} 14%, transparent)`, color: tone }}>
          {icon}
        </div>
        <div className="min-w-0">
          <div className="text-[11px] text-muted-foreground uppercase tracking-wide">{label}</div>
          <div className="text-lg font-semibold leading-tight">{value}</div>
        </div>
      </CardContent>
    </Card>
  );
}
