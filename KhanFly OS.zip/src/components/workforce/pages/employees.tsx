import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { WorkforcePage, PageSkeleton } from "../page-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { EmptyState } from "@/components/empty-state";
import { Users, Building2, UserCheck, UserX, Search, LayoutGrid, List } from "lucide-react";
import { writeEvent, indexEntity } from "@/lib/workforce";
import { toast } from "sonner";

function StatTile({ icon: Icon, label, value, tint }: { icon: any; label: string; value: any; tint: string }) {
  return (
    <Card>
      <CardContent className="p-4 flex items-center gap-3">
        <div className="h-10 w-10 rounded-lg flex items-center justify-center" style={{ background: tint }}>
          <Icon className="h-5 w-5" style={{ color: "var(--workforce)" }} />
        </div>
        <div className="min-w-0">
          <div className="text-[11px] uppercase tracking-wider text-muted-foreground">{label}</div>
          <div className="text-lg font-semibold truncate">{value}</div>
        </div>
      </CardContent>
    </Card>
  );
}

const DEMO_TEAM = [
  { full_name: "Aiman Khan", email: "aiman@example.com", position: "Product Manager" },
  { full_name: "Daniyar Yusupov", email: "daniyar@example.com", position: "Senior Engineer" },
  { full_name: "Saule Tursunova", email: "saule@example.com", position: "Designer" },
];

export default function EmployeesPage() {
  const { org, user } = useAuth();
  const [rows, setRows] = useState<any[] | null>(null);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ full_name: "", email: "", position: "", phone: "" });
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | "active" | "inactive">("active");

  const [deptFilter, setDeptFilter] = useState<string>("all");
  const [view, setView] = useState<"list" | "grid">("list");

  const load = async () => {
    if (!org?.id) return;
    const { data } = await supabase.from("employees").select("*").eq("org_id", org.id).order("created_at", { ascending: false });
    setRows(data ?? []);
  };
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [org?.id]);

  const departments = useMemo(() => {
    const set = new Set<string>();
    (rows ?? []).forEach((e) => { if (e.department) set.add(e.department); });
    return Array.from(set).sort();
  }, [rows]);

  const filtered = (rows ?? []).filter((e) => {
    if (statusFilter === "active" && !e.is_active) return false;
    if (statusFilter === "inactive" && e.is_active) return false;
    if (deptFilter !== "all" && e.department !== deptFilter) return false;
    if (!query) return true;
    const q = query.toLowerCase();
    return (e.full_name ?? "").toLowerCase().includes(q)
      || (e.email ?? "").toLowerCase().includes(q)
      || (e.position ?? "").toLowerCase().includes(q)
      || (e.department ?? "").toLowerCase().includes(q);
  });

  const create = async () => {
    if (!org?.id) return;
    const { data, error } = await supabase.from("employees").insert({
      org_id: org.id, full_name: form.full_name, email: form.email, position: form.position, phone: form.phone, is_active: true,
    } as any).select().single();
    if (error) return toast.error(error.message);
    await writeEvent(org.id, "workforce", "employee_created", {
      employee_id: data.id, name: data.full_name, email: data.email,
    }, user?.id);
    await indexEntity({
      org_id: org.id, module: "workforce", entity_type: "employee", entity_id: data.id,
      title: data.full_name, subtitle: data.position ?? "Employee",
      keywords: `${data.email ?? ""} ${data.phone ?? ""} ${data.employee_code ?? ""}`,
      url: `/workforce/employees/${data.id}`,
    });
    toast.success("Employee added");
    setOpen(false);
    setForm({ full_name: "", email: "", position: "", phone: "" });
    load();
  };

  if (rows === null) return <PageSkeleton />;

  const activeCount = rows.filter((e) => e.is_active).length;
  const inactiveCount = rows.length - activeCount;
  const tint = "color-mix(in oklab, var(--workforce) 14%, transparent)";

  return (
    <WorkforcePage
      title="Employees"
      description={`${filtered.length} of ${rows.length} ${rows.length === 1 ? "member" : "members"}`}
      actions={
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button style={{ background: "var(--workforce)", color: "white" }}>Add employee</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Add employee</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div><Label>Full name</Label><Input value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} /></div>
              <div><Label>Email</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
              <div><Label>Position</Label><Input value={form.position} onChange={(e) => setForm({ ...form, position: e.target.value })} /></div>
              <div><Label>Phone</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
            </div>
            <DialogFooter><Button onClick={create} disabled={!form.full_name}>Create</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      }
    >
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatTile icon={Users} label="Total" value={rows.length} tint={tint} />
        <StatTile icon={UserCheck} label="Active" value={activeCount} tint={tint} />
        <StatTile icon={UserX} label="Inactive" value={inactiveCount} tint={tint} />
        <StatTile icon={Building2} label="Departments" value={departments.length} tint={tint} />
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <div className="relative w-full md:w-72">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
          <Input className="h-8 pl-7" placeholder="Search name, email, position…" value={query} onChange={(e) => setQuery(e.target.value)} />
        </div>
        <div className="flex rounded-md border overflow-hidden text-xs">
          {(["active", "inactive", "all"] as const).map((s) => (
            <button key={s} onClick={() => setStatusFilter(s)}
              className={`px-3 py-1.5 capitalize ${statusFilter === s ? "bg-muted font-medium" : "hover:bg-muted/50"}`}>{s}</button>
          ))}
        </div>
        {departments.length > 0 && (
          <select
            className="h-8 rounded-md border bg-background px-2 text-sm"
            value={deptFilter}
            onChange={(e) => setDeptFilter(e.target.value)}
          >
            <option value="all">All departments</option>
            {departments.map((d) => <option key={d} value={d}>{d}</option>)}
          </select>
        )}
        <div className="flex rounded-md border overflow-hidden text-xs ml-auto">
          <button onClick={() => setView("list")} className={`px-2 py-1.5 ${view === "list" ? "bg-muted" : "hover:bg-muted/50"}`} title="List view"><List className="h-3.5 w-3.5" /></button>
          <button onClick={() => setView("grid")} className={`px-2 py-1.5 ${view === "grid" ? "bg-muted" : "hover:bg-muted/50"}`} title="Grid view"><LayoutGrid className="h-3.5 w-3.5" /></button>
        </div>
      </div>

      {rows.length === 0 ? (
        <Card><CardContent className="p-0">
          <EmptyState
            icon={Users}
            accent="var(--workforce)"
            title="No employees yet"
            description="Add your team to unlock attendance, payroll, leave tracking, and project assignments. Or seed a small demo team to explore."
            actionLabel="Add 3 demo teammates"
            onAction={async () => {
              if (!org?.id) return;
              const { error } = await supabase.from("employees").insert(
                DEMO_TEAM.map((d) => ({ ...d, org_id: org.id, is_active: true })) as any
              );
              if (error) return toast.error(error.message);
              toast.success("Demo team added");
              load();
            }}
            secondaryLabel="Add real employee"
            onSecondary={() => setOpen(true)}
          />
        </CardContent></Card>
      ) : filtered.length === 0 ? (
        <Card><CardContent className="p-10 text-center text-sm text-muted-foreground">No matches.</CardContent></Card>
      ) : view === "grid" ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {filtered.map((e) => (
            <Link key={e.id} to="/workforce/employees/$id" params={{ id: e.id }} className="block">
              <Card className="hover:shadow-md transition-shadow h-full">
                <CardContent className="p-4 flex items-start gap-3">
                  <div className="h-12 w-12 rounded-full text-sm flex items-center justify-center font-semibold" style={{ background: tint, color: "var(--workforce)" }}>
                    {e.full_name.split(" ").map((n: string) => n[0]).join("").slice(0, 2).toUpperCase()}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="font-medium truncate">{e.full_name}</div>
                    <div className="text-xs text-muted-foreground truncate">{e.position ?? "—"}</div>
                    <div className="text-[11px] text-muted-foreground truncate mt-0.5">{e.email ?? ""}</div>
                    {e.department && <div className="text-[10px] mt-1 inline-flex px-1.5 py-0.5 rounded" style={{ background: tint, color: "var(--workforce)" }}>{e.department}</div>}
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      ) : (
        <Card><CardContent className="p-0">
          <div className="divide-y">
            {filtered.map((e) => (
              <Link key={e.id} to="/workforce/employees/$id" params={{ id: e.id }} className="flex items-center gap-3 px-4 py-3 hover:bg-muted/30">
                <div className="h-9 w-9 rounded-full text-xs flex items-center justify-center font-medium" style={{ background: tint, color: "var(--workforce)" }}>
                  {e.full_name.split(" ").map((n: string) => n[0]).join("").slice(0, 2).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-medium truncate">{e.full_name}</div>
                  <div className="text-xs text-muted-foreground truncate">{e.position ?? "—"} · {e.email ?? ""}</div>
                </div>
                {e.department && <span className="text-[10px] hidden md:inline px-1.5 py-0.5 rounded" style={{ background: tint, color: "var(--workforce)" }}>{e.department}</span>}
                <span className="text-xs text-muted-foreground">{e.is_active ? "Active" : "Inactive"}</span>
              </Link>
            ))}
          </div>
        </CardContent></Card>
      )}
    </WorkforcePage>
  );
}
