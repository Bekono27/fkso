import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { WorkforcePage, PageSkeleton } from "../page-shell";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { writeEvent, indexEntity } from "@/lib/workforce";
import { QuickCreate } from "@/components/quick-create";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

type Status = "todo" | "in_progress" | "in_review" | "completed";
const COLUMNS: { key: Status; label: string; color: string }[] = [
  { key: "todo", label: "To Do", color: "#71717a" },
  { key: "in_progress", label: "In Progress", color: "var(--workforce)" },
  { key: "in_review", label: "Review", color: "#f59e0b" },
  { key: "completed", label: "Done", color: "#16a34a" },
];

const PRIORITY_COLOR: Record<string, string> = {
  low: "#71717a", medium: "#3b82f6", high: "#f59e0b", urgent: "#dc2626",
};

export default function ProjectsPage() {
  const { org, user } = useAuth();
  const [projects, setProjects] = useState<any[] | null>(null);
  const [tasks, setTasks] = useState<any[]>([]);
  const [activeProject, setActiveProject] = useState<string>("all");
  const [reload, setReload] = useState(0);

  useEffect(() => {
    if (!org?.id) return;
    (async () => {
      const [{ data: p }, { data: t }] = await Promise.all([
        supabase.from("workforce_projects").select("*").eq("org_id", org.id).order("created_at", { ascending: false }),
        supabase.from("workforce_tasks").select("*").eq("org_id", org.id).order("created_at", { ascending: false }).limit(500),
      ]);
      setProjects(p ?? []);
      setTasks(t ?? []);
    })();
  }, [org?.id, reload]);

  const visibleTasks = activeProject === "all" ? tasks : tasks.filter((t) => t.project_id === activeProject);

  const moveTask = async (t: any, status: Status) => {
    if (!org?.id || t.status === status) return;
    const patch: any = { status };
    if (status === "completed") {
      patch.completed_at = new Date().toISOString();
      patch.completion_percentage = 100;
    } else if (t.status === "completed") {
      patch.completed_at = null;
    }
    if (status === "in_progress" && !t.started_at) patch.started_at = new Date().toISOString();
    setTasks((prev) => prev.map((x) => (x.id === t.id ? { ...x, ...patch } : x)));
    const { error } = await supabase.from("workforce_tasks").update(patch).eq("id", t.id);
    if (error) { toast.error(error.message); setReload((k) => k + 1); return; }
    if (status === "completed") {
      await writeEvent(org.id, "workforce", "task_completed", {
        task_id: t.id, task_title: t.title, project_id: t.project_id, completed_by: user?.id,
      }, user?.id);
      await indexEntity({
        org_id: org.id, module: "workforce", entity_type: "task", entity_id: t.id,
        title: t.title, subtitle: `Task · completed`, keywords: t.description ?? "",
        url: `/workforce/projects?task=${t.id}`,
      });
    }
  };

  const onDrop = (e: React.DragEvent, status: Status) => {
    e.preventDefault();
    const id = e.dataTransfer.getData("text/plain");
    const t = tasks.find((x) => x.id === id);
    if (t) moveTask(t, status);
  };

  if (projects === null) return <PageSkeleton />;

  return (
    <WorkforcePage
      title="Projects & Tasks"
      description={`${projects.length} projects · ${visibleTasks.length} tasks`}
      actions={
        <div className="flex items-center gap-2">
          <QuickCreate
            table="workforce_projects"
            title="New project"
            buttonLabel="New project"
            triggerVariant="outline"
            fields={[
              { key: "name", label: "Name", required: true },
              { key: "description", label: "Description", type: "textarea" },
              { key: "start_date", label: "Start date", placeholder: "YYYY-MM-DD" },
              { key: "end_date", label: "End date", placeholder: "YYYY-MM-DD" },
              { key: "budget", label: "Budget", type: "number" },
            ]}
            defaults={{ status: "active" }}
            onCreated={() => setReload((k) => k + 1)}
          />
          <QuickCreate
            table="workforce_tasks"
            title="New task"
            buttonLabel="New task"
            buttonStyle={{ background: "var(--workforce)", color: "white" }}
            fields={[
              { key: "title", label: "Title", required: true },
              { key: "description", label: "Description", type: "textarea" },
              { key: "due_date", label: "Due date", placeholder: "YYYY-MM-DD" },
              { key: "estimated_hours", label: "Estimated hours", type: "number" },
            ]}
            defaults={{
              status: "todo",
              priority: "medium",
              ...(activeProject !== "all" ? { project_id: activeProject } : {}),
            }}
            onCreated={() => setReload((k) => k + 1)}
          />
        </div>
      }
    >
      <div className="flex items-center gap-2">
        <span className="text-sm text-muted-foreground">Project:</span>
        <Select value={activeProject} onValueChange={setActiveProject}>
          <SelectTrigger className="w-[260px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All projects</SelectItem>
            {projects.map((p) => (
              <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="grid gap-3 md:grid-cols-4">
        {COLUMNS.map((col) => {
          const items = visibleTasks.filter((t) => t.status === col.key);
          return (
            <div
              key={col.key}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => onDrop(e, col.key)}
              className="flex flex-col rounded-lg border bg-muted/20 min-h-[400px]"
            >
              <div className="px-3 py-2 border-b flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full" style={{ background: col.color }} />
                  <span className="text-sm font-medium">{col.label}</span>
                </div>
                <Badge variant="outline" className="text-xs">{items.length}</Badge>
              </div>
              <div className="flex-1 p-2 space-y-2">
                {items.length === 0 ? (
                  <div className="text-xs text-muted-foreground text-center py-6">Drop tasks here</div>
                ) : items.map((t) => {
                  const proj = projects.find((p) => p.id === t.project_id);
                  return (
                    <Card
                      key={t.id}
                      draggable
                      onDragStart={(e) => e.dataTransfer.setData("text/plain", t.id)}
                      className="p-3 cursor-grab active:cursor-grabbing hover:shadow-md transition-shadow"
                    >
                      <div className="text-sm font-medium leading-snug">{t.title}</div>
                      {t.description && (
                        <div className="text-xs text-muted-foreground mt-1 line-clamp-2">{t.description}</div>
                      )}
                      <div className="flex items-center justify-between mt-2 gap-2">
                        <span
                          className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium uppercase"
                          style={{
                            background: `color-mix(in oklab, ${PRIORITY_COLOR[t.priority] ?? "#71717a"} 18%, transparent)`,
                            color: PRIORITY_COLOR[t.priority] ?? "#71717a",
                          }}
                        >
                          {t.priority}
                        </span>
                        {proj && <span className="text-[10px] text-muted-foreground truncate">{proj.name}</span>}
                      </div>
                      {t.due_date && (
                        <div className="text-[10px] text-muted-foreground mt-1">Due {new Date(t.due_date).toLocaleDateString()}</div>
                      )}
                      <div className="flex gap-1 mt-2">
                        {COLUMNS.filter((c) => c.key !== t.status).map((c) => (
                          <Button
                            key={c.key}
                            size="sm"
                            variant="ghost"
                            className="h-6 px-1.5 text-[10px]"
                            onClick={() => moveTask(t, c.key)}
                          >
                            → {c.label}
                          </Button>
                        ))}
                      </div>
                    </Card>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </WorkforcePage>
  );
}
