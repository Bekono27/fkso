import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { WorkforcePage, PageSkeleton } from "../page-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { getMondayISO, todayISO } from "@/lib/workforce";
import { Users, Clock, Timer, Plane, DollarSign, TrendingUp, FileText, Megaphone, GraduationCap, Wrench } from "lucide-react";

function StatTile({ icon: Icon, label, value, sub, tint }: { icon: any; label: string; value: any; sub?: string; tint: string }) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-lg flex items-center justify-center" style={{ background: tint }}>
            <Icon className="h-5 w-5" style={{ color: "var(--workforce)" }} />
          </div>
          <div className="min-w-0">
            <div className="text-[11px] uppercase tracking-wider text-muted-foreground">{label}</div>
            <div className="text-xl font-semibold truncate">{value}</div>
            {sub && <div className="text-[11px] text-muted-foreground mt-0.5">{sub}</div>}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function ReportsPage() {
  const { org } = useAuth();
  const [stats, setStats] = useState<any | null>(null);

  useEffect(() => {
    if (!org?.id) return;
    const today = todayISO();
    const weekStart = getMondayISO();
    const monthStart = new Date();
    monthStart.setDate(1);
    const monthStartISO = monthStart.toISOString().slice(0, 10);

    Promise.all([
      supabase.from("employees").select("id,department", { count: "exact" }).eq("org_id", org.id).eq("is_active", true),
      supabase.from("work_sessions").select("total_minutes,overtime_minutes,date").eq("org_id", org.id).gte("date", weekStart),
      supabase.from("leave_requests").select("id,status").eq("org_id", org.id),
      supabase.from("payroll_records").select("gross_salary,net_salary,year,month,status").eq("org_id", org.id),
      supabase.from("announcements").select("id", { count: "exact", head: true }).eq("org_id", org.id).eq("is_active", true),
      supabase.from("courses").select("id", { count: "exact", head: true }).eq("org_id", org.id).eq("is_published", true),
      supabase.from("assets").select("id,status,assigned_to"),
      supabase.from("helpdesk_tickets").select("id,status").eq("org_id", org.id),
      supabase.from("workforce_projects").select("id,status").eq("org_id", org.id),
    ]).then(([emp, sess, leave, pay, ann, courses, assets, tickets, projects]) => {
      const totalMin = (sess.data ?? []).reduce((s, r: any) => s + (r.total_minutes ?? 0), 0);
      const otMin = (sess.data ?? []).reduce((s, r: any) => s + (r.overtime_minutes ?? 0), 0);
      const onLeaveToday = (leave.data ?? []).filter((l: any) => l.status === "approved").length;
      const pendingLeave = (leave.data ?? []).filter((l: any) => l.status === "pending").length;
      const totalPay = (pay.data ?? []).reduce((s, r: any) => s + Number(r.net_salary ?? 0), 0);
      const thisMonthPay = (pay.data ?? [])
        .filter((r: any) => r.year === new Date().getFullYear() && r.month === new Date().getMonth() + 1)
        .reduce((s, r: any) => s + Number(r.net_salary ?? 0), 0);
      const draftPay = (pay.data ?? []).filter((r: any) => r.status === "draft").length;

      const depts = new Map<string, number>();
      (emp.data ?? []).forEach((e: any) => {
        const d = e.department ?? "Unassigned";
        depts.set(d, (depts.get(d) ?? 0) + 1);
      });

      const assetRows = assets.data ?? [];
      const ticketRows = tickets.data ?? [];
      const projRows = projects.data ?? [];

      setStats({
        employees: emp.count ?? 0,
        depts: Array.from(depts.entries()).sort((a, b) => b[1] - a[1]),
        hoursWeek: Math.round(totalMin / 60),
        overtimeWeek: Math.round(otMin / 60),
        onLeaveToday,
        pendingLeave,
        totalPayroll: totalPay,
        monthPayroll: thisMonthPay,
        draftPay,
        announcements: ann.count ?? 0,
        courses: courses.count ?? 0,
        assetsTotal: assetRows.length,
        assetsAssigned: assetRows.filter((a: any) => a.assigned_to).length,
        assetsMaintenance: assetRows.filter((a: any) => a.status === "maintenance").length,
        ticketsOpen: ticketRows.filter((t: any) => t.status !== "closed" && t.status !== "resolved").length,
        ticketsTotal: ticketRows.length,
        projectsActive: projRows.filter((p: any) => p.status === "active" || p.status === "in_progress").length,
        projectsTotal: projRows.length,
      });
    });
  }, [org?.id]);

  if (!stats) return <PageSkeleton />;

  const tint = "color-mix(in oklab, var(--workforce) 14%, transparent)";

  return (
    <WorkforcePage title="Reports" description="Live workforce snapshot across all modules">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatTile icon={Users} label="Active employees" value={stats.employees} tint={tint} />
        <StatTile icon={Clock} label="Hours this week" value={`${stats.hoursWeek}h`} sub={`${stats.overtimeWeek}h overtime`} tint={tint} />
        <StatTile icon={Plane} label="On leave today" value={stats.onLeaveToday} sub={`${stats.pendingLeave} pending`} tint={tint} />
        <StatTile icon={DollarSign} label="Payroll this month" value={Number(stats.monthPayroll).toLocaleString()} sub={`${stats.draftPay} draft`} tint={tint} />
        <StatTile icon={Wrench} label="Assets assigned" value={`${stats.assetsAssigned}/${stats.assetsTotal}`} sub={`${stats.assetsMaintenance} in maintenance`} tint={tint} />
        <StatTile icon={FileText} label="Open tickets" value={stats.ticketsOpen} sub={`${stats.ticketsTotal} total`} tint={tint} />
        <StatTile icon={Timer} label="Active projects" value={stats.projectsActive} sub={`${stats.projectsTotal} total`} tint={tint} />
        <StatTile icon={GraduationCap} label="Published courses" value={stats.courses} sub={`${stats.announcements} announcements`} tint={tint} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-base flex items-center gap-2"><Users className="h-4 w-4" /> Headcount by department</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {stats.depts.length === 0 ? (
              <p className="text-sm text-muted-foreground">No departments yet.</p>
            ) : stats.depts.map(([name, count]: [string, number]) => {
              const pct = Math.round((count / Math.max(1, stats.employees)) * 100);
              return (
                <div key={name}>
                  <div className="flex justify-between text-sm">
                    <span className="font-medium">{name}</span>
                    <span className="text-muted-foreground">{count} · {pct}%</span>
                  </div>
                  <div className="h-2 mt-1 rounded-full bg-muted overflow-hidden">
                    <div className="h-full" style={{ width: `${pct}%`, background: "var(--workforce)" }} />
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base flex items-center gap-2"><TrendingUp className="h-4 w-4" /> Lifetime totals</CardTitle></CardHeader>
          <CardContent className="space-y-3 text-sm">
            <div className="flex justify-between"><span className="text-muted-foreground">Lifetime payroll paid</span><span className="font-semibold">{Number(stats.totalPayroll).toLocaleString()} MNT</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Total work hours (week)</span><span className="font-semibold">{stats.hoursWeek}h</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Overtime (week)</span><span className="font-semibold">{stats.overtimeWeek}h</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Active announcements</span><span className="font-semibold flex items-center gap-1"><Megaphone className="h-3.5 w-3.5" /> {stats.announcements}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Pending leave requests</span><span className="font-semibold">{stats.pendingLeave}</span></div>
          </CardContent>
        </Card>
      </div>
    </WorkforcePage>
  );
}
