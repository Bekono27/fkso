import { useEffect, useMemo, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { WorkforcePage, PageSkeleton } from "../page-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { writeEvent } from "@/lib/workforce";
import { CalendarDays, CheckCircle2, XCircle, Clock } from "lucide-react";
import { toast } from "sonner";

const STATUS_FILTERS = ["all", "pending", "approved", "rejected"] as const;
const TYPE_META: Record<string, { label: string; tone: string }> = {
  annual: { label: "Annual", tone: "var(--workforce)" },
  sick: { label: "Sick", tone: "#ef4444" },
  personal: { label: "Personal", tone: "#8b5cf6" },
  unpaid: { label: "Unpaid", tone: "#64748b" },
};

const daysBetween = (a: string, b: string) => Math.max(1, Math.round((new Date(b).getTime() - new Date(a).getTime()) / 86400000) + 1);

export default function LeavePage() {
  const { org, user, roles } = useAuth();
  const isAdmin = roles.includes("admin") || roles.includes("ceo") || roles.includes("manager");
  const [rows, setRows] = useState<any[] | null>(null);
  const [empId, setEmpId] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const [filter, setFilter] = useState<(typeof STATUS_FILTERS)[number]>("pending");
  const [form, setForm] = useState({ leave_type: "annual", start_date: "", end_date: "", reason: "" });

  const load = async () => {
    if (!org?.id) return;
    const { data } = await supabase.from("leave_requests")
      .select("*,employees!inner(full_name)").eq("org_id", org.id).order("created_at", { ascending: false }).limit(200);
    setRows(data ?? []);
    if (user?.id) {
      const { data: e } = await supabase.from("employees").select("id").eq("org_id", org.id).eq("user_id", user.id).maybeSingle();
      setEmpId(e?.id ?? null);
    }
  };
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [org?.id, user?.id]);

  const days = form.start_date && form.end_date ? daysBetween(form.start_date, form.end_date) : 0;

  const submit = async () => {
    if (!org?.id || !empId) return toast.error("No employee profile");
    if (!form.start_date || !form.end_date) return toast.error("Pick dates");
    if (new Date(form.end_date) < new Date(form.start_date)) return toast.error("End date is before start");
    const { error } = await supabase.from("leave_requests").insert({
      org_id: org.id, employee_id: empId, leave_type: form.leave_type as any,
      start_date: form.start_date, end_date: form.end_date, days_requested: days,
      reason: form.reason, status: "pending",
    } as any);
    if (error) return toast.error(error.message);
    toast.success("Request submitted");
    setOpen(false); setForm({ leave_type: "annual", start_date: "", end_date: "", reason: "" });
    load();
  };

  const decide = async (l: any, status: "approved" | "rejected") => {
    if (!org?.id) return;
    const { error } = await supabase.from("leave_requests").update({
      status, reviewed_by: user?.id, reviewed_at: new Date().toISOString(),
    }).eq("id", l.id);
    if (error) return toast.error(error.message);
    await writeEvent(org.id, "workforce", status === "approved" ? "leave_approved" : "leave_rejected", {
      employee_id: l.employee_id, name: l.employees?.full_name,
      start_date: l.start_date, end_date: l.end_date, leave_type: l.leave_type,
    }, user?.id);
    toast.success(`Leave ${status}`);
    load();
  };

  if (rows === null) return <PageSkeleton />;

  const counts = {
    all: rows.length,
    pending: rows.filter((r) => r.status === "pending").length,
    approved: rows.filter((r) => r.status === "approved").length,
    rejected: rows.filter((r) => r.status === "rejected").length,
  };
  const visible = useMemo(
    () => (filter === "all" ? rows : rows.filter((r) => r.status === filter)),
    [rows, filter]
  );
  const totalDaysApproved = rows.filter((r) => r.status === "approved").reduce((s, r) => s + (r.days_requested ?? 0), 0);

  return (
    <WorkforcePage
      title="Leave Requests"
      description={`${counts.pending} pending · ${counts.approved} approved · ${totalDaysApproved} days off this period`}
      actions={
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button style={{ background: "var(--workforce)", color: "white" }}>Request leave</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Request leave</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div>
                <Label>Type</Label>
                <Select value={form.leave_type} onValueChange={(v) => setForm({ ...form, leave_type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {Object.entries(TYPE_META).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Start</Label><Input type="date" value={form.start_date} onChange={(e) => setForm({ ...form, start_date: e.target.value })} /></div>
                <div><Label>End</Label><Input type="date" value={form.end_date} onChange={(e) => setForm({ ...form, end_date: e.target.value })} /></div>
              </div>
              {days > 0 && (
                <div className="text-xs px-3 py-2 rounded-md flex items-center gap-2" style={{ background: "color-mix(in oklab, var(--workforce) 10%, transparent)", color: "var(--workforce)" }}>
                  <CalendarDays className="h-3.5 w-3.5" /> {days} day{days === 1 ? "" : "s"} requested
                </div>
              )}
              <div><Label>Reason</Label><Textarea rows={3} value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} /></div>
            </div>
            <DialogFooter><Button onClick={submit} disabled={!form.start_date || !form.end_date}>Submit</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      }
    >
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatTile icon={<Clock className="h-4 w-4" />} label="Pending" value={counts.pending} tone="#f59e0b" />
        <StatTile icon={<CheckCircle2 className="h-4 w-4" />} label="Approved" value={counts.approved} tone="var(--workforce)" />
        <StatTile icon={<XCircle className="h-4 w-4" />} label="Rejected" value={counts.rejected} tone="#ef4444" />
        <StatTile icon={<CalendarDays className="h-4 w-4" />} label="Days off" value={totalDaysApproved} tone="var(--workforce)" />
      </div>

      <div className="flex flex-wrap items-center gap-2">
        {STATUS_FILTERS.map((s) => (
          <Button key={s} size="sm" variant={filter === s ? "default" : "outline"} className="capitalize h-8" onClick={() => setFilter(s)}>
            {s} <span className="ml-1.5 opacity-60">{counts[s]}</span>
          </Button>
        ))}
      </div>

      <Card><CardContent className="p-0">
        {visible.length === 0 ? (
          <div className="p-10 text-center text-sm text-muted-foreground">No requests in this view.</div>
        ) : (
          <div className="divide-y">
            {visible.map((l) => {
              const meta = TYPE_META[l.leave_type] ?? { label: l.leave_type, tone: "var(--muted-foreground)" };
              return (
                <div key={l.id} className="flex items-center gap-3 px-4 py-3">
                  <div className="h-9 w-9 rounded-full flex items-center justify-center text-xs font-semibold" style={{ background: `color-mix(in oklab, ${meta.tone} 18%, transparent)`, color: meta.tone }}>
                    {(l.employees?.full_name ?? "?").slice(0, 2).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-sm truncate">{l.employees?.full_name}</div>
                    <div className="text-xs text-muted-foreground">
                      {meta.label} · {l.start_date} → {l.end_date} · <span className="font-medium">{l.days_requested}d</span>
                    </div>
                    {l.reason && <div className="text-[11px] text-muted-foreground line-clamp-1 mt-0.5">{l.reason}</div>}
                  </div>
                  <Badge variant="outline" className="capitalize" style={{ background: `color-mix(in oklab, ${meta.tone} 12%, transparent)`, color: meta.tone, borderColor: "transparent" }}>{meta.label}</Badge>
                  <Badge variant="outline" className="capitalize">{l.status}</Badge>
                  {isAdmin && l.status === "pending" && (
                    <div className="flex gap-1.5">
                      <Button size="sm" variant="outline" onClick={() => decide(l, "rejected")}>Reject</Button>
                      <Button size="sm" style={{ background: "var(--workforce)", color: "white" }} onClick={() => decide(l, "approved")}>Approve</Button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </CardContent></Card>
    </WorkforcePage>
  );
}

function StatTile({ icon, label, value, tone }: { icon: React.ReactNode; label: string; value: number | string; tone: string }) {
  return (
    <Card>
      <CardContent className="p-3 flex items-center gap-3">
        <div className="h-8 w-8 rounded-md flex items-center justify-center" style={{ background: `color-mix(in oklab, ${tone} 14%, transparent)`, color: tone }}>
          {icon}
        </div>
        <div className="min-w-0">
          <div className="text-[11px] text-muted-foreground uppercase tracking-wide">{label}</div>
          <div className="text-lg font-semibold leading-tight">{value}</div>
        </div>
      </CardContent>
    </Card>
  );
}
