import { useEffect, useMemo, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { WorkforcePage, PageSkeleton } from "../page-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { writeEvent } from "@/lib/workforce";
import { toast } from "sonner";
import { DollarSign, FileText, CheckCircle2, Send, Search, Download } from "lucide-react";

const TAX_RATE = 0.1;

const STATUS = [
  { key: "all", label: "All" },
  { key: "draft", label: "Draft" },
  { key: "approved", label: "Approved" },
  { key: "paid", label: "Paid" },
] as const;

function statusMeta(s: string) {
  if (s === "paid") return { bg: "color-mix(in oklab, #10b981 20%, transparent)", fg: "#047857" };
  if (s === "approved") return { bg: "color-mix(in oklab, var(--workforce) 18%, transparent)", fg: "var(--workforce)" };
  return { bg: "color-mix(in oklab, #f59e0b 22%, transparent)", fg: "#b45309" };
}

function StatTile({ icon: Icon, label, value, tint }: { icon: any; label: string; value: any; tint: string }) {
  return (
    <Card>
      <CardContent className="p-4 flex items-center gap-3">
        <div className="h-10 w-10 rounded-lg flex items-center justify-center" style={{ background: tint }}>
          <Icon className="h-5 w-5" style={{ color: tint.includes("workforce") ? "var(--workforce)" : undefined }} />
        </div>
        <div className="min-w-0">
          <div className="text-[11px] uppercase tracking-wider text-muted-foreground">{label}</div>
          <div className="text-lg font-semibold truncate">{value}</div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function PayrollPage() {
  const { org, user, roles } = useAuth();
  const isAdmin = roles.includes("admin") || roles.includes("ceo") || roles.includes("manager");
  const [rows, setRows] = useState<any[] | null>(null);
  const [open, setOpen] = useState(false);
  const now = new Date();
  const [period, setPeriod] = useState({ year: now.getFullYear(), month: now.getMonth() + 1 });
  const [busy, setBusy] = useState(false);
  const [filter, setFilter] = useState<typeof STATUS[number]["key"]>("all");
  const [search, setSearch] = useState("");
  const [periodFilter, setPeriodFilter] = useState<string>("all");

  const load = async () => {
    if (!org?.id) return;
    const { data } = await supabase.from("payroll_records")
      .select("*,employees!inner(full_name)").eq("org_id", org.id)
      .order("year", { ascending: false }).order("month", { ascending: false }).limit(500);
    setRows(data ?? []);
  };
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [org?.id]);

  const generate = async () => {
    if (!org?.id) return;
    setBusy(true);
    try {
      const { data: emps } = await supabase.from("employees").select("id,salary,full_name").eq("org_id", org.id).eq("is_active", true);
      if (!emps?.length) { toast.error("No active employees"); return; }
      const { data: existing } = await supabase.from("payroll_records").select("employee_id").eq("org_id", org.id).eq("year", period.year).eq("month", period.month);
      const skip = new Set((existing ?? []).map((r: any) => r.employee_id));
      const inserts = emps.filter((e: any) => !skip.has(e.id)).map((e: any) => {
        const gross = Number(e.salary ?? 0);
        const tax = Math.round(gross * TAX_RATE);
        return {
          org_id: org.id, employee_id: e.id, year: period.year, month: period.month,
          base_salary: gross, gross_salary: gross, income_tax: tax, net_salary: gross - tax,
          status: "draft",
        };
      });
      if (!inserts.length) { toast.message("All employees already have records for this period"); return; }
      const { error } = await supabase.from("payroll_records").insert(inserts as any);
      if (error) { toast.error(error.message); return; }
      await writeEvent(org.id, "workforce", "payroll_generated", {
        year: period.year, month: period.month, count: inserts.length,
      }, user?.id);
      toast.success(`${inserts.length} draft records created`);
      setOpen(false); load();
    } finally { setBusy(false); }
  };

  const approve = async (r: any) => {
    if (!org?.id) return;
    const { error } = await supabase.from("payroll_records").update({ status: "approved", approved_at: new Date().toISOString(), approved_by: user?.id ?? null }).eq("id", r.id);
    if (error) return toast.error(error.message);
    await writeEvent(org.id, "workforce", "payroll_approved", {
      payroll_id: r.id, employee_id: r.employee_id, period: `${r.year}-${r.month}`,
    }, user?.id);
    toast.success("Approved");
    load();
  };

  const markPaid = async (r: any) => {
    const { error } = await supabase.from("payroll_records").update({ status: "paid" }).eq("id", r.id);
    if (error) return toast.error(error.message);
    toast.success("Marked paid");
    load();
  };

  const approveAll = async () => {
    if (!org?.id) return;
    const drafts = (rows ?? []).filter((r) => r.status === "draft").map((r) => r.id);
    if (!drafts.length) return toast.message("No drafts to approve");
    const { error } = await supabase.from("payroll_records").update({ status: "approved", approved_at: new Date().toISOString(), approved_by: user?.id ?? null } as any).in("id", drafts);
    if (error) return toast.error(error.message);
    toast.success(`${drafts.length} approved`);
    load();
  };

  const exportCsv = () => {
    const visible = filtered;
    const header = ["Employee", "Year", "Month", "Base", "Gross", "Tax", "Net", "Status"];
    const lines = [header.join(",")].concat(
      visible.map((r) => [
        JSON.stringify(r.employees?.full_name ?? ""),
        r.year, r.month, r.base_salary ?? 0, r.gross_salary ?? 0, r.income_tax ?? 0, r.net_salary ?? 0, r.status,
      ].join(","))
    );
    const blob = new Blob([lines.join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = `payroll-${Date.now()}.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  if (rows === null) return <PageSkeleton />;

  const periods = Array.from(new Set(rows.map((r) => `${r.year}-${String(r.month).padStart(2, "0")}`))).sort().reverse();
  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return rows.filter((r) => {
      if (filter !== "all" && r.status !== filter) return false;
      if (periodFilter !== "all" && `${r.year}-${String(r.month).padStart(2, "0")}` !== periodFilter) return false;
      if (q && !(r.employees?.full_name ?? "").toLowerCase().includes(q)) return false;
      return true;
    });
  }, [rows, filter, periodFilter, search]);

  const totals = filtered.reduce(
    (acc, r) => {
      acc.gross += Number(r.gross_salary ?? 0);
      acc.tax += Number(r.income_tax ?? 0);
      acc.net += Number(r.net_salary ?? 0);
      if (r.status === "draft") acc.drafts++;
      if (r.status === "paid") acc.paid++;
      return acc;
    },
    { gross: 0, tax: 0, net: 0, drafts: 0, paid: 0 }
  );

  const counts = STATUS.reduce((acc, s) => {
    acc[s.key] = s.key === "all" ? rows.length : rows.filter((r) => r.status === s.key).length;
    return acc;
  }, {} as Record<string, number>);

  return (
    <WorkforcePage
      title="Payroll"
      description={`${filtered.length} of ${rows.length} record${rows.length === 1 ? "" : "s"}`}
      actions={
        isAdmin && (
          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" onClick={exportCsv}><Download className="h-4 w-4 mr-1.5" /> Export</Button>
            {totals.drafts > 0 && (
              <Button size="sm" variant="outline" onClick={approveAll}><CheckCircle2 className="h-4 w-4 mr-1.5" /> Approve all drafts</Button>
            )}
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Button style={{ background: "var(--workforce)", color: "white" }}><FileText className="h-4 w-4 mr-1.5" /> Generate</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader><DialogTitle>Generate payroll</DialogTitle></DialogHeader>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label>Year</Label><Input type="number" value={period.year} onChange={(e) => setPeriod({ ...period, year: Number(e.target.value) })} /></div>
                  <div><Label>Month</Label><Input type="number" min={1} max={12} value={period.month} onChange={(e) => setPeriod({ ...period, month: Number(e.target.value) })} /></div>
                </div>
                <p className="text-xs text-muted-foreground">Creates draft records for all active employees using base salary minus {TAX_RATE * 100}% tax.</p>
                <DialogFooter><Button onClick={generate} disabled={busy}>{busy ? "Generating…" : "Generate drafts"}</Button></DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        )
      }
    >
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatTile icon={DollarSign} label="Total gross" value={totals.gross.toLocaleString()} tint="color-mix(in oklab, var(--workforce) 14%, transparent)" />
        <StatTile icon={DollarSign} label="Total net" value={totals.net.toLocaleString()} tint="color-mix(in oklab, #10b981 18%, transparent)" />
        <StatTile icon={FileText} label="Drafts" value={totals.drafts} tint="color-mix(in oklab, #f59e0b 22%, transparent)" />
        <StatTile icon={Send} label="Paid" value={totals.paid} tint="color-mix(in oklab, #6366f1 18%, transparent)" />
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        <div className="flex gap-1">
          {STATUS.map((s) => (
            <Button key={s.key} size="sm" variant={filter === s.key ? "default" : "outline"} className="h-7" onClick={() => setFilter(s.key)}>
              {s.label} <span className="ml-1.5 text-[10px] opacity-70">{counts[s.key]}</span>
            </Button>
          ))}
        </div>
        <select
          className="h-7 rounded-md border bg-background px-2 text-sm"
          value={periodFilter}
          onChange={(e) => setPeriodFilter(e.target.value)}
        >
          <option value="all">All periods</option>
          {periods.map((p) => <option key={p} value={p}>{p}</option>)}
        </select>
        <div className="relative ml-auto w-full md:w-72">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
          <Input className="h-8 pl-7" placeholder="Search employee…" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
      </div>

      <Card><CardContent className="p-0">
        {filtered.length === 0 ? (
          <div className="p-10 text-center text-sm text-muted-foreground">No payroll records in this view.</div>
        ) : (
          <table className="w-full text-sm">
            <thead className="text-xs uppercase text-muted-foreground bg-muted/40">
              <tr>
                <th className="text-left px-4 py-2">Employee</th>
                <th className="text-left px-4 py-2">Period</th>
                <th className="text-right px-4 py-2">Gross</th>
                <th className="text-right px-4 py-2">Tax</th>
                <th className="text-right px-4 py-2">Net</th>
                <th className="text-left px-4 py-2">Status</th>
                <th className="text-right px-4 py-2"></th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {filtered.map((r: any) => {
                const sm = statusMeta(r.status);
                return (
                  <tr key={r.id} className="hover:bg-muted/30">
                    <td className="px-4 py-2 font-medium">{r.employees?.full_name}</td>
                    <td className="px-4 py-2 text-muted-foreground">{r.year}-{String(r.month).padStart(2, "0")}</td>
                    <td className="px-4 py-2 text-right tabular-nums">{Number(r.gross_salary || 0).toLocaleString()}</td>
                    <td className="px-4 py-2 text-right tabular-nums text-muted-foreground">{Number(r.income_tax || 0).toLocaleString()}</td>
                    <td className="px-4 py-2 text-right tabular-nums font-semibold">{Number(r.net_salary || 0).toLocaleString()}</td>
                    <td className="px-4 py-2">
                      <Badge variant="outline" className="capitalize text-[10px]" style={{ background: sm.bg, color: sm.fg, borderColor: "transparent" }}>
                        {r.status}
                      </Badge>
                    </td>
                    <td className="px-4 py-2 text-right">
                      {isAdmin && r.status === "draft" && <Button size="sm" variant="outline" className="h-7" onClick={() => approve(r)}>Approve</Button>}
                      {isAdmin && r.status === "approved" && <Button size="sm" variant="outline" className="h-7" onClick={() => markPaid(r)}>Mark paid</Button>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </CardContent></Card>
    </WorkforcePage>
  );
}
