import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { WorkforcePage, PageSkeleton } from "../page-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { QuickCreate } from "@/components/quick-create";
import { toast } from "sonner";

export default function PerformancePage() {
  const { org } = useAuth();
  const [okrs, setOkrs] = useState<any[]>([]);
  const [reviews, setReviews] = useState<any[]>([]);
  const [kpis, setKpis] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [reload, setReload] = useState(0);
  const [editing, setEditing] = useState<string | null>(null);
  const [editValue, setEditValue] = useState<string>("");

  useEffect(() => {
    if (!org?.id) return;
    setLoading(true);
    Promise.all([
      supabase.from("okr_goals").select("*").eq("org_id", org.id).order("created_at", { ascending: false }).limit(50),
      supabase.from("performance_reviews").select("*").eq("org_id", org.id).order("created_at", { ascending: false }).limit(20),
      supabase.from("kpi_records").select("*").eq("org_id", org.id).order("created_at", { ascending: false }).limit(20),
    ]).then(([o, r, k]) => {
      setOkrs(o.data ?? []); setReviews(r.data ?? []); setKpis(k.data ?? []); setLoading(false);
    });
  }, [org?.id, reload]);

  const saveProgress = async (o: any) => {
    const v = Math.max(0, Math.min(100, Number(editValue) || 0));
    const { error } = await supabase.from("okr_goals").update({
      progress: v, status: v >= 100 ? "completed" : v > 0 ? "in_progress" : "not_started",
    }).eq("id", o.id);
    if (error) return toast.error(error.message);
    toast.success("Progress updated");
    setEditing(null);
    setReload((k) => k + 1);
  };

  if (loading) return <PageSkeleton />;

  const avgProgress = okrs.length ? Math.round(okrs.reduce((s, o) => s + (o.progress ?? 0), 0) / okrs.length) : 0;

  return (
    <WorkforcePage
      title="Performance"
      description={`${okrs.length} OKRs · avg progress ${avgProgress}%`}
      actions={
        <QuickCreate
          table="okr_goals"
          title="New OKR"
          buttonLabel="New OKR"
          buttonStyle={{ background: "var(--workforce)", color: "white" }}
          fields={[
            { key: "title", label: "Goal title", required: true },
            { key: "description", label: "Description", type: "textarea" },
            { key: "period", label: "Period", placeholder: "Q2 2026" },
          ]}
          defaults={{ level: "team", progress: 0, status: "not_started" }}
          onCreated={() => setReload((k) => k + 1)}
        />
      }
    >
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="md:col-span-2"><CardHeader><CardTitle className="text-base">OKRs</CardTitle></CardHeader><CardContent className="space-y-3">
          {okrs.length === 0 ? (
            <p className="text-sm text-muted-foreground">No goals yet. Click "New OKR" to start.</p>
          ) : okrs.map((o) => (
            <div key={o.id} className="border-l-2 pl-3 py-1" style={{ borderColor: "var(--workforce)" }}>
              <div className="flex items-center justify-between gap-2">
                <div className="font-medium text-sm">{o.title}</div>
                <span className="text-xs text-muted-foreground">{o.period ?? "—"} · {o.level}</span>
              </div>
              {o.description && <div className="text-xs text-muted-foreground mt-0.5">{o.description}</div>}
              <div className="flex items-center gap-2 mt-2">
                <Progress value={o.progress ?? 0} className="flex-1 h-2" />
                {editing === o.id ? (
                  <>
                    <Input
                      type="number" min={0} max={100}
                      className="w-20 h-7"
                      value={editValue}
                      onChange={(e) => setEditValue(e.target.value)}
                    />
                    <Button size="sm" className="h-7" onClick={() => saveProgress(o)}>Save</Button>
                    <Button size="sm" variant="ghost" className="h-7" onClick={() => setEditing(null)}>Cancel</Button>
                  </>
                ) : (
                  <>
                    <span className="text-xs font-medium w-10 text-right">{o.progress ?? 0}%</span>
                    <Button size="sm" variant="ghost" className="h-7" onClick={() => { setEditing(o.id); setEditValue(String(o.progress ?? 0)); }}>Update</Button>
                  </>
                )}
              </div>
            </div>
          ))}
        </CardContent></Card>

        <div className="space-y-4">
          <Card><CardHeader><CardTitle className="text-base">Reviews ({reviews.length})</CardTitle></CardHeader><CardContent className="space-y-2 text-sm">
            {reviews.length === 0 ? <p className="text-muted-foreground">No reviews yet.</p> : reviews.slice(0, 6).map((r) => (
              <div key={r.id} className="flex justify-between">
                <div>
                  <div className="font-medium">{r.period}</div>
                  <div className="text-xs text-muted-foreground">{r.review_type}</div>
                </div>
                <div className="text-sm font-semibold" style={{ color: "var(--workforce)" }}>{r.overall_rating ?? "—"}</div>
              </div>
            ))}
          </CardContent></Card>

          <Card><CardHeader><CardTitle className="text-base">KPIs ({kpis.length})</CardTitle></CardHeader><CardContent className="space-y-2 text-sm">
            {kpis.length === 0 ? <p className="text-muted-foreground">No KPIs yet.</p> : kpis.slice(0, 6).map((k) => {
              const pct = k.target_value > 0 ? Math.round((k.current_value / k.target_value) * 100) : 0;
              return (
                <div key={k.id}>
                  <div className="flex justify-between">
                    <span className="font-medium">{k.metric_name}</span>
                    <span className="text-xs text-muted-foreground">{k.current_value}/{k.target_value} {k.unit ?? ""}</span>
                  </div>
                  <Progress value={Math.min(100, pct)} className="h-1.5 mt-1" />
                </div>
              );
            })}
          </CardContent></Card>
        </div>
      </div>
    </WorkforcePage>
  );
}
