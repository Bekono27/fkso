import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { WorkforcePage, PageSkeleton } from "../page-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Megaphone, Pin, Trash2 } from "lucide-react";
import { toast } from "sonner";

const PRIORITIES = [
  { key: "low", label: "Low", color: "color-mix(in oklab, var(--workforce) 8%, transparent)", text: "var(--muted-foreground)" },
  { key: "normal", label: "Normal", color: "color-mix(in oklab, var(--workforce) 14%, transparent)", text: "var(--workforce)" },
  { key: "high", label: "High", color: "color-mix(in oklab, #f59e0b 22%, transparent)", text: "#b45309" },
  { key: "urgent", label: "Urgent", color: "color-mix(in oklab, #ef4444 24%, transparent)", text: "#b91c1c" },
] as const;

function priorityMeta(p: string | null | undefined) {
  return PRIORITIES.find((x) => x.key === p) ?? PRIORITIES[1];
}

export default function AnnouncementsPage() {
  const { org, user, roles } = useAuth();
  const isAdmin = roles.includes("admin") || roles.includes("ceo") || roles.includes("manager");
  const [rows, setRows] = useState<any[] | null>(null);
  const [open, setOpen] = useState(false);
  const [filter, setFilter] = useState<"all" | "active" | "pinned">("active");
  const [form, setForm] = useState({ title: "", content: "", priority: "normal", pinned: false });

  const load = async () => {
    if (!org?.id) return;
    const { data } = await supabase
      .from("announcements")
      .select("*")
      .eq("org_id", org.id)
      .order("created_at", { ascending: false })
      .limit(100);
    setRows(data ?? []);
  };
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [org?.id]);

  const post = async () => {
    if (!org?.id || !form.title.trim()) return;
    const payload: any = {
      org_id: org.id,
      title: form.title.trim(),
      content: form.content,
      priority: form.priority,
      author_id: user?.id,
      is_active: true,
    };
    if (form.pinned) payload.pinned = true;
    const { error } = await supabase.from("announcements").insert(payload);
    if (error) return toast.error(error.message);
    toast.success("Posted");
    setOpen(false);
    setForm({ title: "", content: "", priority: "normal", pinned: false });
    load();
  };

  const togglePinned = async (a: any) => {
    const { error } = await supabase.from("announcements").update({ pinned: !a.pinned } as any).eq("id", a.id);
    if (error) toast.error(error.message); else load();
  };

  const remove = async (a: any) => {
    if (!confirm(`Delete "${a.title}"?`)) return;
    const { error } = await supabase.from("announcements").delete().eq("id", a.id);
    if (error) toast.error(error.message); else { toast.success("Deleted"); load(); }
  };

  if (rows === null) return <PageSkeleton />;

  const visible = rows.filter((a) => {
    if (filter === "pinned") return a.pinned;
    if (filter === "active") return a.is_active !== false;
    return true;
  });
  const sorted = [...visible].sort((a, b) => {
    if (!!b.pinned !== !!a.pinned) return b.pinned ? 1 : -1;
    return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
  });

  return (
    <WorkforcePage
      title="Announcements"
      description={`${visible.length} of ${rows.length} announcement${rows.length === 1 ? "" : "s"}`}
      actions={
        isAdmin && (
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button style={{ background: "var(--workforce)", color: "white" }}>
                <Megaphone className="h-4 w-4 mr-1.5" /> New
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>New announcement</DialogTitle></DialogHeader>
              <div className="space-y-3">
                <div>
                  <Label>Title</Label>
                  <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Q4 all-hands meeting" />
                </div>
                <div>
                  <Label>Content</Label>
                  <Textarea rows={5} value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label>Priority</Label>
                    <Select value={form.priority} onValueChange={(v) => setForm({ ...form, priority: v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {PRIORITIES.map((p) => (
                          <SelectItem key={p.key} value={p.key}>{p.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <label className="flex items-end gap-2 pb-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={form.pinned}
                      onChange={(e) => setForm({ ...form, pinned: e.target.checked })}
                      className="rounded"
                    />
                    <span className="text-sm flex items-center gap-1"><Pin className="h-3.5 w-3.5" /> Pin to top</span>
                  </label>
                </div>
              </div>
              <DialogFooter>
                <Button onClick={post} disabled={!form.title.trim()}>Post</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )
      }
    >
      <div className="flex gap-1">
        {(["active", "pinned", "all"] as const).map((f) => (
          <Button key={f} size="sm" variant={filter === f ? "default" : "outline"} className="h-7 capitalize" onClick={() => setFilter(f)}>
            {f}
          </Button>
        ))}
      </div>

      {sorted.length === 0 ? (
        <Card><CardContent className="p-10 text-center text-sm text-muted-foreground">No announcements in this view.</CardContent></Card>
      ) : (
        <div className="space-y-3">
          {sorted.map((a) => {
            const pm = priorityMeta(a.priority);
            return (
              <Card key={a.id} className={a.pinned ? "border-l-4" : ""} style={a.pinned ? { borderLeftColor: "var(--workforce)" } : undefined}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        {a.pinned && <Pin className="h-3.5 w-3.5" style={{ color: "var(--workforce)" }} />}
                        <div className="font-medium">{a.title}</div>
                        <Badge variant="outline" className="capitalize text-[10px]" style={{ background: pm.color, color: pm.text, borderColor: "transparent" }}>
                          {pm.label}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1.5 whitespace-pre-wrap">{a.content}</p>
                      <div className="text-[11px] text-muted-foreground mt-2">{new Date(a.created_at).toLocaleString()}</div>
                    </div>
                    {isAdmin && (
                      <div className="flex flex-col gap-1">
                        <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => togglePinned(a)} title={a.pinned ? "Unpin" : "Pin"}>
                          <Pin className="h-3.5 w-3.5" style={a.pinned ? { color: "var(--workforce)" } : undefined} />
                        </Button>
                        <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive" onClick={() => remove(a)} title="Delete">
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </WorkforcePage>
  );
}
