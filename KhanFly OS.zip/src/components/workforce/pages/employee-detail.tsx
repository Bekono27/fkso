import { useEffect, useState } from "react";
import { useParams } from "@tanstack/react-router";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { WorkforcePage, PageSkeleton } from "../page-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { writeEvent } from "@/lib/workforce";
import { toast } from "sonner";

export default function EmployeeDetail() {
  const { id } = useParams({ from: "/_app/workforce/employees/$id" });
  const { org, user } = useAuth();
  const [emp, setEmp] = useState<any | null>(null);
  const [sessions, setSessions] = useState<any[]>([]);
  const [leaves, setLeaves] = useState<any[]>([]);
  const [payroll, setPayroll] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!org?.id) return;
    (async () => {
      const { data: e } = await supabase.from("employees").select("*").eq("id", id).eq("org_id", org.id).maybeSingle();
      setEmp(e);
      if (e) {
        const [s, l, p] = await Promise.all([
          supabase.from("work_sessions").select("*").eq("employee_id", e.id).order("date", { ascending: false }).limit(20),
          supabase.from("leave_requests").select("*").eq("employee_id", e.id).order("start_date", { ascending: false }).limit(20),
          supabase.from("payroll_records").select("*").eq("employee_id", e.id).order("year", { ascending: false }).order("month", { ascending: false }).limit(12),
        ]);
        setSessions(s.data ?? []); setLeaves(l.data ?? []); setPayroll(p.data ?? []);
      }
      setLoading(false);
    })();
  }, [org?.id, id]);

  const offboard = async () => {
    if (!org?.id || !emp) return;
    const { error } = await supabase.from("employees").update({ is_active: false }).eq("id", emp.id);
    if (error) return toast.error(error.message);
    await writeEvent(org.id, "workforce", "employee_offboarded", {
      employee_id: emp.id, name: emp.full_name, last_day: new Date().toISOString().split("T")[0],
    }, user?.id);
    toast.success("Employee offboarded");
    setEmp({ ...emp, is_active: false });
  };

  if (loading) return <PageSkeleton />;
  if (!emp) return <WorkforcePage title="Not found"><p className="text-sm text-muted-foreground">Employee not found.</p></WorkforcePage>;

  return (
    <WorkforcePage
      title={emp.full_name}
      description={emp.position ?? "Employee"}
      actions={emp.is_active ? <Button variant="outline" onClick={offboard}>Offboard</Button> : <Badge variant="outline">Inactive</Badge>}
    >
      <Tabs defaultValue="overview">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="attendance">Attendance ({sessions.length})</TabsTrigger>
          <TabsTrigger value="leave">Leave ({leaves.length})</TabsTrigger>
          <TabsTrigger value="payroll">Payroll ({payroll.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card><CardHeader><CardTitle className="text-base">Contact</CardTitle></CardHeader><CardContent className="space-y-1.5 text-sm">
              <div><span className="text-muted-foreground">Email:</span> {emp.email ?? "—"}</div>
              <div><span className="text-muted-foreground">Phone:</span> {emp.phone ?? "—"}</div>
              <div><span className="text-muted-foreground">Code:</span> {emp.employee_code ?? "—"}</div>
            </CardContent></Card>
            <Card><CardHeader><CardTitle className="text-base">Employment</CardTitle></CardHeader><CardContent className="space-y-1.5 text-sm">
              <div><span className="text-muted-foreground">Hired:</span> {emp.hire_date ?? "—"}</div>
              <div><span className="text-muted-foreground">Salary:</span> {emp.salary ? Number(emp.salary).toLocaleString() + " MNT" : "—"}</div>
              <div><span className="text-muted-foreground">Hours/day:</span> {emp.work_hours_per_day ?? "—"}</div>
            </CardContent></Card>
          </div>
        </TabsContent>

        <TabsContent value="attendance" className="mt-4">
          <Card><CardContent className="p-0">
            {sessions.length === 0 ? <div className="p-8 text-center text-sm text-muted-foreground">No attendance records.</div> : (
              <table className="w-full text-sm"><thead className="text-xs uppercase text-muted-foreground bg-muted/40">
                <tr><th className="text-left px-4 py-2">Date</th><th className="text-left px-4 py-2">In</th><th className="text-left px-4 py-2">Out</th><th className="text-left px-4 py-2">Hours</th></tr>
              </thead><tbody className="divide-y">
                {sessions.map((s) => (
                  <tr key={s.id}>
                    <td className="px-4 py-2">{s.date}</td>
                    <td className="px-4 py-2">{s.clock_in ? new Date(s.clock_in).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : "—"}</td>
                    <td className="px-4 py-2">{s.clock_out ? new Date(s.clock_out).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : "—"}</td>
                    <td className="px-4 py-2">{s.total_minutes ? (s.total_minutes / 60).toFixed(1) + "h" : "—"}</td>
                  </tr>
                ))}
              </tbody></table>
            )}
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="leave" className="mt-4">
          <Card><CardContent className="p-0">
            {leaves.length === 0 ? <div className="p-8 text-center text-sm text-muted-foreground">No leave history.</div> : (
              <div className="divide-y">{leaves.map((l) => (
                <div key={l.id} className="flex items-center gap-3 px-4 py-2.5 text-sm">
                  <div className="flex-1"><div className="font-medium">{l.leave_type}</div><div className="text-xs text-muted-foreground">{l.start_date} → {l.end_date}</div></div>
                  <Badge variant="outline">{l.status}</Badge>
                </div>
              ))}</div>
            )}
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="payroll" className="mt-4">
          <Card><CardContent className="p-0">
            {payroll.length === 0 ? <div className="p-8 text-center text-sm text-muted-foreground">No payroll records.</div> : (
              <table className="w-full text-sm"><thead className="text-xs uppercase text-muted-foreground bg-muted/40">
                <tr><th className="text-left px-4 py-2">Period</th><th className="text-left px-4 py-2">Gross</th><th className="text-left px-4 py-2">Net</th><th className="text-left px-4 py-2">Status</th></tr>
              </thead><tbody className="divide-y">
                {payroll.map((p) => (
                  <tr key={p.id}>
                    <td className="px-4 py-2">{p.year}-{String(p.month).padStart(2, "0")}</td>
                    <td className="px-4 py-2">{Number(p.gross_salary || 0).toLocaleString()}</td>
                    <td className="px-4 py-2">{Number(p.net_salary || 0).toLocaleString()}</td>
                    <td className="px-4 py-2"><Badge variant="outline">{p.status}</Badge></td>
                  </tr>
                ))}
              </tbody></table>
            )}
          </CardContent></Card>
        </TabsContent>
      </Tabs>
    </WorkforcePage>
  );
}
