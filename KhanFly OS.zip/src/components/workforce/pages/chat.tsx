import { useEffect, useMemo, useRef, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { WorkforcePage, PageSkeleton } from "../page-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Hash, Send, Plus, Search, Lock } from "lucide-react";
import { toast } from "sonner";

function initials(name: string) {
  return name.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase();
}

function fmtTime(iso: string) {
  const d = new Date(iso);
  const today = new Date();
  if (d.toDateString() === today.toDateString()) return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  return d.toLocaleDateString([], { month: "short", day: "numeric" }) + " " + d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

export default function ChatPage() {
  const { org, user } = useAuth();
  const [empId, setEmpId] = useState<string | null>(null);
  const [channels, setChannels] = useState<any[]>([]);
  const [active, setActive] = useState<any | null>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "", description: "", type: "group" as "group" | "private" });
  const endRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!org?.id || !user?.id) return;
    (async () => {
      const { data: e } = await supabase.from("employees").select("id").eq("org_id", org.id).eq("user_id", user.id).maybeSingle();
      setEmpId(e?.id ?? null);
      const { data: ch } = await supabase.from("chat_channels").select("*").eq("org_id", org.id).eq("is_archived", false).order("created_at", { ascending: true });
      setChannels(ch ?? []);
      setActive((ch ?? [])[0] ?? null);
      setLoading(false);
    })();
  }, [org?.id, user?.id]);

  useEffect(() => {
    if (!active || !org?.id) return;
    supabase.from("chat_messages").select("*,sender:employees!sender_id(full_name)")
      .eq("org_id", org.id).eq("channel_id", active.id).order("created_at", { ascending: true }).limit(200)
      .then(({ data }) => { setMessages(data ?? []); setTimeout(() => endRef.current?.scrollIntoView({ behavior: "smooth" }), 50); });
    const ch = supabase.channel("chat-" + active.id).on("postgres_changes", { event: "INSERT", schema: "public", table: "chat_messages", filter: `channel_id=eq.${active.id}` }, async (payload) => {
      const m: any = payload.new;
      // hydrate sender
      const { data: s } = await supabase.from("employees").select("full_name").eq("id", m.sender_id).maybeSingle();
      setMessages((prev) => [...prev, { ...m, sender: s }]);
      setTimeout(() => endRef.current?.scrollIntoView({ behavior: "smooth" }), 50);
    }).subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [active, org?.id]);

  useEffect(() => { inputRef.current?.focus(); }, [active]);

  const send = async () => {
    if (!org?.id || !active || !empId || !text.trim()) return;
    const content = text.trim();
    setText("");
    const { error } = await supabase.from("chat_messages").insert({
      org_id: org.id, channel_id: active.id, sender_id: empId, content,
    } as any);
    if (error) { setText(content); toast.error(error.message); }
  };

  const createChannel = async () => {
    if (!form.name.trim() || !org?.id || !empId) return;
    const { data, error } = await supabase.from("chat_channels").insert({
      org_id: org.id, name: form.name.trim(), description: form.description || null, type: form.type, created_by: empId,
    } as any).select().single();
    if (error) return toast.error(error.message);
    await supabase.from("chat_members").insert({ org_id: org.id, channel_id: data.id, employee_id: empId, role: "owner" } as any);
    setChannels((c) => [...c, data]);
    setActive(data);
    setOpen(false);
    setForm({ name: "", description: "", type: "group" });
    toast.success("Channel created");
  };

  const filteredChannels = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return channels;
    return channels.filter((c) => c.name.toLowerCase().includes(q));
  }, [channels, search]);

  if (loading) return <PageSkeleton />;

  return (
    <WorkforcePage
      title="Team Chat"
      description={`${channels.length} channel${channels.length === 1 ? "" : "s"}`}
      actions={
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button style={{ background: "var(--workforce)", color: "white" }}><Plus className="h-4 w-4 mr-1.5" /> Channel</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Create channel</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div><Label>Name</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value.toLowerCase().replace(/\s+/g, "-") })} placeholder="general" /></div>
              <div><Label>Description</Label><Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="What is this channel about?" /></div>
              <div>
                <Label>Type</Label>
                <div className="flex gap-2 mt-1">
                  {(["group", "private"] as const).map((t) => (
                    <button key={t} type="button" onClick={() => setForm({ ...form, type: t })}
                      className={`flex-1 px-3 py-2 rounded-md border text-sm capitalize ${form.type === t ? "border-[var(--workforce)] bg-muted" : ""}`}>
                      {t}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <DialogFooter><Button onClick={createChannel} disabled={!form.name.trim()}>Create</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      }
    >
      <div className="grid grid-cols-1 md:grid-cols-[260px_1fr] gap-4 h-[calc(100vh-280px)] min-h-[500px]">
        <Card className="overflow-hidden">
          <div className="p-2 border-b">
            <div className="relative">
              <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input className="h-8 pl-7 text-sm" placeholder="Search channels…" value={search} onChange={(e) => setSearch(e.target.value)} />
            </div>
          </div>
          <CardContent className="p-2 overflow-y-auto h-full">
            {filteredChannels.length === 0 ? (
              <div className="text-sm text-muted-foreground p-3 text-center">No channels.</div>
            ) : filteredChannels.map((c) => (
              <button
                key={c.id}
                onClick={() => setActive(c)}
                className={`w-full text-left px-2.5 py-1.5 rounded-md text-sm flex items-center gap-2 ${active?.id === c.id ? "bg-muted font-medium" : "hover:bg-muted/50"}`}
                style={active?.id === c.id ? { color: "var(--workforce)" } : undefined}
              >
                {c.type === "private" ? <Lock className="h-3.5 w-3.5" /> : <Hash className="h-3.5 w-3.5" />}
                <span className="truncate">{c.name}</span>
              </button>
            ))}
          </CardContent>
        </Card>

        <Card className="flex flex-col overflow-hidden">
          <div className="px-4 py-2.5 border-b flex items-center gap-2">
            {active ? (
              <>
                {active.type === "private" ? <Lock className="h-4 w-4" /> : <Hash className="h-4 w-4" />}
                <div className="font-semibold">{active.name}</div>
                {active.description && <div className="text-xs text-muted-foreground">· {active.description}</div>}
              </>
            ) : <div className="text-sm text-muted-foreground">Select a channel</div>}
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.length === 0 && active && (
              <div className="text-center text-sm text-muted-foreground py-12">
                Be the first to send a message in <span className="font-medium">#{active.name}</span>.
              </div>
            )}
            {messages.map((m, i) => {
              const prev = messages[i - 1];
              const samePrev = prev && prev.sender_id === m.sender_id && (new Date(m.created_at).getTime() - new Date(prev.created_at).getTime() < 5 * 60 * 1000);
              const name = m.sender?.full_name ?? "User";
              const mine = m.sender_id === empId;
              return (
                <div key={m.id} className={`flex gap-2.5 ${samePrev ? "" : "mt-3"}`}>
                  {samePrev ? (
                    <div className="w-8" />
                  ) : (
                    <div className="h-8 w-8 rounded-full text-[11px] flex items-center justify-center font-semibold shrink-0"
                      style={{ background: "color-mix(in oklab, var(--workforce) 14%, transparent)", color: "var(--workforce)" }}>
                      {initials(name)}
                    </div>
                  )}
                  <div className="min-w-0 flex-1">
                    {!samePrev && (
                      <div className="flex items-baseline gap-2">
                        <span className="font-medium text-sm">{name}{mine && <span className="text-[10px] text-muted-foreground ml-1">(you)</span>}</span>
                        <span className="text-[10px] text-muted-foreground">{fmtTime(m.created_at)}</span>
                      </div>
                    )}
                    <div className="text-sm whitespace-pre-wrap break-words">{m.content}</div>
                  </div>
                </div>
              );
            })}
            <div ref={endRef} />
          </div>
          {active && (
            <div className="border-t p-2 flex gap-2">
              <Input
                ref={inputRef}
                value={text}
                onChange={(e) => setText(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
                placeholder={`Message #${active.name}`}
              />
              <Button onClick={send} disabled={!text.trim()} style={{ background: "var(--workforce)", color: "white" }}>
                <Send className="h-4 w-4" />
              </Button>
            </div>
          )}
        </Card>
      </div>
    </WorkforcePage>
  );
}
