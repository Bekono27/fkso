import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Users, CalendarDays, Clock, TrendingUp, CheckCircle2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { WorkforcePage } from "./page-shell";
import { writeEvent, todayISO, getMondayISO } from "@/lib/workforce";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

const TEAL = "var(--workforce)";

function MetricCard({
  label, value, sub, icon: Icon, to, accent = TEAL,
}: { label: string; value: string | number; sub?: string; icon: any; to?: string; accent?: string }) {
  const inner = (
    <Card className="hover:shadow-md transition-shadow cursor-pointer h-full">
      <CardContent className="p-5">
        <div className="flex items-start justify-between">
          <div>
            <div className="text-xs text-muted-foreground uppercase tracking-wider">{label}</div>
            <div className="text-3xl font-bold mt-2" style={{ color: accent }}>{value}</div>
            {sub && <div className="text-xs text-muted-foreground mt-1">{sub}</div>}
          </div>
          <div className="rounded-lg p-2" style={{ background: `color-mix(in oklab, ${accent} 14%, transparent)`, color: accent }}>
            <Icon className="h-5 w-5" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
  return to ? <Link to={to}>{inner}</Link> : inner;
}

type Pres = { employee_id: string; name: string; dept: string | null; status: "present" | "absent" | "leave"; clock_in?: string; leave_type?: string };

export default function WorkforceDashboard() {
  const { org, user } = useAuth();
  const orgId = org?.id;
  const today = todayISO();
  const weekStart = getMondayISO();

  const [totalEmp, setTotalEmp] = useState(0);
  const [presentNow, setPresentNow] = useState(0);
  const [onLeave, setOnLeave] = useState(0);
  const [returningTomorrow, setReturningTomorrow] = useState(0);
  const [pendingLeave, setPendingLeave] = useState<any[]>([]);
  const [draftPayroll, setDraftPayroll] = useState<any[]>([]);
  const [openTickets, setOpenTickets] = useState<any[]>([]);
  const [overtimeH, setOvertimeH] = useState(0);
  const [overtimeEmps, setOvertimeEmps] = useState(0);
  const [presence, setPresence] = useState<Pres[]>([]);
  const [recentEvents, setRecentEvents] = useState<any[]>([]);
  const [weekStats, setWeekStats] = useState<{ day: string; pct: number; present: number; absent: number; leave: number }[]>([]);

  const loadAll = async () => {
    if (!orgId) return;
    const tomorrow = new Date(Date.now() + 86400000).toISOString().split("T")[0];

    const [emps, sessions, leaveToday, leaveTmr, leavePending, payDraft, ticketsOpen, otRows, recent] = await Promise.all([
      supabase.from("employees").select("id,full_name,department_id,user_id,avatar_url,is_active").eq("org_id", orgId).eq("is_active", true),
      supabase.from("work_sessions").select("employee_id,clock_in,clock_out,date").eq("org_id", orgId).eq("date", today),
      supabase.from("leave_requests").select("id,employee_id,leave_type,start_date,end_date").eq("org_id", orgId).eq("status", "approved").lte("start_date", today).gte("end_date", today),
      supabase.from("leave_requests").select("id").eq("org_id", orgId).eq("status", "approved").eq("end_date", today),
      supabase.from("leave_requests").select("id,employee_id,leave_type,start_date,end_date,reason").eq("org_id", orgId).eq("status", "pending").order("created_at", { ascending: false }).limit(10),
      supabase.from("payroll_records").select("id,month,year,gross_salary,employee_id").eq("org_id", orgId).eq("status", "draft").order("created_at", { ascending: false }).limit(10),
      supabase.from("helpdesk_tickets").select("id,title,priority,created_at").eq("org_id", orgId).eq("status", "open").is("assignee_id", null).order("created_at", { ascending: false }).limit(10),
      supabase.from("work_sessions").select("employee_id,overtime_minutes").eq("org_id", orgId).gte("date", weekStart),
      supabase.from("work_sessions").select("id,employee_id,clock_in,clock_out,created_at").eq("org_id", orgId).order("created_at", { ascending: false }).limit(15),
    ]);

    const empList = emps.data ?? [];
    setTotalEmp(empList.length);

    const sessionMap = new Map<string, any>();
    (sessions.data ?? []).forEach((s: any) => sessionMap.set(s.employee_id, s));
    const present = (sessions.data ?? []).filter((s: any) => !s.clock_out);
    setPresentNow(present.length);

    setOnLeave(leaveToday.data?.length ?? 0);
    setReturningTomorrow(leaveTmr.data?.length ?? 0);

    // pending counts
    const [pendLeaveCount, draftPayCount, openTicketCount] = await Promise.all([
      supabase.from("leave_requests").select("id", { count: "exact", head: true }).eq("org_id", orgId).eq("status", "pending"),
      supabase.from("payroll_records").select("id", { count: "exact", head: true }).eq("org_id", orgId).eq("status", "draft"),
      supabase.from("helpdesk_tickets").select("id", { count: "exact", head: true }).eq("org_id", orgId).eq("status", "open").is("assignee_id", null),
    ]);
    void pendLeaveCount; void draftPayCount; void openTicketCount;

    // names lookup
    const empById = new Map(empList.map((e: any) => [e.id, e]));
    const leaveByEmp = new Map((leaveToday.data ?? []).map((l: any) => [l.employee_id, l]));

    const presList: Pres[] = empList.map((e: any): Pres => {
      const s = sessionMap.get(e.id);
      const lv = leaveByEmp.get(e.id);
      if (lv) return { employee_id: e.id, name: e.full_name, dept: null, status: "leave" as const, leave_type: lv.leave_type };
      if (s && !s.clock_out) return { employee_id: e.id, name: e.full_name, dept: null, status: "present" as const, clock_in: s.clock_in };
      return { employee_id: e.id, name: e.full_name, dept: null, status: "absent" as const };
    }).sort((a, b) => {
      const order: Record<Pres["status"], number> = { present: 0, leave: 1, absent: 2 };
      return order[a.status] - order[b.status];
    });
    setPresence(presList);

    setPendingLeave((leavePending.data ?? []).map((l: any) => ({ ...l, employee: empById.get(l.employee_id) })));
    setDraftPayroll(payDraft.data ?? []);
    setOpenTickets(ticketsOpen.data ?? []);

    // overtime
    const otByEmp = new Map<string, number>();
    (otRows.data ?? []).forEach((r: any) => {
      otByEmp.set(r.employee_id, (otByEmp.get(r.employee_id) ?? 0) + (r.overtime_minutes ?? 0));
    });
    let totalOt = 0;
    let empsWithOt = 0;
    otByEmp.forEach((mins) => { totalOt += mins; if (mins > 0) empsWithOt++; });
    setOvertimeH(Math.round(totalOt / 60));
    setOvertimeEmps(empsWithOt);

    setRecentEvents((recent.data ?? []).map((s: any) => ({ ...s, employee: empById.get(s.employee_id) })));

    // week stats
    const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    const monday = new Date(weekStart);
    const allWeekSessions = await supabase.from("work_sessions").select("employee_id,date,clock_out").eq("org_id", orgId).gte("date", weekStart);
    const stats = days.map((d, i) => {
      const dateStr = new Date(monday.getTime() + i * 86400000).toISOString().split("T")[0];
      const dayPresent = new Set((allWeekSessions.data ?? []).filter((s: any) => s.date === dateStr).map((s: any) => s.employee_id)).size;
      const pct = empList.length ? Math.round((dayPresent / empList.length) * 100) : 0;
      return { day: d, pct, present: dayPresent, absent: Math.max(0, empList.length - dayPresent), leave: 0 };
    });
    setWeekStats(stats);
  };

  useEffect(() => {
    loadAll();
    if (!orgId) return;
    const ch = supabase
      .channel("workforce-dashboard-" + orgId)
      .on("postgres_changes", { event: "*", schema: "public", table: "work_sessions", filter: `org_id=eq.${orgId}` }, () => loadAll())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orgId]);

  const otColor = overtimeH > 80 ? "var(--destructive)" : overtimeH > 40 ? "#f59e0b" : TEAL;
  const pendingTotal = pendingLeave.length + draftPayroll.length + openTickets.length;

  const approveLeave = async (leave: any) => {
    if (!orgId) return;
    const { error } = await supabase.from("leave_requests")
      .update({ status: "approved", reviewed_by: user?.id, reviewed_at: new Date().toISOString() })
      .eq("id", leave.id);
    if (error) { toast.error(error.message); return; }
    await writeEvent(orgId, "workforce", "leave_approved", {
      employee_id: leave.employee_id,
      name: leave.employee?.full_name,
      start_date: leave.start_date,
      end_date: leave.end_date,
      leave_type: leave.leave_type,
    }, user?.id);
    toast.success("Leave approved");
    loadAll();
  };
  const rejectLeave = async (leave: any) => {
    if (!orgId) return;
    const { error } = await supabase.from("leave_requests")
      .update({ status: "rejected", reviewed_by: user?.id, reviewed_at: new Date().toISOString() })
      .eq("id", leave.id);
    if (error) { toast.error(error.message); return; }
    await writeEvent(orgId, "workforce", "leave_rejected", {
      employee_id: leave.employee_id,
      name: leave.employee?.full_name,
      start_date: leave.start_date,
      end_date: leave.end_date,
    }, user?.id);
    toast.success("Leave rejected");
    loadAll();
  };

  return (
    <WorkforcePage hero title="Workforce Overview" description="Attendance, payroll, HR, projects and ops in one pane.">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard label="Present now" value={presentNow} sub={`of ${totalEmp} total`} icon={Users} to="/workforce/attendance" />
        <MetricCard label="On leave today" value={onLeave} sub={`${returningTomorrow} returning tomorrow`} icon={CalendarDays} to="/workforce/leave" />
        <MetricCard label="Pending approvals" value={pendingTotal} sub="need your attention" icon={Clock} />
        <MetricCard label="Overtime this week" value={`${overtimeH}h`} sub={`across ${overtimeEmps} employees`} icon={TrendingUp} accent={otColor} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Live presence */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center justify-between">
              <span>Who's in today</span>
              <span className="text-xs text-muted-foreground font-normal">{new Date().toLocaleDateString()}</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="max-h-80 overflow-y-auto divide-y">
              {presence.length === 0 && <div className="p-6 text-sm text-muted-foreground text-center">No employees yet.</div>}
              {presence.map((p) => (
                <div key={p.employee_id} className="flex items-center gap-3 px-4 py-2.5">
                  <div className="h-8 w-8 rounded-full bg-muted text-xs flex items-center justify-center font-medium">
                    {p.name.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">{p.name}</div>
                    {p.clock_in && <div className="text-[11px] text-muted-foreground">in at {new Date(p.clock_in).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</div>}
                    {p.leave_type && <div className="text-[11px] text-muted-foreground">{p.leave_type}</div>}
                  </div>
                  <Badge variant="outline" style={{
                    borderColor:
                      p.status === "present" ? "#16a34a" :
                      p.status === "leave" ? "#f59e0b" : "#ef4444",
                    color:
                      p.status === "present" ? "#16a34a" :
                      p.status === "leave" ? "#f59e0b" : "#ef4444",
                  }}>
                    {p.status === "present" ? "🟢 Present" : p.status === "leave" ? "🟡 On leave" : "🔴 Absent"}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Pending */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Needs attention</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {pendingTotal === 0 && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <CheckCircle2 className="h-5 w-5" style={{ color: TEAL }} /> All caught up!
              </div>
            )}
            {pendingLeave.length > 0 && (
              <div>
                <div className="text-[11px] uppercase tracking-wider text-muted-foreground mb-2">Leave requests ({pendingLeave.length})</div>
                <div className="space-y-2">
                  {pendingLeave.map((l) => (
                    <div key={l.id} className="border rounded-md p-2.5 text-sm">
                      <div className="flex items-center justify-between gap-2">
                        <div>
                          <div className="font-medium">{l.employee?.full_name ?? "—"}</div>
                          <div className="text-xs text-muted-foreground">
                            {l.leave_type} · {l.start_date} → {l.end_date}
                          </div>
                        </div>
                        <div className="flex gap-1.5">
                          <Button size="sm" variant="outline" onClick={() => rejectLeave(l)}>Reject</Button>
                          <Button size="sm" style={{ background: TEAL, color: "white" }} onClick={() => approveLeave(l)}>Approve</Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            {draftPayroll.length > 0 && (
              <div>
                <div className="text-[11px] uppercase tracking-wider text-muted-foreground mb-2">Payroll drafts ({draftPayroll.length})</div>
                <div className="space-y-1.5">
                  {draftPayroll.map((p) => (
                    <Link key={p.id} to="/workforce/payroll" className="block border rounded-md p-2.5 text-sm hover:bg-accent">
                      {p.year}-{String(p.month).padStart(2, "0")} · {Number(p.gross_salary || 0).toLocaleString()} MNT
                    </Link>
                  ))}
                </div>
              </div>
            )}
            {openTickets.length > 0 && (
              <div>
                <div className="text-[11px] uppercase tracking-wider text-muted-foreground mb-2">Open tickets ({openTickets.length})</div>
                <div className="space-y-1.5">
                  {openTickets.map((t) => (
                    <Link key={t.id} to="/workforce/helpdesk" className="block border rounded-md p-2.5 text-sm hover:bg-accent">
                      <div className="flex items-center justify-between">
                        <span>{t.title}</span>
                        <Badge variant="outline">{t.priority}</Badge>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              Clock activity
              <span className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="max-h-80 overflow-y-auto divide-y">
              {recentEvents.length === 0 && <div className="p-6 text-sm text-muted-foreground text-center">No activity yet.</div>}
              {recentEvents.map((s) => {
                const isOut = !!s.clock_out;
                const time = new Date(isOut ? s.clock_out : s.clock_in);
                return (
                  <div key={s.id} className="flex items-center gap-3 px-4 py-2 text-sm">
                    <div className="h-7 w-7 rounded-full bg-muted text-[11px] flex items-center justify-center">
                      {(s.employee?.full_name ?? "?").split(" ").map((n: string) => n[0]).join("").slice(0, 2).toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0 truncate">
                      <span className="font-medium">{s.employee?.full_name ?? "Employee"}</span>
                      <span className="text-muted-foreground"> clocked </span>
                      <span style={{ color: isOut ? "#ef4444" : "#16a34a" }}>{isOut ? "OUT" : "IN"}</span>
                      <span className="text-muted-foreground"> at {time.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">This week at a glance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-end gap-2 h-32">
              {weekStats.map((d) => (
                <div key={d.day} className="flex-1 flex flex-col items-center gap-1.5" title={`${d.present} present · ${d.absent} absent`}>
                  <div className="w-full rounded-t" style={{ height: `${Math.max(4, d.pct)}%`, background: TEAL, opacity: 0.85 }} />
                  <div className="text-[11px] text-muted-foreground">{d.day}</div>
                </div>
              ))}
            </div>
            <div className="grid grid-cols-3 gap-3 mt-4 text-xs">
              <div>
                <div className="text-muted-foreground">Avg presence</div>
                <div className="text-base font-semibold">
                  {weekStats.length ? Math.round(weekStats.reduce((s, d) => s + d.pct, 0) / weekStats.length) : 0}%
                </div>
              </div>
              <div>
                <div className="text-muted-foreground">Best day</div>
                <div className="text-base font-semibold">
                  {weekStats.length ? weekStats.reduce((a, b) => (a.pct >= b.pct ? a : b)).day : "—"}
                </div>
              </div>
              <div>
                <div className="text-muted-foreground">Overtime</div>
                <div className="text-base font-semibold">{overtimeH}h</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </WorkforcePage>
  );
}
