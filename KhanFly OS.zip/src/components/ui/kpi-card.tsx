import { Link } from "@tanstack/react-router";
import { Card, CardContent } from "@/components/ui/card";
import { Area, AreaChart, ResponsiveContainer } from "recharts";
import { ArrowDownRight, ArrowUpRight, Minus } from "lucide-react";
import { cn } from "@/lib/utils";

export type KpiCardProps = {
  label: string;
  value: number | string;
  icon?: React.ComponentType<{ className?: string }>;
  href?: string;
  accent?: string; // CSS var like "var(--research)"
  delta?: number; // pct change, e.g. +12 or -5
  spark?: number[];
  loading?: boolean;
  className?: string;
};

export function KpiCard({
  label,
  value,
  icon: Icon,
  href,
  accent = "var(--primary)",
  delta,
  spark,
  loading,
  className,
}: KpiCardProps) {
  const data = (spark ?? []).map((v, i) => ({ i, v }));
  const trendUp = (delta ?? 0) > 0;
  const trendFlat = !delta;
  const TrendIcon = trendFlat ? Minus : trendUp ? ArrowUpRight : ArrowDownRight;
  const trendColor = trendFlat
    ? "text-muted-foreground"
    : trendUp
      ? "text-emerald-600 dark:text-emerald-400"
      : "text-red-600 dark:text-red-400";

  const body = (
    <Card
      className={cn(
        "relative overflow-hidden transition-all hover:shadow-md hover:-translate-y-0.5",
        className,
      )}
    >
      <span
        aria-hidden
        className="absolute left-0 top-0 bottom-0 w-[3px]"
        style={{ background: accent }}
      />
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <div className="text-[11px] uppercase tracking-wide text-muted-foreground font-medium">
              {label}
            </div>
            <div
              className="text-3xl font-semibold tabular-nums mt-1 leading-none"
              style={{ color: accent }}
            >
              {loading ? "—" : value}
            </div>
            {typeof delta === "number" && (
              <div className={cn("flex items-center gap-1 text-xs mt-2", trendColor)}>
                <TrendIcon className="h-3 w-3" />
                <span>{Math.abs(delta).toFixed(0)}%</span>
                <span className="text-muted-foreground">vs prev</span>
              </div>
            )}
          </div>
          {Icon && <Icon className="h-4 w-4 text-muted-foreground shrink-0" />}
        </div>
        {data.length > 1 && (
          <div className="h-10 -mx-1 mt-2">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id={`g-${label}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={accent} stopOpacity={0.35} />
                    <stop offset="100%" stopColor={accent} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <Area
                  type="monotone"
                  dataKey="v"
                  stroke={accent}
                  strokeWidth={1.5}
                  fill={`url(#g-${label})`}
                  isAnimationActive={false}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        )}
      </CardContent>
    </Card>
  );

  if (!href) return body;
  return (
    <Link to={href} className="block">
      {body}
    </Link>
  );
}
