import { MODULES, type ModuleKey } from "@/lib/modules";
import { Card, CardContent } from "@/components/ui/card";

export function ModulePlaceholder({ moduleKey }: { moduleKey: ModuleKey }) {
  const m = MODULES.find((x) => x.key === moduleKey)!;
  const Icon = m.icon;
  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <span
          className="h-12 w-12 rounded-xl flex items-center justify-center"
          style={{ background: `color-mix(in oklab, var(--${m.accent}) 18%, transparent)`, color: `var(--${m.accent})` }}
        >
          <Icon className="h-6 w-6" />
        </span>
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">{m.label}</h1>
          <p className="text-sm text-muted-foreground">{m.origin} — {m.description}</p>
        </div>
      </div>

      <Card>
        <CardContent className="p-8 text-center space-y-2">
          <div className="text-sm font-medium">Module shell ready</div>
          <p className="text-sm text-muted-foreground max-w-md mx-auto">
            Navigation, auth, organization scoping and design tokens are wired up.
            The full {m.origin} feature set will be ported in here in the next step.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
