import { Link, useRouterState } from "@tanstack/react-router";
import { LayoutDashboard } from "lucide-react";
import { MODULES, moduleFromPath } from "@/lib/modules";

export function MobileTabBar() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const activeMod = moduleFromPath(pathname);
  const isDash = pathname === "/dashboard";

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-background/95 backdrop-blur-md border-t flex items-stretch h-16 pb-[env(safe-area-inset-bottom)]">
      <Link to="/dashboard"
        className="flex-1 min-w-0 flex flex-col items-center justify-center gap-1 text-[9px] font-medium transition-colors active:bg-accent/50"
        style={{ color: isDash ? "var(--primary)" : "var(--muted-foreground)" }}>
        <div className="relative">
          {isDash && <span aria-hidden className="absolute -inset-1.5 rounded-full" style={{ background: "color-mix(in oklab, var(--primary) 14%, transparent)" }} />}
          <LayoutDashboard className="relative h-[18px] w-[18px]" />
        </div>
        <span className="truncate max-w-full px-0.5">Home</span>
      </Link>
      {MODULES.map((m) => {
        const Icon = m.icon;
        const active = activeMod?.key === m.key;
        return (
          <Link key={m.key} to={m.basePath}
            className="flex-1 min-w-0 flex flex-col items-center justify-center gap-1 text-[9px] font-medium transition-colors active:bg-accent/50"
            style={{ color: active ? `var(--${m.accent})` : "var(--muted-foreground)" }}>
            <div className="relative">
              {active && <span aria-hidden className="absolute -inset-1.5 rounded-full" style={{ background: `color-mix(in oklab, var(--${m.accent}) 14%, transparent)` }} />}
              <Icon className="relative h-[18px] w-[18px]" />
            </div>
            <span className="truncate max-w-full px-0.5">{m.label}</span>
          </Link>
        );
      })}
    </nav>
  );
}
