import type { ReactNode } from "react";
import { Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";

export function EmptyState({
  icon: Icon = Sparkles,
  title,
  description,
  actionLabel,
  onAction,
  secondaryLabel,
  onSecondary,
  accent,
  busy,
}: {
  icon?: React.ComponentType<{ className?: string }>;
  title: string;
  description?: string;
  actionLabel?: string;
  onAction?: () => void;
  secondaryLabel?: string;
  onSecondary?: () => void;
  accent?: string; // CSS color, e.g. "var(--monitor)"
  busy?: boolean;
}) {
  const tint = accent ?? "var(--primary)";
  return (
    <div className="flex flex-col items-center justify-center text-center px-6 py-14">
      <div
        className="h-14 w-14 rounded-2xl flex items-center justify-center mb-4"
        style={{ background: `color-mix(in oklab, ${tint} 14%, transparent)`, color: tint }}
      >
        <Icon className="h-6 w-6" />
      </div>
      <h3 className="text-base font-semibold">{title}</h3>
      {description && <p className="mt-1.5 text-sm text-muted-foreground max-w-md">{description}</p>}
      {(actionLabel || secondaryLabel) && (
        <div className="mt-5 flex flex-wrap items-center justify-center gap-2">
          {actionLabel && (
            <Button onClick={onAction} disabled={busy} style={{ background: tint, color: "white" }}>
              {busy ? "Working…" : actionLabel}
            </Button>
          )}
          {secondaryLabel && (
            <Button variant="outline" onClick={onSecondary} disabled={busy}>{secondaryLabel}</Button>
          )}
        </div>
      )}
    </div>
  );
}

export function renderChildrenOrEmpty(children: ReactNode, empty: ReactNode, isEmpty: boolean) {
  return isEmpty ? empty : children;
}
