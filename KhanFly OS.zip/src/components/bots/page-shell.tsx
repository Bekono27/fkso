import type { ReactNode } from "react";
import { ModuleHero } from "@/components/module-hero";

export function BotsPage({
  title, description, actions, children, hero,
}: { title: string; description?: string; actions?: ReactNode; children: ReactNode; hero?: boolean }) {
  return (
    <div className="p-4 sm:p-6 space-y-5 sm:space-y-6 animate-page-in">
      {hero ? (
        <ModuleHero moduleKey="bots" title={title} description={description} actions={actions} />
      ) : (
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3 sm:gap-4">
          <div>
            <h1 className="text-xl sm:text-2xl font-semibold tracking-tight" style={{ color: "var(--bots)" }}>{title}</h1>
            {description && <p className="text-sm text-muted-foreground mt-1">{description}</p>}
          </div>
          {actions && <div className="flex items-center gap-2 flex-wrap">{actions}</div>}
        </div>
      )}
      {children}
    </div>
  );
}

export function BotsSkeleton() {
  return (
    <div className="p-6 space-y-4">
      <div className="h-8 w-48 bg-muted rounded animate-pulse" />
      <div className="h-32 rounded animate-pulse" style={{ background: "color-mix(in oklab, var(--bots) 12%, transparent)" }} />
      <div className="h-32 rounded animate-pulse" style={{ background: "color-mix(in oklab, var(--bots) 8%, transparent)" }} />
    </div>
  );
}

export function StatusPill({ value }: { value: string | null | undefined }) {
  const map: Record<string, { label: string; color: string }> = {
    active: { label: "🟢 Active", color: "#16a34a" },
    paused: { label: "⏸ Paused", color: "#f59e0b" },
    draft: { label: "📝 Draft", color: "#71717a" },
    archived: { label: "🗄 Archived", color: "#71717a" },
    pending: { label: "⏳ Pending", color: "#f59e0b" },
    sent: { label: "✓ Sent", color: "#16a34a" },
    sending: { label: "📤 Sending", color: "var(--bots)" },
    scheduled: { label: "🗓 Scheduled", color: "var(--bots)" },
    failed: { label: "✗ Failed", color: "#dc2626" },
    accepted: { label: "✓ Accepted", color: "#16a34a" },
    resolved: { label: "✓ Resolved", color: "#16a34a" },
    cancelled: { label: "✗ Cancelled", color: "#71717a" },
    open: { label: "💬 Open", color: "var(--bots)" },
  };
  const m = value ? (map[value] ?? { label: value, color: "#71717a" }) : null;
  if (!m) return <span className="text-muted-foreground">—</span>;
  return (
    <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium"
      style={{ background: `color-mix(in oklab, ${m.color} 18%, transparent)`, color: m.color }}>
      {m.label}
    </span>
  );
}

export function PlatformIcon({ platform }: { platform?: string | null }) {
  const map: Record<string, string> = {
    telegram: "📱", whatsapp: "💬", messenger: "📘",
    instagram: "📸", facebook: "📘", web: "🌐", sms: "✉️",
  };
  return <span title={platform ?? ""}>{platform ? (map[platform] ?? "💬") : "—"}</span>;
}

export function timeAgo(iso: string | null | undefined) {
  if (!iso) return "—";
  const s = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}
