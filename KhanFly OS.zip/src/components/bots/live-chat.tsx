import { useEffect, useState, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { BotsPage, BotsSkeleton, PlatformIcon, StatusPill, timeAgo } from "./page-shell";
import { Button } from "@/components/ui/button";

type Conversation = {
  id: string;
  bot_id: string | null;
  platform: string | null;
  channel: string | null;
  status: string | null;
  resolved_by: string | null;
  message_count: number | null;
  lead_captured: boolean | null;
  last_message_at: string | null;
  created_at: string;
};

type Message = {
  id: string;
  conversation_id: string | null;
  direction: string;
  sender: string | null;
  content: string | null;
  created_at: string;
};

export default function BotsLiveChat() {
  const { org } = useAuth();
  const orgId = org?.id;
  const [convs, setConvs] = useState<Conversation[]>([]);
  const [active, setActive] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Initial conversation list + realtime
  useEffect(() => {
    if (!orgId) return;
    let cancelled = false;
    (async () => {
      const { data } = await supabase
        .from("bot_conversations")
        .select("id,bot_id,platform,channel,status,resolved_by,message_count,lead_captured,last_message_at,created_at")
        .eq("org_id", orgId)
        .order("last_message_at", { ascending: false, nullsFirst: false })
        .limit(50);
      if (!cancelled) {
        const list = (data ?? []) as Conversation[];
        setConvs(list);
        if (!active && list.length) setActive(list[0].id);
        setLoading(false);
      }
    })();

    const ch = supabase
      .channel(`bot_convs_${orgId}`)
      .on("postgres_changes",
        { event: "*", schema: "public", table: "bot_conversations", filter: `org_id=eq.${orgId}` },
        (p) => {
          setConvs((prev) => {
            const row = p.new as Conversation;
            if (p.eventType === "DELETE") return prev.filter((c) => c.id !== (p.old as any).id);
            const without = prev.filter((c) => c.id !== row.id);
            return [row, ...without].sort((a, b) =>
              (b.last_message_at ?? b.created_at).localeCompare(a.last_message_at ?? a.created_at),
            );
          });
        },
      )
      .subscribe();

    return () => { cancelled = true; supabase.removeChannel(ch); };
  }, [orgId, active]);

  // Messages for active conversation + realtime
  useEffect(() => {
    if (!active) { setMessages([]); return; }
    let cancelled = false;
    (async () => {
      const { data } = await supabase
        .from("bot_messages")
        .select("id,conversation_id,direction,sender,content,created_at")
        .eq("conversation_id", active)
        .order("created_at", { ascending: true })
        .limit(200);
      if (!cancelled) setMessages((data ?? []) as unknown as Message[]);
    })();

    const ch = supabase
      .channel(`bot_msgs_${active}`)
      .on("postgres_changes",
        { event: "INSERT", schema: "public", table: "bot_messages", filter: `conversation_id=eq.${active}` },
        (p) => setMessages((prev) => [...prev, p.new as Message]),
      )
      .subscribe();

    return () => { cancelled = true; supabase.removeChannel(ch); };
  }, [active]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages.length]);

  if (loading) return <BotsSkeleton />;

  const activeConv = convs.find((c) => c.id === active);

  return (
    <BotsPage title="Live Chat" description="Realtime view of bot conversations.">
      <div className="grid grid-cols-12 gap-4 h-[calc(100vh-220px)] min-h-[480px]">
        {/* Conversation list */}
        <div className="col-span-4 border rounded-lg overflow-hidden flex flex-col">
          <div className="px-3 py-2 border-b text-xs uppercase tracking-wider text-muted-foreground">
            Conversations · {convs.length}
          </div>
          <div className="flex-1 overflow-y-auto divide-y">
            {convs.length === 0 ? (
              <div className="p-4 text-sm text-muted-foreground">No conversations yet.</div>
            ) : convs.map((c) => (
              <button
                key={c.id}
                onClick={() => setActive(c.id)}
                className={`w-full text-left p-3 hover:bg-accent transition-colors ${
                  active === c.id ? "bg-accent" : ""
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <PlatformIcon platform={c.platform} />
                    <span className="text-sm font-medium truncate">{c.channel ?? c.platform ?? "—"}</span>
                  </div>
                  <StatusPill value={c.status} />
                </div>
                <div className="flex items-center justify-between mt-1 text-xs text-muted-foreground">
                  <span>{c.message_count ?? 0} msgs {c.lead_captured ? "· 🎯" : ""}</span>
                  <span>{timeAgo(c.last_message_at ?? c.created_at)}</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Message pane */}
        <div className="col-span-8 border rounded-lg overflow-hidden flex flex-col">
          {activeConv ? (
            <>
              <div className="px-4 py-2 border-b flex items-center gap-3">
                <PlatformIcon platform={activeConv.platform} />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium truncate">{activeConv.channel ?? activeConv.platform ?? "Conversation"}</div>
                  <div className="text-xs text-muted-foreground">
                    {activeConv.message_count ?? 0} messages
                    {activeConv.resolved_by ? ` · resolved by ${activeConv.resolved_by}` : ""}
                  </div>
                </div>
                <StatusPill value={activeConv.status} />
                <Button size="sm" variant="outline" onClick={() => requestHandoff(activeConv.id, orgId!)}>
                  Hand off to human
                </Button>
              </div>
              <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-2 bg-muted/30">
                {messages.length === 0 ? (
                  <div className="text-sm text-muted-foreground text-center py-12">No messages yet.</div>
                ) : messages.map((m) => {
                  const me = m.direction === "outbound";
                  return (
                    <div key={m.id} className={`flex ${me ? "justify-end" : "justify-start"}`}>
                      <div
                        className={`max-w-[70%] rounded-2xl px-3 py-2 text-sm ${
                          me ? "text-white" : "bg-background border"
                        }`}
                        style={me ? { background: "var(--bots, #BA7517)" } : undefined}
                      >
                        <div className="text-[10px] opacity-70 mb-0.5 capitalize">{m.sender ?? m.direction}</div>
                        <div className="whitespace-pre-wrap">{m.content}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-sm text-muted-foreground">
              Select a conversation
            </div>
          )}
        </div>
      </div>
    </BotsPage>
  );
}

async function requestHandoff(conversationId: string, orgId: string) {
  await supabase.from("handoff_requests").insert({
    org_id: orgId,
    conversation_id: conversationId,
    status: "pending",
    reason: "Manual handoff requested from Live Chat",
  } as any);
}
