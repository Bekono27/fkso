import { useEffect, useState, useCallback } from "react";
import { useNavigate } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { BotsPage, BotsSkeleton, StatusPill } from "./page-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger,
} from "@/components/ui/dialog";
import { Plus, Trash2, ArrowDown, MessageSquare, Sparkles, GitBranch, Flag, Square, ArrowRight, Save } from "lucide-react";
import { toast } from "sonner";
import { writeEvent } from "@/lib/bots";

type Node = {
  id: string;
  flow_id: string;
  org_id: string;
  node_type: string;
  position: { x: number; y: number };
  config: Record<string, any>;
};
type Edge = { id: string; flow_id: string; org_id: string; source_node: string; target_node: string };
type Flow = { id: string; bot_id: string; org_id: string; name: string; is_published: boolean };
type Bot = { id: string; org_id: string; name: string; status: string; emoji: string | null; description: string | null };

const NODE_TYPES = [
  { type: "start",   label: "Start",     icon: Flag,          color: "#16a34a", canCreate: false },
  { type: "message", label: "Message",   icon: MessageSquare, color: "var(--bots)" },
  { type: "ai",      label: "AI reply",  icon: Sparkles,      color: "#8b5cf6" },
  { type: "input",   label: "Ask input", icon: ArrowRight,    color: "#0ea5e9" },
  { type: "branch",  label: "Branch",    icon: GitBranch,     color: "#f59e0b" },
  { type: "end",     label: "End",       icon: Square,        color: "#71717a", canCreate: false },
];

function nodeMeta(t: string) {
  return NODE_TYPES.find((n) => n.type === t) ?? { type: t, label: t, icon: MessageSquare, color: "#71717a" };
}

export default function FlowBuilder({ botId }: { botId: string }) {
  const { org, user } = useAuth();
  const navigate = useNavigate();
  const [bot, setBot] = useState<Bot | null>(null);
  const [flow, setFlow] = useState<Flow | null>(null);
  const [nodes, setNodes] = useState<Node[]>([]);
  const [edges, setEdges] = useState<Edge[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editingNode, setEditingNode] = useState<Node | null>(null);
  const [draft, setDraft] = useState<Record<string, any>>({});
  const [addOpen, setAddOpen] = useState(false);
  const [addAfter, setAddAfter] = useState<string | null>(null);
  const [newType, setNewType] = useState("message");

  const load = useCallback(async () => {
    if (!org?.id) return;
    setLoading(true);
    const { data: b } = await supabase.from("bots").select("*").eq("id", botId).eq("org_id", org.id).maybeSingle();
    if (!b) { setLoading(false); return; }
    setBot(b as any);
    let { data: f } = await supabase.from("bot_flows").select("*")
      .eq("bot_id", botId).eq("org_id", org.id).order("created_at").limit(1).maybeSingle();
    if (!f) {
      const { data: created } = await supabase.from("bot_flows").insert({
        org_id: org.id, bot_id: botId, name: "Main",
      } as any).select().single();
      f = created;
    }
    setFlow(f as any);
    if (f) {
      const [{ data: ns }, { data: es }] = await Promise.all([
        supabase.from("bot_nodes").select("*").eq("flow_id", f.id),
        supabase.from("bot_edges").select("*").eq("flow_id", f.id),
      ]);
      let nodesData = (ns ?? []) as unknown as Node[];
      let edgesData = (es ?? []) as unknown as Edge[];
      // Auto-create start node if empty
      if (nodesData.length === 0) {
        const { data: start } = await supabase.from("bot_nodes").insert({
          org_id: org.id, flow_id: f.id, node_type: "start",
          position: { x: 100, y: 100 }, config: { label: "Start" },
        } as any).select().single();
        if (start) nodesData = [start as unknown as Node];
      }
      setNodes(nodesData);
      setEdges(edgesData);
    }
    setLoading(false);
  }, [botId, org?.id]);

  useEffect(() => { load(); }, [load]);

  // Build linear order from edges (topological-ish from Start)
  const ordered = (() => {
    if (nodes.length === 0) return [];
    const start = nodes.find((n) => n.node_type === "start") ?? nodes[0];
    const visited: string[] = [];
    const seen = new Set<string>();
    let cur: Node | undefined = start;
    while (cur && !seen.has(cur.id)) {
      seen.add(cur.id);
      visited.push(cur.id);
      const e = edges.find((x) => x.source_node === cur!.id);
      cur = e ? nodes.find((n) => n.id === e.target_node) : undefined;
    }
    // Append orphans
    nodes.forEach((n) => { if (!seen.has(n.id)) visited.push(n.id); });
    return visited.map((id) => nodes.find((n) => n.id === id)!).filter(Boolean);
  })();

  const addNode = async () => {
    if (!flow || !org?.id) return;
    const meta = nodeMeta(newType);
    const baseConfig: Record<string, any> =
      newType === "message" ? { text: "Hello! 👋" } :
      newType === "ai"      ? { prompt: "You are a helpful assistant.", model: "google/gemini-2.5-flash" } :
      newType === "input"   ? { text: "What's your name?", variable: "name" } :
      newType === "branch"  ? { conditions: [{ if: "name == 'admin'", goto: null }] } :
      newType === "end"     ? { label: "End" } :
                              { label: meta.label };
    const lastY = nodes.reduce((m, n) => Math.max(m, n.position?.y ?? 0), 0);
    const { data: created, error } = await supabase.from("bot_nodes").insert({
      org_id: org.id, flow_id: flow.id, node_type: newType,
      position: { x: 100, y: lastY + 120 }, config: baseConfig,
    } as any).select().single();
    if (error || !created) return toast.error(error?.message ?? "Failed");
    setNodes((prev) => [...prev, created as unknown as Node]);
    if (addAfter) {
      const { data: edge } = await supabase.from("bot_edges").insert({
        org_id: org.id, flow_id: flow.id, source_node: addAfter, target_node: created.id,
      } as any).select().single();
      if (edge) setEdges((prev) => [...prev.filter((e) => e.source_node !== addAfter), edge as unknown as Edge]);
    }
    setAddOpen(false); setAddAfter(null); setNewType("message");
    toast.success("Node added");
  };

  const deleteNode = async (id: string) => {
    const node = nodes.find((n) => n.id === id);
    if (!node || node.node_type === "start") return;
    if (!confirm("Delete this node? Connected edges will be removed.")) return;
    await supabase.from("bot_nodes").delete().eq("id", id);
    setNodes((prev) => prev.filter((n) => n.id !== id));
    setEdges((prev) => prev.filter((e) => e.source_node !== id && e.target_node !== id));
  };

  const saveNode = async () => {
    if (!editingNode) return;
    setSaving(true);
    const { error } = await supabase.from("bot_nodes").update({ config: draft } as any).eq("id", editingNode.id);
    setSaving(false);
    if (error) return toast.error(error.message);
    setNodes((prev) => prev.map((n) => (n.id === editingNode.id ? { ...n, config: draft } : n)));
    setEditingNode(null);
    toast.success("Saved");
  };

  const publish = async () => {
    if (!flow || !bot || !org?.id) return;
    setSaving(true);
    const { error: e1 } = await supabase.from("bot_flows").update({ is_published: true } as any).eq("id", flow.id);
    const { error: e2 } = await supabase.from("bots").update({ status: "active" } as any).eq("id", bot.id);
    setSaving(false);
    if (e1 || e2) return toast.error((e1 ?? e2)?.message ?? "Failed");
    setFlow({ ...flow, is_published: true });
    setBot({ ...bot, status: "active" });
    await writeEvent(org.id, "bots", "bot_published", { bot_id: bot.id, flow_id: flow.id }, user?.id);
    toast.success("Bot is live!");
  };

  if (loading) return <BotsSkeleton />;
  if (!bot) return (
    <BotsPage title="Not found"><p className="text-sm text-muted-foreground">Bot not found.</p></BotsPage>
  );

  return (
    <BotsPage
      title={`${bot.emoji ?? "🤖"}  ${bot.name}`}
      description={bot.description ?? "Visual flow builder"}
      actions={
        <div className="flex items-center gap-2">
          <StatusPill value={bot.status} />
          <Button variant="outline" size="sm" onClick={() => navigate({ to: "/bots/list" })}>← Back</Button>
          {!flow?.is_published ? (
            <Button size="sm" style={{ background: "var(--bots)", color: "white" }} disabled={saving} onClick={publish}>
              <Save className="h-4 w-4 mr-1" /> Publish
            </Button>
          ) : (
            <span className="text-xs text-green-600 font-medium">● Published</span>
          )}
        </div>
      }
    >
      <Card>
        <CardContent className="p-6">
          <div className="max-w-2xl mx-auto space-y-2">
            {ordered.map((n, idx) => {
              const meta = nodeMeta(n.node_type);
              const Icon = meta.icon;
              const summary =
                n.node_type === "message" ? (n.config?.text ?? "") :
                n.node_type === "ai"      ? `AI: ${(n.config?.prompt ?? "").slice(0, 80)}` :
                n.node_type === "input"   ? `Ask: ${n.config?.text ?? ""} → ${n.config?.variable ?? "var"}` :
                n.node_type === "branch"  ? `${(n.config?.conditions ?? []).length} branches` :
                n.config?.label ?? meta.label;
              return (
                <div key={n.id}>
                  <Card
                    className="cursor-pointer hover:border-primary/40 transition-colors group"
                    onClick={() => { setEditingNode(n); setDraft({ ...(n.config ?? {}) }); }}
                  >
                    <CardContent className="p-4 flex items-start gap-3">
                      <div className="rounded-lg p-2"
                        style={{ background: `color-mix(in oklab, ${meta.color} 14%, transparent)`, color: meta.color }}>
                        <Icon className="h-4 w-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: meta.color }}>
                            {meta.label}
                          </span>
                          <span className="text-xs text-muted-foreground">#{idx + 1}</span>
                        </div>
                        <div className="text-sm mt-0.5 truncate">{summary || <em className="text-muted-foreground">empty</em>}</div>
                      </div>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button size="sm" variant="ghost" onClick={(e) => { e.stopPropagation(); setAddAfter(n.id); setAddOpen(true); }}>
                          <Plus className="h-3.5 w-3.5" />
                        </Button>
                        {n.node_type !== "start" && (
                          <Button size="sm" variant="ghost" onClick={(e) => { e.stopPropagation(); deleteNode(n.id); }}>
                            <Trash2 className="h-3.5 w-3.5 text-destructive" />
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                  {idx < ordered.length - 1 && (
                    <div className="flex justify-center py-1">
                      <ArrowDown className="h-4 w-4 text-muted-foreground" />
                    </div>
                  )}
                </div>
              );
            })}

            <div className="pt-4 flex justify-center">
              <Button variant="outline" size="sm" onClick={() => { setAddAfter(ordered[ordered.length - 1]?.id ?? null); setAddOpen(true); }}>
                <Plus className="h-4 w-4 mr-1" /> Add step
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Add node dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Add a step</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-2">
            {NODE_TYPES.filter((n) => n.canCreate !== false).map((n) => {
              const Icon = n.icon;
              return (
                <button key={n.type} onClick={() => setNewType(n.type)}
                  className={`text-left rounded-lg border p-3 hover:border-primary transition-colors ${newType === n.type ? "border-primary bg-muted/50" : ""}`}>
                  <div className="flex items-center gap-2">
                    <div className="rounded p-1.5" style={{ background: `color-mix(in oklab, ${n.color} 14%, transparent)`, color: n.color }}>
                      <Icon className="h-4 w-4" />
                    </div>
                    <span className="font-medium text-sm">{n.label}</span>
                  </div>
                </button>
              );
            })}
          </div>
          <DialogFooter><Button onClick={addNode}>Add</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit node dialog */}
      <Dialog open={!!editingNode} onOpenChange={(o) => { if (!o) setEditingNode(null); }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit {editingNode ? nodeMeta(editingNode.node_type).label : ""}</DialogTitle>
          </DialogHeader>
          {editingNode?.node_type === "message" && (
            <div className="space-y-2">
              <Label>Message text</Label>
              <Textarea rows={5} value={draft.text ?? ""} onChange={(e) => setDraft({ ...draft, text: e.target.value })}
                placeholder="Hello! How can I help today?" />
              <p className="text-xs text-muted-foreground">Use {"{{name}}"} or other variables collected in earlier steps.</p>
            </div>
          )}
          {editingNode?.node_type === "ai" && (
            <div className="space-y-3">
              <div>
                <Label>System prompt</Label>
                <Textarea rows={5} value={draft.prompt ?? ""} onChange={(e) => setDraft({ ...draft, prompt: e.target.value })}
                  placeholder="You are a helpful customer support assistant…" />
              </div>
              <div>
                <Label>Model</Label>
                <Select value={draft.model ?? "google/gemini-2.5-flash"} onValueChange={(v) => setDraft({ ...draft, model: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="google/gemini-2.5-flash">Gemini 2.5 Flash · fast & cheap</SelectItem>
                    <SelectItem value="google/gemini-2.5-pro">Gemini 2.5 Pro · best reasoning</SelectItem>
                    <SelectItem value="openai/gpt-5-mini">GPT-5 mini</SelectItem>
                    <SelectItem value="openai/gpt-5">GPT-5 · top quality</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
          {editingNode?.node_type === "input" && (
            <div className="space-y-3">
              <div>
                <Label>Prompt to user</Label>
                <Input value={draft.text ?? ""} onChange={(e) => setDraft({ ...draft, text: e.target.value })} />
              </div>
              <div>
                <Label>Variable name</Label>
                <Input value={draft.variable ?? ""} onChange={(e) => setDraft({ ...draft, variable: e.target.value })}
                  placeholder="e.g. email, phone, name" />
              </div>
            </div>
          )}
          {editingNode?.node_type === "branch" && (
            <div className="space-y-2">
              <Label>Conditions (JSON)</Label>
              <Textarea rows={6} value={JSON.stringify(draft.conditions ?? [], null, 2)}
                onChange={(e) => { try { setDraft({ ...draft, conditions: JSON.parse(e.target.value) }); } catch {} }} />
            </div>
          )}
          {editingNode?.node_type === "start" && (
            <p className="text-sm text-muted-foreground">The Start node is the entry point of every conversation. No configuration needed.</p>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingNode(null)}>Cancel</Button>
            <Button onClick={saveNode} disabled={saving}>{saving ? "Saving…" : "Save"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </BotsPage>
  );
}
