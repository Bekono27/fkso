import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Bot, MessageCircle, CheckCircle, Target, Plus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { BotsPage } from "./page-shell";
import { StatusPill, PlatformIcon, timeAgo } from "./page-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from "recharts";

const AMBER = "var(--bots)";

function MetricCard({ label, value, sub, icon: Icon, to, accent = AMBER }:
  { label: string; value: string | number; sub?: string; icon: any; to?: string; accent?: string }) {
  const inner = (
    <Card className="hover:shadow-md transition-shadow cursor-pointer h-full">
      <CardContent className="p-5">
        <div className="flex items-start justify-between">
          <div>
            <div className="text-xs text-muted-foreground uppercase tracking-wider">{label}</div>
            <div className="text-3xl font-bold mt-2" style={{ color: accent }}>{value}</div>
            {sub && <div className="text-xs text-muted-foreground mt-1">{sub}</div>}
          </div>
          <div className="rounded-lg p-2" style={{ background: `color-mix(in oklab, ${accent} 14%, transparent)`, color: accent }}>
            <Icon className="h-5 w-5" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
  return to ? <Link to={to}>{inner}</Link> : inner;
}

export default function BotsDashboard() {
  const { org } = useAuth();
  const orgId = org?.id;

  const [bots, setBots] = useState<any[]>([]);
  const [convsToday, setConvsToday] = useState(0);
  const [aiResolved, setAiResolved] = useState(0);
  const [leadsToday, setLeadsToday] = useState(0);
  const [leadsWeek, setLeadsWeek] = useState(0);
  const [leadsMonth, setLeadsMonth] = useState(0);
  const [activeNow, setActiveNow] = useState(0);
  const [handoffs, setHandoffs] = useState<any[]>([]);
  const [recentSessions, setRecentSessions] = useState<any[]>([]);
  const [analytics14d, setAnalytics14d] = useState<any[]>([]);
  const [topBots, setTopBots] = useState<any[]>([]);
  const [channelBreakdown, setChannelBreakdown] = useState<Record<string, { bots: number; convs: number }>>({});

  const today = new Date().toISOString().split("T")[0];
  const weekStart = new Date(Date.now() - 6 * 86400000).toISOString().split("T")[0];
  const monthStart = today.slice(0, 7) + "-01";
  const fortnight = new Date(Date.now() - 13 * 86400000).toISOString().split("T")[0];
  const tenMinAgo = new Date(Date.now() - 10 * 60000).toISOString();

  const loadAll = async () => {
    if (!orgId) return;
    const [b, ct, ar, lt, lw, lm, an, ho, rs, ana, ch] = await Promise.all([
      supabase.from("bots").select("id,name,emoji,status,description")
        .eq("org_id", orgId).order("created_at", { ascending: false }),
      supabase.from("bot_conversations").select("id", { count: "exact", head: true })
        .eq("org_id", orgId).gte("created_at", today),
      supabase.from("bot_conversations").select("id", { count: "exact", head: true })
        .eq("org_id", orgId).eq("resolved_by", "ai").gte("created_at", today),
      supabase.from("bot_conversations").select("id", { count: "exact", head: true })
        .eq("org_id", orgId).eq("lead_captured", true).gte("created_at", today),
      supabase.from("bot_conversations").select("id", { count: "exact", head: true })
        .eq("org_id", orgId).eq("lead_captured", true).gte("created_at", weekStart),
      supabase.from("bot_conversations").select("id", { count: "exact", head: true })
        .eq("org_id", orgId).eq("lead_captured", true).gte("created_at", monthStart),
      supabase.from("bot_conversations").select("id", { count: "exact", head: true })
        .eq("org_id", orgId).gte("last_message_at", tenMinAgo),
      supabase.from("handoff_requests")
        .select("id,bot_id,reason,created_at,conversation_id")
        .eq("org_id", orgId).eq("status", "pending")
        .order("created_at", { ascending: true }).limit(8),
      supabase.from("live_chat_sessions")
        .select("id,conversation_id,status,started_at,ended_at")
        .eq("org_id", orgId).order("started_at", { ascending: false }).limit(5),
      supabase.from("bot_analytics_daily")
        .select("date,bot_id,conversations,ai_resolved,human_handoffs,leads_captured")
        .eq("org_id", orgId).gte("date", fortnight).order("date"),
      supabase.from("bot_channels")
        .select("platform,bot_id,is_active").eq("org_id", orgId).eq("is_active", true),
    ]);

    setBots(b.data ?? []);
    setConvsToday(ct.count ?? 0);
    setAiResolved(ar.count ?? 0);
    setLeadsToday(lt.count ?? 0);
    setLeadsWeek(lw.count ?? 0);
    setLeadsMonth(lm.count ?? 0);
    setActiveNow(an.count ?? 0);
    setHandoffs(ho.data ?? []);
    setRecentSessions(rs.data ?? []);

    // 14-day chart aggregation
    const byDate: Record<string, { date: string; ai: number; human: number }> = {};
    for (let i = 13; i >= 0; i--) {
      const d = new Date(Date.now() - i * 86400000).toISOString().split("T")[0];
      byDate[d] = { date: d.slice(5), ai: 0, human: 0 };
    }
    (ana.data ?? []).forEach((r: any) => {
      const k = r.date;
      if (byDate[k]) {
        byDate[k].ai += r.ai_resolved ?? 0;
        byDate[k].human += r.human_handoffs ?? 0;
      }
    });
    setAnalytics14d(Object.values(byDate));

    // Top bots by conversations today
    const byBot: Record<string, { id: string; convs: number; ai: number; leads: number }> = {};
    (ana.data ?? []).filter((r: any) => r.date === today).forEach((r: any) => {
      const k = r.bot_id;
      if (!k) return;
      byBot[k] = byBot[k] ?? { id: k, convs: 0, ai: 0, leads: 0 };
      byBot[k].convs += r.conversations ?? 0;
      byBot[k].ai += r.ai_resolved ?? 0;
      byBot[k].leads += r.leads_captured ?? 0;
    });
    const ranked = Object.values(byBot).sort((a, b) => b.convs - a.convs).slice(0, 5)
      .map((r) => {
        const bot = (b.data ?? []).find((bb: any) => bb.id === r.id);
        return { ...r, name: bot?.name ?? "Unknown", emoji: bot?.emoji ?? "🤖" };
      });
    setTopBots(ranked);

    // Channel breakdown
    const breakdown: Record<string, { bots: number; convs: number }> = {};
    const seenBots = new Set<string>();
    (ch.data ?? []).forEach((c: any) => {
      breakdown[c.platform] = breakdown[c.platform] ?? { bots: 0, convs: 0 };
      const key = `${c.platform}:${c.bot_id}`;
      if (!seenBots.has(key)) { breakdown[c.platform].bots++; seenBots.add(key); }
    });
    setChannelBreakdown(breakdown);
  };

  useEffect(() => {
    loadAll();
    if (!orgId) return;
    const ch = supabase.channel("bots-dashboard-" + orgId)
      .on("postgres_changes", { event: "*", schema: "public", table: "bot_conversations", filter: `org_id=eq.${orgId}` }, () => loadAll())
      .on("postgres_changes", { event: "*", schema: "public", table: "handoff_requests", filter: `org_id=eq.${orgId}` }, () => loadAll())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orgId]);

  const activeBots = bots.filter((b) => b.status === "active").length;
  const totalChannels = Object.values(channelBreakdown).reduce((s, v) => s + v.bots, 0);
  const resolutionRate = convsToday > 0 ? Math.round((aiResolved * 100) / convsToday) : 0;
  const handedToHuman = convsToday - aiResolved;
  const resolutionColor = resolutionRate > 80 ? "#16a34a" : resolutionRate >= 60 ? AMBER : "#dc2626";

  return (
    <BotsPage hero
      title="Bots"
      description={`Today · ${new Date().toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })}`}
      actions={
        <Link to="/bots/list">
          <Button size="sm" style={{ background: AMBER, color: "white" }}>
            <Plus className="h-4 w-4 mr-1" /> New bot
          </Button>
        </Link>
      }
    >
      {/* Top metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard label="Active bots" value={activeBots} sub={`across ${totalChannels} channels`} icon={Bot} to="/bots/list" />
        <MetricCard label="Conversations today" value={convsToday} sub={`${activeNow} active right now`} icon={MessageCircle} to="/bots/chat" />
        <MetricCard label="AI resolution rate" value={`${resolutionRate}%`} sub={`${handedToHuman} handed to human today`} icon={CheckCircle} to="/bots/analytics" accent={resolutionColor} />
        <MetricCard label="Leads captured today" value={leadsToday} sub={`${leadsWeek} this week · ${leadsMonth} this month`} icon={Target} to="/bots/contacts" />
      </div>

      {/* Middle row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center justify-between">
              <span>Your bots</span>
              <Link to="/bots/list"><Button size="sm" variant="outline">View all</Button></Link>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {bots.length === 0 ? (
              <div className="p-8 text-center text-sm text-muted-foreground">
                No bots yet.{" "}
                <Link to="/bots/list" className="font-medium" style={{ color: AMBER }}>Create your first bot →</Link>
              </div>
            ) : (
              <div className="max-h-[360px] overflow-y-auto divide-y">
                {bots.slice(0, 8).map((b: any) => (
                  <div key={b.id} className="flex items-center gap-3 px-4 py-3 hover:bg-muted/30">
                    <div className="text-2xl">{b.emoji ?? "🤖"}</div>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-sm truncate">{b.name}</div>
                      <div className="flex items-center gap-2 mt-0.5">
                        <StatusPill value={b.status} />
                      </div>
                    </div>
                    <Link to="/bots/list">
                      <Button size="sm" variant="ghost">⚙ Edit</Button>
                    </Link>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center justify-between">
              <span>Handoffs waiting</span>
              {handoffs.length > 0 && (
                <span className="bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">{handoffs.length}</span>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {handoffs.length === 0 ? (
              <div className="text-sm text-green-600 flex items-center gap-2">✓ No handoffs waiting</div>
            ) : (
              <div className="space-y-2">
                {handoffs.map((h: any) => (
                  <div key={h.id} className="border rounded-md p-2.5 text-sm flex items-center justify-between gap-2">
                    <div className="min-w-0">
                      <div className="font-medium truncate">{h.reason ?? "Handoff requested"}</div>
                      <div className="text-[11px] text-muted-foreground">Waiting {timeAgo(h.created_at)}</div>
                    </div>
                    <Link to="/bots/chat"><Button size="sm" variant="outline">✓ Accept</Button></Link>
                  </div>
                ))}
              </div>
            )}
            {recentSessions.length > 0 && (
              <div className="pt-2 border-t">
                <div className="text-[11px] uppercase tracking-wider text-muted-foreground mb-2">Recent live chats</div>
                <div className="space-y-1">
                  {recentSessions.map((s: any) => (
                    <div key={s.id} className="flex items-center justify-between text-xs py-1">
                      <span className="text-muted-foreground">Session · {timeAgo(s.started_at)}</span>
                      <StatusPill value={s.status} />
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Bottom row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-base">Conversation volume — last 14 days</CardTitle></CardHeader>
          <CardContent>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={analytics14d} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <XAxis dataKey="date" fontSize={11} />
                  <YAxis fontSize={11} />
                  <Tooltip contentStyle={{ fontSize: 12 }} />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                  <Bar dataKey="ai" stackId="a" fill="var(--bots)" name="AI resolved" />
                  <Bar dataKey="human" stackId="a" fill="#dc2626" name="Human handoff" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Top performers & channels</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="text-[11px] uppercase tracking-wider text-muted-foreground mb-2">Top bots today</div>
              {topBots.length === 0 ? (
                <div className="text-sm text-muted-foreground">No data yet.</div>
              ) : (
                <div className="space-y-1">
                  {topBots.map((b, i) => (
                    <Link key={b.id} to="/bots/analytics" className="flex items-center gap-3 text-sm py-1.5 hover:bg-muted/30 rounded px-2">
                      <span className="text-muted-foreground w-4">{i + 1}</span>
                      <span>{b.emoji}</span>
                      <span className="flex-1 truncate font-medium">{b.name}</span>
                      <span className="text-xs text-muted-foreground">{b.convs} convs</span>
                      <span className="text-xs" style={{ color: AMBER }}>
                        {b.convs > 0 ? Math.round((b.ai * 100) / b.convs) : 0}%
                      </span>
                      <span className="text-xs">🎯 {b.leads}</span>
                    </Link>
                  ))}
                </div>
              )}
            </div>

            <div className="pt-3 border-t">
              <div className="text-[11px] uppercase tracking-wider text-muted-foreground mb-2">Channel breakdown</div>
              {Object.keys(channelBreakdown).length === 0 ? (
                <div className="text-sm text-muted-foreground">No channels connected.</div>
              ) : (
                <div className="space-y-1.5">
                  {Object.entries(channelBreakdown).map(([platform, v]) => (
                    <div key={platform} className="flex items-center gap-2 text-sm">
                      <PlatformIcon platform={platform} />
                      <span className="capitalize flex-1">{platform}</span>
                      <span className="text-xs text-muted-foreground">{v.bots} bot{v.bots === 1 ? "" : "s"}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </BotsPage>
  );
}
