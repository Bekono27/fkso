import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import {
  Search, LayoutDashboard, Settings, LogOut, ArrowRight, Clock,
  Home, Wallet, Users, Palmtree, ClipboardList, MessageSquare, LifeBuoy,
  Laptop, GraduationCap, Trophy, Megaphone, BarChart3, Radio, Bell,
  Bot, ScanLine, FileText, Puzzle, Zap, BookOpen, FolderKanban,
  TrendingUp, CalendarDays, Link2, Clock as ClockIcon,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { MODULES, type ModuleKey } from "@/lib/modules";
import {
  CommandDialog, CommandEmpty, CommandGroup, CommandInput,
  CommandItem, CommandList, CommandSeparator,
} from "@/components/ui/command";

type Page = { label: string; to: string; icon: any; module: ModuleKey | "core"; keywords?: string };

const PAGES: Page[] = [
  { label: "Executive Dashboard", to: "/dashboard", icon: LayoutDashboard, module: "core", keywords: "home overview" },
  { label: "Settings", to: "/settings", icon: Settings, module: "core" },
  { label: "Team", to: "/settings/team", icon: Users, module: "core" },
  { label: "Billing", to: "/settings/billing", icon: Wallet, module: "core" },
  { label: "Integrations", to: "/settings/integrations", icon: Link2, module: "core" },
  { label: "Modules", to: "/settings/modules", icon: Puzzle, module: "core" },

  { label: "Workforce Overview", to: "/workforce/dashboard", icon: Home, module: "workforce" },
  { label: "Attendance", to: "/workforce/attendance", icon: ClockIcon, module: "workforce" },
  { label: "Payroll", to: "/workforce/payroll", icon: Wallet, module: "workforce" },
  { label: "Employees", to: "/workforce/employees", icon: Users, module: "workforce" },
  { label: "Leave", to: "/workforce/leave", icon: Palmtree, module: "workforce" },
  { label: "Projects", to: "/workforce/projects", icon: ClipboardList, module: "workforce" },
  { label: "Workforce Chat", to: "/workforce/chat", icon: MessageSquare, module: "workforce" },
  { label: "Helpdesk", to: "/workforce/helpdesk", icon: LifeBuoy, module: "workforce" },
  { label: "Assets", to: "/workforce/assets", icon: Laptop, module: "workforce" },
  { label: "E-Learning", to: "/workforce/elearning", icon: GraduationCap, module: "workforce" },
  { label: "Performance", to: "/workforce/performance", icon: Trophy, module: "workforce" },
  { label: "Announcements", to: "/workforce/announcements", icon: Megaphone, module: "workforce" },
  { label: "Workforce Reports", to: "/workforce/reports", icon: BarChart3, module: "workforce" },

  { label: "Monitor Overview", to: "/monitor/dashboard", icon: Home, module: "monitor" },
  { label: "Live Feed", to: "/monitor/feed", icon: Radio, module: "monitor" },
  { label: "Alerts", to: "/monitor/alerts", icon: Bell, module: "monitor" },
  { label: "Keywords", to: "/monitor/keywords", icon: Search, module: "monitor" },
  { label: "Competitors", to: "/monitor/competitors", icon: Trophy, module: "monitor" },
  { label: "AI Agents", to: "/monitor/agents", icon: Bot, module: "monitor" },
  { label: "Monitor Analytics", to: "/monitor/analytics", icon: BarChart3, module: "monitor" },
  { label: "Page Analysis", to: "/monitor/page-analysis", icon: ScanLine, module: "monitor" },
  { label: "Monitor Reports", to: "/monitor/reports", icon: FileText, module: "monitor" },

  { label: "Research Overview", to: "/research/dashboard", icon: Home, module: "research" },
  { label: "Research Projects", to: "/research/projects", icon: FolderKanban, module: "research" },
  { label: "Intelligence", to: "/research/intelligence", icon: Trophy, module: "research" },
  { label: "Trends", to: "/research/trends", icon: TrendingUp, module: "research" },
  { label: "Audience", to: "/research/audience", icon: Users, module: "research" },
  { label: "Research Reports", to: "/research/reports", icon: FileText, module: "research" },

  { label: "Content Overview", to: "/content/dashboard", icon: Home, module: "content" },
  { label: "Content Calendar", to: "/content/calendar", icon: CalendarDays, module: "content" },
  { label: "Clients", to: "/content/clients", icon: Users, module: "content" },
  { label: "Proposals", to: "/content/proposals", icon: FileText, module: "content" },
  { label: "Invoices", to: "/content/invoices", icon: Wallet, module: "content" },

  { label: "Bots Overview", to: "/bots/dashboard", icon: Home, module: "bots" },
  { label: "My Bots", to: "/bots/list", icon: Bot, module: "bots" },
  { label: "Bot Templates", to: "/bots/templates", icon: Puzzle, module: "bots" },
  { label: "Live Chat", to: "/bots/chat", icon: MessageSquare, module: "bots" },
  { label: "Contacts", to: "/bots/contacts", icon: Users, module: "bots" },
  { label: "Broadcasts", to: "/bots/broadcasts", icon: Megaphone, module: "bots" },
  { label: "Automation", to: "/bots/automation", icon: Zap, module: "bots" },
  { label: "Knowledge Base", to: "/bots/knowledge", icon: BookOpen, module: "bots" },
  { label: "Bots Analytics", to: "/bots/analytics", icon: BarChart3, module: "bots" },

  { label: "Analytics Overview", to: "/analytics/dashboard", icon: Home, module: "analytics" },
  { label: "Workforce Analytics", to: "/analytics/workforce", icon: Users, module: "analytics" },
  { label: "Monitor Analytics", to: "/analytics/monitor", icon: Radio, module: "analytics" },
  { label: "Content Analytics", to: "/analytics/content", icon: CalendarDays, module: "analytics" },
  { label: "Bots Analytics", to: "/analytics/bots", icon: Bot, module: "analytics" },
  { label: "Cross-module", to: "/analytics/cross-module", icon: Link2, module: "analytics" },
];

const RECENTS_KEY = "kf:cmdk:recents";

function loadRecents(): string[] {
  try { return JSON.parse(localStorage.getItem(RECENTS_KEY) || "[]"); } catch { return []; }
}
function pushRecent(to: string) {
  try {
    const prev = loadRecents().filter((x) => x !== to);
    const next = [to, ...prev].slice(0, 6);
    localStorage.setItem(RECENTS_KEY, JSON.stringify(next));
  } catch { /* ignore */ }
}

function accentFor(module: ModuleKey | "core") {
  if (module === "core") return "var(--muted-foreground)";
  const m = MODULES.find((x) => x.key === module);
  return m ? `var(--${m.accent})` : "var(--muted-foreground)";
}

export function GlobalSearch() {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<any[]>([]);
  const [recentsTick, setRecentsTick] = useState(0);
  const { org } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setOpen((v) => !v);
      }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, []);

  // Reset query when opened
  useEffect(() => { if (open) { setQuery(""); setRecentsTick((t) => t + 1); } }, [open]);

  useEffect(() => {
    if (!open || !org?.id) return;
    const q = query.trim();
    if (!q) { setResults([]); return; }
    const builder = supabase.from("search_index").select("*").eq("org_id", org.id)
      .or(`title.ilike.%${q}%,subtitle.ilike.%${q}%,keywords.ilike.%${q}%`)
      .order("updated_at", { ascending: false }).limit(20);
    let cancelled = false;
    builder.then(({ data }) => { if (!cancelled) setResults(data ?? []); });
    return () => { cancelled = true; };
  }, [open, query, org?.id]);

  const recents = useMemo(() => {
    void recentsTick;
    const ids = loadRecents();
    return ids
      .map((to) => PAGES.find((p) => p.to === to))
      .filter((p): p is Page => Boolean(p));
  }, [recentsTick]);

  const grouped = useMemo(() =>
    MODULES.map((m) => ({ module: m, items: results.filter((r) => r.module === m.key) }))
      .filter((g) => g.items.length),
    [results]
  );

  const go = (to: string) => {
    pushRecent(to);
    setOpen(false);
    navigate({ to: to as any });
  };

  return (
    <CommandDialog open={open} onOpenChange={setOpen}>
      <CommandInput placeholder="Search pages, entities, anything…  (try 'invoice', 'leave', 'alerts')"
        value={query} onValueChange={setQuery} />
      <CommandList className="max-h-[60vh]">
        <CommandEmpty>
          <div className="py-6 text-center text-sm text-muted-foreground">
            No matches. Try a different keyword.
          </div>
        </CommandEmpty>

        {!query && recents.length > 0 && (
          <>
            <CommandGroup heading={<span className="inline-flex items-center gap-1.5"><Clock className="h-3 w-3" /> Recent</span> as any}>
              {recents.map((p) => {
                const Icon = p.icon;
                const accent = accentFor(p.module);
                return (
                  <CommandItem key={`r-${p.to}`} value={`recent ${p.label}`} onSelect={() => go(p.to)}>
                    <span className="h-6 w-6 rounded-md flex items-center justify-center mr-2"
                      style={{ background: `color-mix(in oklab, ${accent} 14%, transparent)`, color: accent }}>
                      <Icon className="h-3.5 w-3.5" />
                    </span>
                    <span className="flex-1 truncate">{p.label}</span>
                    <span className="text-[10px] uppercase text-muted-foreground tracking-wide">
                      {p.module === "core" ? "Core" : MODULES.find((m) => m.key === p.module)?.label}
                    </span>
                    <ArrowRight className="h-3 w-3 ml-2 opacity-50" />
                  </CommandItem>
                );
              })}
            </CommandGroup>
            <CommandSeparator />
          </>
        )}

        {/* Pages — always available */}
        {(["core", ...MODULES.map((m) => m.key)] as (ModuleKey | "core")[]).map((modKey) => {
          const heading = modKey === "core" ? "Workspace" : MODULES.find((m) => m.key === modKey)?.label;
          const accent = accentFor(modKey);
          const items = PAGES.filter((p) => p.module === modKey);
          if (!items.length) return null;
          return (
            <CommandGroup key={`pg-${modKey}`} heading={
              <span className="inline-flex items-center gap-1.5">
                <span className="h-1.5 w-1.5 rounded-full" style={{ background: accent }} />
                {heading}
              </span> as any
            }>
              {items.map((p) => {
                const Icon = p.icon;
                return (
                  <CommandItem key={p.to} value={`${heading} ${p.label} ${p.keywords ?? ""} ${p.to}`}
                    onSelect={() => go(p.to)}>
                    <span className="h-6 w-6 rounded-md flex items-center justify-center mr-2"
                      style={{ background: `color-mix(in oklab, ${accent} 14%, transparent)`, color: accent }}>
                      <Icon className="h-3.5 w-3.5" />
                    </span>
                    <span className="flex-1 truncate">{p.label}</span>
                    <span className="text-[10px] font-mono text-muted-foreground/70 truncate max-w-[160px]">{p.to}</span>
                  </CommandItem>
                );
              })}
            </CommandGroup>
          );
        })}

        {/* Entity results from DB */}
        {grouped.length > 0 && <CommandSeparator />}
        {grouped.map((g) => (
          <CommandGroup key={g.module.key} heading={
            <span className="inline-flex items-center gap-1.5">
              <span className="h-1.5 w-1.5 rounded-full" style={{ background: `var(--${g.module.accent})` }} />
              {g.module.label} · results
            </span> as any
          }>
            {g.items.map((r) => (
              <CommandItem key={r.id} value={`entity ${r.title} ${r.subtitle ?? ""}`}
                onSelect={() => go(r.url || g.module.basePath)}>
                <span className="h-6 w-6 rounded-md flex items-center justify-center mr-2"
                  style={{ background: `color-mix(in oklab, var(--${g.module.accent}) 14%, transparent)`, color: `var(--${g.module.accent})` }}>
                  <Search className="h-3.5 w-3.5" />
                </span>
                <div className="flex-1 min-w-0">
                  <div className="text-sm truncate">{r.title}</div>
                  {r.subtitle && <div className="text-xs text-muted-foreground truncate">{r.subtitle}</div>}
                </div>
                <span className="text-[10px] uppercase text-muted-foreground tracking-wide">{r.entity_type}</span>
              </CommandItem>
            ))}
          </CommandGroup>
        ))}
      </CommandList>

      <div className="border-t px-3 py-2 flex items-center gap-3 text-[10px] text-muted-foreground bg-muted/30">
        <span className="flex items-center gap-1"><kbd className="px-1.5 py-0.5 rounded border bg-background font-mono">↑↓</kbd> navigate</span>
        <span className="flex items-center gap-1"><kbd className="px-1.5 py-0.5 rounded border bg-background font-mono">↵</kbd> open</span>
        <span className="flex items-center gap-1"><kbd className="px-1.5 py-0.5 rounded border bg-background font-mono">esc</kbd> close</span>
        <span className="ml-auto">⌘K anywhere</span>
      </div>
    </CommandDialog>
  );
}
