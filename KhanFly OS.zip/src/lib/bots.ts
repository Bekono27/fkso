import { supabase } from "@/integrations/supabase/client";
import { todayISO, getMondayISO } from "./workforce";

export { writeEvent, indexEntity, todayISO, getMondayISO } from "./workforce";

const CRISIS_KEYWORDS = ["complaint", "refund", "angry", "problem", "хэрэг", "буцаах"];

export function detectCrisisKeyword(text: string | null | undefined): string | null {
  if (!text) return null;
  const lower = text.toLowerCase();
  for (const kw of CRISIS_KEYWORDS) {
    if (lower.includes(kw)) return kw;
  }
  return null;
}

export async function getBotsSummary(orgId: string) {
  const today = todayISO();
  const weekStart = getMondayISO();
  const monthStart = today.slice(0, 7) + "-01";

  const [activeBots, convsToday, aiResolved, humanHandoffs, leadsToday, leadsWeek, pendingHandoffs, broadcasts] =
    await Promise.all([
      supabase.from("bots").select("id,name", { count: "exact" })
        .eq("org_id", orgId).eq("status", "active"),
      supabase.from("bot_conversations").select("id", { count: "exact", head: true })
        .eq("org_id", orgId).gte("created_at", today),
      supabase.from("bot_conversations").select("id", { count: "exact", head: true })
        .eq("org_id", orgId).eq("resolved_by", "ai").gte("created_at", today),
      supabase.from("bot_conversations").select("id", { count: "exact", head: true })
        .eq("org_id", orgId).eq("resolved_by", "human").gte("created_at", today),
      supabase.from("bot_conversations").select("id", { count: "exact", head: true })
        .eq("org_id", orgId).eq("lead_captured", true).gte("created_at", today),
      supabase.from("bot_conversations").select("id", { count: "exact", head: true })
        .eq("org_id", orgId).eq("lead_captured", true).gte("created_at", weekStart),
      supabase.from("handoff_requests").select("id", { count: "exact", head: true })
        .eq("org_id", orgId).eq("status", "pending"),
      supabase.from("bot_broadcasts")
        .select("id,name,recipient_count,status")
        .eq("org_id", orgId).gte("created_at", monthStart)
        .order("created_at", { ascending: false }).limit(3),
    ]);

  const convs = convsToday.count ?? 0;
  const ai = aiResolved.count ?? 0;
  const resolution = convs > 0 ? Math.round((ai * 100) / convs) : 0;

  return {
    active_bots: activeBots.count ?? 0,
    active_bot_names: (activeBots.data ?? []).map((b: any) => b.name).join(", "),
    conversations_today: convs,
    ai_resolution_rate: resolution,
    human_handoffs_today: humanHandoffs.count ?? 0,
    leads_today: leadsToday.count ?? 0,
    leads_this_week: leadsWeek.count ?? 0,
    pending_handoffs: pendingHandoffs.count ?? 0,
    recent_broadcasts: (broadcasts.data ?? [])
      .map((b: any) => `${b.name} (${b.status}, ${b.recipient_count} recipients)`).join("; "),
  };
}

export function botsSummaryToPrompt(s: Awaited<ReturnType<typeof getBotsSummary>>) {
  return (
    `BOTS: ${s.active_bots} active bots${s.active_bot_names ? ` (${s.active_bot_names})` : ""}. ` +
    `${s.conversations_today} conversations today — ${s.ai_resolution_rate}% resolved by AI, ` +
    `${s.human_handoffs_today} handed to human. ` +
    `${s.leads_today} leads captured today (${s.leads_this_week} this week). ` +
    `${s.pending_handoffs} handoffs waiting for agent. ` +
    `Recent broadcasts: ${s.recent_broadcasts || "none"}.`
  );
}
