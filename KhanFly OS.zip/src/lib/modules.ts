import { Briefcase, Eye, CalendarDays, Bot, FlaskConical, BarChart3, Banknote, type LucideIcon } from "lucide-react";

export type ModuleKey = "workforce" | "monitor" | "research" | "content" | "bots" | "analytics" | "digilend";

export type ModuleDef = {
  key: ModuleKey;
  label: string;
  origin: string;
  basePath: "/workforce" | "/monitor" | "/research" | "/content" | "/bots" | "/analytics" | "/ewa";
  icon: LucideIcon;
  accent: string;
  description: string;
};

export const MODULES: ModuleDef[] = [
  { key: "workforce", label: "Workforce", origin: "TimeFlow",   basePath: "/workforce", icon: Briefcase,    accent: "workforce", description: "Attendance, payroll, HR, projects, ops" },
  { key: "monitor",   label: "Monitor",   origin: "OmniSight",  basePath: "/monitor",   icon: Eye,          accent: "monitor",   description: "Brand listening, sentiment, alerts" },
  { key: "research",  label: "Research",  origin: "Insight Lab",basePath: "/research",  icon: FlaskConical, accent: "research",  description: "AI market research & business intel" },
  { key: "content",   label: "Content",   origin: "SMM Agency", basePath: "/content",   icon: CalendarDays, accent: "content",   description: "Calendar, AI captions, invoicing" },
  { key: "bots",      label: "Bots",      origin: "FlowBot",    basePath: "/bots",      icon: Bot,          accent: "bots",      description: "No-code chatbot builder & live chat" },
  { key: "digilend",  label: "EWA System",  origin: "uLu",        basePath: "/ewa",  icon: Banknote,     accent: "digilend",  description: "Mongolian earned-wage advance (MNT)" },
  { key: "analytics", label: "Analytics", origin: "Unified BI", basePath: "/analytics", icon: BarChart3,    accent: "analytics", description: "Cross-module business intelligence" },
];

export function moduleFromPath(pathname: string): ModuleDef | null {
  return MODULES.find((m) => pathname === m.basePath || pathname.startsWith(m.basePath + "/")) ?? null;
}
