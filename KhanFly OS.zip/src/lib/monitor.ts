import { supabase } from "@/integrations/supabase/client";
import { todayISO } from "./workforce";

export { writeEvent, indexEntity, todayISO } from "./workforce";

function subtractDays(iso: string, n: number) {
  const d = new Date(iso);
  d.setDate(d.getDate() - n);
  return d.toISOString().split("T")[0];
}

export async function getMonitorSummary(orgId: string) {
  const today = todayISO();
  const yesterday = subtractDays(today, 1);

  const [todayScore, yesterdayScore, activeAlerts, mentionsToday, topKeywords, competitors] =
    await Promise.all([
      supabase.from("sentiment_scores").select("score, mention_count")
        .eq("org_id", orgId).eq("date", today).maybeSingle(),
      supabase.from("sentiment_scores").select("score")
        .eq("org_id", orgId).eq("date", yesterday).maybeSingle(),
      supabase.from("monitoring_alerts").select("id,title,severity", { count: "exact" })
        .eq("org_id", orgId).eq("status", "active"),
      supabase.from("sentiment_mentions").select("sentiment", { count: "exact" })
        .eq("org_id", orgId).eq("date", today),
      supabase.from("keyword_mentions").select("keyword_term,count")
        .eq("org_id", orgId).eq("date", today)
        .order("count", { ascending: false }).limit(5),
      supabase.from("monitoring_competitors").select("name,last_post_at,engagement_avg")
        .eq("org_id", orgId).eq("active", true),
    ]);

  const alerts = activeAlerts.data ?? [];
  const critical = alerts.filter((a: any) => a.severity === "critical").length;
  const high = alerts.filter((a: any) => a.severity === "high").length;

  return {
    brand_score_today: todayScore.data?.score ?? null,
    brand_score_yesterday: yesterdayScore.data?.score ?? null,
    score_change: ((todayScore.data?.score ?? 0) as number) - ((yesterdayScore.data?.score ?? 0) as number),
    active_alerts_total: activeAlerts.count ?? 0,
    critical_alerts: critical,
    high_alerts: high,
    mentions_today: mentionsToday.count ?? 0,
    top_keywords: (topKeywords.data ?? []).map((k: any) => `${k.keyword_term}(${k.count})`).join(", "),
    competitor_count: competitors.data?.length ?? 0,
  };
}

export function monitorSummaryToPrompt(s: Awaited<ReturnType<typeof getMonitorSummary>>) {
  return (
    `MONITOR: Brand score ${s.brand_score_today ?? "N/A"}/100 ` +
    `(${s.score_change >= 0 ? "+" : ""}${s.score_change} vs yesterday). ` +
    `${s.active_alerts_total} active alerts (${s.critical_alerts} critical, ${s.high_alerts} high). ` +
    `${s.mentions_today} mentions today. ` +
    `Top keywords: ${s.top_keywords || "none"}. ` +
    `Tracking ${s.competitor_count} competitors.`
  );
}
