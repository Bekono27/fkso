import { getWorkforceSummary, summaryToPrompt } from "./workforce";
import { getMonitorSummary, monitorSummaryToPrompt } from "./monitor";
import { getBotsSummary, botsSummaryToPrompt } from "./bots";
import { getContentSummary, contentSummaryToPrompt } from "./content";

export type ModuleKey = "workforce" | "monitor" | "research" | "content" | "bots" | "analytics" | "digilend" | "core";

/** Build an AI-assistant system prompt for the active module(s). */
export async function buildPlatformContext(orgId: string, activeModule: ModuleKey | null) {
  const parts: string[] = [];
  const wantsAll = !activeModule || activeModule === "core";

  if (wantsAll || activeModule === "workforce") {
    try { parts.push(summaryToPrompt(await getWorkforceSummary(orgId))); }
    catch (e) { console.warn("workforce summary failed", e); }
  }
  if (wantsAll || activeModule === "monitor") {
    try { parts.push(monitorSummaryToPrompt(await getMonitorSummary(orgId))); }
    catch (e) { console.warn("monitor summary failed", e); }
  }
  if (wantsAll || activeModule === "content") {
    try { parts.push(contentSummaryToPrompt(await getContentSummary(orgId))); }
    catch (e) { console.warn("content summary failed", e); }
  }
  if (wantsAll || activeModule === "bots") {
    try { parts.push(botsSummaryToPrompt(await getBotsSummary(orgId))); }
    catch (e) { console.warn("bots summary failed", e); }
  }

  return parts.join("\n\n");
}
