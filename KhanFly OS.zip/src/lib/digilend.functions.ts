// DigiLend / uLu Mongolian banking server functions.
// QPay-first with Khan Bank fallback (mock in stub mode).
import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

// =============== Types ==========================================
type QPayInvoiceResult = {
  invoice_id: string;
  qr_text: string;
  qr_image: string;
  urls?: Array<{ name: string; logo?: string; link: string }>;
};

// =============== QPay helpers (server-only) =====================
const QPAY_BASE = "https://merchant.qpay.mn/v2";

async function qpayToken(): Promise<string> {
  const user = process.env.QPAY_USERNAME;
  const pass = process.env.QPAY_PASSWORD;
  if (!user || !pass) throw new Error("QPay credentials are not configured");
  const auth = Buffer.from(`${user}:${pass}`).toString("base64");
  const res = await fetch(`${QPAY_BASE}/auth/token`, {
    method: "POST",
    headers: { Authorization: `Basic ${auth}`, "content-type": "application/json" },
    body: JSON.stringify({ grant_type: "client_credentials" }),
  });
  if (!res.ok) throw new Error(`QPay auth failed [${res.status}]: ${await res.text()}`);
  const j = (await res.json()) as { access_token: string };
  return j.access_token;
}

async function qpayCreateInvoice(args: {
  transactionId: string;
  amount: number;
  description: string;
  callbackUrl: string;
}): Promise<QPayInvoiceResult> {
  const invoiceCode = process.env.QPAY_INVOICE_CODE;
  if (!invoiceCode) throw new Error("QPAY_INVOICE_CODE is not configured");
  const token = await qpayToken();
  const res = await fetch(`${QPAY_BASE}/invoice`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "content-type": "application/json" },
    body: JSON.stringify({
      invoice_code: invoiceCode,
      sender_invoice_no: args.transactionId,
      invoice_receiver_code: "terminal",
      invoice_description: args.description,
      amount: args.amount,
      callback_url: args.callbackUrl,
    }),
  });
  if (!res.ok) throw new Error(`QPay invoice failed [${res.status}]: ${await res.text()}`);
  return (await res.json()) as QPayInvoiceResult;
}

// =============== Risk check =====================================
export const mnRiskCheck = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { amount: number; employeeId?: string | null }) =>
    z.object({ amount: z.number().positive(), employeeId: z.string().uuid().nullable().optional() }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    // Caller's org from profile
    const { data: prof } = await supabase
      .from("profiles")
      .select("org_id")
      .eq("id", userId)
      .single();
    const orgId = prof?.org_id;
    if (!orgId) return { ok: false, reason: "Байгууллага олдсонгүй" };

    // Config
    const { data: cfg } = await supabase
      .from("mn_payment_config")
      .select("*")
      .eq("org_id", orgId)
      .maybeSingle();
    if (!cfg) return { ok: false, reason: "Банкны тохиргоо хийгдээгүй" };

    if (data.amount < cfg.ewa_min_amount)
      return { ok: false, reason: `Доод дүн ₮${cfg.ewa_min_amount.toLocaleString()}` };
    if (data.amount > cfg.ewa_max_amount)
      return { ok: false, reason: `Дээд дүн ₮${cfg.ewa_max_amount.toLocaleString()}` };

    // AML flag
    let flag: string | null = null;
    if (data.amount > cfg.aml_single_threshold) {
      flag = `AML: нэг гүйлгээний дээд хязгаар (₮${cfg.aml_single_threshold.toLocaleString()}) давсан`;
    }

    // Daily limit
    const since = new Date();
    since.setHours(0, 0, 0, 0);
    const { count: today } = await supabase
      .from("ulu_transactions")
      .select("*", { count: "exact", head: true })
      .eq("org_id", orgId)
      .eq("employee_id", data.employeeId ?? "")
      .gte("requested_at", since.toISOString())
      .in("status", ["pending", "approved", "completed"]);
    if ((today ?? 0) >= cfg.ewa_max_per_day)
      return { ok: false, reason: "Өдрийн дээд урьдчилгааны тоо хэтэрсэн" };

    const fee = Math.round((data.amount * Number(cfg.ewa_fee_percent)) / 100);
    return { ok: true, fee, total: data.amount + fee, flag };
  });

// =============== Initiate payment (creates QPay invoice) ========
export const mnPaymentInitiate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { transactionId: string }) =>
    z.object({ transactionId: z.string().uuid() }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { data: txn, error } = await supabase
      .from("ulu_transactions")
      .select("*")
      .eq("id", data.transactionId)
      .single();
    if (error || !txn) throw new Error("Гүйлгээ олдсонгүй");
    if (txn.status === "completed") return { ok: true, alreadyPaid: true };

    const origin = process.env.SUPABASE_URL!.replace(".supabase.co", ".functions.supabase.co");
    const callbackUrl = `${origin}/mn-payment-webhook?txn=${txn.id}`;

    const invoice = await qpayCreateInvoice({
      transactionId: txn.id,
      amount: Number(txn.amount),
      description: txn.description ?? "KFOS uLu цалингийн урьдчилгаа",
      callbackUrl,
    });

    await supabase
      .from("ulu_transactions")
      .update({
        provider: "qpay",
        qpay_invoice_id: invoice.invoice_id,
        qpay_qr_text: invoice.qr_text,
        status: "approved",
        approved_at: new Date().toISOString(),
      })
      .eq("id", txn.id);

    return {
      ok: true,
      invoice_id: invoice.invoice_id,
      qr_image: invoice.qr_image,
      qr_text: invoice.qr_text,
      urls: invoice.urls ?? [],
    };
  });

// =============== KYC verify (Khan Bank mocked in stub) ==========
export const mnKycVerify = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { bankAccountId: string; expectedName: string }) =>
    z.object({ bankAccountId: z.string().uuid(), expectedName: z.string().min(1) }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    // Khan Bank API not wired in stub mode — accept the provided name as verified.
    // TODO: when KHANBANK_* secrets are added, call POST /v1/account/verify.
    const verifiedName = data.expectedName.trim().toUpperCase();
    const { error } = await supabase
      .from("mn_bank_accounts")
      .update({
        verified: true,
        verified_at: new Date().toISOString(),
        verified_name: verifiedName,
      })
      .eq("id", data.bankAccountId);
    if (error) throw error;
    return { ok: true, verified_name: verifiedName, mode: "mock" as const };
  });

// =============== QPay sandbox connection test ===================
export const mnQpayTest = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async () => {
    try {
      const token = await qpayToken();
      return { ok: true, token_preview: token.slice(0, 8) + "…" };
    } catch (e) {
      return { ok: false, error: (e as Error).message };
    }
  });
