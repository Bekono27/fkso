import { supabase } from "@/integrations/supabase/client";
import { todayISO, getMondayISO } from "./workforce";

export { writeEvent, indexEntity, todayISO, getMondayISO } from "./workforce";

export async function getContentSummary(orgId: string) {
  const today = todayISO();
  const weekStart = getMondayISO();
  const monthStart = today.slice(0, 7) + "-01";

  const [clients, activeClients, postsScheduled, postsPublishedWeek, awaitingApproval,
    proposalsOpen, invoicesUnpaid, mrr] = await Promise.all([
    supabase.from("smm_clients").select("id", { count: "exact", head: true }).eq("org_id", orgId),
    supabase.from("smm_clients").select("id", { count: "exact", head: true })
      .eq("org_id", orgId).eq("status", "active"),
    supabase.from("smm_posts").select("id", { count: "exact", head: true })
      .eq("org_id", orgId).eq("status", "scheduled").gte("scheduled_at", today),
    supabase.from("smm_posts").select("id", { count: "exact", head: true })
      .eq("org_id", orgId).eq("status", "published").gte("published_at", weekStart),
    supabase.from("smm_posts").select("id", { count: "exact", head: true })
      .eq("org_id", orgId).eq("status", "review"),
    supabase.from("smm_proposals").select("id,amount", { count: "exact" })
      .eq("org_id", orgId).in("status", ["sent", "viewed"]),
    supabase.from("smm_invoices").select("id,amount,amount_paid", { count: "exact" })
      .eq("org_id", orgId).in("status", ["sent", "overdue", "partial"]),
    supabase.from("smm_clients").select("monthly_retainer")
      .eq("org_id", orgId).eq("status", "active"),
  ]);

  const unpaidTotal = (invoicesUnpaid.data ?? [])
    .reduce((s, i: any) => s + Number(i.amount ?? 0) - Number(i.amount_paid ?? 0), 0);
  const proposalsValue = (proposalsOpen.data ?? [])
    .reduce((s, p: any) => s + Number(p.amount ?? 0), 0);
  const monthlyRevenue = (mrr.data ?? [])
    .reduce((s, c: any) => s + Number(c.monthly_retainer ?? 0), 0);

  return {
    total_clients: clients.count ?? 0,
    active_clients: activeClients.count ?? 0,
    posts_scheduled: postsScheduled.count ?? 0,
    posts_published_this_week: postsPublishedWeek.count ?? 0,
    awaiting_approval: awaitingApproval.count ?? 0,
    open_proposals: proposalsOpen.count ?? 0,
    open_proposals_value: proposalsValue,
    unpaid_invoices: invoicesUnpaid.count ?? 0,
    unpaid_total: unpaidTotal,
    monthly_recurring_revenue: monthlyRevenue,
  };
}

export function contentSummaryToPrompt(s: Awaited<ReturnType<typeof getContentSummary>>) {
  return (
    `CONTENT: ${s.active_clients}/${s.total_clients} active clients, MRR ${s.monthly_recurring_revenue.toLocaleString()}. ` +
    `${s.posts_scheduled} posts scheduled, ${s.posts_published_this_week} published this week, ${s.awaiting_approval} awaiting approval. ` +
    `${s.open_proposals} open proposals worth ${s.open_proposals_value.toLocaleString()}. ` +
    `${s.unpaid_invoices} unpaid invoices totalling ${s.unpaid_total.toLocaleString()}.`
  );
}
