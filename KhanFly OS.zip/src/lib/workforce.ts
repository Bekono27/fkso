import { supabase } from "@/integrations/supabase/client";

/* ---------- platform_events ---------- */
export type WorkforceEventType =
  | "employee_created"
  | "employee_offboarded"
  | "leave_approved"
  | "leave_rejected"
  | "payroll_approved"
  | "task_completed"
  | "ticket_resolved";

export async function writeEvent(
  org_id: string,
  source_module: "workforce" | "monitor" | "content" | "bots" | "core",
  event_type: string,
  payload: Record<string, unknown>,
  triggered_by?: string,
) {
  if (!org_id) return;
  await supabase.from("platform_events").insert({
    org_id,
    source_module: source_module as any,
    event_type,
    payload: payload as any,
    triggered_by: triggered_by ?? null,
  } as any);
}

/* ---------- search_index ---------- */
export async function indexEntity(args: {
  org_id: string;
  module: "workforce" | "monitor" | "content" | "bots" | "core";
  entity_type: string;
  entity_id: string;
  title: string;
  subtitle?: string | null;
  keywords?: string | null;
  url: string;
}) {
  if (!args.org_id || !args.entity_id) return;
  await supabase.from("search_index").upsert(
    {
      org_id: args.org_id,
      module: args.module as any,
      entity_type: args.entity_type,
      entity_id: args.entity_id,
      title: args.title,
      subtitle: args.subtitle ?? null,
      keywords: args.keywords ?? null,
      url: args.url,
      updated_at: new Date().toISOString(),
    } as any,
    { onConflict: "org_id,entity_id" },
  );
}

/* ---------- date helpers ---------- */
export function todayISO() {
  return new Date().toISOString().split("T")[0];
}
export function getMondayISO(d = new Date()) {
  const day = d.getDay(); // 0..6 (Sun..Sat)
  const diff = (day === 0 ? -6 : 1) - day;
  const m = new Date(d);
  m.setDate(d.getDate() + diff);
  m.setHours(0, 0, 0, 0);
  return m.toISOString().split("T")[0];
}

/* ---------- AI summary ---------- */
export async function getWorkforceSummary(orgId: string) {
  const today = todayISO();
  const weekStart = getMondayISO();

  const [employees, present, onLeave, pendingLeave, draftPayroll, overtime, openTickets] =
    await Promise.all([
      supabase.from("employees").select("id", { count: "exact", head: true })
        .eq("org_id", orgId).eq("is_active", true),
      supabase.from("work_sessions").select("id", { count: "exact", head: true })
        .eq("org_id", orgId).eq("date", today).is("clock_out", null),
      supabase.from("leave_requests").select("id", { count: "exact", head: true })
        .eq("org_id", orgId).eq("status", "approved")
        .lte("start_date", today).gte("end_date", today),
      supabase.from("leave_requests").select("id", { count: "exact", head: true })
        .eq("org_id", orgId).eq("status", "pending"),
      supabase.from("payroll_records")
        .select("id,month,year,gross_salary", { count: "exact" })
        .eq("org_id", orgId).eq("status", "draft"),
      supabase.from("work_sessions").select("overtime_minutes")
        .eq("org_id", orgId).gte("date", weekStart),
      supabase.from("helpdesk_tickets").select("id", { count: "exact", head: true })
        .eq("org_id", orgId).eq("status", "open"),
    ]);

  const totalEmp = employees.count ?? 0;
  const presentCount = present.count ?? 0;
  const onLeaveCount = onLeave.count ?? 0;
  const overtimeHours = Math.round(
    (overtime.data ?? []).reduce((s, r: any) => s + (r.overtime_minutes ?? 0), 0) / 60,
  );
  const draftPeriods = (draftPayroll.data ?? [])
    .map((p: any) => `${p.year}-${String(p.month).padStart(2, "0")}`)
    .join(", ");

  return {
    total_employees: totalEmp,
    present_today: presentCount,
    on_leave_today: onLeaveCount,
    absent_today: Math.max(0, totalEmp - presentCount - onLeaveCount),
    pending_leave_requests: pendingLeave.count ?? 0,
    draft_payroll_count: draftPayroll.count ?? 0,
    draft_payroll_periods: draftPeriods,
    overtime_hours_this_week: overtimeHours,
    open_helpdesk_tickets: openTickets.count ?? 0,
  };
}

export function summaryToPrompt(s: Awaited<ReturnType<typeof getWorkforceSummary>>) {
  return (
    `WORKFORCE: ${s.total_employees} employees, ${s.present_today} present today, ` +
    `${s.absent_today} absent, ${s.on_leave_today} on leave. ` +
    `${s.pending_leave_requests} leave requests pending approval. ` +
    `${s.draft_payroll_count} payroll drafts${s.draft_payroll_periods ? ` (${s.draft_payroll_periods})` : ""}. ` +
    `${s.overtime_hours_this_week}h overtime this week. ` +
    `${s.open_helpdesk_tickets} open helpdesk tickets.`
  );
}
