import { createFileRoute, useParams } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export const Route = createFileRoute("/approval/$token")({
  component: ApprovalPage,
});

function ApprovalPage() {
  const { token } = useParams({ from: "/approval/$token" });
  const [proposal, setProposal] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [acted, setActed] = useState<string | null>(null);

  useEffect(() => {
    supabase.from("smm_proposals").select("*").eq("approval_token", token).maybeSingle()
      .then(({ data }) => { setProposal(data); setLoading(false); });
  }, [token]);

  const respond = async (status: "accepted" | "rejected") => {
    if (!proposal) return;
    await supabase.from("smm_proposals").update({ status, responded_at: new Date().toISOString() } as any)
      .eq("approval_token", token);
    setActed(status);
    setProposal({ ...proposal, status });
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center text-muted-foreground">Loading…</div>;
  if (!proposal) return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="text-center"><h1 className="text-2xl font-semibold">Proposal not found</h1>
      <p className="text-sm text-muted-foreground mt-2">This link may have expired.</p></div>
    </div>
  );

  const done = acted || ["accepted", "rejected"].includes(proposal.status);

  return (
    <div className="min-h-screen bg-muted/30 py-12 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <div className="inline-block h-12 w-12 rounded-xl mb-3 flex items-center justify-center font-bold text-white"
            style={{ background: "var(--content)" }}>K</div>
          <h1 className="text-3xl font-semibold">{proposal.title}</h1>
        </div>

        <Card>
          <CardContent className="p-8 space-y-6">
            <div className="flex justify-between items-baseline">
              <div className="text-sm text-muted-foreground">Total</div>
              <div className="text-3xl font-bold" style={{ color: "var(--content)" }}>
                {proposal.currency ?? "$"} {Number(proposal.amount).toLocaleString()}
              </div>
            </div>
            {proposal.description && (
              <div className="prose prose-sm max-w-none text-sm whitespace-pre-wrap">{proposal.description}</div>
            )}
            {proposal.valid_until && (
              <div className="text-xs text-muted-foreground">Valid until {new Date(proposal.valid_until).toLocaleDateString()}</div>
            )}

            {done ? (
              <div className="text-center py-4">
                <div className="text-lg font-semibold">
                  {proposal.status === "accepted" ? "✓ Proposal accepted" : "Proposal rejected"}
                </div>
                <div className="text-sm text-muted-foreground mt-1">Thank you for your response.</div>
              </div>
            ) : (
              <div className="flex gap-3 pt-2">
                <Button className="flex-1" style={{ background: "var(--content)", color: "white" }} onClick={() => respond("accepted")}>
                  Accept
                </Button>
                <Button variant="outline" className="flex-1" onClick={() => respond("rejected")}>
                  Decline
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="text-center mt-6 text-xs text-muted-foreground">Powered by KhanFly OS</div>
      </div>
    </div>
  );
}
