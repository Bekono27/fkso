import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { AuthLayout } from "@/components/auth-layout";
import { Eye, EyeOff, Loader2, Check } from "lucide-react";

export const Route = createFileRoute("/signup")({ component: SignupPage });

function SignupPage() {
  const nav = useNavigate();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [busy, setBusy] = useState(false);

  const pwChecks = [
    { label: "8+ characters", ok: password.length >= 8 },
    { label: "1 number", ok: /\d/.test(password) },
    { label: "1 letter", ok: /[a-zA-Z]/.test(password) },
  ];

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    const redirectUrl = `${window.location.origin}/dashboard`;
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: { emailRedirectTo: redirectUrl, data: { full_name: name } },
    });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Check your email to confirm your account");
    nav({ to: "/login" });
  }

  return (
    <AuthLayout eyebrow="Create account" title="Start your workspace" subtitle="A workspace and all six modules are provisioned automatically.">
      <form onSubmit={onSubmit} className="space-y-5">
        <div className="space-y-2">
          <Label htmlFor="name">Full name</Label>
          <Input id="name" required value={name} onChange={(e) => setName(e.target.value)} className="h-11" placeholder="Ada Lovelace" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="email">Work email</Label>
          <Input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="h-11" placeholder="you@company.com" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="password">Password</Label>
          <div className="relative">
            <Input
              id="password"
              type={showPw ? "text" : "password"}
              required minLength={6}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="h-11 pr-10"
            />
            <button type="button" onClick={() => setShowPw((v) => !v)}
              aria-label={showPw ? "Hide password" : "Show password"}
              className="absolute inset-y-0 right-0 px-3 text-muted-foreground hover:text-foreground transition-colors">
              {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
          <ul className="flex flex-wrap gap-x-3 gap-y-1 pt-1">
            {pwChecks.map((c) => (
              <li key={c.label} className={`flex items-center gap-1 text-[11px] transition-colors ${c.ok ? "text-emerald-600 dark:text-emerald-400" : "text-muted-foreground"}`}>
                <Check className={`h-3 w-3 ${c.ok ? "opacity-100" : "opacity-30"}`} />
                {c.label}
              </li>
            ))}
          </ul>
        </div>
        <Button type="submit" className="w-full h-11 text-sm font-medium" disabled={busy}>
          {busy ? (<><Loader2 className="h-4 w-4 animate-spin" /> Creating…</>) : "Create account"}
        </Button>
        <p className="text-sm text-muted-foreground text-center">
          Already have one?{" "}
          <Link to="/login" className="text-foreground font-medium underline underline-offset-4 decoration-muted-foreground/40 hover:decoration-foreground">Sign in</Link>
        </p>
      </form>
    </AuthLayout>
  );
}
