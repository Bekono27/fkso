import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/_app/monitor/")({
  beforeLoad: () => { throw redirect({ to: "/monitor/dashboard" }); },
});
