import { createFileRoute } from "@tanstack/react-router";
import { ContentList, ContentStatusPill } from "@/components/content/list";
import { QuickCreate } from "@/components/quick-create";

export const Route = createFileRoute("/_app/content/invoices")({
  component: () => (
    <ContentList
      title="Invoices"
      description="Track outstanding and paid invoices"
      table="smm_invoices"
      orderBy="issue_date"
      actions={
        <QuickCreate
          table="smm_invoices"
          title="New invoice"
          buttonLabel="New invoice"
          buttonStyle={{ background: "var(--content)", color: "white" }}
          fields={[
            { key: "number", label: "Number", required: true, placeholder: "INV-001" },
            { key: "amount", label: "Amount", type: "number", required: true },
            { key: "currency", label: "Currency", placeholder: "USD" },
            { key: "due_date", label: "Due date", type: "text", placeholder: "YYYY-MM-DD" },
          ]}
          defaults={{ status: "draft", issue_date: new Date().toISOString().split("T")[0] }}
        />
      }
      columns={[
        { key: "number", label: "Number" },
        { key: "amount", label: "Amount", render: (r) => `${r.currency ?? "$"} ${Number(r.amount).toLocaleString()}` },
        { key: "amount_paid", label: "Paid", render: (r) => `${r.currency ?? "$"} ${Number(r.amount_paid ?? 0).toLocaleString()}` },
        { key: "due_date", label: "Due", render: (r) => r.due_date ? new Date(r.due_date).toLocaleDateString() : "—" },
        { key: "status", label: "Status", render: (r) => <ContentStatusPill value={r.status} /> },
      ]}
    />
  ),
});
