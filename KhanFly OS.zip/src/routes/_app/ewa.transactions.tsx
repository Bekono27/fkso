import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { EwaPage, MNT, STATUS_TONE } from "@/components/ewa/page-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/_app/ewa/transactions")({ component: TransactionsPage });

function TransactionsPage() {
  const { org } = useAuth();
  const [rows, setRows] = useState<any[] | null>(null);
  const [q, setQ] = useState("");

  useEffect(() => {
    if (!org?.id) return;
    supabase.from("ulu_transactions" as never)
      .select("*, employee:employees(full_name, email)")
      .eq("org_id", org.id)
      .order("requested_at", { ascending: false })
      .limit(200)
      .then(({ data }) => setRows((data as any[]) ?? []));
  }, [org?.id]);

  const filtered = (rows ?? []).filter((r) => {
    if (!q) return true;
    const hay = `${r.status} ${r.amount} ${r.description ?? ""} ${r.employee?.full_name ?? ""}`.toLowerCase();
    return hay.includes(q.toLowerCase());
  });

  return (
    <EwaPage
      title="Гүйлгээ"
      description="Цалингийн урьдчилгааны бүх гүйлгээ"
      actions={<Input placeholder="Хайх…" value={q} onChange={(e) => setQ(e.target.value)} className="h-9 w-56" />}
    >
      <Card>
        <CardContent className="p-0">
          {rows === null ? (
            <div className="p-8 text-center text-sm text-muted-foreground">Уншиж байна…</div>
          ) : filtered.length === 0 ? (
            <div className="p-10 text-center text-sm text-muted-foreground">Гүйлгээ алга байна.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/40 text-xs uppercase tracking-wider text-muted-foreground">
                  <tr>
                    <th className="text-left px-4 py-2.5 font-medium">Огноо</th>
                    <th className="text-left px-4 py-2.5 font-medium">Ажилтан</th>
                    <th className="text-right px-4 py-2.5 font-medium">Дүн</th>
                    <th className="text-right px-4 py-2.5 font-medium">Шимтгэл</th>
                    <th className="text-left px-4 py-2.5 font-medium">Провайдер</th>
                    <th className="text-left px-4 py-2.5 font-medium">Төлөв</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {filtered.map((r) => (
                    <tr key={r.id} className="hover:bg-muted/20">
                      <td className="px-4 py-2.5 whitespace-nowrap">{new Date(r.requested_at).toLocaleString("mn-MN")}</td>
                      <td className="px-4 py-2.5">{r.employee?.full_name ?? "—"}</td>
                      <td className="px-4 py-2.5 text-right font-medium">{MNT(r.amount)}</td>
                      <td className="px-4 py-2.5 text-right text-muted-foreground">{MNT(r.fee)}</td>
                      <td className="px-4 py-2.5 uppercase text-xs">{r.provider ?? "—"}</td>
                      <td className="px-4 py-2.5">
                        <Badge variant="outline" style={{ color: STATUS_TONE[r.status], borderColor: STATUS_TONE[r.status] }}>{r.status}</Badge>
                        {r.flag_reason && <div className="text-[10px] text-amber-600 mt-0.5">{r.flag_reason}</div>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </EwaPage>
  );
}
