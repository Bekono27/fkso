import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { mnQpayTest } from "@/lib/digilend.functions";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Building2, ShieldCheck, AlertTriangle, CheckCircle2 } from "lucide-react";

export const Route = createFileRoute("/_app/settings/banking")({ component: BankingPage });

const ALL_BANKS = [
  "Khan Bank", "Golomt Bank", "TDB", "XacBank",
  "State Bank", "Bogd Bank", "MobiFinance",
];

type Config = {
  id: string;
  org_id: string;
  provider: string;
  environment: string;
  merchant_id: string | null;
  qpay_invoice_code: string | null;
  khanbank_account_number: string | null;
  active: boolean;
  ewa_limit_percent: number;
  ewa_max_per_month: number;
  ewa_max_per_day: number;
  ewa_fee_percent: number;
  ewa_min_amount: number;
  ewa_max_amount: number;
  frc_license_number: string | null;
  frc_license_expiry: string | null;
  aml_single_threshold: number;
  aml_daily_threshold: number;
  enabled_banks: string[];
};

function BankingPage() {
  const { org } = useAuth();
  const testQpay = useServerFn(mnQpayTest);
  const [cfg, setCfg] = useState<Config | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);

  useEffect(() => {
    if (!org?.id) return;
    setLoading(true);
    supabase
      .from("mn_payment_config" as never)
      .select("*")
      .eq("org_id", org.id)
      .maybeSingle()
      .then(({ data }) => {
        setCfg((data as Config | null) ?? {
          id: "", org_id: org.id, provider: "qpay", environment: "sandbox",
          merchant_id: "", qpay_invoice_code: "", khanbank_account_number: "",
          active: false, ewa_limit_percent: 50, ewa_max_per_month: 3, ewa_max_per_day: 1,
          ewa_fee_percent: 1.5, ewa_min_amount: 50000, ewa_max_amount: 5000000,
          frc_license_number: "", frc_license_expiry: null,
          aml_single_threshold: 5000000, aml_daily_threshold: 10000000,
          enabled_banks: ["Khan Bank", "Golomt Bank", "TDB", "XacBank", "State Bank"],
        });
        setLoading(false);
      });
  }, [org?.id]);

  const patch = <K extends keyof Config>(k: K, v: Config[K]) =>
    setCfg((c) => (c ? { ...c, [k]: v } : c));

  const save = async () => {
    if (!cfg || !org?.id) return;
    setSaving(true);
    const payload = { ...cfg, org_id: org.id };
    if (!cfg.id) delete (payload as Partial<Config>).id;
    const { error } = await supabase
      .from("mn_payment_config" as never)
      .upsert(payload as never, { onConflict: "org_id" });
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Хадгаллаа");
  };

  const runTest = async () => {
    setTesting(true);
    const r = await testQpay({});
    setTesting(false);
    if (r.ok) toast.success(`QPay sandbox OK · token ${r.token_preview}`);
    else toast.error(r.error ?? "Test failed");
  };

  if (loading || !cfg) return <div className="p-6 text-sm text-muted-foreground">Уншиж байна…</div>;

  const expiry = cfg.frc_license_expiry ? new Date(cfg.frc_license_expiry) : null;
  const daysToExpiry = expiry ? Math.ceil((expiry.getTime() - Date.now()) / 86400000) : null;
  const licenseStatus =
    daysToExpiry == null ? null
    : daysToExpiry < 0 ? { tone: "destructive", label: "Хугацаа дууссан" }
    : daysToExpiry < 60 ? { tone: "warning", label: `${daysToExpiry} хоног үлдсэн` }
    : { tone: "success", label: "Хүчинтэй" };

  return (
    <div className="p-6 max-w-3xl mx-auto space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold flex items-center gap-2">
            <Building2 className="h-5 w-5" /> Mongolian banking
          </h1>
          <p className="text-sm text-muted-foreground">
            QPay sandbox, Khan Bank, EWA параметр болон FRC лицензийн тохиргоо.
          </p>
        </div>
        <Badge variant={cfg.active ? "default" : "outline"}>
          {cfg.active ? "Идэвхтэй" : "Идэвхгүй"}
        </Badge>
      </div>

      {/* QPay */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-sm">QPay</CardTitle>
          <Button size="sm" variant="outline" onClick={runTest} disabled={testing}>
            {testing ? "Шалгаж байна…" : "Connection test"}
          </Button>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Merchant ID</Label>
              <Input value={cfg.merchant_id ?? ""} onChange={(e) => patch("merchant_id", e.target.value)} />
            </div>
            <div>
              <Label className="text-xs">Invoice code</Label>
              <Input
                value={cfg.qpay_invoice_code ?? ""}
                onChange={(e) => patch("qpay_invoice_code", e.target.value)}
                placeholder="QPAY_INVOICE_CODE"
              />
            </div>
            <div>
              <Label className="text-xs">Environment</Label>
              <select
                value={cfg.environment}
                onChange={(e) => patch("environment", e.target.value)}
                className="w-full h-9 rounded-md border bg-background px-3 text-sm"
              >
                <option value="sandbox">Sandbox</option>
                <option value="production">Production</option>
              </select>
            </div>
            <div className="flex items-end gap-2">
              <label className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={cfg.active}
                  onChange={(e) => patch("active", e.target.checked)}
                />
                Идэвхжүүлэх
              </label>
            </div>
          </div>
          <p className="text-[11px] text-muted-foreground">
            QPay username / password / invoice code нь Lovable Cloud secret-д хадгалагдсан.
          </p>
        </CardContent>
      </Card>

      {/* Khan Bank (stub) */}
      <Card>
        <CardHeader><CardTitle className="text-sm">Khan Bank (stub)</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <div>
            <Label className="text-xs">Disbursement account number</Label>
            <Input
              value={cfg.khanbank_account_number ?? ""}
              onChange={(e) => patch("khanbank_account_number", e.target.value)}
              placeholder="1234567890"
            />
          </div>
          <p className="text-[11px] text-muted-foreground">
            Khan Bank API нь mock горимд байна — KHANBANK_CLIENT_ID / SECRET нэмэгдэхэд идэвхжинэ.
          </p>
        </CardContent>
      </Card>

      {/* EWA */}
      <Card>
        <CardHeader><CardTitle className="text-sm">EWA параметр (MNT)</CardTitle></CardHeader>
        <CardContent className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          <NumField label="Дээд хувь (%)" value={cfg.ewa_limit_percent} onChange={(v) => patch("ewa_limit_percent", v)} />
          <NumField label="Сард дээд тоо" value={cfg.ewa_max_per_month} onChange={(v) => patch("ewa_max_per_month", v)} />
          <NumField label="Өдөрт дээд тоо" value={cfg.ewa_max_per_day} onChange={(v) => patch("ewa_max_per_day", v)} />
          <NumField label="Шимтгэл (%)" value={cfg.ewa_fee_percent} onChange={(v) => patch("ewa_fee_percent", v)} step={0.1} />
          <NumField label="Доод дүн" value={cfg.ewa_min_amount} onChange={(v) => patch("ewa_min_amount", v)} />
          <NumField label="Дээд дүн" value={cfg.ewa_max_amount} onChange={(v) => patch("ewa_max_amount", v)} />
        </CardContent>
      </Card>

      {/* Compliance */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-sm flex items-center gap-2">
            <ShieldCheck className="h-4 w-4" /> Compliance (FRC, AML)
          </CardTitle>
          {licenseStatus && (
            <Badge
              variant={licenseStatus.tone === "destructive" ? "destructive" : "outline"}
              className={
                licenseStatus.tone === "warning" ? "border-amber-500 text-amber-600" :
                licenseStatus.tone === "success" ? "border-emerald-500 text-emerald-600" : ""
              }
            >
              {licenseStatus.tone === "destructive" ? <AlertTriangle className="h-3 w-3 mr-1" /> :
               licenseStatus.tone === "warning" ? <AlertTriangle className="h-3 w-3 mr-1" /> :
               <CheckCircle2 className="h-3 w-3 mr-1" />}
              {licenseStatus.label}
            </Badge>
          )}
        </CardHeader>
        <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <Label className="text-xs">FRC лицензийн дугаар</Label>
            <Input
              value={cfg.frc_license_number ?? ""}
              onChange={(e) => patch("frc_license_number", e.target.value)}
            />
          </div>
          <div>
            <Label className="text-xs">Лицензийн хугацаа</Label>
            <Input
              type="date"
              value={cfg.frc_license_expiry ?? ""}
              onChange={(e) => patch("frc_license_expiry", e.target.value || null)}
            />
          </div>
          <NumField label="AML нэг гүйлгээ" value={cfg.aml_single_threshold} onChange={(v) => patch("aml_single_threshold", v)} />
          <NumField label="AML өдөр" value={cfg.aml_daily_threshold} onChange={(v) => patch("aml_daily_threshold", v)} />
        </CardContent>
      </Card>

      {/* Banks */}
      <Card>
        <CardHeader><CardTitle className="text-sm">Дэмжсэн банкууд</CardTitle></CardHeader>
        <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {ALL_BANKS.map((b) => {
            const on = cfg.enabled_banks.includes(b);
            return (
              <label key={b} className="flex items-center gap-2 text-sm border rounded-md px-3 py-2">
                <input
                  type="checkbox"
                  checked={on}
                  onChange={(e) =>
                    patch("enabled_banks",
                      e.target.checked
                        ? [...cfg.enabled_banks, b]
                        : cfg.enabled_banks.filter((x) => x !== b),
                    )
                  }
                />
                {b}
              </label>
            );
          })}
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={save} disabled={saving}>
          {saving ? "Хадгалж байна…" : "Хадгалах"}
        </Button>
      </div>
    </div>
  );
}

function NumField({
  label, value, onChange, step = 1,
}: { label: string; value: number; onChange: (n: number) => void; step?: number }) {
  return (
    <div>
      <Label className="text-xs">{label}</Label>
      <Input
        type="number"
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
      />
    </div>
  );
}
