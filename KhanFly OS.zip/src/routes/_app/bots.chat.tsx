import { createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense } from "react";
import { BotsSkeleton } from "@/components/bots/page-shell";

const BotsLiveChat = lazy(() => import("@/components/bots/live-chat"));

export const Route = createFileRoute("/_app/bots/chat")({
  component: () => (
    <Suspense fallback={<BotsSkeleton />}>
      <BotsLiveChat />
    </Suspense>
  ),
});
