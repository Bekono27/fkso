import { createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense } from "react";
import { MonitorSkeleton } from "@/components/monitor/page-shell";
const Page = lazy(() => import("@/components/monitor/pages/alerts"));
export const Route = createFileRoute("/_app/monitor/alerts")({
  component: () => <Suspense fallback={<MonitorSkeleton />}><Page /></Suspense>,
});
