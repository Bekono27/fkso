import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { AnalyticsPage } from "@/components/analytics/page-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

export const Route = createFileRoute("/_app/analytics/monitor")({
  component: () => {
    const { org } = useAuth();
    const [data, setData] = useState<any>(null);
    useEffect(() => {
      if (!org?.id) return;
      const since = new Date(Date.now() - 29 * 86400000).toISOString().split("T")[0];
      Promise.all([
        supabase.from("sentiment_scores").select("date,score,mention_count").eq("org_id", org.id).gte("date", since).order("date"),
        supabase.from("monitoring_keywords").select("id", { count: "exact", head: true }).eq("org_id", org.id).eq("is_active", true),
        supabase.from("monitoring_alerts").select("id", { count: "exact", head: true }).eq("org_id", org.id),
      ]).then(([t, k, a]) => setData({ trend: t.data ?? [], keywords: k.count ?? 0, alerts: a.count ?? 0 }));
    }, [org?.id]);

    return (
      <AnalyticsPage title="Monitor Analytics" description="Brand sentiment performance.">
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {[["Active Keywords", data?.keywords], ["Alerts", data?.alerts], ["Avg Sentiment", data?.trend?.length ? Math.round(data.trend.reduce((s: number, r: any) => s + (r.score ?? 0), 0) / data.trend.length) + "/100" : "—"]].map(([l, v]) => (
            <Card key={l as string}><CardContent className="p-4">
              <div className="text-xs uppercase text-muted-foreground">{l}</div>
              <div className="text-2xl font-semibold mt-1" style={{ color: "var(--analytics)" }}>{v ?? "—"}</div>
            </CardContent></Card>
          ))}
        </div>
        <Card>
          <CardHeader><CardTitle className="text-base">Sentiment Trend (30d)</CardTitle></CardHeader>
          <CardContent>
            {!data?.trend?.length ? <div className="text-sm text-muted-foreground p-6 text-center">No data.</div> : (
              <div className="h-72"><ResponsiveContainer width="100%" height="100%">
                <LineChart data={data.trend}><XAxis dataKey="date" fontSize={11} tickFormatter={(d) => d.slice(5)} /><YAxis domain={[0,100]} fontSize={11} /><Tooltip /><Line type="monotone" dataKey="score" stroke="var(--analytics)" strokeWidth={2} dot={false} /></LineChart>
              </ResponsiveContainer></div>
            )}
          </CardContent>
        </Card>
      </AnalyticsPage>
    );
  },
});
