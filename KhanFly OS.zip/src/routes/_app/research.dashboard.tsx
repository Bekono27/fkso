import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { ResearchPage } from "@/components/research/page-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { KpiCard } from "@/components/ui/kpi-card";
import { FolderKanban, FileText, Eye, TrendingUp, Sparkles, Users, ArrowRight } from "lucide-react";

function bucketByDay(rows: { created_at: string }[], days = 7): number[] {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const buckets = new Array(days).fill(0);
  for (const r of rows) {
    const d = new Date(r.created_at);
    d.setHours(0, 0, 0, 0);
    const diff = Math.floor((today.getTime() - d.getTime()) / 86400000);
    if (diff >= 0 && diff < days) buckets[days - 1 - diff]++;
  }
  return buckets;
}

export const Route = createFileRoute("/_app/research/dashboard")({
  component: () => {
    const { org } = useAuth();
    const [stats, setStats] = useState({ projects: 0, sections: 0, reports: 0, sources: 0, competitors: 0, keywords: 0 });
    const [sparks, setSparks] = useState<Record<string, number[]>>({});
    const [recent, setRecent] = useState<any[]>([]);
    const [recentReports, setRecentReports] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
      if (!org?.id) return;
      (async () => {
        setLoading(true);
        const since = new Date(Date.now() - 7 * 86400000).toISOString();
        const [p, s, rep, src, comp, kw, pTrend, sTrend, repTrend, srcTrend, rp, rr] = await Promise.all([
          supabase.from("research_projects").select("id", { count: "exact", head: true }).eq("org_id", org.id),
          supabase.from("research_sections").select("id", { count: "exact", head: true }).eq("org_id", org.id),
          supabase.from("research_reports").select("id", { count: "exact", head: true }).eq("org_id", org.id),
          supabase.from("research_sources").select("id", { count: "exact", head: true }).eq("org_id", org.id),
          supabase.from("monitoring_competitors").select("id", { count: "exact", head: true }).eq("org_id", org.id),
          supabase.from("monitoring_keywords").select("id", { count: "exact", head: true }).eq("org_id", org.id),
          supabase.from("research_projects").select("created_at").eq("org_id", org.id).gte("created_at", since),
          supabase.from("research_sections").select("created_at").eq("org_id", org.id).gte("created_at", since),
          supabase.from("research_reports").select("generated_at").eq("org_id", org.id).gte("generated_at", since),
          supabase.from("research_sources").select("added_at").eq("org_id", org.id).gte("added_at", since),
          supabase.from("research_projects").select("id, title, type, status, updated_at").eq("org_id", org.id).order("updated_at", { ascending: false }).limit(5),
          supabase.from("research_reports").select("id, title, type, generated_at").eq("org_id", org.id).order("generated_at", { ascending: false }).limit(5),
        ]);
        setStats({
          projects: p.count ?? 0, sections: s.count ?? 0, reports: rep.count ?? 0,
          sources: src.count ?? 0, competitors: comp.count ?? 0, keywords: kw.count ?? 0,
        });
        setSparks({
          projects: bucketByDay((pTrend.data ?? []) as any),
          sections: bucketByDay((sTrend.data ?? []) as any),
          reports: bucketByDay(((repTrend.data ?? []) as any).map((x: any) => ({ created_at: x.generated_at }))),
          sources: bucketByDay(((srcTrend.data ?? []) as any).map((x: any) => ({ created_at: x.added_at }))),
        });
        setRecent(rp.data ?? []);
        setRecentReports(rr.data ?? []);
        setLoading(false);
      })();
    }, [org?.id]);

    const accent = "var(--research)";

    return (
      <ResearchPage hero
        title="Research"
        description="AI-powered market research, competitive intelligence, and audience analytics."
        actions={
          <Button asChild size="sm" style={{ background: accent }}>
            <Link to="/research/projects"><Sparkles className="h-4 w-4 mr-1" /> New project</Link>
          </Button>
        }
      >
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 animate-page-in">
          <KpiCard label="Projects" value={stats.projects} icon={FolderKanban} href="/research/projects" accent={accent} spark={sparks.projects} loading={loading} />
          <KpiCard label="Sections" value={stats.sections} icon={Sparkles} href="/research/projects" accent={accent} spark={sparks.sections} loading={loading} />
          <KpiCard label="Reports" value={stats.reports} icon={FileText} href="/research/reports" accent={accent} spark={sparks.reports} loading={loading} />
          <KpiCard label="Sources" value={stats.sources} icon={Eye} href="/research/projects" accent={accent} spark={sparks.sources} loading={loading} />
          <KpiCard label="Competitors" value={stats.competitors} icon={Users} href="/research/intelligence" accent={accent} loading={loading} />
          <KpiCard label="Keywords" value={stats.keywords} icon={TrendingUp} href="/research/trends" accent={accent} loading={loading} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Card>
            <CardContent className="p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="font-medium text-sm">Recent projects</div>
                <Link to="/research/projects" className="text-xs text-muted-foreground hover:text-primary inline-flex items-center gap-1">
                  All <ArrowRight className="h-3 w-3" />
                </Link>
              </div>
              {recent.length === 0 ? (
                <div className="text-xs text-muted-foreground py-6 text-center">No projects yet.</div>
              ) : recent.map((p) => (
                <Link key={p.id} to="/research/projects/$id" params={{ id: p.id }}
                  className="flex items-center justify-between gap-2 border rounded-md p-2 hover:bg-muted/40 transition-colors">
                  <div className="min-w-0">
                    <div className="text-sm font-medium truncate">{p.title}</div>
                    <div className="text-[11px] text-muted-foreground capitalize">{p.type} · {new Date(p.updated_at).toLocaleDateString()}</div>
                  </div>
                  <Badge variant="outline" className="text-[10px]">{p.status}</Badge>
                </Link>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="font-medium text-sm">Recent reports</div>
                <Link to="/research/reports" className="text-xs text-muted-foreground hover:text-primary inline-flex items-center gap-1">
                  All <ArrowRight className="h-3 w-3" />
                </Link>
              </div>
              {recentReports.length === 0 ? (
                <div className="text-xs text-muted-foreground py-6 text-center">No reports yet.</div>
              ) : recentReports.map((r) => (
                <div key={r.id} className="flex items-center justify-between gap-2 border rounded-md p-2">
                  <div className="min-w-0">
                    <div className="text-sm font-medium truncate">{r.title}</div>
                    <div className="text-[11px] text-muted-foreground capitalize">{r.type} · {new Date(r.generated_at).toLocaleDateString()}</div>
                  </div>
                  <FileText className="h-4 w-4 text-muted-foreground" />
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </ResearchPage>
    );
  },
});
