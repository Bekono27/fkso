import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { AnalyticsPage } from "@/components/analytics/page-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

export const Route = createFileRoute("/_app/analytics/workforce")({
  component: () => {
    const { org } = useAuth();
    const [data, setData] = useState<any>(null);
    useEffect(() => {
      if (!org?.id) return;
      Promise.all([
        supabase.from("employees").select("position,is_active").eq("org_id", org.id),
        supabase.from("payroll_records").select("net_pay,status").eq("org_id", org.id),
        supabase.from("leave_requests").select("status").eq("org_id", org.id),
      ]).then(([emp, pay, lv]) => {
        const depts: Record<string, number> = {};
        (emp.data ?? []).forEach((e: any) => {
          if (e.is_active) depts[e.position ?? "Unassigned"] = (depts[e.position ?? "Unassigned"] ?? 0) + 1;
        });
        const totalPay = (pay.data ?? []).reduce((s: number, r: any) => s + Number(r.net_pay ?? 0), 0);
        const pendingLeave = (lv.data ?? []).filter((l: any) => l.status === "pending").length;
        setData({
          deptChart: Object.entries(depts).map(([name, value]) => ({ name, value })),
          totalPay, pendingLeave,
          headcount: (emp.data ?? []).filter((e: any) => e.is_active).length,
        });
      });
    }, [org?.id]);

    return (
      <AnalyticsPage title="Workforce Analytics" description="Headcount, payroll, and leave insights.">
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {[["Headcount", data?.headcount], ["Pending Leave", data?.pendingLeave], ["Total Payroll", data ? `$${data.totalPay.toLocaleString()}` : "—"]].map(([l, v]) => (
            <Card key={l as string}><CardContent className="p-4">
              <div className="text-xs uppercase text-muted-foreground">{l}</div>
              <div className="text-2xl font-semibold mt-1" style={{ color: "var(--analytics)" }}>{v ?? "—"}</div>
            </CardContent></Card>
          ))}
        </div>
        <Card>
          <CardHeader><CardTitle className="text-base">Headcount by Department</CardTitle></CardHeader>
          <CardContent>
            {!data?.deptChart?.length ? <div className="text-sm text-muted-foreground p-6 text-center">No data.</div> : (
              <div className="h-72"><ResponsiveContainer width="100%" height="100%">
                <BarChart data={data.deptChart}><XAxis dataKey="name" fontSize={11} /><YAxis fontSize={11} /><Tooltip /><Bar dataKey="value" fill="var(--analytics)" /></BarChart>
              </ResponsiveContainer></div>
            )}
          </CardContent>
        </Card>
      </AnalyticsPage>
    );
  },
});
