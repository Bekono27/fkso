import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { EwaPage, MNT } from "@/components/ewa/page-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/_app/ewa/employees")({ component: EmployeesPage });

function EmployeesPage() {
  const { org } = useAuth();
  const [rows, setRows] = useState<any[] | null>(null);
  const [q, setQ] = useState("");

  useEffect(() => {
    if (!org?.id) return;
    (async () => {
      const [{ data: emps }, { data: accs }, { data: txns }] = await Promise.all([
        supabase.from("employees").select("id, full_name, email, department:departments(name)").eq("org_id", org.id).eq("is_active", true).order("full_name").limit(500),
        supabase.from("mn_bank_accounts" as never).select("entity_id, bank_name, verified, account_last4").eq("org_id", org.id).eq("entity_type", "employee"),
        supabase.from("ulu_transactions" as never).select("employee_id, amount, status").eq("org_id", org.id),
      ]);
      const accBy: Record<string, any> = {};
      ((accs as any[]) ?? []).forEach((a) => { accBy[a.entity_id] = a; });
      const sumBy: Record<string, number> = {};
      const cntBy: Record<string, number> = {};
      ((txns as any[]) ?? []).forEach((t) => {
        if (!t.employee_id || t.status !== "completed") return;
        sumBy[t.employee_id] = (sumBy[t.employee_id] ?? 0) + Number(t.amount);
        cntBy[t.employee_id] = (cntBy[t.employee_id] ?? 0) + 1;
      });
      setRows((emps ?? []).map((e: any) => ({
        ...e,
        account: accBy[e.id],
        advanceTotal: sumBy[e.id] ?? 0,
        advanceCount: cntBy[e.id] ?? 0,
      })));
    })();
  }, [org?.id]);

  const filtered = (rows ?? []).filter((r) => !q || r.full_name?.toLowerCase().includes(q.toLowerCase()));

  return (
    <EwaPage
      title="Ажилчид"
      description="EWA эрх, банкны данс, түүх"
      actions={<Input placeholder="Хайх…" value={q} onChange={(e) => setQ(e.target.value)} className="h-9 w-56" />}
    >
      <Card>
        <CardContent className="p-0">
          {rows === null ? (
            <div className="p-8 text-center text-sm text-muted-foreground">Уншиж байна…</div>
          ) : filtered.length === 0 ? (
            <div className="p-10 text-center text-sm text-muted-foreground">Ажилтан олдсонгүй.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/40 text-xs uppercase tracking-wider text-muted-foreground">
                  <tr>
                    <th className="text-left px-4 py-2.5 font-medium">Нэр</th>
                    <th className="text-left px-4 py-2.5 font-medium">Хэлтэс</th>
                    <th className="text-left px-4 py-2.5 font-medium">Банк</th>
                    <th className="text-right px-4 py-2.5 font-medium">Урьдчилгаа</th>
                    <th className="text-right px-4 py-2.5 font-medium">Нийт дүн</th>
                    <th className="text-right px-4 py-2.5 font-medium"></th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {filtered.map((r) => (
                    <tr key={r.id} className="hover:bg-muted/20">
                      <td className="px-4 py-2.5">
                        <div className="font-medium">{r.full_name}</div>
                        <div className="text-xs text-muted-foreground">{r.email}</div>
                      </td>
                      <td className="px-4 py-2.5 text-muted-foreground">{r.department?.name ?? "—"}</td>
                      <td className="px-4 py-2.5">
                        {r.account ? (
                          <div className="flex items-center gap-2">
                            <span>{r.account.bank_name} ••{r.account.account_last4}</span>
                            {r.account.verified
                              ? <Badge variant="outline" className="border-emerald-500 text-emerald-600">verified</Badge>
                              : <Badge variant="outline" className="border-amber-500 text-amber-600">pending KYC</Badge>}
                          </div>
                        ) : <span className="text-muted-foreground">—</span>}
                      </td>
                      <td className="px-4 py-2.5 text-right">{r.advanceCount}</td>
                      <td className="px-4 py-2.5 text-right font-medium">{MNT(r.advanceTotal)}</td>
                      <td className="px-4 py-2.5 text-right">
                        <Link to="/ewa/bank-accounts" className="text-xs underline text-muted-foreground hover:text-foreground">
                          Данс
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </EwaPage>
  );
}
