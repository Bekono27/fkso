import { createFileRoute } from "@tanstack/react-router";
import { BotsList } from "@/components/bots/list";
import { PlatformIcon, timeAgo } from "@/components/bots/page-shell";
import { QuickCreate } from "@/components/quick-create";

export const Route = createFileRoute("/_app/bots/contacts")({
  component: () => (
    <BotsList
      title="Contacts"
      description="People who've messaged your bots."
      table="bot_contacts"
      actions={
        <QuickCreate
          table="bot_contacts"
          title="Add contact"
          buttonLabel="Add contact"
          buttonStyle={{ background: "var(--bots)", color: "white" }}
          fields={[
            { key: "name", label: "Name" },
            { key: "phone", label: "Phone" },
            { key: "email", label: "Email", type: "email" },
            { key: "username", label: "Username" },
          ]}
          defaults={{ platform: "telegram" }}
        />
      }
      columns={[
        { key: "platform", label: "", render: (r) => <PlatformIcon platform={r.platform} /> },
        { key: "name", label: "Name", render: (r) => (
          <span className="font-medium">{r.name ?? r.username ?? r.phone ?? "Unknown"}</span>
        )},
        { key: "phone", label: "Phone", render: (r) => <span className="text-xs">{r.phone ?? "—"}</span> },
        { key: "email", label: "Email", render: (r) => <span className="text-xs">{r.email ?? "—"}</span> },
        { key: "lead_captured", label: "Lead", render: (r) => r.lead_captured ? "🎯 Lead" : "—" },
        { key: "conversation_count", label: "Convos", render: (r) => <span className="text-xs">{r.conversation_count ?? 0}</span> },
        { key: "last_seen_at", label: "Last seen", render: (r) => (
          <span className="text-xs text-muted-foreground">{timeAgo(r.last_seen_at ?? r.created_at)}</span>
        )},
      ]}
      emptyMessage="No contacts yet."
    />
  ),
});
