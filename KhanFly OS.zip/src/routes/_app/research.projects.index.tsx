import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { ResearchPage } from "@/components/research/page-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Plus, FolderKanban } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/research/projects/")({
  component: () => {
    const { org, user } = useAuth();
    const [rows, setRows] = useState<any[]>([]);
    const [open, setOpen] = useState(false);
    const [title, setTitle] = useState("");
    const [type, setType] = useState("market");

    const load = () => {
      if (!org?.id) return;
      supabase.from("research_projects").select("*").eq("org_id", org.id).order("created_at", { ascending: false })
        .then(({ data }) => setRows(data ?? []));
    };
    useEffect(load, [org?.id]);

    const create = async () => {
      if (!title.trim() || !org?.id) return;
      const { error } = await supabase.from("research_projects").insert({ org_id: org.id, title, type, created_by: user?.id });
      if (error) return toast.error(error.message);
      toast.success("Project created");
      setOpen(false); setTitle(""); load();
    };

    return (
      <ResearchPage title="Projects" description="Custom research projects with sections and sources." actions={
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button size="sm" style={{ background: "var(--research)" }}><Plus className="h-4 w-4 mr-1" /> New Project</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>New Research Project</DialogTitle></DialogHeader>
            <Input placeholder="Project title" value={title} onChange={(e) => setTitle(e.target.value)} />
            <select className="h-9 px-2 border rounded-md bg-background text-sm" value={type} onChange={(e) => setType(e.target.value)}>
              <option value="market">Market Research</option>
              <option value="competitive">Competitive</option>
              <option value="audience">Audience</option>
              <option value="trend">Trend Analysis</option>
              <option value="custom">Custom</option>
            </select>
            <DialogFooter><Button onClick={create}>Create</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      }>
        {rows.length === 0 ? (
          <Card><CardContent className="p-10 text-center text-sm text-muted-foreground">
            <FolderKanban className="h-8 w-8 mx-auto mb-2 opacity-50" />
            No research projects yet. Create one to start gathering insights.
          </CardContent></Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {rows.map((p) => (
              <Link key={p.id} to="/research/projects/$id" params={{ id: p.id }} className="block">
                <Card className="hover:shadow-md transition-shadow cursor-pointer h-full">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div className="font-medium">{p.title}</div>
                      <Badge variant="outline" className="text-xs">{p.status}</Badge>
                    </div>
                    <div className="text-xs text-muted-foreground capitalize">{p.type}</div>
                    <div className="text-xs text-muted-foreground mt-2">{new Date(p.created_at).toLocaleDateString()}</div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </ResearchPage>
    );
  },
});
