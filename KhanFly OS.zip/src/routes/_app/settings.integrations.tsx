import { createFileRoute } from "@tanstack/react-router";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ExternalLink, KeyRound } from "lucide-react";

export const Route = createFileRoute("/_app/settings/integrations")({ component: IntegrationsPage });

const INTEGRATIONS = [
  {
    key: "telegram",
    name: "Telegram",
    description: "Send broadcasts and run bots from your Telegram account.",
    secret: "TELEGRAM_BOT_TOKEN",
    docsUrl: "https://core.telegram.org/bots#how-do-i-create-a-bot",
  },
  {
    key: "facebook",
    name: "Facebook / Messenger",
    description: "Read page mentions and reply via Messenger.",
    secret: "FACEBOOK_PAGE_ACCESS_TOKEN",
    docsUrl: "https://developers.facebook.com/docs/messenger-platform",
  },
  {
    key: "instagram",
    name: "Instagram",
    description: "Schedule and publish posts to Instagram business accounts.",
    secret: "INSTAGRAM_ACCESS_TOKEN",
    docsUrl: "https://developers.facebook.com/docs/instagram-api",
  },
  {
    key: "whatsapp",
    name: "WhatsApp Business",
    description: "Run bots and broadcasts on WhatsApp.",
    secret: "WHATSAPP_API_TOKEN",
    docsUrl: "https://developers.facebook.com/docs/whatsapp",
  },
  {
    key: "ai",
    name: "Lovable AI Gateway",
    description: "Powers the assistant, sentiment analysis and AI bot nodes.",
    secret: "LOVABLE_API_KEY",
    docsUrl: null,
    builtIn: true,
  },
];

function IntegrationsPage() {
  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Integrations</h1>
        <p className="text-sm text-muted-foreground">Connect external platforms to power bots, monitoring and content.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {INTEGRATIONS.map((it) => (
          <Card key={it.key}>
            <CardHeader className="flex flex-row items-start justify-between space-y-0">
              <div>
                <CardTitle className="text-base">{it.name}</CardTitle>
                <p className="text-xs text-muted-foreground mt-1">{it.description}</p>
              </div>
              {it.builtIn ? (
                <Badge>Active</Badge>
              ) : (
                <Badge variant="outline">Setup required</Badge>
              )}
            </CardHeader>
            <CardContent className="flex items-center justify-between gap-2">
              <code className="text-xs px-2 py-1 rounded bg-muted text-muted-foreground flex items-center gap-1.5">
                <KeyRound className="h-3 w-3" />
                {it.secret}
              </code>
              {it.docsUrl && (
                <Button asChild variant="outline" size="sm">
                  <a href={it.docsUrl} target="_blank" rel="noreferrer" className="flex items-center gap-1.5">
                    Docs <ExternalLink className="h-3 w-3" />
                  </a>
                </Button>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader><CardTitle className="text-sm">How to add a key</CardTitle></CardHeader>
        <CardContent className="text-sm space-y-2 text-muted-foreground">
          <p>Ask the assistant in chat: <em>"Add the {`{secret name}`} secret"</em>.</p>
          <p>It opens a secure form so the value never appears in code or in your messages.</p>
        </CardContent>
      </Card>
    </div>
  );
}
