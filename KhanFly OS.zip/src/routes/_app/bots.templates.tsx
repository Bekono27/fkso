import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { BotsPage, BotsSkeleton } from "@/components/bots/page-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sparkles } from "lucide-react";
import { toast } from "sonner";
import { writeEvent, indexEntity } from "@/lib/bots";

export const Route = createFileRoute("/_app/bots/templates")({ component: TemplatesPage });

function TemplatesPage() {
  const { org, user } = useAuth();
  const navigate = useNavigate();
  const [rows, setRows] = useState<any[] | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  useEffect(() => {
    if (!org?.id) return;
    supabase.from("bot_templates").select("*, bot_template_categories(name)")
      .eq("org_id", org.id).order("created_at", { ascending: true })
      .then(({ data }) => setRows(data ?? []));
  }, [org?.id]);

  const useTemplate = async (t: any) => {
    if (!org?.id) return;
    setBusy(t.id);
    const { data: bot, error } = await supabase.from("bots").insert({
      org_id: org.id, name: t.name, description: t.description, emoji: "🤖", status: "draft",
      created_by: user?.id,
    } as any).select().single();
    setBusy(null);
    if (error || !bot) return toast.error(error?.message ?? "Failed");
    await supabase.from("bot_templates").update({ use_count: (t.use_count ?? 0) + 1 } as any).eq("id", t.id);
    await writeEvent(org.id, "bots", "bot_created_from_template", { bot_id: bot.id, template_id: t.id }, user?.id);
    await indexEntity({
      org_id: org.id, module: "bots", entity_type: "bot", entity_id: bot.id,
      title: bot.name, subtitle: bot.description ?? "Bot", keywords: `bot ${bot.name} template`,
      url: `/bots/builder/${bot.id}`,
    });
    toast.success(`Created "${bot.name}" from template`);
    navigate({ to: "/bots/builder/$id", params: { id: bot.id } });
  };

  if (rows === null) return <BotsSkeleton />;

  return (
    <BotsPage title="Bot Templates" description="Pre-built starting points — click to clone into a new bot.">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {rows.length === 0 ? (
          <Card className="md:col-span-3"><CardContent className="p-10 text-center text-sm text-muted-foreground">
            No templates available.
          </CardContent></Card>
        ) : rows.map((t) => (
          <Card key={t.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-5 space-y-3">
              <div className="flex items-start gap-3">
                <div className="rounded-lg p-2" style={{ background: "color-mix(in oklab, var(--bots) 14%, transparent)", color: "var(--bots)" }}>
                  <Sparkles className="h-5 w-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-semibold">{t.name}</div>
                  {t.bot_template_categories?.name && (
                    <div className="text-xs text-muted-foreground mt-0.5">{t.bot_template_categories.name}</div>
                  )}
                </div>
              </div>
              <p className="text-sm text-muted-foreground line-clamp-2 min-h-[2.5em]">{t.description ?? "—"}</p>
              <div className="flex items-center justify-between pt-2">
                <span className="text-xs text-muted-foreground">Used {t.use_count ?? 0}×</span>
                <Button size="sm" disabled={busy === t.id} onClick={() => useTemplate(t)}
                  style={{ background: "var(--bots)", color: "white" }}>
                  {busy === t.id ? "Creating…" : "Use template"}
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </BotsPage>
  );
}
