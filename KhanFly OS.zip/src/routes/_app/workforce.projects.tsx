import { createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense } from "react";
import { PageSkeleton } from "@/components/workforce/page-shell";
const Page = lazy(() => import("@/components/workforce/pages/projects"));
export const Route = createFileRoute("/_app/workforce/projects")({
  component: () => <Suspense fallback={<PageSkeleton />}><Page /></Suspense>,
});
