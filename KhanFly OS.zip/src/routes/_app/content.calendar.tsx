import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { ContentPage, ContentSkeleton } from "@/components/content/page-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { QuickCreate } from "@/components/quick-create";

const PLATFORM_COLOR: Record<string, string> = {
  instagram: "#e1306c", facebook: "#1877f2", twitter: "#1da1f2",
  linkedin: "#0a66c2", tiktok: "#000000", youtube: "#ff0000",
};

const STATUS_COLOR: Record<string, string> = {
  draft: "#71717a", scheduled: "var(--content)", published: "#16a34a",
  review: "#f59e0b", approved: "#16a34a", failed: "#dc2626",
};

function CalendarPage() {
  const { org } = useAuth();
  const [posts, setPosts] = useState<any[] | null>(null);
  const [cursor, setCursor] = useState(() => {
    const d = new Date(); d.setDate(1); return d;
  });
  const [reload, setReload] = useState(0);

  useEffect(() => {
    if (!org?.id) return;
    const start = new Date(cursor); start.setDate(1);
    const end = new Date(cursor); end.setMonth(end.getMonth() + 1); end.setDate(0);
    end.setHours(23, 59, 59, 999);
    supabase.from("smm_posts").select("*").eq("org_id", org.id)
      .gte("scheduled_at", start.toISOString())
      .lte("scheduled_at", end.toISOString())
      .order("scheduled_at", { ascending: true })
      .then(({ data }) => setPosts(data ?? []));
  }, [org?.id, cursor, reload]);

  const grid = useMemo(() => {
    const first = new Date(cursor); first.setDate(1);
    const startWeekday = (first.getDay() + 6) % 7; // Monday-first
    const daysInMonth = new Date(first.getFullYear(), first.getMonth() + 1, 0).getDate();
    const cells: { date: Date | null }[] = [];
    for (let i = 0; i < startWeekday; i++) cells.push({ date: null });
    for (let d = 1; d <= daysInMonth; d++) cells.push({ date: new Date(first.getFullYear(), first.getMonth(), d) });
    while (cells.length % 7 !== 0) cells.push({ date: null });
    return cells;
  }, [cursor]);

  const postsByDay: Record<string, any[]> = {};
  (posts ?? []).forEach((p) => {
    if (!p.scheduled_at) return;
    const k = new Date(p.scheduled_at).toDateString();
    (postsByDay[k] ||= []).push(p);
  });

  const monthLabel = cursor.toLocaleString(undefined, { month: "long", year: "numeric" });
  const today = new Date().toDateString();

  if (posts === null) return <ContentSkeleton />;

  return (
    <ContentPage
      title="Content Calendar"
      description={`${posts.length} posts in ${monthLabel}`}
      actions={
        <div className="flex items-center gap-2">
          <Button size="sm" variant="outline" onClick={() => { const d = new Date(cursor); d.setMonth(d.getMonth() - 1); setCursor(d); }}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button size="sm" variant="outline" onClick={() => { const d = new Date(); d.setDate(1); setCursor(d); }}>Today</Button>
          <Button size="sm" variant="outline" onClick={() => { const d = new Date(cursor); d.setMonth(d.getMonth() + 1); setCursor(d); }}>
            <ChevronRight className="h-4 w-4" />
          </Button>
          <QuickCreate
            table="smm_posts"
            title="Schedule post"
            buttonLabel="Schedule post"
            buttonStyle={{ background: "var(--content)", color: "white" }}
            fields={[
              { key: "title", label: "Title", required: true },
              { key: "caption", label: "Caption", type: "textarea" },
              { key: "platform", label: "Platform", placeholder: "instagram, facebook, twitter…", required: true },
              { key: "scheduled_at", label: "Scheduled at (ISO)", placeholder: "2026-05-12T14:00", required: true },
            ]}
            defaults={{ status: "scheduled" }}
            onCreated={() => setReload((k) => k + 1)}
          />
        </div>
      }
    >
      <Card>
        <CardContent className="p-3">
          <div className="grid grid-cols-7 text-xs uppercase tracking-wider text-muted-foreground mb-1">
            {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((d) => (
              <div key={d} className="px-2 py-1.5">{d}</div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-1">
            {grid.map((cell, i) => {
              if (!cell.date) return <div key={i} className="min-h-[110px] rounded-md bg-muted/20" />;
              const key = cell.date.toDateString();
              const dayPosts = postsByDay[key] ?? [];
              const isToday = key === today;
              return (
                <div
                  key={i}
                  className={`min-h-[110px] rounded-md border p-1.5 flex flex-col gap-1 ${isToday ? "ring-2" : ""}`}
                  style={isToday ? { borderColor: "var(--content)", boxShadow: "inset 0 0 0 1px var(--content)" } : {}}
                >
                  <div className="flex justify-between items-center">
                    <span className={`text-xs font-medium ${isToday ? "" : "text-muted-foreground"}`} style={isToday ? { color: "var(--content)" } : {}}>
                      {cell.date.getDate()}
                    </span>
                    {dayPosts.length > 0 && <span className="text-[10px] text-muted-foreground">{dayPosts.length}</span>}
                  </div>
                  <div className="flex-1 space-y-1 overflow-hidden">
                    {dayPosts.slice(0, 3).map((p) => (
                      <div
                        key={p.id}
                        title={`${p.platform} · ${p.status}\n${p.title ?? p.caption ?? ""}`}
                        className="text-[11px] leading-tight px-1.5 py-1 rounded truncate"
                        style={{
                          background: `color-mix(in oklab, ${PLATFORM_COLOR[p.platform] ?? "var(--content)"} 15%, transparent)`,
                          borderLeft: `2px solid ${STATUS_COLOR[p.status] ?? "var(--content)"}`,
                        }}
                      >
                        {new Date(p.scheduled_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })} · {p.title ?? (p.caption?.slice(0, 28) ?? "Untitled")}
                      </div>
                    ))}
                    {dayPosts.length > 3 && (
                      <div className="text-[10px] text-muted-foreground px-1.5">+{dayPosts.length - 3} more</div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
        <span className="font-medium">Status:</span>
        {Object.entries(STATUS_COLOR).map(([k, c]) => (
          <span key={k} className="flex items-center gap-1 capitalize">
            <span className="h-2 w-3" style={{ background: c, borderRadius: 1 }} /> {k}
          </span>
        ))}
      </div>
    </ContentPage>
  );
}

export const Route = createFileRoute("/_app/content/calendar")({
  component: CalendarPage,
});
