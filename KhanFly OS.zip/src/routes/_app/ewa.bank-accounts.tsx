import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { mnKycVerify } from "@/lib/digilend.functions";
import { EwaPage } from "@/components/ewa/page-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { ShieldCheck, Plus, Trash2 } from "lucide-react";

const BANKS = ["Khan Bank","Golomt Bank","TDB","XacBank","State Bank","Bogd Bank","MobiFinance","Other"];

export const Route = createFileRoute("/_app/ewa/bank-accounts")({ component: BankAccountsPage });

function BankAccountsPage() {
  const { org } = useAuth();
  const kyc = useServerFn(mnKycVerify);
  const [employees, setEmployees] = useState<any[]>([]);
  const [accounts, setAccounts] = useState<any[]>([]);
  const [reload, setReload] = useState(0);

  const [form, setForm] = useState({ entity_id: "", bank_name: "Khan Bank", account_number: "", account_name: "" });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!org?.id) return;
    Promise.all([
      supabase.from("employees").select("id, full_name").eq("org_id", org.id).eq("is_active", true).order("full_name").limit(500),
      supabase.from("mn_bank_accounts" as never).select("*").eq("org_id", org.id).order("created_at", { ascending: false }),
    ]).then(([emps, accs]) => {
      setEmployees(emps.data ?? []);
      setAccounts((accs.data as any[]) ?? []);
    });
  }, [org?.id, reload]);

  const empName = (id: string) => employees.find((e) => e.id === id)?.full_name ?? "—";

  const addAccount = async () => {
    if (!org?.id || !form.entity_id || !form.account_number || !form.account_name) {
      toast.error("Ажилтан, данс, нэр шаардлагатай"); return;
    }
    setSaving(true);
    const { error } = await supabase.from("mn_bank_accounts" as never).insert({
      org_id: org.id,
      entity_type: "employee",
      entity_id: form.entity_id,
      bank_name: form.bank_name,
      account_number: form.account_number,
      account_name: form.account_name,
      is_primary: true,
    } as never);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Данс нэмэгдлээ");
    setForm({ entity_id: "", bank_name: "Khan Bank", account_number: "", account_name: "" });
    setReload((k) => k + 1);
  };

  const verify = async (id: string, name: string) => {
    try {
      const r = await kyc({ data: { bankAccountId: id, expectedName: name } });
      toast.success(`Verified (${r.mode}): ${r.verified_name}`);
      setReload((k) => k + 1);
    } catch (e) { toast.error((e as Error).message); }
  };

  const remove = async (id: string) => {
    if (!confirm("Устгах уу?")) return;
    const { error } = await supabase.from("mn_bank_accounts" as never).delete().eq("id", id);
    if (error) return toast.error(error.message);
    setReload((k) => k + 1);
  };

  return (
    <EwaPage title="Банкны данс" description="Ажилчдын данс бүртгэх, KYC шалгах">
      <div className="grid lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-1">
          <CardHeader><CardTitle className="text-sm flex items-center gap-2"><Plus className="h-4 w-4" /> Шинэ данс</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <div>
              <Label className="text-xs">Ажилтан</Label>
              <select value={form.entity_id}
                      onChange={(e) => setForm({ ...form, entity_id: e.target.value })}
                      className="w-full h-9 rounded-md border bg-background px-3 text-sm">
                <option value="">— Сонгох —</option>
                {employees.map((e) => <option key={e.id} value={e.id}>{e.full_name}</option>)}
              </select>
            </div>
            <div>
              <Label className="text-xs">Банк</Label>
              <select value={form.bank_name}
                      onChange={(e) => setForm({ ...form, bank_name: e.target.value })}
                      className="w-full h-9 rounded-md border bg-background px-3 text-sm">
                {BANKS.map((b) => <option key={b} value={b}>{b}</option>)}
              </select>
            </div>
            <div>
              <Label className="text-xs">Дансны дугаар</Label>
              <Input value={form.account_number} onChange={(e) => setForm({ ...form, account_number: e.target.value })} />
            </div>
            <div>
              <Label className="text-xs">Дансны эзэмшигчийн нэр</Label>
              <Input value={form.account_name} onChange={(e) => setForm({ ...form, account_name: e.target.value })} />
            </div>
            <Button onClick={addAccount} disabled={saving} className="w-full" style={{ background: "var(--digilend)" }}>
              {saving ? "Хадгалж байна…" : "Нэмэх"}
            </Button>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader><CardTitle className="text-sm">Бүртгэлтэй данс ({accounts.length})</CardTitle></CardHeader>
          <CardContent className="p-0">
            {accounts.length === 0 ? (
              <div className="p-10 text-center text-sm text-muted-foreground">Данс бүртгэлгүй.</div>
            ) : (
              <div className="divide-y">
                {accounts.map((a) => (
                  <div key={a.id} className="px-4 py-3 flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <div className="font-medium text-sm">{empName(a.entity_id)}</div>
                      <div className="text-xs text-muted-foreground">
                        {a.bank_name} · ••{a.account_last4} · {a.account_name ?? "—"}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {a.verified ? (
                        <Badge variant="outline" className="border-emerald-500 text-emerald-600">
                          <ShieldCheck className="h-3 w-3 mr-1" /> verified
                        </Badge>
                      ) : (
                        <Button size="sm" variant="outline" onClick={() => verify(a.id, a.account_name ?? empName(a.entity_id))}>
                          <ShieldCheck className="h-3.5 w-3.5 mr-1.5" /> KYC
                        </Button>
                      )}
                      <Button size="icon" variant="ghost" onClick={() => remove(a.id)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </EwaPage>
  );
}
