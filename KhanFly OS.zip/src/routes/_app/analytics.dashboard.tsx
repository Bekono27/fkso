import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { AnalyticsPage } from "@/components/analytics/page-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TrendingUp, Users, Radio, Bot, Calendar, AlertCircle, Sparkles, Loader2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/analytics/dashboard")({
  component: Dashboard,
});

function Dashboard() {
  const { org } = useAuth();
  const [kpis, setKpis] = useState<any>(null);
  const [insights, setInsights] = useState<any[]>([]);
  const [busy, setBusy] = useState(false);

  const loadInsights = async () => {
    if (!org?.id) return;
    const { data } = await supabase.from("analytics_insights").select("*")
      .eq("org_id", org.id).eq("dismissed", false)
      .order("created_at", { ascending: false }).limit(8);
    setInsights(data ?? []);
  };

  useEffect(() => {
    if (!org?.id) return;
    Promise.all([
      supabase.from("employees").select("id", { count: "exact", head: true }).eq("org_id", org.id).eq("is_active", true),
      supabase.from("monitoring_posts").select("id", { count: "exact", head: true }).eq("org_id", org.id).gte("created_at", new Date(Date.now() - 7 * 86400000).toISOString()),
      supabase.from("smm_posts").select("id", { count: "exact", head: true }).eq("org_id", org.id),
      supabase.from("bot_conversations").select("id", { count: "exact", head: true }).eq("org_id", org.id),
    ]).then(([emp, mon, con, bot]) => {
      setKpis({ employees: emp.count ?? 0, mentions: mon.count ?? 0, posts: con.count ?? 0, conversations: bot.count ?? 0 });
    });
    loadInsights();
  }, [org?.id]);

  const generateInsights = async () => {
    setBusy(true);
    try {
      const { data, error } = await supabase.functions.invoke("analytics-insights", { body: {} });
      if (error) throw error;
      toast.success(`Generated ${data?.inserted ?? 0} insights`);
      await loadInsights();
    } catch (e: any) {
      toast.error(e?.message ?? "Failed");
    } finally {
      setBusy(false);
    }
  };

  const tiles = [
    { label: "Active Employees", value: kpis?.employees, icon: Users, color: "var(--workforce)" },
    { label: "Mentions (7d)", value: kpis?.mentions, icon: Radio, color: "var(--monitor)" },
    { label: "Content Posts", value: kpis?.posts, icon: Calendar, color: "var(--content)" },
    { label: "Bot Conversations", value: kpis?.conversations, icon: Bot, color: "var(--bots)" },
  ];

  return (
    <AnalyticsPage hero title="Unified BI" description="Cross-module insights across all your platforms.">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {tiles.map((t) => (
          <Card key={t.label}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="text-xs uppercase tracking-wider text-muted-foreground">{t.label}</div>
                <t.icon className="h-4 w-4" style={{ color: t.color }} />
              </div>
              <div className="text-2xl font-semibold mt-2" style={{ color: t.color }}>
                {t.value ?? "—"}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2"><TrendingUp className="h-4 w-4" /> AI Insights</CardTitle>
          <Button size="sm" onClick={generateInsights} disabled={busy} style={{ background: "var(--analytics)" }}>
            {busy ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Sparkles className="h-4 w-4 mr-1" />}
            Generate insights
          </Button>
        </CardHeader>
        <CardContent>
          {insights.length === 0 ? (
            <div className="text-sm text-muted-foreground p-6 text-center">
              No insights yet. The analytics-insights engine will surface cross-module correlations as data accumulates.
            </div>
          ) : (
            <div className="space-y-3">
              {insights.map((i) => (
                <div key={i.id} className="flex items-start gap-3 p-3 rounded-lg border">
                  <AlertCircle className="h-4 w-4 mt-0.5" style={{ color: i.severity === "critical" ? "#dc2626" : i.severity === "warning" ? "#f59e0b" : "var(--analytics)" }} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="font-medium text-sm">{i.title}</div>
                      <Badge variant="outline" className="text-xs">{i.severity}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{i.description}</p>
                    {i.modules_involved?.length > 0 && (
                      <div className="flex gap-1 mt-2">
                        {i.modules_involved.map((m: string) => (
                          <Badge key={m} variant="secondary" className="text-xs">{m}</Badge>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </AnalyticsPage>
  );
}
