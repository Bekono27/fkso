import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { ContentPage, ContentSkeleton, ContentStatusPill } from "@/components/content/page-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { toast } from "sonner";
import { writeEvent, indexEntity } from "@/lib/content";

export const Route = createFileRoute("/_app/content/posts")({ component: PostsKanban });

const COLS = [
  { key: "draft",     label: "Draft" },
  { key: "review",    label: "In Review" },
  { key: "approved",  label: "Approved" },
  { key: "scheduled", label: "Scheduled" },
  { key: "published", label: "Published" },
];

function PostsKanban() {
  const { org, user } = useAuth();
  const [rows, setRows] = useState<any[] | null>(null);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ title: "", caption: "", platform: "instagram", scheduled_at: "" });

  const load = async () => {
    if (!org?.id) return;
    const { data } = await supabase.from("smm_posts").select("*").eq("org_id", org.id)
      .order("scheduled_at", { ascending: true, nullsFirst: false });
    setRows(data ?? []);
  };
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [org?.id]);

  const advance = async (post: any) => {
    const idx = COLS.findIndex((c) => c.key === post.status);
    const next = COLS[idx + 1];
    if (!next) return;
    const upd: any = { status: next.key };
    if (next.key === "published") upd.published_at = new Date().toISOString();
    const { error } = await supabase.from("smm_posts").update(upd).eq("id", post.id);
    if (error) return toast.error(error.message);
    toast.success(`Moved to ${next.label}`);
    load();
  };

  const create = async () => {
    if (!org?.id || !form.caption.trim()) return;
    const { data, error } = await supabase.from("smm_posts").insert({
      org_id: org.id, title: form.title || null, caption: form.caption,
      platform: form.platform as any, status: "draft" as any,
      scheduled_at: form.scheduled_at || null, created_by: user?.id,
    } as any).select().single();
    if (error || !data) return toast.error(error?.message ?? "Failed");
    await writeEvent(org.id, "content", "post_created", { post_id: data.id, platform: data.platform }, user?.id);
    await indexEntity({
      org_id: org.id, module: "content", entity_type: "post", entity_id: data.id,
      title: data.title || (data.caption ?? "Untitled").slice(0, 60), subtitle: `${data.platform} · ${data.status}`,
      keywords: `${data.platform} ${data.status}`, url: "/content/posts",
    });
    toast.success("Post created");
    setOpen(false);
    setForm({ title: "", caption: "", platform: "instagram", scheduled_at: "" });
    load();
  };

  if (rows === null) return <ContentSkeleton />;

  return (
    <ContentPage
      title="Content Board"
      description={`${rows.length} post${rows.length === 1 ? "" : "s"} across all stages`}
      actions={
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm" style={{ background: "var(--content)", color: "white" }}>+ New post</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Create post</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div><Label>Title (optional)</Label>
                <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
              </div>
              <div><Label>Caption *</Label>
                <Textarea rows={4} value={form.caption} onChange={(e) => setForm({ ...form, caption: e.target.value })} />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div><Label>Platform</Label>
                  <Select value={form.platform} onValueChange={(v) => setForm({ ...form, platform: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="instagram">Instagram</SelectItem>
                      <SelectItem value="facebook">Facebook</SelectItem>
                      <SelectItem value="tiktok">TikTok</SelectItem>
                      <SelectItem value="linkedin">LinkedIn</SelectItem>
                      <SelectItem value="twitter">Twitter / X</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div><Label>Schedule for</Label>
                  <Input type="datetime-local" value={form.scheduled_at}
                    onChange={(e) => setForm({ ...form, scheduled_at: e.target.value })} />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button onClick={create} disabled={!form.caption.trim()}>Create</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      }
    >
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-3">
        {COLS.map((col) => {
          const items = rows.filter((r) => r.status === col.key);
          return (
            <div key={col.key} className="space-y-2">
              <div className="flex items-center justify-between px-1">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{col.label}</h3>
                <span className="text-xs text-muted-foreground">{items.length}</span>
              </div>
              <div className="space-y-2 min-h-[120px]">
                {items.length === 0 ? (
                  <div className="text-xs text-muted-foreground italic px-2 py-3 text-center border border-dashed rounded">empty</div>
                ) : items.map((p) => (
                  <Card key={p.id}>
                    <CardContent className="p-3 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs uppercase text-muted-foreground">{p.platform}</span>
                        <ContentStatusPill value={p.status} />
                      </div>
                      <div className="text-sm font-medium line-clamp-1">{p.title || "Untitled"}</div>
                      <div className="text-xs text-muted-foreground line-clamp-2">{p.caption}</div>
                      {p.scheduled_at && (
                        <div className="text-[11px] text-muted-foreground">📅 {new Date(p.scheduled_at).toLocaleString()}</div>
                      )}
                      {col.key !== "published" && (
                        <Button size="sm" variant="ghost" className="w-full h-7 text-xs" onClick={() => advance(p)}>
                          Move to {COLS[COLS.findIndex((c) => c.key === col.key) + 1]?.label} →
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </ContentPage>
  );
}
