import { createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense } from "react";
import { PageSkeleton } from "@/components/workforce/page-shell";

const Dashboard = lazy(() => import("@/components/workforce/dashboard"));

export const Route = createFileRoute("/_app/workforce/dashboard")({
  component: () => (
    <Suspense fallback={<PageSkeleton />}>
      <Dashboard />
    </Suspense>
  ),
});
