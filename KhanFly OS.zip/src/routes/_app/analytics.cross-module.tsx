import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { AnalyticsPage } from "@/components/analytics/page-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/_app/analytics/cross-module")({
  component: () => {
    const { org } = useAuth();
    const [insights, setInsights] = useState<any[]>([]);
    useEffect(() => {
      if (!org?.id) return;
      supabase.from("analytics_insights").select("*").eq("org_id", org.id).order("created_at", { ascending: false }).limit(50)
        .then(({ data }) => setInsights(data ?? []));
    }, [org?.id]);

    return (
      <AnalyticsPage title="Cross-module Insights" description="Correlations and patterns detected across modules.">
        <Card>
          <CardHeader><CardTitle className="text-base">All Insights</CardTitle></CardHeader>
          <CardContent>
            {insights.length === 0 ? (
              <div className="text-sm text-muted-foreground p-6 text-center">No insights yet. The AI insights engine will populate this view as it detects patterns.</div>
            ) : (
              <div className="space-y-2">
                {insights.map((i) => (
                  <div key={i.id} className="p-3 border rounded-lg">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium text-sm">{i.title}</span>
                      <Badge variant="outline" className="text-xs">{i.severity}</Badge>
                      {i.dismissed && <Badge variant="secondary" className="text-xs">dismissed</Badge>}
                    </div>
                    <p className="text-sm text-muted-foreground">{i.description}</p>
                    <div className="flex gap-1 mt-2">
                      {(i.modules_involved ?? []).map((m: string) => <Badge key={m} variant="secondary" className="text-xs">{m}</Badge>)}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </AnalyticsPage>
    );
  },
});
