import { useEffect, useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useAuth } from "@/lib/auth-context";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MODULES } from "@/lib/modules";
import { supabase } from "@/integrations/supabase/client";
import { getWorkforceSummary } from "@/lib/workforce";
import { getMonitorSummary } from "@/lib/monitor";
import { getContentSummary } from "@/lib/content";
import { getBotsSummary } from "@/lib/bots";
import { KpiCard } from "@/components/ui/kpi-card";
import { ArrowRight } from "lucide-react";

export const Route = createFileRoute("/_app/dashboard")({ component: DashboardPage });

function relTime(iso: string) {
  const d = (Date.now() - new Date(iso).getTime()) / 1000;
  if (d < 60) return `${Math.floor(d)}s ago`;
  if (d < 3600) return `${Math.floor(d / 60)}m ago`;
  if (d < 86400) return `${Math.floor(d / 3600)}h ago`;
  return `${Math.floor(d / 86400)}d ago`;
}

function fakeSpark(seed: number) {
  return Array.from({ length: 14 }, (_, i) => 40 + Math.sin((i + seed) * 0.7) * 14 + i * 1.6);
}

function DashboardPage() {
  const { profile, org } = useAuth();
  const orgId = org?.id;
  const [wf, setWf] = useState<any>(null);
  const [mon, setMon] = useState<any>(null);
  const [con, setCon] = useState<any>(null);
  const [bot, setBot] = useState<any>(null);
  const [events, setEvents] = useState<any[]>([]);

  useEffect(() => {
    if (!orgId) return;
    getWorkforceSummary(orgId).then(setWf).catch(() => {});
    getMonitorSummary(orgId).then(setMon).catch(() => {});
    getContentSummary(orgId).then(setCon).catch(() => {});
    getBotsSummary(orgId).then(setBot).catch(() => {});

    supabase.from("platform_events").select("*").eq("org_id", orgId)
      .order("created_at", { ascending: false }).limit(20)
      .then(({ data }) => setEvents(data ?? []));

    const ch = supabase.channel(`exec-${orgId}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "platform_events", filter: `org_id=eq.${orgId}` },
        (p) => setEvents((prev) => [p.new, ...prev].slice(0, 20)))
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [orgId]);

  const now = useMemo(() => new Date(), []);
  const greeting = now.getHours() < 12 ? "Good morning" : now.getHours() < 18 ? "Good afternoon" : "Good evening";
  const dateStr = now.toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" });

  const STAT_GROUPS: { module: typeof MODULES[number]; stats: { label: string; value: any; hint?: string; delta?: number }[] }[] = [
    { module: MODULES[0], stats: [
      { label: "Active today", value: wf?.present_today ?? "—", hint: wf ? `${wf.total_employees} total` : undefined, delta: 4 },
      { label: "Pending leave", value: wf?.pending_leave_requests ?? "—", delta: -8 },
      { label: "Open tickets", value: wf?.open_helpdesk_tickets ?? "—", delta: 2 },
    ]},
    { module: MODULES[1], stats: [
      { label: "Brand sentiment", value: mon ? `${mon.brand_score_today ?? "—"}` : "—", hint: mon ? `${mon.score_change >= 0 ? "+" : ""}${mon.score_change} vs yesterday` : undefined, delta: mon?.score_change },
      { label: "Active alerts", value: mon?.active_alerts_total ?? "—", hint: mon ? `${mon.critical_alerts} critical` : undefined, delta: 12 },
      { label: "Mentions today", value: mon?.mentions_today ?? "—", delta: 6 },
    ]},
    { module: MODULES[2], stats: [
      { label: "Active clients", value: con?.active_clients ?? "—", hint: con ? `MRR $${Number(con.monthly_recurring_revenue).toLocaleString()}` : undefined, delta: 3 },
      { label: "Awaiting approval", value: con?.awaiting_approval ?? "—", delta: -5 },
      { label: "Unpaid invoices", value: con?.unpaid_invoices ?? "—", hint: con ? `$${Number(con.unpaid_total).toLocaleString()}` : undefined, delta: -2 },
    ]},
    { module: MODULES[3], stats: [
      { label: "Active bots", value: bot?.active_bots ?? "—", delta: 0 },
      { label: "Conversations today", value: bot?.conversations_today ?? "—", delta: 18 },
      { label: "AI resolution", value: bot ? `${bot.ai_resolution_rate}%` : "—", delta: 7 },
    ]},
  ];

  const moduleSettings = (org as any)?.settings?.modules ?? {};
  const visibleGroups = STAT_GROUPS.filter((g) => moduleSettings[g.module.key] !== false);

  return (
    <div className="p-4 sm:p-6 md:p-8 max-w-7xl mx-auto space-y-6 sm:space-y-8 animate-page-in">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl border surface-radial p-5 sm:p-6 md:p-8">
        <div aria-hidden className="absolute inset-0 surface-grid opacity-40 pointer-events-none" />
        <div className="relative flex flex-col md:flex-row md:items-end md:justify-between gap-4">
          <div className="min-w-0">
            <div className="text-[10px] sm:text-[11px] uppercase tracking-[0.16em] sm:tracking-[0.18em] text-muted-foreground font-medium flex items-center gap-2">
              <span className="live-dot" /> <span className="truncate">{dateStr}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-semibold tracking-tight mt-2 break-words">
              {greeting}, {profile?.full_name?.split(" ")[0] ?? "there"}.
            </h1>
            <p className="text-sm text-muted-foreground mt-1.5 max-w-lg">
              Executive overview across all of <span className="text-foreground font-medium">{org?.name ?? "your workspace"}</span>. {visibleGroups.length} modules active.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            {visibleGroups.slice(0, 4).map((g) => (
              <Link key={g.module.key} to={g.module.basePath}
                className="px-3 py-1.5 rounded-full text-[11px] font-medium ring-1 ring-border bg-card/60 backdrop-blur-sm hover:scale-[1.03] transition-transform inline-flex items-center gap-1.5"
                style={{ color: `var(--${g.module.accent})` }}>
                <span className="h-1.5 w-1.5 rounded-full" style={{ background: `var(--${g.module.accent})` }} />
                {g.module.label}
              </Link>
            ))}
          </div>
        </div>
      </div>

      {/* Module sections */}
      <div className="space-y-7">
        {visibleGroups.map(({ module, stats }, gi) => {
          const Icon = module.icon;
          return (
            <section key={module.key}>
              <div className="flex items-center gap-2.5 mb-3">
                <span className="h-8 w-8 rounded-lg flex items-center justify-center ring-1 ring-border"
                  style={{ background: `color-mix(in oklab, var(--${module.accent}) 14%, transparent)`, color: `var(--${module.accent})` }}>
                  <Icon className="h-4 w-4" />
                </span>
                <div>
                  <h2 className="text-sm font-semibold tracking-tight">{module.label}</h2>
                  <div className="text-[11px] text-muted-foreground">{module.origin}</div>
                </div>
                <Link to={module.basePath} className="ml-auto group text-xs text-muted-foreground hover:text-foreground inline-flex items-center gap-1 transition-colors">
                  Open module <ArrowRight className="h-3 w-3 transition-transform group-hover:translate-x-0.5" />
                </Link>
              </div>
              <div className="grid gap-3 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
                {stats.map((s, i) => (
                  <KpiCard
                    key={s.label}
                    label={s.label}
                    value={s.value}
                    accent={`var(--${module.accent})`}
                    delta={s.delta}
                    spark={fakeSpark(gi * 3 + i)}
                  />
                ))}
              </div>
            </section>
          );
        })}
      </div>

      {/* Activity */}
      <Card className="overflow-hidden">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 border-b py-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <span className="live-dot" /> Live activity
          </CardTitle>
          <span className="text-[11px] text-muted-foreground">Realtime</span>
        </CardHeader>
        <CardContent className="p-0">
          {events.length === 0 ? (
            <div className="p-10 text-center text-sm text-muted-foreground">
              <div className="mx-auto h-10 w-10 rounded-full border border-dashed flex items-center justify-center mb-3">
                <span className="h-2 w-2 rounded-full bg-muted-foreground/40" />
              </div>
              Waiting for the first platform event…
            </div>
          ) : (
            <ul className="divide-y">
              {events.map((e) => {
                const mod = MODULES.find((m) => m.key === e.source_module);
                return (
                  <li key={e.id} className="px-4 py-2.5 flex items-center gap-3 text-sm hover:bg-accent/40 transition-colors">
                    {mod ? (
                      <span className="text-[10px] uppercase font-medium px-2 py-0.5 rounded-md tracking-wide"
                        style={{ background: `color-mix(in oklab, var(--${mod.accent}) 14%, transparent)`, color: `var(--${mod.accent})` }}>
                        {mod.label}
                      </span>
                    ) : (
                      <span className="text-[10px] uppercase font-medium px-2 py-0.5 rounded-md bg-muted text-muted-foreground">system</span>
                    )}
                    <span className="font-mono text-xs text-foreground/80">{e.event_type}</span>
                    <span className="text-xs text-muted-foreground ml-auto tabular-nums">{relTime(e.created_at)}</span>
                  </li>
                );
              })}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
