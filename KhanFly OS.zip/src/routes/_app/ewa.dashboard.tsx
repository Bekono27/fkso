import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { EwaPage, MNT, STATUS_TONE } from "@/components/ewa/page-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { PlusCircle, Wallet, Clock, CheckCircle2, AlertTriangle, Settings } from "lucide-react";

export const Route = createFileRoute("/_app/ewa/dashboard")({ component: Dashboard });

function Dashboard() {
  const { org } = useAuth();
  const [stats, setStats] = useState({ pending: 0, completed: 0, flagged: 0, volumeMonth: 0 });
  const [recent, setRecent] = useState<any[]>([]);
  const [hasConfig, setHasConfig] = useState<boolean | null>(null);

  useEffect(() => {
    if (!org?.id) return;
    const monthStart = new Date(); monthStart.setDate(1); monthStart.setHours(0,0,0,0);

    Promise.all([
      supabase.from("ulu_transactions" as never).select("status, amount, requested_at").eq("org_id", org.id),
      supabase.from("ulu_transactions" as never).select("*").eq("org_id", org.id).order("requested_at", { ascending: false }).limit(8),
      supabase.from("mn_payment_config" as never).select("id").eq("org_id", org.id).maybeSingle(),
    ]).then(([all, rec, cfg]) => {
      const rows = (all.data as any[]) ?? [];
      setStats({
        pending: rows.filter(r => r.status === "pending" || r.status === "approved").length,
        completed: rows.filter(r => r.status === "completed").length,
        flagged: rows.filter(r => r.status === "flagged").length,
        volumeMonth: rows
          .filter(r => new Date(r.requested_at) >= monthStart && r.status === "completed")
          .reduce((s, r) => s + Number(r.amount), 0),
      });
      setRecent((rec.data as any[]) ?? []);
      setHasConfig(!!cfg.data);
    });
  }, [org?.id]);

  return (
    <EwaPage
      title="EWA System"
      description="Цалингийн урьдчилгаа (EWA) удирдлага · QPay + Khan Bank"
      actions={
        <>
          <Button asChild variant="outline" size="sm">
            <Link to="/settings/banking"><Settings className="h-4 w-4 mr-1.5" /> Тохиргоо</Link>
          </Button>
          <Button asChild size="sm" style={{ background: "var(--digilend)" }}>
            <Link to="/ewa/request"><PlusCircle className="h-4 w-4 mr-1.5" /> Шинэ урьдчилгаа</Link>
          </Button>
        </>
      }
    >
      {hasConfig === false && (
        <Card className="border-amber-300/50 bg-amber-50/50 dark:bg-amber-950/20">
          <CardContent className="p-4 flex items-start gap-3">
            <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5" />
            <div className="flex-1">
              <div className="font-medium text-sm">Банкны тохиргоо хийгдээгүй байна</div>
              <div className="text-xs text-muted-foreground mt-1">
                QPay болон EWA параметрүүдийг тохируулна уу.
              </div>
            </div>
            <Button asChild size="sm" variant="outline"><Link to="/settings/banking">Тохируулах</Link></Button>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <Kpi icon={<Clock className="h-4 w-4" />} label="Хүлээгдэж буй" value={stats.pending} />
        <Kpi icon={<CheckCircle2 className="h-4 w-4" />} label="Амжилттай" value={stats.completed} />
        <Kpi icon={<AlertTriangle className="h-4 w-4" />} label="Шалгах шаардлагатай" value={stats.flagged} tone="#f97316" />
        <Kpi icon={<Wallet className="h-4 w-4" />} label="Энэ сарын дүн" value={MNT(stats.volumeMonth)} />
      </div>

      <Card>
        <CardHeader><CardTitle className="text-sm">Сүүлийн гүйлгээ</CardTitle></CardHeader>
        <CardContent className="p-0">
          {recent.length === 0 ? (
            <div className="p-8 text-center text-sm text-muted-foreground">Гүйлгээ алга байна.</div>
          ) : (
            <div className="divide-y">
              {recent.map((r) => (
                <Link
                  key={r.id}
                  to="/ewa/transactions"
                  className="flex items-center justify-between px-4 py-3 hover:bg-muted/30"
                >
                  <div className="min-w-0">
                    <div className="text-sm font-medium">{MNT(r.amount)} <span className="text-muted-foreground font-normal">+ шимтгэл {MNT(r.fee)}</span></div>
                    <div className="text-xs text-muted-foreground truncate">{r.description ?? "Цалингийн урьдчилгаа"} · {new Date(r.requested_at).toLocaleString("mn-MN")}</div>
                  </div>
                  <Badge variant="outline" style={{ color: STATUS_TONE[r.status], borderColor: STATUS_TONE[r.status] }}>{r.status}</Badge>
                </Link>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </EwaPage>
  );
}

function Kpi({ icon, label, value, tone }: { icon: React.ReactNode; label: string; value: React.ReactNode; tone?: string }) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span style={{ color: tone ?? "var(--digilend)" }}>{icon}</span>
          {label}
        </div>
        <div className="text-2xl font-semibold mt-1" style={{ color: tone ?? "var(--foreground)" }}>{value}</div>
      </CardContent>
    </Card>
  );
}
