import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { ResearchPage } from "@/components/research/page-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { ArrowLeft, Plus, Sparkles, Trash2, ArrowUp, ArrowDown, Link as LinkIcon, Save, FileText, RefreshCw, Loader2 } from "lucide-react";
import { toast } from "sonner";

type Project = { id: string; org_id: string; title: string; type: string; status: string; created_at: string };
type Section = { id: string; title: string; content: string; order_index: number; metadata?: { citations?: string[] } | null };
type Source = { id: string; type: string; url: string | null; content_summary: string | null; added_at: string };

export const Route = createFileRoute("/_app/research/projects/$id")({
  component: ProjectDetail,
});

function ProjectDetail() {
  const { id } = Route.useParams();
  const { org } = useAuth();
  const navigate = useNavigate();
  const [project, setProject] = useState<Project | null>(null);
  const [sections, setSections] = useState<Section[]>([]);
  const [sources, setSources] = useState<Source[]>([]);
  const [loading, setLoading] = useState(true);
  const [genOpen, setGenOpen] = useState(false);
  const [genPrompt, setGenPrompt] = useState("");
  const [generating, setGenerating] = useState(false);
  const [pickedSrc, setPickedSrc] = useState<Record<string, boolean>>({});
  const [regenId, setRegenId] = useState<string | null>(null);
  const [srcOpen, setSrcOpen] = useState(false);
  const [srcType, setSrcType] = useState("url");
  const [srcUrl, setSrcUrl] = useState("");
  const [srcSummary, setSrcSummary] = useState("");

  const sourceMap = useMemo(() => Object.fromEntries(sources.map((s) => [s.id, s])), [sources]);

  const load = async () => {
    if (!org?.id) return;
    setLoading(true);
    const [{ data: p }, { data: sec }, { data: src }] = await Promise.all([
      supabase.from("research_projects").select("*").eq("id", id).eq("org_id", org.id).maybeSingle(),
      supabase.from("research_sections").select("*").eq("project_id", id).order("order_index"),
      supabase.from("research_sources").select("*").eq("project_id", id).order("added_at", { ascending: false }),
    ]);
    setProject(p as Project | null);
    setSections((sec as Section[]) ?? []);
    setSources((src as Source[]) ?? []);
    setLoading(false);
  };
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [org?.id, id]);

  // Default: all sources picked
  useEffect(() => {
    setPickedSrc((prev) => {
      const next: Record<string, boolean> = {};
      for (const s of sources) next[s.id] = prev[s.id] ?? true;
      return next;
    });
  }, [sources]);

  const addSection = async () => {
    if (!project) return;
    const order = (sections.at(-1)?.order_index ?? -1) + 1;
    const { data, error } = await supabase.from("research_sections").insert({
      project_id: project.id, org_id: project.org_id, title: "New section", content: "", order_index: order,
    }).select("*").single();
    if (error) return toast.error(error.message);
    setSections((s) => [...s, data as Section]);
  };

  const updateSection = (s: Section, patch: Partial<Section>) => {
    setSections((prev) => prev.map((x) => x.id === s.id ? { ...x, ...patch } : x));
  };
  const saveSection = async (s: Section) => {
    const { error } = await supabase.from("research_sections")
      .update({ title: s.title, content: s.content }).eq("id", s.id);
    if (error) return toast.error(error.message);
  };
  const deleteSection = async (s: Section) => {
    const { error } = await supabase.from("research_sections").delete().eq("id", s.id);
    if (error) return toast.error(error.message);
    setSections((prev) => prev.filter((x) => x.id !== s.id));
  };
  const moveSection = async (s: Section, dir: -1 | 1) => {
    const idx = sections.findIndex((x) => x.id === s.id);
    const swap = sections[idx + dir];
    if (!swap) return;
    const a = { ...s, order_index: swap.order_index };
    const b = { ...swap, order_index: s.order_index };
    const next = [...sections];
    next[idx] = b; next[idx + dir] = a;
    next.sort((x, y) => x.order_index - y.order_index);
    setSections(next);
    await Promise.all([
      supabase.from("research_sections").update({ order_index: a.order_index }).eq("id", a.id),
      supabase.from("research_sections").update({ order_index: b.order_index }).eq("id", b.id),
    ]);
  };

  const regenerateSection = async (s: Section, focus?: string) => {
    if (!project) return;
    setRegenId(s.id);
    try {
      const source_ids = Object.entries(pickedSrc).filter(([, v]) => v).map(([k]) => k);
      const { data, error } = await supabase.functions.invoke("research-generate", {
        body: { project_id: project.id, regenerate_section_id: s.id, prompt: focus, source_ids },
      });
      if (error) throw error;
      const updated = data?.section as Section;
      if (updated) setSections((prev) => prev.map((x) => x.id === s.id ? updated : x));
      toast.success("Section regenerated");
    } catch (e: any) {
      toast.error(e?.message ?? "Regeneration failed");
    } finally {
      setRegenId(null);
    }
  };

  const addSource = async () => {
    if (!project) return;
    if (!srcUrl.trim() && !srcSummary.trim()) return toast.error("URL or summary required");
    const { data, error } = await supabase.from("research_sources").insert({
      project_id: project.id, org_id: project.org_id, type: srcType,
      url: srcUrl.trim() || null, content_summary: srcSummary.trim() || null,
    }).select("*").single();
    if (error) return toast.error(error.message);
    setSources((s) => [data as Source, ...s]);
    setSrcOpen(false); setSrcUrl(""); setSrcSummary("");
  };
  const deleteSource = async (sid: string) => {
    const { error } = await supabase.from("research_sources").delete().eq("id", sid);
    if (error) return toast.error(error.message);
    setSources((s) => s.filter((x) => x.id !== sid));
  };

  const generateAI = async () => {
    if (!project || !genPrompt.trim()) return;
    setGenerating(true);
    try {
      const source_ids = Object.entries(pickedSrc).filter(([, v]) => v).map(([k]) => k);
      const { data, error } = await supabase.functions.invoke("research-generate", {
        body: { project_id: project.id, prompt: genPrompt, source_ids },
      });
      if (error) throw error;
      const created = (data?.sections ?? []) as Section[];
      setSections((prev) => [...prev, ...created]);
      toast.success(`Generated ${created.length} sections`);
      setGenOpen(false); setGenPrompt("");
    } catch (e: any) {
      toast.error(e?.message ?? "Generation failed");
    } finally {
      setGenerating(false);
    }
  };

  const saveAsReport = async () => {
    if (!project) return;
    const content = sections.map((s) => `# ${s.title}\n\n${s.content}`).join("\n\n");
    const { error } = await supabase.from("research_reports").insert({
      org_id: project.org_id, type: project.type, title: project.title, content,
      params: { project_id: project.id },
    });
    if (error) return toast.error(error.message);
    toast.success("Saved as report");
    navigate({ to: "/research/reports" });
  };

  const pickedCount = Object.values(pickedSrc).filter(Boolean).length;

  if (loading) return <ResearchPage title="Loading…"><div /></ResearchPage>;
  if (!project) return <ResearchPage title="Not found"><div className="text-sm text-muted-foreground">Project not found.</div></ResearchPage>;

  return (
    <ResearchPage
      title={project.title}
      description={`${project.type} · ${sections.length} sections · ${sources.length} sources`}
      actions={
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" asChild>
            <Link to="/research/projects"><ArrowLeft className="h-4 w-4 mr-1" /> Back</Link>
          </Button>
          <Button variant="outline" size="sm" onClick={saveAsReport} disabled={!sections.length}>
            <FileText className="h-4 w-4 mr-1" /> Save as Report
          </Button>
          <Dialog open={genOpen} onOpenChange={setGenOpen}>
            <DialogTrigger asChild>
              <Button size="sm" style={{ background: "var(--research)" }}>
                <Sparkles className="h-4 w-4 mr-1" /> Generate with AI
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Generate research sections</DialogTitle></DialogHeader>
              <div className="text-xs text-muted-foreground">
                Describe the focus. {pickedCount} of {sources.length} source{sources.length === 1 ? "" : "s"} selected as context.
              </div>
              <Textarea
                rows={6}
                placeholder="e.g. Analyze the European B2B SaaS HR-tech market for SMB customers in 2025…"
                value={genPrompt}
                onChange={(e) => setGenPrompt(e.target.value)}
              />
              <DialogFooter>
                <Button onClick={generateAI} disabled={generating || !genPrompt.trim()}>
                  {generating ? <><Loader2 className="h-4 w-4 mr-1 animate-spin" />Generating…</> : "Generate"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      }
    >
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-4">
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Badge variant="outline">{project.status}</Badge>
              <span className="text-xs text-muted-foreground">{new Date(project.created_at).toLocaleDateString()}</span>
            </div>
            <Button size="sm" variant="outline" onClick={addSection}><Plus className="h-4 w-4 mr-1" /> Add section</Button>
          </div>

          {sections.length === 0 ? (
            <Card><CardContent className="p-10 text-center text-sm text-muted-foreground">
              <Sparkles className="h-8 w-8 mx-auto mb-2 opacity-50" />
              No sections yet. Generate with AI or add one manually.
            </CardContent></Card>
          ) : sections.map((s, i) => {
            const cites = (s.metadata?.citations ?? []).map((cid) => sourceMap[cid]).filter(Boolean) as Source[];
            return (
              <Card key={s.id}>
                <CardContent className="p-4 space-y-2">
                  <div className="flex items-center gap-2">
                    <Input value={s.title} onChange={(e) => updateSection(s, { title: e.target.value })} className="font-medium" />
                    <Button size="icon" variant="ghost" disabled={i === 0} onClick={() => moveSection(s, -1)}><ArrowUp className="h-4 w-4" /></Button>
                    <Button size="icon" variant="ghost" disabled={i === sections.length - 1} onClick={() => moveSection(s, 1)}><ArrowDown className="h-4 w-4" /></Button>
                    <Button size="icon" variant="ghost" title="Regenerate with AI" disabled={regenId === s.id} onClick={() => regenerateSection(s)}>
                      {regenId === s.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
                    </Button>
                    <Button size="icon" variant="ghost" onClick={() => saveSection(s)}><Save className="h-4 w-4" /></Button>
                    <Button size="icon" variant="ghost" onClick={() => deleteSection(s)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                  </div>
                  <Textarea
                    rows={Math.max(6, Math.min(20, (s.content.match(/\n/g)?.length ?? 4) + 3))}
                    value={s.content}
                    onChange={(e) => updateSection(s, { content: e.target.value })}
                    onBlur={() => saveSection(s)}
                    placeholder="Write or paste markdown content…"
                    className="font-mono text-sm"
                  />
                  {cites.length > 0 && (
                    <div className="flex flex-wrap gap-1 pt-1">
                      <span className="text-[10px] uppercase tracking-wide text-muted-foreground mr-1 self-center">Sources:</span>
                      {cites.map((c) => (
                        <a
                          key={c.id}
                          href={c.url ?? "#"}
                          target="_blank"
                          rel="noreferrer"
                          className="text-[10px] px-1.5 py-0.5 rounded-full border border-sky-500/40 text-sky-700 dark:text-sky-300 hover:bg-sky-500/10 inline-flex items-center gap-1 max-w-[200px] truncate"
                        >
                          <LinkIcon className="h-2.5 w-2.5 shrink-0" />
                          <span className="truncate">{c.url ?? c.content_summary?.slice(0, 28) ?? c.type}</span>
                        </a>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        <aside className="space-y-3">
          <Card>
            <CardContent className="p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="font-medium text-sm">Sources ({pickedCount}/{sources.length})</div>
                <Dialog open={srcOpen} onOpenChange={setSrcOpen}>
                  <DialogTrigger asChild><Button size="sm" variant="outline"><Plus className="h-4 w-4 mr-1" /> Add</Button></DialogTrigger>
                  <DialogContent>
                    <DialogHeader><DialogTitle>Add source</DialogTitle></DialogHeader>
                    <select className="h-9 px-2 border rounded-md bg-background text-sm" value={srcType} onChange={(e) => setSrcType(e.target.value)}>
                      <option value="url">URL</option>
                      <option value="article">Article</option>
                      <option value="report">Report</option>
                      <option value="note">Note</option>
                    </select>
                    <Input placeholder="URL (optional)" value={srcUrl} onChange={(e) => setSrcUrl(e.target.value)} />
                    <Textarea rows={4} placeholder="Summary or notes" value={srcSummary} onChange={(e) => setSrcSummary(e.target.value)} />
                    <DialogFooter><Button onClick={addSource}>Add source</Button></DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
              <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
                Check sources to include as AI context
              </div>
              {sources.length === 0 ? (
                <div className="text-xs text-muted-foreground">No sources yet.</div>
              ) : sources.map((s) => (
                <div key={s.id} className="border rounded-md p-2 text-xs space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <Checkbox
                        checked={!!pickedSrc[s.id]}
                        onCheckedChange={(v) => setPickedSrc((m) => ({ ...m, [s.id]: !!v }))}
                      />
                      <Badge variant="outline" className="text-[10px]">{s.type}</Badge>
                    </div>
                    <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => deleteSource(s.id)}>
                      <Trash2 className="h-3 w-3 text-destructive" />
                    </Button>
                  </div>
                  {s.url && (
                    <a href={s.url} target="_blank" rel="noreferrer" className="flex items-center gap-1 text-primary hover:underline truncate">
                      <LinkIcon className="h-3 w-3 shrink-0" /> <span className="truncate">{s.url}</span>
                    </a>
                  )}
                  {s.content_summary && <div className="text-muted-foreground line-clamp-3">{s.content_summary}</div>}
                </div>
              ))}
            </CardContent>
          </Card>
        </aside>
      </div>
    </ResearchPage>
  );
}
