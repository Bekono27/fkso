import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { ResearchPage } from "@/components/research/page-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export const Route = createFileRoute("/_app/research/trends")({
  component: () => {
    const { org } = useAuth();
    const [keywords, setKeywords] = useState<any[]>([]);
    useEffect(() => {
      if (!org?.id) return;
      supabase.from("monitoring_keywords").select("*").eq("org_id", org.id).order("mention_count_total", { ascending: false }).limit(30)
        .then(({ data }) => setKeywords(data ?? []));
    }, [org?.id]);

    const max = keywords[0]?.mention_count_total ?? 1;

    return (
      <ResearchPage title="Trends" description="Keyword volume and emerging topics.">
        <Card>
          <CardHeader><CardTitle className="text-base">Top Keywords</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {keywords.length === 0 ? <div className="text-sm text-muted-foreground p-6 text-center">No keyword data.</div> :
              keywords.map((k) => (
                <div key={k.id}>
                  <div className="flex justify-between text-sm">
                    <span className="font-medium">{k.term}</span>
                    <span className="text-muted-foreground">{k.mention_count_total ?? 0}</span>
                  </div>
                  <div className="h-1.5 bg-muted rounded-full overflow-hidden mt-1">
                    <div className="h-full rounded-full" style={{ width: `${Math.round(((k.mention_count_total ?? 0) / max) * 100)}%`, background: "var(--research)" }} />
                  </div>
                </div>
              ))}
          </CardContent>
        </Card>
      </ResearchPage>
    );
  },
});
