import { createFileRoute, Link, Outlet, useLocation } from "@tanstack/react-router";
import { User, Users, Plug, ToggleRight, CreditCard, Building2 } from "lucide-react";

export const Route = createFileRoute("/_app/settings")({ component: SettingsLayout });

const NAV = [
  { to: "/settings", label: "Overview", Icon: User, exact: true },
  { to: "/settings/team", label: "Team", Icon: Users },
  { to: "/settings/integrations", label: "Integrations", Icon: Plug },
  { to: "/settings/modules", label: "Modules", Icon: ToggleRight },
  { to: "/settings/banking", label: "Banking (MN)", Icon: Building2 },
  { to: "/settings/billing", label: "Billing", Icon: CreditCard },
];

function SettingsLayout() {
  const { pathname } = useLocation();
  return (
    <div className="flex flex-col md:flex-row min-h-[calc(100vh-3.5rem)]">
      <aside className="w-full md:w-56 shrink-0 border-b md:border-b-0 md:border-r p-4 space-y-1">
        <div className="px-2 pb-2">
          <h2 className="text-sm font-semibold">Settings</h2>
        </div>
        {NAV.map(({ to, label, Icon, exact }) => {
          const active = exact ? pathname === to : pathname === to || pathname.startsWith(to + "/");
          return (
            <Link
              key={to}
              to={to}
              className={`flex items-center gap-2 rounded-md px-2 py-1.5 text-sm transition-colors ${
                active ? "bg-accent font-medium" : "hover:bg-accent/50 text-muted-foreground"
              }`}
            >
              <Icon className="h-4 w-4" />
              <span>{label}</span>
            </Link>
          );
        })}
      </aside>
      <main className="flex-1 min-w-0">
        <Outlet />
      </main>
    </div>
  );
}
