import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/_app/research/")({
  beforeLoad: () => { throw redirect({ to: "/research/dashboard" }); },
});
