import { createFileRoute } from "@tanstack/react-router";
import { BotsList } from "@/components/bots/list";
import { StatusPill, PlatformIcon, timeAgo } from "@/components/bots/page-shell";
import { QuickCreate } from "@/components/quick-create";

export const Route = createFileRoute("/_app/bots/broadcasts")({
  component: () => (
    <BotsList
      title="Broadcasts"
      description="One-to-many message campaigns."
      table="bot_broadcasts"
      actions={
        <QuickCreate
          table="bot_broadcasts"
          title="New broadcast"
          buttonLabel="New broadcast"
          buttonStyle={{ background: "var(--bots)", color: "white" }}
          fields={[
            { key: "name", label: "Campaign name", required: true },
            { key: "message", label: "Message", type: "textarea", required: true },
            { key: "scheduled_at", label: "Send at (ISO)", placeholder: "2026-05-15T10:00" },
          ]}
          defaults={{ status: "draft", platform: "telegram" }}
        />
      }
      columns={[
        { key: "name", label: "Name", render: (r) => <span className="font-medium">{r.name}</span> },
        { key: "platform", label: "", render: (r) => <PlatformIcon platform={r.platform} /> },
        { key: "status", label: "Status", render: (r) => <StatusPill value={r.status} /> },
        { key: "recipient_count", label: "Recipients", render: (r) => <span className="text-xs">{r.recipient_count ?? 0}</span> },
        { key: "delivered_count", label: "Delivered", render: (r) => <span className="text-xs">{r.delivered_count ?? 0}</span> },
        { key: "scheduled_at", label: "Scheduled", render: (r) => (
          <span className="text-xs text-muted-foreground">{r.scheduled_at ? new Date(r.scheduled_at).toLocaleString() : "—"}</span>
        )},
        { key: "created_at", label: "Created", render: (r) => <span className="text-xs text-muted-foreground">{timeAgo(r.created_at)}</span> },
      ]}
      emptyMessage="No broadcasts yet."
    />
  ),
});
