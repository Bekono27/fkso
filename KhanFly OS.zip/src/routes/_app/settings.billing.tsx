import { createFileRoute } from "@tanstack/react-router";
import { useAuth } from "@/lib/auth-context";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";

export const Route = createFileRoute("/_app/settings/billing")({ component: BillingPage });

const PLANS = [
  { key: "free", name: "Free", price: "$0", features: ["Up to 3 members", "1 bot", "100 mentions/mo"] },
  { key: "pro", name: "Pro", price: "$49/mo", features: ["Up to 25 members", "Unlimited bots", "10k mentions/mo", "AI assistant"] },
  { key: "business", name: "Business", price: "$199/mo", features: ["Unlimited members", "Priority support", "100k mentions/mo", "Custom integrations"] },
];

function BillingPage() {
  const { org } = useAuth();
  const current = org?.plan ?? "free";

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Billing</h1>
        <p className="text-sm text-muted-foreground">Your current plan: <Badge className="ml-1 capitalize">{current}</Badge></p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {PLANS.map((p) => {
          const active = p.key === current;
          return (
            <Card key={p.key} className={active ? "border-primary ring-2 ring-primary/20" : ""}>
              <CardHeader>
                <CardTitle className="text-lg">{p.name}</CardTitle>
                <div className="text-2xl font-semibold">{p.price}</div>
              </CardHeader>
              <CardContent className="space-y-3">
                <ul className="text-sm space-y-1.5">
                  {p.features.map((f) => (
                    <li key={f} className="flex items-start gap-2">
                      <Check className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
                <Button className="w-full" variant={active ? "outline" : "default"} disabled>
                  {active ? "Current plan" : "Upgrade"}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <p className="text-xs text-muted-foreground">Payments aren't connected yet — ask the assistant to "enable Stripe billing" to wire checkout.</p>
    </div>
  );
}
