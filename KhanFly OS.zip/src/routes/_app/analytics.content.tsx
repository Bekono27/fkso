import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { AnalyticsPage } from "@/components/analytics/page-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export const Route = createFileRoute("/_app/analytics/content")({
  component: () => {
    const { org } = useAuth();
    const [data, setData] = useState<any>(null);
    useEffect(() => {
      if (!org?.id) return;
      Promise.all([
        supabase.from("smm_posts").select("status,platform").eq("org_id", org.id),
        supabase.from("smm_clients").select("id", { count: "exact", head: true }).eq("org_id", org.id),
        supabase.from("smm_invoices").select("amount,status").eq("org_id", org.id),
      ]).then(([p, c, inv]) => {
        const byStatus: Record<string, number> = {};
        const byPlatform: Record<string, number> = {};
        (p.data ?? []).forEach((x: any) => {
          byStatus[x.status ?? "draft"] = (byStatus[x.status ?? "draft"] ?? 0) + 1;
          byPlatform[x.platform ?? "other"] = (byPlatform[x.platform ?? "other"] ?? 0) + 1;
        });
        const revenue = (inv.data ?? []).filter((i: any) => i.status === "paid").reduce((s: number, i: any) => s + Number(i.amount ?? 0), 0);
        setData({ byStatus, byPlatform, clients: c.count ?? 0, revenue });
      });
    }, [org?.id]);

    return (
      <AnalyticsPage title="Content Analytics" description="Posts, clients, and revenue.">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[["Clients", data?.clients], ["Total Posts", data ? Object.values(data.byStatus as Record<string,number>).reduce((a,b)=>a+b,0) : "—"], ["Published", data?.byStatus?.published ?? 0], ["Revenue", data ? `$${data.revenue.toLocaleString()}` : "—"]].map(([l, v]) => (
            <Card key={l as string}><CardContent className="p-4">
              <div className="text-xs uppercase text-muted-foreground">{l}</div>
              <div className="text-2xl font-semibold mt-1" style={{ color: "var(--analytics)" }}>{v ?? "—"}</div>
            </CardContent></Card>
          ))}
        </div>
        <Card>
          <CardHeader><CardTitle className="text-base">Posts by Platform</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {!data || Object.keys(data.byPlatform).length === 0 ? <div className="text-sm text-muted-foreground p-6 text-center">No data.</div> :
              Object.entries(data.byPlatform as Record<string, number>).sort((a,b)=>b[1]-a[1]).map(([name, count]) => (
                <div key={name} className="flex items-center justify-between text-sm">
                  <span className="capitalize">{name}</span><span className="text-muted-foreground">{count}</span>
                </div>
              ))}
          </CardContent>
        </Card>
      </AnalyticsPage>
    );
  },
});
