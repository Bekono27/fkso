import { createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense } from "react";
import { BotsSkeleton } from "@/components/bots/page-shell";

const BotsDashboard = lazy(() => import("@/components/bots/dashboard"));

export const Route = createFileRoute("/_app/bots/dashboard")({
  component: () => (
    <Suspense fallback={<BotsSkeleton />}>
      <BotsDashboard />
    </Suspense>
  ),
});
