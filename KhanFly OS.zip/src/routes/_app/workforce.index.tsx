import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/_app/workforce/")({
  beforeLoad: () => {
    throw redirect({ to: "/workforce/dashboard" });
  },
});
