import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { mnRiskCheck, mnPaymentInitiate } from "@/lib/digilend.functions";
import { EwaPage, MNT } from "@/components/ewa/page-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { ShieldCheck, AlertTriangle, QrCode, CheckCircle2 } from "lucide-react";

export const Route = createFileRoute("/_app/ewa/request")({ component: RequestPage });

type RiskResult =
  | { ok: true; fee: number; total: number; flag: string | null }
  | { ok: false; reason: string };

function RequestPage() {
  const { org, user } = useAuth();
  const navigate = useNavigate();
  const riskCheck = useServerFn(mnRiskCheck);
  const initiate = useServerFn(mnPaymentInitiate);

  const [employees, setEmployees] = useState<any[]>([]);
  const [employeeId, setEmployeeId] = useState<string>("");
  const [amount, setAmount] = useState<number>(100000);
  const [description, setDescription] = useState("");
  const [risk, setRisk] = useState<RiskResult | null>(null);
  const [checking, setChecking] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [invoice, setInvoice] = useState<{ qr_image: string; qr_text: string; urls: any[] } | null>(null);

  useEffect(() => {
    if (!org?.id) return;
    supabase.from("employees").select("id, full_name, email").eq("org_id", org.id).eq("is_active", true)
      .order("full_name").limit(500).then(({ data }) => setEmployees(data ?? []));
  }, [org?.id]);

  const runRisk = async () => {
    setChecking(true); setRisk(null);
    try {
      const r = await riskCheck({ data: { amount, employeeId: employeeId || null } });
      setRisk(r as RiskResult);
    } catch (e) { toast.error((e as Error).message); }
    finally { setChecking(false); }
  };

  const submit = async () => {
    if (!org?.id || !risk?.ok) return;
    setSubmitting(true);
    try {
      const { data: txn, error } = await supabase
        .from("ulu_transactions" as never)
        .insert({
          org_id: org.id,
          employee_id: employeeId || null,
          amount,
          fee: risk.fee,
          description: description || "Цалингийн урьдчилгаа",
          status: risk.flag ? "flagged" : "pending",
          flag_reason: risk.flag,
          created_by: user?.id,
        } as never)
        .select()
        .single();
      if (error) throw error;

      if (risk.flag) {
        toast.warning("Гүйлгээ AML шалгалт хүлээж байна");
        navigate({ to: "/ewa/transactions" });
        return;
      }

      const inv = await initiate({ data: { transactionId: (txn as any).id } });
      if (!inv.ok) throw new Error("QPay invoice алдаа");
      setInvoice({ qr_image: inv.qr_image!, qr_text: inv.qr_text!, urls: inv.urls ?? [] });
      toast.success("QPay нэхэмжлэх үүсгэгдлээ");
    } catch (e) { toast.error((e as Error).message); }
    finally { setSubmitting(false); }
  };

  if (invoice) {
    return (
      <EwaPage title="QPay-ээр төлөх" description="QR-ийг уншуулж эсвэл банкны аппликейшнаар нээнэ үү">
        <Card className="max-w-md mx-auto">
          <CardContent className="p-6 text-center space-y-4">
            <CheckCircle2 className="h-10 w-10 mx-auto text-emerald-500" />
            <div>
              <div className="text-2xl font-semibold">{MNT(amount + (risk?.ok ? risk.fee : 0))}</div>
              <div className="text-xs text-muted-foreground">Нийт төлөх дүн</div>
            </div>
            <div className="bg-white p-4 rounded-lg inline-block">
              <img src={`data:image/png;base64,${invoice.qr_image}`} alt="QPay QR" className="h-56 w-56" />
            </div>
            {invoice.urls?.length > 0 && (
              <div className="grid grid-cols-2 gap-2 text-left">
                {invoice.urls.slice(0, 6).map((u) => (
                  <a key={u.name} href={u.link} target="_blank" rel="noreferrer"
                     className="text-xs border rounded-md px-3 py-2 hover:bg-muted">
                    {u.name}
                  </a>
                ))}
              </div>
            )}
            <Button variant="outline" className="w-full" onClick={() => navigate({ to: "/ewa/transactions" })}>
              Гүйлгээний жагсаалт руу
            </Button>
          </CardContent>
        </Card>
      </EwaPage>
    );
  }

  return (
    <EwaPage title="Шинэ урьдчилгаа" description="Цалингийн урьдчилгаа хүсэлт + QPay invoice">
      <div className="grid lg:grid-cols-2 gap-4 max-w-4xl">
        <Card>
          <CardHeader><CardTitle className="text-sm">1. Дэлгэрэнгүй</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <div>
              <Label className="text-xs">Ажилтан</Label>
              <select
                value={employeeId}
                onChange={(e) => { setEmployeeId(e.target.value); setRisk(null); }}
                className="w-full h-9 rounded-md border bg-background px-3 text-sm"
              >
                <option value="">— Сонгох —</option>
                {employees.map((emp) => (
                  <option key={emp.id} value={emp.id}>{emp.full_name}</option>
                ))}
              </select>
            </div>
            <div>
              <Label className="text-xs">Дүн (MNT)</Label>
              <Input type="number" step={10000} min={0} value={amount}
                     onChange={(e) => { setAmount(Number(e.target.value)); setRisk(null); }} />
            </div>
            <div>
              <Label className="text-xs">Тайлбар</Label>
              <Textarea rows={2} value={description} onChange={(e) => setDescription(e.target.value)}
                        placeholder="Цалингийн урьдчилгаа" />
            </div>
            <Button onClick={runRisk} disabled={checking || !amount} variant="outline" className="w-full">
              <ShieldCheck className="h-4 w-4 mr-2" />
              {checking ? "Шалгаж байна…" : "Risk check"}
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-sm">2. Шалгалт ба батлах</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {!risk && (
              <div className="text-sm text-muted-foreground text-center py-6">
                Risk check-г ажиллуулна уу.
              </div>
            )}
            {risk && !risk.ok && (
              <div className="flex items-start gap-2 p-3 rounded-md bg-destructive/10 text-destructive text-sm">
                <AlertTriangle className="h-4 w-4 mt-0.5" />
                {risk.reason}
              </div>
            )}
            {risk?.ok && (
              <>
                <Row label="Үндсэн дүн" value={MNT(amount)} />
                <Row label="Шимтгэл" value={MNT(risk.fee)} />
                <Row label="Нийт" value={MNT(risk.total)} bold />
                {risk.flag && (
                  <div className="flex items-start gap-2 p-3 rounded-md bg-amber-50 dark:bg-amber-950/30 text-amber-700 dark:text-amber-300 text-xs">
                    <AlertTriangle className="h-4 w-4 mt-0.5" />
                    {risk.flag}
                  </div>
                )}
                <Button onClick={submit} disabled={submitting} className="w-full"
                        style={{ background: "var(--digilend)" }}>
                  <QrCode className="h-4 w-4 mr-2" />
                  {submitting ? "Үүсгэж байна…" : risk.flag ? "AML-д илгээх" : "QPay invoice үүсгэх"}
                </Button>
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </EwaPage>
  );
}

function Row({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return (
    <div className="flex justify-between text-sm">
      <span className="text-muted-foreground">{label}</span>
      <span className={bold ? "font-semibold" : ""}>{value}</span>
    </div>
  );
}
