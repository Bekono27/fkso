import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { useTheme } from "@/lib/theme";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Sun, Moon, Monitor } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/settings/")({ component: OverviewPage });

const LANGUAGES = [
  { value: "en", label: "English" },
  { value: "mn", label: "Монгол" },
  { value: "ja", label: "日本語" },
  { value: "ko", label: "한국어" },
  { value: "zh", label: "中文" },
];

function OverviewPage() {
  const { profile, org, roles, refresh } = useAuth();
  const { theme, setTheme } = useTheme();

  const [fullName, setFullName] = useState(profile?.full_name ?? "");
  const [language, setLanguage] = useState(profile?.language ?? "en");
  const [orgName, setOrgName] = useState(org?.name ?? "");
  const [savingProfile, setSavingProfile] = useState(false);
  const [savingOrg, setSavingOrg] = useState(false);

  useEffect(() => {
    setFullName(profile?.full_name ?? "");
    setLanguage(profile?.language ?? "en");
  }, [profile]);
  useEffect(() => { setOrgName(org?.name ?? ""); }, [org]);

  const profileDirty = fullName !== (profile?.full_name ?? "") || language !== (profile?.language ?? "en");
  const orgDirty = orgName !== (org?.name ?? "");

  const saveProfile = async () => {
    if (!profile?.id) return;
    setSavingProfile(true);
    const { error } = await supabase.from("profiles")
      .update({ full_name: fullName.trim() || null, language })
      .eq("id", profile.id);
    setSavingProfile(false);
    if (error) return toast.error(error.message);
    toast.success("Profile updated");
    refresh();
  };

  const saveOrg = async () => {
    if (!org?.id || !orgName.trim()) return;
    setSavingOrg(true);
    const { error } = await supabase.from("organizations").update({ name: orgName.trim() }).eq("id", org.id);
    setSavingOrg(false);
    if (error) return toast.error(error.message);
    toast.success("Workspace updated");
    refresh();
  };

  const themeOpts: { value: "light" | "dark" | "system"; label: string; Icon: React.ComponentType<{ className?: string }> }[] = [
    { value: "light", label: "Light", Icon: Sun },
    { value: "dark", label: "Dark", Icon: Moon },
    { value: "system", label: "System", Icon: Monitor },
  ];

  return (
    <div className="p-6 max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Overview</h1>
        <p className="text-sm text-muted-foreground">Profile, workspace and appearance settings.</p>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-sm">Profile</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <div>
            <Label className="text-xs">Full name</Label>
            <Input value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Your name" />
          </div>
          <div>
            <Label className="text-xs">Email</Label>
            <Input value={profile?.email ?? ""} disabled />
            <p className="text-[11px] text-muted-foreground mt-1">Contact support to change your email.</p>
          </div>
          <div>
            <Label className="text-xs">Language</Label>
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              className="w-full h-9 rounded-md border bg-background px-3 text-sm"
            >
              {LANGUAGES.map((l) => <option key={l.value} value={l.value}>{l.label}</option>)}
            </select>
          </div>
          <div className="flex justify-end">
            <Button onClick={saveProfile} disabled={!profileDirty || savingProfile}>
              {savingProfile ? "Saving…" : "Save profile"}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-sm">Workspace</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <div>
            <Label className="text-xs">Workspace name</Label>
            <Input value={orgName} onChange={(e) => setOrgName(e.target.value)} />
          </div>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div><span className="text-muted-foreground">Plan: </span><span className="capitalize">{org?.plan ?? "—"}</span></div>
            <div><span className="text-muted-foreground">Your roles: </span>{roles.join(", ") || "none"}</div>
          </div>
          <div className="flex justify-end">
            <Button onClick={saveOrg} disabled={!orgDirty || savingOrg || !orgName.trim()}>
              {savingOrg ? "Saving…" : "Save workspace"}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-sm">Appearance</CardTitle></CardHeader>
        <CardContent>
          <p className="text-xs text-muted-foreground mb-3">Theme preference is saved to this browser.</p>
          <div className="grid grid-cols-3 gap-2">
            {themeOpts.map(({ value, label, Icon }) => (
              <button
                key={value}
                onClick={() => setTheme(value)}
                className={`flex flex-col items-center gap-2 rounded-lg border p-4 transition-colors hover:bg-accent ${theme === value ? "border-primary ring-2 ring-primary/20" : ""}`}
              >
                <Icon className="h-5 w-5" />
                <span className="text-xs font-medium">{label}</span>
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-sm">Help</CardTitle></CardHeader>
        <CardContent className="text-sm space-y-2">
          <div className="flex items-center justify-between">
            <span>Restart onboarding tour</span>
            <Button variant="outline" size="sm" onClick={() => { localStorage.removeItem("kf_onboarded_v1"); window.location.assign("/dashboard"); }}>Restart</Button>
          </div>
          <div className="flex items-center justify-between">
            <span>Keyboard shortcuts</span>
            <Button variant="outline" size="sm" onClick={() => window.dispatchEvent(new KeyboardEvent("keydown", { key: "?" }))}>Show (?)</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
