import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/settings/modules")({ component: ModulesPage });

const MODULES = [
  { key: "workforce", name: "Workforce", description: "HR, attendance, payroll, projects." },
  { key: "monitor", name: "Monitor", description: "Brand & sentiment monitoring." },
  { key: "content", name: "Content", description: "SMM clients, posts, invoices." },
  { key: "bots", name: "Bots", description: "Visual flow builder and live chat." },
];

function ModulesPage() {
  const { org, roles, refresh } = useAuth();
  const isAdmin = roles.includes("admin") || roles.includes("ceo");
  const [enabled, setEnabled] = useState<Record<string, boolean>>({});
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    if (!org?.id) return;
    supabase.from("organizations").select("settings").eq("id", org.id).single().then(({ data }) => {
      const map = (data?.settings as any)?.modules ?? {};
      const initial: Record<string, boolean> = {};
      for (const m of MODULES) initial[m.key] = map[m.key] !== false;
      setEnabled(initial);
      setLoaded(true);
    });
  }, [org?.id]);

  async function toggle(key: string, value: boolean) {
    if (!org?.id || !isAdmin) return;
    const next = { ...enabled, [key]: value };
    setEnabled(next);
    const { data: cur } = await supabase.from("organizations").select("settings").eq("id", org.id).single();
    const settings = { ...(cur?.settings as any ?? {}), modules: next };
    const { error } = await supabase.from("organizations").update({ settings }).eq("id", org.id);
    if (error) toast.error(error.message);
    else { toast.success(`${key} ${value ? "enabled" : "disabled"}`); refresh(); }
  }

  return (
    <div className="p-6 max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Modules</h1>
        <p className="text-sm text-muted-foreground">Show or hide modules across your workspace.</p>
      </div>

      <Card>
        <CardContent className="p-0 divide-y">
          {MODULES.map((m) => (
            <div key={m.key} className="p-4 flex items-center justify-between gap-4">
              <div className="min-w-0">
                <div className="text-sm font-medium">{m.name}</div>
                <div className="text-xs text-muted-foreground">{m.description}</div>
              </div>
              <Switch
                checked={!!enabled[m.key]}
                disabled={!isAdmin || !loaded}
                onCheckedChange={(v) => toggle(m.key, v)}
              />
            </div>
          ))}
        </CardContent>
      </Card>

      {!isAdmin && <p className="text-xs text-muted-foreground">Only admins can change module visibility.</p>}
    </div>
  );
}
