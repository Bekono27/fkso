import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { ResearchPage } from "@/components/research/page-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, FileText } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/research/reports")({
  component: () => {
    const { org, user } = useAuth();
    const [rows, setRows] = useState<any[]>([]);
    const [open, setOpen] = useState(false);
    const [title, setTitle] = useState("");
    const [type, setType] = useState("market");

    const load = () => {
      if (!org?.id) return;
      supabase.from("research_reports").select("*").eq("org_id", org.id).order("generated_at", { ascending: false })
        .then(({ data }) => setRows(data ?? []));
    };
    useEffect(load, [org?.id]);

    const create = async () => {
      if (!title.trim() || !org?.id) return;
      const { error } = await supabase.from("research_reports").insert({ org_id: org.id, title, type, created_by: user?.id });
      if (error) return toast.error(error.message);
      toast.success("Report draft created");
      setOpen(false); setTitle(""); load();
    };

    return (
      <ResearchPage title="Reports" description="Generated research reports and exports." actions={
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button size="sm" style={{ background: "var(--research)" }}><Plus className="h-4 w-4 mr-1" /> New Report</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Generate Report</DialogTitle></DialogHeader>
            <Input placeholder="Report title" value={title} onChange={(e) => setTitle(e.target.value)} />
            <select className="h-9 px-2 border rounded-md bg-background text-sm" value={type} onChange={(e) => setType(e.target.value)}>
              <option value="market">Market Overview</option>
              <option value="competitive">Competitive Analysis</option>
              <option value="trend">Trend Report</option>
              <option value="audience">Audience Report</option>
            </select>
            <DialogFooter><Button onClick={create}>Create</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      }>
        {rows.length === 0 ? (
          <Card><CardContent className="p-10 text-center text-sm text-muted-foreground">
            <FileText className="h-8 w-8 mx-auto mb-2 opacity-50" />
            No reports yet.
          </CardContent></Card>
        ) : (
          <div className="space-y-2">
            {rows.map((r) => (
              <Card key={r.id}><CardContent className="p-4 flex items-center justify-between">
                <div>
                  <div className="font-medium">{r.title}</div>
                  <div className="text-xs text-muted-foreground capitalize">{r.type} · {new Date(r.generated_at).toLocaleDateString()}</div>
                </div>
                {r.file_url && <Button variant="outline" size="sm" asChild><a href={r.file_url} target="_blank" rel="noreferrer">Download</a></Button>}
              </CardContent></Card>
            ))}
          </div>
        )}
      </ResearchPage>
    );
  },
});
