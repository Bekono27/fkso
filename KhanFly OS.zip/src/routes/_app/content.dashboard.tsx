import { createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense } from "react";
import { ContentSkeleton } from "@/components/content/page-shell";

const ContentDashboard = lazy(() => import("@/components/content/dashboard"));

export const Route = createFileRoute("/_app/content/dashboard")({
  component: () => (
    <Suspense fallback={<ContentSkeleton />}><ContentDashboard /></Suspense>
  ),
});
