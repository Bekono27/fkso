import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Bell, Check, CheckCheck, Inbox, Trash2 } from "lucide-react";
import { MODULES } from "@/lib/modules";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/notifications")({
  component: NotificationsPage,
});

type Filter = "all" | "unread" | "read";

function NotificationsPage() {
  const { user, org } = useAuth();
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<Filter>("all");
  const [mod, setMod] = useState<string>("all");

  const load = async () => {
    if (!user?.id || !org?.id) return;
    setLoading(true);
    const { data } = await supabase
      .from("notifications")
      .select("*")
      .eq("org_id", org.id)
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(200);
    setItems(data ?? []);
    setLoading(false);
  };

  useEffect(() => {
    load();
    if (!user?.id) return;
    const ch = supabase
      .channel(`notif-page-${user.id}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "notifications", filter: `user_id=eq.${user.id}` },
        load,
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id, org?.id]);

  const visible = useMemo(() => {
    return items.filter((n) => {
      if (filter === "unread" && n.read) return false;
      if (filter === "read" && !n.read) return false;
      if (mod !== "all" && n.source_module !== mod) return false;
      return true;
    });
  }, [items, filter, mod]);

  const unreadCount = items.filter((n) => !n.read).length;

  const markRead = async (id: string, val = true) => {
    setItems((p) => p.map((n) => (n.id === id ? { ...n, read: val } : n)));
    await supabase.from("notifications").update({ read: val } as any).eq("id", id);
  };
  const markAll = async () => {
    if (!user?.id) return;
    setItems((p) => p.map((n) => ({ ...n, read: true })));
    await supabase
      .from("notifications")
      .update({ read: true } as any)
      .eq("user_id", user.id)
      .eq("read", false);
    toast.success("All notifications marked as read");
  };
  const remove = async (id: string) => {
    setItems((p) => p.filter((n) => n.id !== id));
    await supabase.from("notifications").delete().eq("id", id);
  };
  const clearAllRead = async () => {
    if (!user?.id) return;
    setItems((p) => p.filter((n) => !n.read));
    await supabase.from("notifications").delete().eq("user_id", user.id).eq("read", true);
    toast.success("Read notifications cleared");
  };

  const typeStyles: Record<string, string> = {
    info: "var(--research)",
    success: "var(--workforce)",
    warning: "var(--bots)",
    danger: "var(--destructive)",
  };

  return (
    <div className="p-6 md:p-8 max-w-5xl mx-auto space-y-5 animate-page-in">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <div className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground font-medium flex items-center gap-2">
            <span className="live-dot" /> Inbox · {unreadCount} unread
          </div>
          <h1 className="text-3xl font-semibold tracking-tight mt-1">Notifications</h1>
          <p className="text-sm text-muted-foreground mt-1">Everything that happened across your workspace.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={markAll} disabled={unreadCount === 0}>
            <CheckCheck className="h-4 w-4 mr-1.5" /> Mark all read
          </Button>
          <Button variant="outline" size="sm" onClick={clearAllRead}>
            <Trash2 className="h-4 w-4 mr-1.5" /> Clear read
          </Button>
        </div>
      </div>

      <Card className="p-3 flex flex-wrap items-center gap-3">
        <Tabs value={filter} onValueChange={(v) => setFilter(v as Filter)}>
          <TabsList>
            <TabsTrigger value="all">All <Badge variant="secondary" className="ml-1.5">{items.length}</Badge></TabsTrigger>
            <TabsTrigger value="unread">Unread <Badge variant="secondary" className="ml-1.5">{unreadCount}</Badge></TabsTrigger>
            <TabsTrigger value="read">Read</TabsTrigger>
          </TabsList>
        </Tabs>
        <div className="flex items-center gap-1.5 flex-wrap">
          <button
            onClick={() => setMod("all")}
            className={`text-xs rounded-full px-2.5 py-1 border transition-colors ${mod === "all" ? "bg-foreground text-background" : "hover:bg-accent"}`}
          >
            All modules
          </button>
          {MODULES.map((m) => (
            <button
              key={m.key}
              onClick={() => setMod(m.key)}
              className="text-xs rounded-full px-2.5 py-1 border transition-colors hover:opacity-90"
              style={
                mod === m.key
                  ? { background: `var(--${m.accent})`, color: "white", borderColor: `var(--${m.accent})` }
                  : undefined
              }
            >
              <span
                className="inline-block h-1.5 w-1.5 rounded-full mr-1.5 align-middle"
                style={{ background: `var(--${m.accent})` }}
              />
              {m.label}
            </button>
          ))}
        </div>
      </Card>

      {loading ? (
        <Card className="p-10 text-center text-muted-foreground text-sm">Loading…</Card>
      ) : visible.length === 0 ? (
        <Card className="p-16 text-center">
          <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-muted text-muted-foreground mb-3">
            <Inbox className="h-6 w-6" />
          </div>
          <div className="text-lg font-medium">You're all caught up</div>
          <p className="text-sm text-muted-foreground mt-1">
            New activity from your modules will appear here.
          </p>
        </Card>
      ) : (
        <Card className="overflow-hidden divide-y">
          {visible.map((n) => {
            const mod = MODULES.find((m) => m.key === n.source_module);
            const color = typeStyles[n.type] ?? "var(--muted-foreground)";
            return (
              <div
                key={n.id}
                className={`group relative flex gap-3 p-4 transition-colors ${
                  !n.read ? "bg-accent/30" : ""
                } hover:bg-accent/50`}
              >
                {!n.read && (
                  <span
                    aria-hidden
                    className="absolute left-0 top-0 bottom-0 w-[3px]"
                    style={{ background: color }}
                  />
                )}
                <span
                  className="shrink-0 h-9 w-9 rounded-lg flex items-center justify-center ring-1 ring-black/5"
                  style={{
                    background: `color-mix(in oklab, ${mod ? `var(--${mod.accent})` : color} 18%, transparent)`,
                    color: mod ? `var(--${mod.accent})` : color,
                  }}
                >
                  {mod ? <mod.icon className="h-4 w-4" /> : <Bell className="h-4 w-4" />}
                </span>
                <div className="flex-1 min-w-0">
                  {n.link ? (
                    <Link to={n.link as any} onClick={() => markRead(n.id)} className="block">
                      <div className="text-sm font-medium leading-snug">{n.title}</div>
                      {n.body && <div className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{n.body}</div>}
                    </Link>
                  ) : (
                    <>
                      <div className="text-sm font-medium leading-snug">{n.title}</div>
                      {n.body && <div className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{n.body}</div>}
                    </>
                  )}
                  <div className="flex items-center gap-2 mt-1.5 text-[10px] text-muted-foreground">
                    {mod && (
                      <span style={{ color: `var(--${mod.accent})` }} className="font-medium uppercase tracking-wide">
                        {mod.label}
                      </span>
                    )}
                    <span>·</span>
                    <span>{new Date(n.created_at).toLocaleString()}</span>
                  </div>
                </div>
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  {!n.read && (
                    <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={() => markRead(n.id)}>
                      <Check className="h-4 w-4" />
                    </Button>
                  )}
                  <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={() => remove(n.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            );
          })}
        </Card>
      )}
    </div>
  );
}
