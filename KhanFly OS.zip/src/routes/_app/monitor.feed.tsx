import { createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense } from "react";
import { MonitorSkeleton } from "@/components/monitor/page-shell";
const Page = lazy(() => import("@/components/monitor/pages/feed"));
export const Route = createFileRoute("/_app/monitor/feed")({
  component: () => <Suspense fallback={<MonitorSkeleton />}><Page /></Suspense>,
});
