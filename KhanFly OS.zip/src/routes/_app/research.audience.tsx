import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { ResearchPage } from "@/components/research/page-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export const Route = createFileRoute("/_app/research/audience")({
  component: () => {
    const { org } = useAuth();
    const [data, setData] = useState<any>(null);
    useEffect(() => {
      if (!org?.id) return;
      supabase.from("bot_contacts").select("platform,lead_captured").eq("org_id", org.id).limit(2000).then(({ data: c }) => {
        const platforms: Record<string, number> = {};
        let leads = 0;
        (c ?? []).forEach((x: any) => {
          if (x.platform) platforms[x.platform] = (platforms[x.platform] ?? 0) + 1;
          if (x.lead_captured) leads += 1;
        });
        setData({ total: (c ?? []).length, platforms, leads });
      });
    }, [org?.id]);

    return (
      <ResearchPage title="Audience" description="Demographic insights from your contact base.">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card>
            <CardHeader><CardTitle className="text-base">By Platform ({data?.total ?? 0} contacts)</CardTitle></CardHeader>
            <CardContent className="space-y-1">
              {!data || Object.keys(data.platforms).length === 0 ? <div className="text-sm text-muted-foreground p-4 text-center">No data.</div> :
                Object.entries(data.platforms as Record<string, number>).sort((a,b)=>b[1]-a[1]).slice(0,10).map(([k,v]) => (
                  <div key={k} className="flex justify-between text-sm"><span className="capitalize">{k}</span><span className="text-muted-foreground">{v}</span></div>
                ))}
            </CardContent>
          </Card>
          <Card>
            <CardHeader><CardTitle className="text-base">Lead Capture Rate</CardTitle></CardHeader>
            <CardContent>
              <div className="text-3xl font-semibold" style={{ color: "var(--research)" }}>
                {data ? `${data.leads} / ${data.total}` : "—"}
              </div>
              <div className="text-sm text-muted-foreground mt-1">
                {data && data.total > 0 ? `${Math.round((data.leads / data.total) * 100)}% conversion` : "No contacts yet"}
              </div>
            </CardContent>
          </Card>
        </div>
      </ResearchPage>
    );
  },
});
