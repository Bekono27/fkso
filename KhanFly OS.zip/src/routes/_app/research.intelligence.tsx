import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { ResearchPage } from "@/components/research/page-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Loader2, ExternalLink } from "lucide-react";
import { toast } from "sonner";

type Swot = { strengths: string[]; weaknesses: string[]; opportunities: string[]; threats: string[] };
type Competitor = { id: string; name: string; url: string | null; swot: Swot | null };

export const Route = createFileRoute("/_app/research/intelligence")({
  component: () => {
    const { org } = useAuth();
    const [comps, setComps] = useState<Competitor[]>([]);
    const [busyId, setBusyId] = useState<string | null>(null);

    const load = async () => {
      if (!org?.id) return;
      const { data } = await supabase
        .from("monitoring_competitors")
        .select("id, name, url, swot")
        .eq("org_id", org.id)
        .limit(50);
      setComps((data ?? []) as Competitor[]);
    };
    useEffect(() => { load(); /* eslint-disable-next-line */ }, [org?.id]);

    const generateSwot = async (c: Competitor) => {
      setBusyId(c.id);
      try {
        const { data, error } = await supabase.functions.invoke("ai-assist", {
          body: {
            task: "competitor_swot",
            payload: { name: c.name, url: c.url },
          },
        });
        if (error) throw error;
        const swot = data?.swot as Swot | undefined;
        if (!swot) throw new Error("No SWOT returned");
        const { error: uErr } = await supabase
          .from("monitoring_competitors")
          .update({ swot } as any)
          .eq("id", c.id);
        if (uErr) throw uErr;
        toast.success("SWOT generated");
        await load();
      } catch (e: any) {
        toast.error(e?.message ?? "Generation failed");
      } finally {
        setBusyId(null);
      }
    };

    return (
      <ResearchPage title="Competitive Intelligence" description="Competitor profiles with AI-generated SWOT analyses.">
        <Card>
          <CardHeader><CardTitle className="text-base">Tracked Competitors ({comps.length})</CardTitle></CardHeader>
          <CardContent>
            {comps.length === 0 ? (
              <div className="text-sm text-muted-foreground p-6 text-center">
                No competitors tracked. Add some in Monitor → Competitors.
              </div>
            ) : (
              <div className="space-y-3">
                {comps.map((c) => (
                  <div key={c.id} className="border rounded-lg p-3 space-y-3">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <div className="font-medium text-sm">{c.name}</div>
                        {c.url && (
                          <a href={c.url} target="_blank" rel="noreferrer"
                             className="text-xs text-muted-foreground hover:text-primary inline-flex items-center gap-1">
                            <ExternalLink className="h-3 w-3" /> {c.url}
                          </a>
                        )}
                      </div>
                      <Button
                        size="sm"
                        variant={c.swot ? "outline" : "default"}
                        onClick={() => generateSwot(c)}
                        disabled={busyId === c.id}
                        style={c.swot ? undefined : { background: "var(--research)" }}
                      >
                        {busyId === c.id ? <Loader2 className="h-3 w-3 animate-spin mr-1" /> : <Sparkles className="h-3 w-3 mr-1" />}
                        {c.swot ? "Regenerate SWOT" : "Generate SWOT"}
                      </Button>
                    </div>
                    {c.swot && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                        {([
                          ["Strengths", c.swot.strengths, "emerald"],
                          ["Weaknesses", c.swot.weaknesses, "red"],
                          ["Opportunities", c.swot.opportunities, "sky"],
                          ["Threats", c.swot.threats, "amber"],
                        ] as const).map(([label, items, color]) => (
                          <div key={label} className="bg-muted/30 rounded-md p-2">
                            <Badge variant="outline" className={`text-[10px] mb-1.5 border-${color}-500/40 text-${color}-700 dark:text-${color}-400`}>
                              {label}
                            </Badge>
                            <ul className="list-disc pl-4 space-y-0.5 text-muted-foreground">
                              {(items ?? []).slice(0, 5).map((it, i) => <li key={i}>{it}</li>)}
                            </ul>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </ResearchPage>
    );
  },
});
