import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/_app/content/")({
  beforeLoad: () => { throw redirect({ to: "/content/dashboard" }); },
});
