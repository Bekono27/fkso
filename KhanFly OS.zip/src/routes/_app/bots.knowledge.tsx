import { createFileRoute } from "@tanstack/react-router";
import { BotsList } from "@/components/bots/list";
import { timeAgo } from "@/components/bots/page-shell";
import { QuickCreate } from "@/components/quick-create";

export const Route = createFileRoute("/_app/bots/knowledge")({
  component: () => (
    <BotsList
      title="Knowledge Base"
      description="FAQs and documents your bots can answer from."
      table="knowledge_base_items"
      actions={
        <QuickCreate
          table="knowledge_base_items"
          title="Add knowledge item"
          buttonLabel="Add item"
          buttonStyle={{ background: "var(--bots)", color: "white" }}
          fields={[
            { key: "question", label: "Question", required: true },
            { key: "answer", label: "Answer", type: "textarea", required: true },
            { key: "category", label: "Category", placeholder: "general" },
          ]}
        />
      }
      columns={[
        { key: "question", label: "Question", render: (r) => <span className="font-medium">{r.question ?? r.title ?? "—"}</span> },
        { key: "category", label: "Category", render: (r) => <span className="text-xs">{r.category ?? "general"}</span> },
        { key: "answer", label: "Answer", render: (r) => <span className="text-muted-foreground line-clamp-1">{r.answer ?? "—"}</span> },
        { key: "updated_at", label: "Updated", render: (r) => <span className="text-xs text-muted-foreground">{timeAgo(r.updated_at)}</span> },
      ]}
      emptyMessage="No knowledge items yet."
    />
  ),
});
