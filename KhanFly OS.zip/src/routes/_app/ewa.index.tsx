import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/_app/ewa/")({
  beforeLoad: () => { throw redirect({ to: "/ewa/dashboard" }); },
});
