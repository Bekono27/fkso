import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { BotsPage, BotsSkeleton } from "@/components/bots/page-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, Legend, CartesianGrid,
} from "recharts";

function BotsAnalytics() {
  const { org } = useAuth();
  const [rows, setRows] = useState<any[] | null>(null);
  const [bots, setBots] = useState<any[]>([]);

  useEffect(() => {
    if (!org?.id) return;
    const since = new Date(Date.now() - 29 * 86400000).toISOString().split("T")[0];
    Promise.all([
      supabase.from("bot_analytics_daily").select("*").eq("org_id", org.id).gte("date", since).order("date"),
      supabase.from("bots").select("id,name,emoji").eq("org_id", org.id),
    ]).then(([a, b]) => { setRows(a.data ?? []); setBots(b.data ?? []); });
  }, [org?.id]);

  if (rows === null) return <BotsSkeleton />;

  // Aggregate by date across all bots
  const byDate: Record<string, any> = {};
  rows.forEach((r) => {
    const d = byDate[r.date] ||= {
      date: r.date, conversations: 0, ai_resolved: 0, human_handoffs: 0, leads_captured: 0,
      _respSum: 0, _respN: 0,
    };
    d.conversations += r.conversations ?? 0;
    d.ai_resolved += r.ai_resolved ?? 0;
    d.human_handoffs += r.human_handoffs ?? 0;
    d.leads_captured += r.leads_captured ?? 0;
    if (r.avg_response_seconds) { d._respSum += r.avg_response_seconds; d._respN += 1; }
  });
  const trend = Object.values(byDate).sort((a: any, b: any) => a.date.localeCompare(b.date)) as any[];

  // Per-bot totals
  const byBot: Record<string, any> = {};
  rows.forEach((r) => {
    const b = byBot[r.bot_id] ||= { bot_id: r.bot_id, conversations: 0, leads_captured: 0, ai_resolved: 0, human_handoffs: 0 };
    b.conversations += r.conversations ?? 0;
    b.leads_captured += r.leads_captured ?? 0;
    b.ai_resolved += r.ai_resolved ?? 0;
    b.human_handoffs += r.human_handoffs ?? 0;
  });
  const perBot = Object.values(byBot).map((b: any) => {
    const meta = bots.find((x) => x.id === b.bot_id);
    return { ...b, name: meta ? `${meta.emoji ?? "🤖"} ${meta.name}` : "Unknown bot" };
  }).sort((a: any, b: any) => b.conversations - a.conversations).slice(0, 8);

  const totals = trend.reduce((s, r: any) => ({
    conversations: s.conversations + r.conversations,
    ai_resolved: s.ai_resolved + r.ai_resolved,
    human_handoffs: s.human_handoffs + r.human_handoffs,
    leads_captured: s.leads_captured + r.leads_captured,
    respSum: s.respSum + r._respSum,
    respN: s.respN + r._respN,
  }), { conversations: 0, ai_resolved: 0, human_handoffs: 0, leads_captured: 0, respSum: 0, respN: 0 });
  const aiRate = totals.conversations ? Math.round((totals.ai_resolved / totals.conversations) * 100) : 0;
  const avgResp = totals.respN ? Math.round(totals.respSum / totals.respN) : 0;

  return (
    <BotsPage title="Bot Analytics" description="Last 30 days across all bots">
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {[
          ["Conversations", totals.conversations.toLocaleString()],
          ["Leads captured", totals.leads_captured.toLocaleString()],
          ["AI resolution", `${aiRate}%`],
          ["Human handoffs", totals.human_handoffs.toLocaleString()],
          ["Avg response", avgResp ? `${avgResp}s` : "—"],
        ].map(([label, val]) => (
          <Card key={label as string}><CardContent className="p-4">
            <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
            <div className="text-2xl font-semibold mt-1" style={{ color: "var(--bots)" }}>{val}</div>
          </CardContent></Card>
        ))}
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Conversations & leads</CardTitle></CardHeader>
        <CardContent>
          {trend.length === 0 ? (
            <div className="text-sm text-muted-foreground text-center p-6">No analytics yet — start chatting with a bot to see data.</div>
          ) : (
            <div className="h-72"><ResponsiveContainer width="100%" height="100%">
              <LineChart data={trend} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                <XAxis dataKey="date" fontSize={11} tickFormatter={(d) => d.slice(5)} />
                <YAxis fontSize={11} />
                <Tooltip contentStyle={{ fontSize: 12 }} />
                <Legend />
                <Line type="monotone" dataKey="conversations" stroke="var(--bots)" strokeWidth={2} name="Conversations" />
                <Line type="monotone" dataKey="leads_captured" stroke="#16a34a" strokeWidth={2} name="Leads" />
              </LineChart>
            </ResponsiveContainer></div>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-base">AI vs human handling</CardTitle></CardHeader>
          <CardContent>
            {trend.length === 0 ? (
              <div className="text-sm text-muted-foreground text-center p-6">No data.</div>
            ) : (
              <div className="h-64"><ResponsiveContainer width="100%" height="100%">
                <BarChart data={trend} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <XAxis dataKey="date" fontSize={11} tickFormatter={(d) => d.slice(5)} />
                  <YAxis fontSize={11} />
                  <Tooltip contentStyle={{ fontSize: 12 }} />
                  <Legend />
                  <Bar dataKey="ai_resolved" stackId="a" fill="var(--bots)" name="AI resolved" />
                  <Bar dataKey="human_handoffs" stackId="a" fill="#f59e0b" name="Human handoffs" />
                </BarChart>
              </ResponsiveContainer></div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Top bots</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {perBot.length === 0 ? (
              <div className="text-sm text-muted-foreground text-center p-6">No bot activity yet.</div>
            ) : perBot.map((b) => {
              const max = perBot[0].conversations || 1;
              const pct = Math.round((b.conversations / max) * 100);
              return (
                <div key={b.bot_id}>
                  <div className="flex justify-between text-sm">
                    <span className="font-medium truncate">{b.name}</span>
                    <span className="text-muted-foreground">{b.conversations} convo · 🎯 {b.leads_captured}</span>
                  </div>
                  <div className="h-1.5 bg-muted rounded-full overflow-hidden mt-1">
                    <div className="h-full rounded-full" style={{ width: `${pct}%`, background: "var(--bots)" }} />
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>
      </div>
    </BotsPage>
  );
}

export const Route = createFileRoute("/_app/bots/analytics")({
  component: BotsAnalytics,
});
