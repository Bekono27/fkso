import { createFileRoute } from "@tanstack/react-router";
import { ContentList, ContentStatusPill } from "@/components/content/list";
import { QuickCreate } from "@/components/quick-create";

export const Route = createFileRoute("/_app/content/clients")({
  component: () => (
    <ContentList
      title="Clients"
      description="Manage SMM clients and their retainers"
      table="smm_clients"
      actions={
        <QuickCreate
          table="smm_clients"
          title="Add client"
          buttonLabel="Add client"
          buttonStyle={{ background: "var(--content)", color: "white" }}
          fields={[
            { key: "name", label: "Name", required: true },
            { key: "company", label: "Company" },
            { key: "email", label: "Email", type: "email" },
            { key: "monthly_retainer", label: "Monthly retainer", type: "number" },
          ]}
          defaults={{ status: "prospect" }}
        />
      }
      columns={[
        { key: "name", label: "Name" },
        { key: "company", label: "Company" },
        { key: "email", label: "Email" },
        { key: "monthly_retainer", label: "Retainer", render: (r) => r.monthly_retainer ? `$${Number(r.monthly_retainer).toLocaleString()}` : "—" },
        { key: "status", label: "Status", render: (r) => <ContentStatusPill value={r.status} /> },
      ]}
    />
  ),
});
