import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { BotsPage, BotsSkeleton, StatusPill, timeAgo } from "@/components/bots/page-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { EmptyState } from "@/components/empty-state";
import { Bot } from "lucide-react";
import { toast } from "sonner";
import { writeEvent, indexEntity } from "@/lib/bots";

export const Route = createFileRoute("/_app/bots/list")({ component: BotsListPage });

function BotsListPage() {
  const { org, user } = useAuth();
  const navigate = useNavigate();
  const [rows, setRows] = useState<any[] | null>(null);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "", emoji: "🤖", description: "" });
  const [creating, setCreating] = useState(false);

  const load = async () => {
    if (!org?.id) return;
    const { data } = await supabase.from("bots").select("*").eq("org_id", org.id).order("created_at", { ascending: false });
    setRows(data ?? []);
  };
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [org?.id]);

  const createBot = async () => {
    if (!org?.id || !form.name.trim()) return;
    setCreating(true);
    const { data, error } = await supabase.from("bots").insert({
      org_id: org.id, name: form.name.trim(), emoji: form.emoji, description: form.description, status: "draft",
      created_by: user?.id,
    } as any).select().single();
    setCreating(false);
    if (error || !data) return toast.error(error?.message ?? "Failed");
    await writeEvent(org.id, "bots", "bot_created", { bot_id: data.id, name: data.name }, user?.id);
    await indexEntity({
      org_id: org.id, module: "bots", entity_type: "bot", entity_id: data.id,
      title: data.name, subtitle: data.description ?? "Bot",
      keywords: `bot ${data.name}`, url: `/bots/builder/${data.id}`,
    });
    setOpen(false);
    setForm({ name: "", emoji: "🤖", description: "" });
    toast.success("Bot created — opening builder…");
    navigate({ to: "/bots/builder/$id", params: { id: data.id } });
  };

  if (rows === null) return <BotsSkeleton />;

  return (
    <BotsPage
      title="My Bots"
      description={`${rows.length} bot${rows.length === 1 ? "" : "s"} in your workspace.`}
      actions={
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm" style={{ background: "var(--bots)", color: "white" }}>+ New bot</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Create a bot</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div className="flex gap-2">
                <div className="w-20"><Label>Emoji</Label>
                  <Input value={form.emoji} onChange={(e) => setForm({ ...form, emoji: e.target.value })} />
                </div>
                <div className="flex-1"><Label>Name</Label>
                  <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Customer Support Bot" />
                </div>
              </div>
              <div><Label>Description</Label>
                <Textarea rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })}
                  placeholder="What does this bot do?" />
              </div>
            </div>
            <DialogFooter>
              <Button onClick={createBot} disabled={creating || !form.name.trim()}>
                {creating ? "Creating…" : "Create & open builder"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      }
    >
      <Card>
        <CardContent className="p-0">
          {rows.length === 0 ? (
            <EmptyState
              icon={Bot}
              accent="var(--bots)"
              title="No bots yet"
              description="Build your first conversational bot in minutes — start from a template or build from scratch in the visual editor."
              actionLabel="+ New bot"
              onAction={() => setOpen(true)}
              secondaryLabel="Browse templates"
              onSecondary={() => navigate({ to: "/bots/templates" })}
            />
          ) : (
            <div className="divide-y">
              {rows.map((b) => (
                <div key={b.id} className="flex items-center gap-3 px-4 py-3 hover:bg-muted/30">
                  <div className="text-2xl">{b.emoji ?? "🤖"}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{b.name}</span>
                      <StatusPill value={b.status} />
                    </div>
                    <div className="text-xs text-muted-foreground line-clamp-1">{b.description ?? "—"}</div>
                  </div>
                  <span className="text-xs text-muted-foreground hidden md:inline">Updated {timeAgo(b.updated_at)}</span>
                  <Link to="/bots/builder/$id" params={{ id: b.id }}>
                    <Button size="sm" variant="outline">Open builder →</Button>
                  </Link>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </BotsPage>
  );
}
