import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/settings/team")({ component: TeamPage });

type Member = {
  user_id: string;
  email: string | null;
  full_name: string | null;
  roles: string[];
};

const ROLES = ["admin", "ceo", "manager", "employee", "viewer"] as const;

function TeamPage() {
  const { org, roles: myRoles } = useAuth();
  const [members, setMembers] = useState<Member[] | null>(null);
  const [inviteEmail, setInviteEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const isAdmin = myRoles.includes("admin") || myRoles.includes("ceo");

  async function load() {
    if (!org?.id) return;
    const { data: rows } = await supabase
      .from("user_roles")
      .select("user_id, role")
      .eq("org_id", org.id);
    const userIds = Array.from(new Set((rows ?? []).map((r) => r.user_id)));
    const { data: profs } = await supabase
      .from("profiles")
      .select("id, email, full_name")
      .in("id", userIds.length ? userIds : ["00000000-0000-0000-0000-000000000000"]);
    const byUser = new Map<string, Member>();
    (rows ?? []).forEach((r) => {
      const p = profs?.find((p: any) => p.id === r.user_id);
      if (!byUser.has(r.user_id)) {
        byUser.set(r.user_id, { user_id: r.user_id, email: p?.email ?? null, full_name: p?.full_name ?? null, roles: [] });
      }
      byUser.get(r.user_id)!.roles.push(r.role);
    });
    setMembers(Array.from(byUser.values()));
  }

  useEffect(() => { load(); }, [org?.id]);

  async function sendInvite() {
    if (!org?.id || !inviteEmail.trim()) return;
    setBusy(true);
    const email = inviteEmail.trim().toLowerCase();
    // Check if a profile already exists for this email and add role
    const { data: prof } = await supabase
      .from("profiles")
      .select("id")
      .eq("email", email)
      .maybeSingle();
    if (prof?.id) {
      const { error } = await supabase
        .from("user_roles")
        .insert({ user_id: prof.id, org_id: org.id, role: "employee" });
      if (error) toast.error(error.message);
      else { toast.success("Added existing user to your workspace"); setInviteEmail(""); load(); }
    } else {
      toast.message("Invite sent", { description: `Ask ${email} to sign up at this app — they'll be added once they create an account.` });
      setInviteEmail("");
    }
    setBusy(false);
  }

  async function toggleRole(userId: string, role: string, has: boolean) {
    if (!org?.id) return;
    if (has) {
      const { error } = await supabase
        .from("user_roles")
        .delete()
        .eq("org_id", org.id)
        .eq("user_id", userId)
        .eq("role", role as any);
      if (error) toast.error(error.message); else load();
    } else {
      const { error } = await supabase
        .from("user_roles")
        .insert({ org_id: org.id, user_id: userId, role: role as any });
      if (error) toast.error(error.message); else load();
    }
  }

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Team</h1>
        <p className="text-sm text-muted-foreground">Manage members of <span className="font-medium">{org?.name ?? "your workspace"}</span>.</p>
      </div>

      {isAdmin && (
        <Card>
          <CardHeader><CardTitle className="text-sm">Invite member</CardTitle></CardHeader>
          <CardContent className="flex gap-2">
            <Input
              type="email"
              placeholder="teammate@company.com"
              value={inviteEmail}
              onChange={(e) => setInviteEmail(e.target.value)}
            />
            <Button onClick={sendInvite} disabled={busy || !inviteEmail.trim()}>Invite</Button>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader><CardTitle className="text-sm">Members ({members?.length ?? 0})</CardTitle></CardHeader>
        <CardContent className="p-0">
          {members === null ? (
            <div className="p-6 text-sm text-muted-foreground">Loading…</div>
          ) : members.length === 0 ? (
            <div className="p-6 text-sm text-muted-foreground">No members yet.</div>
          ) : (
            <div className="divide-y">
              {members.map((m) => (
                <div key={m.user_id} className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-sm font-medium truncate">{m.full_name || m.email || m.user_id.slice(0, 8)}</div>
                    <div className="text-xs text-muted-foreground truncate">{m.email}</div>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {ROLES.map((r) => {
                      const has = m.roles.includes(r);
                      return (
                        <button
                          key={r}
                          disabled={!isAdmin}
                          onClick={() => toggleRole(m.user_id, r, has)}
                          className="disabled:opacity-60 disabled:cursor-not-allowed"
                        >
                          <Badge variant={has ? "default" : "outline"} className="capitalize">{r}</Badge>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
