import { createFileRoute } from "@tanstack/react-router";
import { BotsList } from "@/components/bots/list";
import { timeAgo } from "@/components/bots/page-shell";
import { QuickCreate } from "@/components/quick-create";

export const Route = createFileRoute("/_app/bots/automation")({
  component: () => (
    <BotsList
      title="Automation"
      description="Trigger → action rules that run on bot events."
      table="automation_rules"
      actions={
        <QuickCreate
          table="automation_rules"
          title="New rule"
          buttonLabel="New rule"
          buttonStyle={{ background: "var(--bots)", color: "white" }}
          fields={[
            { key: "name", label: "Rule name", required: true },
            { key: "trigger_type", label: "Trigger", required: true, placeholder: "message_received" },
            { key: "description", label: "Description", type: "textarea" },
          ]}
          defaults={{ active: true }}
        />
      }
      columns={[
        { key: "name", label: "Rule", render: (r) => <span className="font-medium">{r.name}</span> },
        { key: "trigger_type", label: "Trigger", render: (r) => <span className="text-xs">{r.trigger_type}</span> },
        { key: "active", label: "Status", render: (r) => r.active ? "🟢 Active" : "⏸ Paused" },
        { key: "updated_at", label: "Updated", render: (r) => <span className="text-xs text-muted-foreground">{timeAgo(r.updated_at)}</span> },
      ]}
      emptyMessage="No automation rules yet."
    />
  ),
});
