import { createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense } from "react";
import { BotsSkeleton } from "@/components/bots/page-shell";
const Builder = lazy(() => import("@/components/bots/flow-builder"));

export const Route = createFileRoute("/_app/bots/builder/$id")({
  component: () => {
    const { id } = Route.useParams();
    return (
      <Suspense fallback={<BotsSkeleton />}>
        <Builder botId={id} />
      </Suspense>
    );
  },
});
