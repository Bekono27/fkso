import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { AnalyticsPage } from "@/components/analytics/page-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export const Route = createFileRoute("/_app/analytics/bots")({
  component: () => {
    const { org } = useAuth();
    const [data, setData] = useState<any>(null);
    useEffect(() => {
      if (!org?.id) return;
      Promise.all([
        supabase.from("bots").select("id", { count: "exact", head: true }).eq("org_id", org.id),
        supabase.from("bot_conversations").select("status").eq("org_id", org.id),
        supabase.from("bot_contacts").select("id", { count: "exact", head: true }).eq("org_id", org.id),
        supabase.from("bot_messages").select("id", { count: "exact", head: true }).eq("org_id", org.id).gte("created_at", new Date(Date.now() - 7 * 86400000).toISOString()),
      ]).then(([b, c, ct, m]) => {
        const byStatus: Record<string, number> = {};
        (c.data ?? []).forEach((x: any) => { byStatus[x.status ?? "open"] = (byStatus[x.status ?? "open"] ?? 0) + 1; });
        setData({ bots: b.count ?? 0, contacts: ct.count ?? 0, msg7d: m.count ?? 0, byStatus });
      });
    }, [org?.id]);

    return (
      <AnalyticsPage title="Bots Analytics" description="Bot performance and reach.">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[["Bots", data?.bots], ["Contacts", data?.contacts], ["Messages (7d)", data?.msg7d], ["Open Convos", data?.byStatus?.open ?? 0]].map(([l, v]) => (
            <Card key={l as string}><CardContent className="p-4">
              <div className="text-xs uppercase text-muted-foreground">{l}</div>
              <div className="text-2xl font-semibold mt-1" style={{ color: "var(--analytics)" }}>{v ?? "—"}</div>
            </CardContent></Card>
          ))}
        </div>
      </AnalyticsPage>
    );
  },
});
