import { createFileRoute } from "@tanstack/react-router";
import { ContentList, ContentStatusPill } from "@/components/content/list";
import { QuickCreate } from "@/components/quick-create";

export const Route = createFileRoute("/_app/content/proposals")({
  component: () => (
    <ContentList
      title="Proposals"
      description="Send and track client proposals"
      table="smm_proposals"
      actions={
        <QuickCreate
          table="smm_proposals"
          title="New proposal"
          buttonLabel="New proposal"
          buttonStyle={{ background: "var(--content)", color: "white" }}
          fields={[
            { key: "title", label: "Title", required: true },
            { key: "amount", label: "Amount", type: "number" },
            { key: "currency", label: "Currency", placeholder: "USD" },
            { key: "valid_until", label: "Valid until", placeholder: "YYYY-MM-DD" },
          ]}
          defaults={{ status: "draft" }}
        />
      }
      columns={[
        { key: "title", label: "Title" },
        { key: "amount", label: "Amount", render: (r) => `${r.currency ?? "$"} ${Number(r.amount ?? 0).toLocaleString()}` },
        { key: "status", label: "Status", render: (r) => <ContentStatusPill value={r.status} /> },
        { key: "valid_until", label: "Valid until", render: (r) => r.valid_until ? new Date(r.valid_until).toLocaleDateString() : "—" },
        { key: "approval_token", label: "Public link", render: (r) => r.approval_token
          ? <a className="text-xs text-primary underline" href={`/approval/${r.approval_token}`} target="_blank" rel="noreferrer">Open</a> : "—" },
      ]}
    />
  ),
});
