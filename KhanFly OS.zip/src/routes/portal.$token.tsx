import { createFileRoute, useParams } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { FileText, Receipt, Sparkles, CheckCircle2, Clock } from "lucide-react";

export const Route = createFileRoute("/portal/$token")({
  component: PortalPage,
});

/**
 * Public client portal. The token is the client's id (UUID) — clients see
 * their proposals + invoices without authentication.
 * RLS still applies, so this only works for rows reachable via a public
 * select policy. If your policies are stricter, expose via a server fn.
 */
function PortalPage() {
  const { token } = useParams({ from: "/portal/$token" });
  const [client, setClient] = useState<any>(null);
  const [proposals, setProposals] = useState<any[]>([]);
  const [invoices, setInvoices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const [{ data: c }, { data: p }, { data: i }] = await Promise.all([
        supabase.from("smm_clients").select("id,name,company,email").eq("id", token).maybeSingle(),
        supabase.from("smm_proposals").select("*").eq("client_id", token).order("created_at", { ascending: false }),
        supabase.from("smm_invoices").select("*").eq("client_id", token).order("created_at", { ascending: false }),
      ]);
      setClient(c);
      setProposals(p ?? []);
      setInvoices(i ?? []);
      setLoading(false);
    })();
  }, [token]);

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center text-muted-foreground">Loading…</div>;
  }
  if (!client) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4">
        <div className="text-center max-w-md">
          <h1 className="text-2xl font-semibold">Portal unavailable</h1>
          <p className="text-sm text-muted-foreground mt-2">This link may have expired or been revoked.</p>
        </div>
      </div>
    );
  }

  const totalOutstanding = invoices
    .filter((i) => i.status !== "paid")
    .reduce((acc, i) => acc + Number(i.amount ?? 0) - Number(i.amount_paid ?? 0), 0);

  return (
    <div className="min-h-screen bg-muted/30">
      {/* Brand header */}
      <header
        className="text-white"
        style={{
          background:
            "linear-gradient(135deg, var(--content), color-mix(in oklab, var(--content) 55%, black))",
        }}
      >
        <div className="max-w-5xl mx-auto px-6 py-10">
          <div className="flex items-center gap-3 text-xs uppercase tracking-[0.18em] opacity-80">
            <Sparkles className="h-3.5 w-3.5" />
            Client Portal
          </div>
          <h1 className="text-3xl md:text-4xl font-semibold mt-2">
            Welcome, {client.name}
          </h1>
          {client.company && (
            <p className="text-white/80 mt-1">{client.company}</p>
          )}
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-8 space-y-8">
        {/* Quick summary */}
        <div className="grid gap-3 md:grid-cols-3">
          <Card><CardContent className="p-4">
            <div className="text-[11px] uppercase tracking-wide text-muted-foreground font-medium">Proposals</div>
            <div className="text-2xl font-semibold tabular-nums mt-1">{proposals.length}</div>
          </CardContent></Card>
          <Card><CardContent className="p-4">
            <div className="text-[11px] uppercase tracking-wide text-muted-foreground font-medium">Invoices</div>
            <div className="text-2xl font-semibold tabular-nums mt-1">{invoices.length}</div>
          </CardContent></Card>
          <Card><CardContent className="p-4">
            <div className="text-[11px] uppercase tracking-wide text-muted-foreground font-medium">Outstanding</div>
            <div className="text-2xl font-semibold tabular-nums mt-1" style={{ color: "var(--content)" }}>
              ${totalOutstanding.toLocaleString()}
            </div>
          </CardContent></Card>
        </div>

        {/* Proposals */}
        <section>
          <h2 className="text-lg font-semibold flex items-center gap-2 mb-3">
            <FileText className="h-4 w-4" /> Proposals
          </h2>
          {proposals.length === 0 ? (
            <Card><CardContent className="p-6 text-sm text-muted-foreground text-center">No proposals yet.</CardContent></Card>
          ) : (
            <div className="space-y-2">
              {proposals.map((p) => (
                <Card key={p.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4 flex items-center justify-between gap-4">
                    <div className="min-w-0">
                      <div className="font-medium truncate">{p.title}</div>
                      <div className="text-xs text-muted-foreground mt-0.5">
                        {p.currency ?? "$"} {Number(p.amount ?? 0).toLocaleString()}
                        {p.valid_until && <> · Valid until {new Date(p.valid_until).toLocaleDateString()}</>}
                      </div>
                    </div>
                    <ProposalBadge status={p.status} />
                    {p.approval_token && p.status !== "accepted" && p.status !== "rejected" && (
                      <a
                        href={`/approval/${p.approval_token}`}
                        className="text-xs font-medium px-3 py-1.5 rounded-md text-white"
                        style={{ background: "var(--content)" }}
                      >
                        Review →
                      </a>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </section>

        {/* Invoices */}
        <section>
          <h2 className="text-lg font-semibold flex items-center gap-2 mb-3">
            <Receipt className="h-4 w-4" /> Invoices
          </h2>
          {invoices.length === 0 ? (
            <Card><CardContent className="p-6 text-sm text-muted-foreground text-center">No invoices yet.</CardContent></Card>
          ) : (
            <div className="space-y-2">
              {invoices.map((i) => (
                <Card key={i.id}>
                  <CardContent className="p-4 flex items-center justify-between gap-4">
                    <div className="min-w-0">
                      <div className="font-medium">Invoice {i.number}</div>
                      <div className="text-xs text-muted-foreground mt-0.5">
                        {i.currency ?? "$"} {Number(i.amount ?? 0).toLocaleString()}
                        {i.due_date && <> · Due {new Date(i.due_date).toLocaleDateString()}</>}
                      </div>
                    </div>
                    <InvoiceBadge status={i.status} />
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </section>

        <footer className="text-center text-xs text-muted-foreground pt-8 pb-4">
          Powered by KhanFly OS
        </footer>
      </main>
    </div>
  );
}

function ProposalBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; color: string; icon?: any }> = {
    draft: { label: "Draft", color: "var(--muted-foreground)" },
    sent: { label: "Awaiting review", color: "var(--research)", icon: Clock },
    accepted: { label: "Accepted", color: "var(--workforce)", icon: CheckCircle2 },
    rejected: { label: "Declined", color: "var(--destructive)" },
  };
  const s = map[status] ?? { label: status, color: "var(--muted-foreground)" };
  const I = s.icon;
  return (
    <Badge variant="outline" className="gap-1" style={{ color: s.color, borderColor: `color-mix(in oklab, ${s.color} 35%, transparent)` }}>
      {I && <I className="h-3 w-3" />} {s.label}
    </Badge>
  );
}
function InvoiceBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    draft: "var(--muted-foreground)",
    sent: "var(--research)",
    partial: "var(--bots)",
    paid: "var(--workforce)",
    overdue: "var(--destructive)",
  };
  const color = map[status] ?? "var(--muted-foreground)";
  return (
    <Badge variant="outline" style={{ color, borderColor: `color-mix(in oklab, ${color} 35%, transparent)` }} className="capitalize">
      {status}
    </Badge>
  );
}
