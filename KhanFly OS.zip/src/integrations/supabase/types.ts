export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      ai_agents: {
        Row: {
          agent_type: string
          config: Json
          created_at: string
          description: string | null
          id: string
          is_active: boolean
          last_run_at: string | null
          name: string
          org_id: string
          updated_at: string
        }
        Insert: {
          agent_type?: string
          config?: Json
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          last_run_at?: string | null
          name: string
          org_id: string
          updated_at?: string
        }
        Update: {
          agent_type?: string
          config?: Json
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          last_run_at?: string | null
          name?: string
          org_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "ai_agents_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      alert_notifications: {
        Row: {
          alert_id: string
          channel: string | null
          id: string
          org_id: string
          sent_at: string
          user_id: string
        }
        Insert: {
          alert_id: string
          channel?: string | null
          id?: string
          org_id: string
          sent_at?: string
          user_id: string
        }
        Update: {
          alert_id?: string
          channel?: string | null
          id?: string
          org_id?: string
          sent_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "alert_notifications_alert_id_fkey"
            columns: ["alert_id"]
            isOneToOne: false
            referencedRelation: "monitoring_alerts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "alert_notifications_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      analytics_events: {
        Row: {
          created_at: string
          event_name: string
          id: string
          module: Database["public"]["Enums"]["module_source"]
          org_id: string
          properties: Json
          user_id: string | null
        }
        Insert: {
          created_at?: string
          event_name: string
          id?: string
          module: Database["public"]["Enums"]["module_source"]
          org_id: string
          properties?: Json
          user_id?: string | null
        }
        Update: {
          created_at?: string
          event_name?: string
          id?: string
          module?: Database["public"]["Enums"]["module_source"]
          org_id?: string
          properties?: Json
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "analytics_events_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      analytics_goals: {
        Row: {
          created_at: string
          created_by: string | null
          current_value: number
          deadline: string | null
          description: string | null
          id: string
          metric_key: string
          module: string
          org_id: string
          target_value: number
          title: string
          unit: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          current_value?: number
          deadline?: string | null
          description?: string | null
          id?: string
          metric_key: string
          module: string
          org_id: string
          target_value?: number
          title: string
          unit?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          current_value?: number
          deadline?: string | null
          description?: string | null
          id?: string
          metric_key?: string
          module?: string
          org_id?: string
          target_value?: number
          title?: string
          unit?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "analytics_goals_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      analytics_insights: {
        Row: {
          created_at: string
          description: string
          dismissed: boolean
          id: string
          modules_involved: string[]
          org_id: string
          severity: string
          supporting_data: Json
          title: string
          type: string
        }
        Insert: {
          created_at?: string
          description?: string
          dismissed?: boolean
          id?: string
          modules_involved?: string[]
          org_id: string
          severity?: string
          supporting_data?: Json
          title: string
          type?: string
        }
        Update: {
          created_at?: string
          description?: string
          dismissed?: boolean
          id?: string
          modules_involved?: string[]
          org_id?: string
          severity?: string
          supporting_data?: Json
          title?: string
          type?: string
        }
        Relationships: [
          {
            foreignKeyName: "analytics_insights_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      analytics_snapshots: {
        Row: {
          created_at: string
          id: string
          metrics: Json
          module: string
          org_id: string
          snapshot_date: string
        }
        Insert: {
          created_at?: string
          id?: string
          metrics?: Json
          module: string
          org_id: string
          snapshot_date: string
        }
        Update: {
          created_at?: string
          id?: string
          metrics?: Json
          module?: string
          org_id?: string
          snapshot_date?: string
        }
        Relationships: [
          {
            foreignKeyName: "analytics_snapshots_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      announcements: {
        Row: {
          author_id: string | null
          content: string
          created_at: string
          expires_at: string | null
          id: string
          is_active: boolean
          org_id: string
          pinned: boolean
          priority: string | null
          title: string
        }
        Insert: {
          author_id?: string | null
          content: string
          created_at?: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          org_id: string
          pinned?: boolean
          priority?: string | null
          title: string
        }
        Update: {
          author_id?: string | null
          content?: string
          created_at?: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          org_id?: string
          pinned?: boolean
          priority?: string | null
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "announcements_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "announcements_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      asset_assignments: {
        Row: {
          asset_id: string
          assigned_at: string
          created_at: string
          employee_id: string
          id: string
          notes: string | null
          org_id: string
          returned_at: string | null
        }
        Insert: {
          asset_id: string
          assigned_at?: string
          created_at?: string
          employee_id: string
          id?: string
          notes?: string | null
          org_id: string
          returned_at?: string | null
        }
        Update: {
          asset_id?: string
          assigned_at?: string
          created_at?: string
          employee_id?: string
          id?: string
          notes?: string | null
          org_id?: string
          returned_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "asset_assignments_asset_id_fkey"
            columns: ["asset_id"]
            isOneToOne: false
            referencedRelation: "assets"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "asset_assignments_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "asset_assignments_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      assets: {
        Row: {
          asset_tag: string | null
          assigned_at: string | null
          assigned_to: string | null
          category: string | null
          created_at: string
          id: string
          name: string
          notes: string | null
          org_id: string
          purchase_cost: number | null
          purchase_date: string | null
          serial_number: string | null
          status: string
          updated_at: string
        }
        Insert: {
          asset_tag?: string | null
          assigned_at?: string | null
          assigned_to?: string | null
          category?: string | null
          created_at?: string
          id?: string
          name: string
          notes?: string | null
          org_id: string
          purchase_cost?: number | null
          purchase_date?: string | null
          serial_number?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          asset_tag?: string | null
          assigned_at?: string | null
          assigned_to?: string | null
          category?: string | null
          created_at?: string
          id?: string
          name?: string
          notes?: string | null
          org_id?: string
          purchase_cost?: number | null
          purchase_date?: string | null
          serial_number?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "assets_assigned_to_fkey"
            columns: ["assigned_to"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "assets_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      attendance_events: {
        Row: {
          created_at: string
          device_id: string | null
          employee_id: string
          event_type: Database["public"]["Enums"]["event_type"]
          id: string
          latitude: number | null
          location_accuracy: number | null
          longitude: number | null
          method: Database["public"]["Enums"]["attendance_method"]
          notes: string | null
          org_id: string
        }
        Insert: {
          created_at?: string
          device_id?: string | null
          employee_id: string
          event_type: Database["public"]["Enums"]["event_type"]
          id?: string
          latitude?: number | null
          location_accuracy?: number | null
          longitude?: number | null
          method?: Database["public"]["Enums"]["attendance_method"]
          notes?: string | null
          org_id: string
        }
        Update: {
          created_at?: string
          device_id?: string | null
          employee_id?: string
          event_type?: Database["public"]["Enums"]["event_type"]
          id?: string
          latitude?: number | null
          location_accuracy?: number | null
          longitude?: number | null
          method?: Database["public"]["Enums"]["attendance_method"]
          notes?: string | null
          org_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "attendance_events_device_id_fkey"
            columns: ["device_id"]
            isOneToOne: false
            referencedRelation: "device_keys"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "attendance_events_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "attendance_events_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      audit_log: {
        Row: {
          action: string
          created_at: string
          id: string
          ip_address: string | null
          new_values: Json | null
          old_values: Json | null
          org_id: string
          record_id: string | null
          source_module: Database["public"]["Enums"]["module_source"]
          table_name: string | null
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          action: string
          created_at?: string
          id?: string
          ip_address?: string | null
          new_values?: Json | null
          old_values?: Json | null
          org_id: string
          record_id?: string | null
          source_module?: Database["public"]["Enums"]["module_source"]
          table_name?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          action?: string
          created_at?: string
          id?: string
          ip_address?: string | null
          new_values?: Json | null
          old_values?: Json | null
          org_id?: string
          record_id?: string | null
          source_module?: Database["public"]["Enums"]["module_source"]
          table_name?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "audit_log_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      automation_actions: {
        Row: {
          action_type: string
          config: Json | null
          created_at: string
          id: string
          org_id: string
          rule_id: string
          sort_order: number | null
        }
        Insert: {
          action_type: string
          config?: Json | null
          created_at?: string
          id?: string
          org_id: string
          rule_id: string
          sort_order?: number | null
        }
        Update: {
          action_type?: string
          config?: Json | null
          created_at?: string
          id?: string
          org_id?: string
          rule_id?: string
          sort_order?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "automation_actions_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "automation_actions_rule_id_fkey"
            columns: ["rule_id"]
            isOneToOne: false
            referencedRelation: "automation_rules"
            referencedColumns: ["id"]
          },
        ]
      }
      automation_rules: {
        Row: {
          active: boolean | null
          bot_id: string | null
          config: Json | null
          created_at: string
          description: string | null
          id: string
          name: string
          org_id: string
          trigger_type: string
          updated_at: string
        }
        Insert: {
          active?: boolean | null
          bot_id?: string | null
          config?: Json | null
          created_at?: string
          description?: string | null
          id?: string
          name: string
          org_id: string
          trigger_type: string
          updated_at?: string
        }
        Update: {
          active?: boolean | null
          bot_id?: string | null
          config?: Json | null
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          org_id?: string
          trigger_type?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "automation_rules_bot_id_fkey"
            columns: ["bot_id"]
            isOneToOne: false
            referencedRelation: "bots"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "automation_rules_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      automation_triggers: {
        Row: {
          config: Json | null
          created_at: string
          event: string
          id: string
          org_id: string
          rule_id: string
        }
        Insert: {
          config?: Json | null
          created_at?: string
          event: string
          id?: string
          org_id: string
          rule_id: string
        }
        Update: {
          config?: Json | null
          created_at?: string
          event?: string
          id?: string
          org_id?: string
          rule_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "automation_triggers_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "automation_triggers_rule_id_fkey"
            columns: ["rule_id"]
            isOneToOne: false
            referencedRelation: "automation_rules"
            referencedColumns: ["id"]
          },
        ]
      }
      bot_analytics_daily: {
        Row: {
          ai_resolved: number | null
          avg_response_seconds: number | null
          bot_id: string | null
          conversations: number | null
          created_at: string
          date: string
          human_handoffs: number | null
          id: string
          leads_captured: number | null
          org_id: string
        }
        Insert: {
          ai_resolved?: number | null
          avg_response_seconds?: number | null
          bot_id?: string | null
          conversations?: number | null
          created_at?: string
          date: string
          human_handoffs?: number | null
          id?: string
          leads_captured?: number | null
          org_id: string
        }
        Update: {
          ai_resolved?: number | null
          avg_response_seconds?: number | null
          bot_id?: string | null
          conversations?: number | null
          created_at?: string
          date?: string
          human_handoffs?: number | null
          id?: string
          leads_captured?: number | null
          org_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "bot_analytics_daily_bot_id_fkey"
            columns: ["bot_id"]
            isOneToOne: false
            referencedRelation: "bots"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bot_analytics_daily_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      bot_broadcast_recipients: {
        Row: {
          broadcast_id: string
          contact_id: string | null
          created_at: string
          delivered_at: string | null
          error_message: string | null
          id: string
          org_id: string
          status: string | null
        }
        Insert: {
          broadcast_id: string
          contact_id?: string | null
          created_at?: string
          delivered_at?: string | null
          error_message?: string | null
          id?: string
          org_id: string
          status?: string | null
        }
        Update: {
          broadcast_id?: string
          contact_id?: string | null
          created_at?: string
          delivered_at?: string | null
          error_message?: string | null
          id?: string
          org_id?: string
          status?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "bot_broadcast_recipients_broadcast_id_fkey"
            columns: ["broadcast_id"]
            isOneToOne: false
            referencedRelation: "bot_broadcasts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bot_broadcast_recipients_contact_id_fkey"
            columns: ["contact_id"]
            isOneToOne: false
            referencedRelation: "bot_contacts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bot_broadcast_recipients_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      bot_broadcasts: {
        Row: {
          bot_id: string | null
          created_at: string
          created_by: string | null
          delivered_count: number | null
          id: string
          message: string | null
          message_preview: string | null
          name: string
          org_id: string
          platform: Database["public"]["Enums"]["bot_platform"] | null
          recipient_count: number | null
          scheduled_at: string | null
          segment: Json | null
          sent_at: string | null
          status: Database["public"]["Enums"]["broadcast_status"] | null
          updated_at: string
        }
        Insert: {
          bot_id?: string | null
          created_at?: string
          created_by?: string | null
          delivered_count?: number | null
          id?: string
          message?: string | null
          message_preview?: string | null
          name: string
          org_id: string
          platform?: Database["public"]["Enums"]["bot_platform"] | null
          recipient_count?: number | null
          scheduled_at?: string | null
          segment?: Json | null
          sent_at?: string | null
          status?: Database["public"]["Enums"]["broadcast_status"] | null
          updated_at?: string
        }
        Update: {
          bot_id?: string | null
          created_at?: string
          created_by?: string | null
          delivered_count?: number | null
          id?: string
          message?: string | null
          message_preview?: string | null
          name?: string
          org_id?: string
          platform?: Database["public"]["Enums"]["bot_platform"] | null
          recipient_count?: number | null
          scheduled_at?: string | null
          segment?: Json | null
          sent_at?: string | null
          status?: Database["public"]["Enums"]["broadcast_status"] | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "bot_broadcasts_bot_id_fkey"
            columns: ["bot_id"]
            isOneToOne: false
            referencedRelation: "bots"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bot_broadcasts_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      bot_channels: {
        Row: {
          bot_id: string
          created_at: string
          credentials: Json | null
          display_name: string | null
          external_id: string | null
          id: string
          is_active: boolean | null
          org_id: string
          platform: Database["public"]["Enums"]["bot_platform"]
          updated_at: string
          webhook_url: string | null
        }
        Insert: {
          bot_id: string
          created_at?: string
          credentials?: Json | null
          display_name?: string | null
          external_id?: string | null
          id?: string
          is_active?: boolean | null
          org_id: string
          platform: Database["public"]["Enums"]["bot_platform"]
          updated_at?: string
          webhook_url?: string | null
        }
        Update: {
          bot_id?: string
          created_at?: string
          credentials?: Json | null
          display_name?: string | null
          external_id?: string | null
          id?: string
          is_active?: boolean | null
          org_id?: string
          platform?: Database["public"]["Enums"]["bot_platform"]
          updated_at?: string
          webhook_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "bot_channels_bot_id_fkey"
            columns: ["bot_id"]
            isOneToOne: false
            referencedRelation: "bots"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bot_channels_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      bot_contact_attributes: {
        Row: {
          contact_id: string
          created_at: string
          id: string
          key: string
          org_id: string
          value: string | null
        }
        Insert: {
          contact_id: string
          created_at?: string
          id?: string
          key: string
          org_id: string
          value?: string | null
        }
        Update: {
          contact_id?: string
          created_at?: string
          id?: string
          key?: string
          org_id?: string
          value?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "bot_contact_attributes_contact_id_fkey"
            columns: ["contact_id"]
            isOneToOne: false
            referencedRelation: "bot_contacts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bot_contact_attributes_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      bot_contact_tags: {
        Row: {
          contact_id: string
          created_at: string
          id: string
          org_id: string
          tag: string
        }
        Insert: {
          contact_id: string
          created_at?: string
          id?: string
          org_id: string
          tag: string
        }
        Update: {
          contact_id?: string
          created_at?: string
          id?: string
          org_id?: string
          tag?: string
        }
        Relationships: [
          {
            foreignKeyName: "bot_contact_tags_contact_id_fkey"
            columns: ["contact_id"]
            isOneToOne: false
            referencedRelation: "bot_contacts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bot_contact_tags_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      bot_contacts: {
        Row: {
          attributes: Json | null
          avatar_url: string | null
          conversation_count: number | null
          created_at: string
          email: string | null
          external_id: string | null
          id: string
          last_seen_at: string | null
          lead_captured: boolean | null
          name: string | null
          org_id: string
          phone: string | null
          platform: Database["public"]["Enums"]["bot_platform"] | null
          updated_at: string
          username: string | null
        }
        Insert: {
          attributes?: Json | null
          avatar_url?: string | null
          conversation_count?: number | null
          created_at?: string
          email?: string | null
          external_id?: string | null
          id?: string
          last_seen_at?: string | null
          lead_captured?: boolean | null
          name?: string | null
          org_id: string
          phone?: string | null
          platform?: Database["public"]["Enums"]["bot_platform"] | null
          updated_at?: string
          username?: string | null
        }
        Update: {
          attributes?: Json | null
          avatar_url?: string | null
          conversation_count?: number | null
          created_at?: string
          email?: string | null
          external_id?: string | null
          id?: string
          last_seen_at?: string | null
          lead_captured?: boolean | null
          name?: string | null
          org_id?: string
          phone?: string | null
          platform?: Database["public"]["Enums"]["bot_platform"] | null
          updated_at?: string
          username?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "bot_contacts_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      bot_conversations: {
        Row: {
          bot_id: string | null
          channel: string | null
          channel_id: string | null
          contact_id: string | null
          created_at: string
          id: string
          last_message_at: string | null
          lead_captured: boolean | null
          message_count: number | null
          org_id: string
          platform: Database["public"]["Enums"]["bot_platform"] | null
          resolved_by: Database["public"]["Enums"]["bot_resolution"] | null
          satisfaction_score: number | null
          status: string | null
          updated_at: string
        }
        Insert: {
          bot_id?: string | null
          channel?: string | null
          channel_id?: string | null
          contact_id?: string | null
          created_at?: string
          id?: string
          last_message_at?: string | null
          lead_captured?: boolean | null
          message_count?: number | null
          org_id: string
          platform?: Database["public"]["Enums"]["bot_platform"] | null
          resolved_by?: Database["public"]["Enums"]["bot_resolution"] | null
          satisfaction_score?: number | null
          status?: string | null
          updated_at?: string
        }
        Update: {
          bot_id?: string | null
          channel?: string | null
          channel_id?: string | null
          contact_id?: string | null
          created_at?: string
          id?: string
          last_message_at?: string | null
          lead_captured?: boolean | null
          message_count?: number | null
          org_id?: string
          platform?: Database["public"]["Enums"]["bot_platform"] | null
          resolved_by?: Database["public"]["Enums"]["bot_resolution"] | null
          satisfaction_score?: number | null
          status?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "bot_conversations_bot_id_fkey"
            columns: ["bot_id"]
            isOneToOne: false
            referencedRelation: "bots"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bot_conversations_channel_id_fkey"
            columns: ["channel_id"]
            isOneToOne: false
            referencedRelation: "bot_channels"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bot_conversations_contact_id_fkey"
            columns: ["contact_id"]
            isOneToOne: false
            referencedRelation: "bot_contacts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bot_conversations_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      bot_edges: {
        Row: {
          condition: Json | null
          created_at: string
          flow_id: string
          id: string
          label: string | null
          org_id: string
          source_node: string
          target_node: string
        }
        Insert: {
          condition?: Json | null
          created_at?: string
          flow_id: string
          id?: string
          label?: string | null
          org_id: string
          source_node: string
          target_node: string
        }
        Update: {
          condition?: Json | null
          created_at?: string
          flow_id?: string
          id?: string
          label?: string | null
          org_id?: string
          source_node?: string
          target_node?: string
        }
        Relationships: [
          {
            foreignKeyName: "bot_edges_flow_id_fkey"
            columns: ["flow_id"]
            isOneToOne: false
            referencedRelation: "bot_flows"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bot_edges_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bot_edges_source_node_fkey"
            columns: ["source_node"]
            isOneToOne: false
            referencedRelation: "bot_nodes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bot_edges_target_node_fkey"
            columns: ["target_node"]
            isOneToOne: false
            referencedRelation: "bot_nodes"
            referencedColumns: ["id"]
          },
        ]
      }
      bot_flows: {
        Row: {
          bot_id: string
          created_at: string
          data: Json
          id: string
          is_published: boolean | null
          name: string
          org_id: string
          updated_at: string
          version: number
        }
        Insert: {
          bot_id: string
          created_at?: string
          data?: Json
          id?: string
          is_published?: boolean | null
          name?: string
          org_id: string
          updated_at?: string
          version?: number
        }
        Update: {
          bot_id?: string
          created_at?: string
          data?: Json
          id?: string
          is_published?: boolean | null
          name?: string
          org_id?: string
          updated_at?: string
          version?: number
        }
        Relationships: [
          {
            foreignKeyName: "bot_flows_bot_id_fkey"
            columns: ["bot_id"]
            isOneToOne: false
            referencedRelation: "bots"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bot_flows_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      bot_messages: {
        Row: {
          ai_confidence: number | null
          content: string | null
          conversation_id: string | null
          created_at: string
          direction: Database["public"]["Enums"]["bot_msg_direction"]
          id: string
          media_url: string | null
          metadata: Json | null
          org_id: string
          sender: string | null
        }
        Insert: {
          ai_confidence?: number | null
          content?: string | null
          conversation_id?: string | null
          created_at?: string
          direction: Database["public"]["Enums"]["bot_msg_direction"]
          id?: string
          media_url?: string | null
          metadata?: Json | null
          org_id: string
          sender?: string | null
        }
        Update: {
          ai_confidence?: number | null
          content?: string | null
          conversation_id?: string | null
          created_at?: string
          direction?: Database["public"]["Enums"]["bot_msg_direction"]
          id?: string
          media_url?: string | null
          metadata?: Json | null
          org_id?: string
          sender?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "bot_messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "bot_conversations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bot_messages_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      bot_nodes: {
        Row: {
          config: Json
          created_at: string
          flow_id: string
          id: string
          node_type: string
          org_id: string
          position: Json | null
        }
        Insert: {
          config?: Json
          created_at?: string
          flow_id: string
          id?: string
          node_type: string
          org_id: string
          position?: Json | null
        }
        Update: {
          config?: Json
          created_at?: string
          flow_id?: string
          id?: string
          node_type?: string
          org_id?: string
          position?: Json | null
        }
        Relationships: [
          {
            foreignKeyName: "bot_nodes_flow_id_fkey"
            columns: ["flow_id"]
            isOneToOne: false
            referencedRelation: "bot_flows"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bot_nodes_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      bot_template_categories: {
        Row: {
          created_at: string
          description: string | null
          id: string
          name: string
          org_id: string
          sort_order: number | null
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          name: string
          org_id: string
          sort_order?: number | null
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          org_id?: string
          sort_order?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "bot_template_categories_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      bot_templates: {
        Row: {
          category_id: string | null
          created_at: string
          description: string | null
          flow_data: Json
          id: string
          is_official: boolean | null
          name: string
          org_id: string
          preview_image: string | null
          updated_at: string
          use_count: number | null
        }
        Insert: {
          category_id?: string | null
          created_at?: string
          description?: string | null
          flow_data?: Json
          id?: string
          is_official?: boolean | null
          name: string
          org_id: string
          preview_image?: string | null
          updated_at?: string
          use_count?: number | null
        }
        Update: {
          category_id?: string | null
          created_at?: string
          description?: string | null
          flow_data?: Json
          id?: string
          is_official?: boolean | null
          name?: string
          org_id?: string
          preview_image?: string | null
          updated_at?: string
          use_count?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "bot_templates_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "bot_template_categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bot_templates_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      bot_variables: {
        Row: {
          bot_id: string
          created_at: string
          default_value: string | null
          id: string
          key: string
          org_id: string
          scope: string | null
        }
        Insert: {
          bot_id: string
          created_at?: string
          default_value?: string | null
          id?: string
          key: string
          org_id: string
          scope?: string | null
        }
        Update: {
          bot_id?: string
          created_at?: string
          default_value?: string | null
          id?: string
          key?: string
          org_id?: string
          scope?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "bot_variables_bot_id_fkey"
            columns: ["bot_id"]
            isOneToOne: false
            referencedRelation: "bots"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bot_variables_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      bots: {
        Row: {
          avatar_url: string | null
          created_at: string
          created_by: string | null
          description: string | null
          emoji: string | null
          id: string
          name: string
          org_id: string
          settings: Json
          status: Database["public"]["Enums"]["bot_status"]
          template_id: string | null
          template_name: string | null
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          emoji?: string | null
          id?: string
          name: string
          org_id: string
          settings?: Json
          status?: Database["public"]["Enums"]["bot_status"]
          template_id?: string | null
          template_name?: string | null
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          emoji?: string | null
          id?: string
          name?: string
          org_id?: string
          settings?: Json
          status?: Database["public"]["Enums"]["bot_status"]
          template_id?: string | null
          template_name?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "bots_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bots_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "bot_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      chat_channels: {
        Row: {
          created_at: string
          created_by: string | null
          description: string | null
          id: string
          is_archived: boolean | null
          name: string
          org_id: string
          type: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          is_archived?: boolean | null
          name: string
          org_id: string
          type?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          is_archived?: boolean | null
          name?: string
          org_id?: string
          type?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "chat_channels_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "chat_channels_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      chat_members: {
        Row: {
          channel_id: string
          created_at: string
          employee_id: string
          id: string
          joined_at: string
          org_id: string
          role: string | null
        }
        Insert: {
          channel_id: string
          created_at?: string
          employee_id: string
          id?: string
          joined_at?: string
          org_id: string
          role?: string | null
        }
        Update: {
          channel_id?: string
          created_at?: string
          employee_id?: string
          id?: string
          joined_at?: string
          org_id?: string
          role?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "chat_members_channel_id_fkey"
            columns: ["channel_id"]
            isOneToOne: false
            referencedRelation: "chat_channels"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "chat_members_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "chat_members_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      chat_messages: {
        Row: {
          channel_id: string
          content: string
          created_at: string
          id: string
          is_edited: boolean | null
          org_id: string
          reply_to: string | null
          sender_id: string
        }
        Insert: {
          channel_id: string
          content: string
          created_at?: string
          id?: string
          is_edited?: boolean | null
          org_id: string
          reply_to?: string | null
          sender_id: string
        }
        Update: {
          channel_id?: string
          content?: string
          created_at?: string
          id?: string
          is_edited?: boolean | null
          org_id?: string
          reply_to?: string | null
          sender_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "chat_messages_channel_id_fkey"
            columns: ["channel_id"]
            isOneToOne: false
            referencedRelation: "chat_channels"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "chat_messages_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "chat_messages_reply_to_fkey"
            columns: ["reply_to"]
            isOneToOne: false
            referencedRelation: "chat_messages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "chat_messages_sender_id_fkey"
            columns: ["sender_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
        ]
      }
      competitor_posts: {
        Row: {
          competitor_id: string
          content: string | null
          created_at: string
          engagement: number | null
          id: string
          org_id: string
          platform: Database["public"]["Enums"]["social_platform"] | null
          posted_at: string | null
          url: string | null
        }
        Insert: {
          competitor_id: string
          content?: string | null
          created_at?: string
          engagement?: number | null
          id?: string
          org_id: string
          platform?: Database["public"]["Enums"]["social_platform"] | null
          posted_at?: string | null
          url?: string | null
        }
        Update: {
          competitor_id?: string
          content?: string | null
          created_at?: string
          engagement?: number | null
          id?: string
          org_id?: string
          platform?: Database["public"]["Enums"]["social_platform"] | null
          posted_at?: string | null
          url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "competitor_posts_competitor_id_fkey"
            columns: ["competitor_id"]
            isOneToOne: false
            referencedRelation: "monitoring_competitors"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "competitor_posts_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      course_enrollments: {
        Row: {
          completed_at: string | null
          course_id: string
          created_at: string
          employee_id: string
          enrolled_at: string
          id: string
          org_id: string
          progress: number | null
        }
        Insert: {
          completed_at?: string | null
          course_id: string
          created_at?: string
          employee_id: string
          enrolled_at?: string
          id?: string
          org_id: string
          progress?: number | null
        }
        Update: {
          completed_at?: string | null
          course_id?: string
          created_at?: string
          employee_id?: string
          enrolled_at?: string
          id?: string
          org_id?: string
          progress?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "course_enrollments_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "course_enrollments_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "course_enrollments_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      courses: {
        Row: {
          category: string | null
          cover_url: string | null
          created_at: string
          created_by: string | null
          description: string | null
          duration_minutes: number | null
          id: string
          is_published: boolean
          org_id: string
          title: string
          updated_at: string
        }
        Insert: {
          category?: string | null
          cover_url?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          duration_minutes?: number | null
          id?: string
          is_published?: boolean
          org_id: string
          title: string
          updated_at?: string
        }
        Update: {
          category?: string | null
          cover_url?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          duration_minutes?: number | null
          id?: string
          is_published?: boolean
          org_id?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "courses_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "courses_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      departments: {
        Row: {
          created_at: string
          description: string | null
          id: string
          manager_id: string | null
          name: string
          org_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          manager_id?: string | null
          name: string
          org_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          manager_id?: string | null
          name?: string
          org_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "departments_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "departments_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      device_keys: {
        Row: {
          api_key: string
          created_at: string
          device_type: Database["public"]["Enums"]["device_type"]
          id: string
          is_active: boolean
          last_heartbeat: string | null
          location: string | null
          mac_address: string | null
          name: string
          org_id: string
          updated_at: string
        }
        Insert: {
          api_key?: string
          created_at?: string
          device_type: Database["public"]["Enums"]["device_type"]
          id?: string
          is_active?: boolean
          last_heartbeat?: string | null
          location?: string | null
          mac_address?: string | null
          name: string
          org_id: string
          updated_at?: string
        }
        Update: {
          api_key?: string
          created_at?: string
          device_type?: Database["public"]["Enums"]["device_type"]
          id?: string
          is_active?: boolean
          last_heartbeat?: string | null
          location?: string | null
          mac_address?: string | null
          name?: string
          org_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "device_keys_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      employees: {
        Row: {
          avatar_url: string | null
          created_at: string
          department_id: string | null
          email: string | null
          employee_code: string | null
          full_name: string
          hire_date: string | null
          id: string
          is_active: boolean
          nfc_card_id: string | null
          org_id: string
          phone: string | null
          position: string | null
          salary: number | null
          updated_at: string
          user_id: string | null
          work_hours_per_day: number | null
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          department_id?: string | null
          email?: string | null
          employee_code?: string | null
          full_name: string
          hire_date?: string | null
          id?: string
          is_active?: boolean
          nfc_card_id?: string | null
          org_id: string
          phone?: string | null
          position?: string | null
          salary?: number | null
          updated_at?: string
          user_id?: string | null
          work_hours_per_day?: number | null
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          department_id?: string | null
          email?: string | null
          employee_code?: string | null
          full_name?: string
          hire_date?: string | null
          id?: string
          is_active?: boolean
          nfc_card_id?: string | null
          org_id?: string
          phone?: string | null
          position?: string | null
          salary?: number | null
          updated_at?: string
          user_id?: string | null
          work_hours_per_day?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "employees_dept_fk"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employees_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      handoff_requests: {
        Row: {
          accepted_at: string | null
          accepted_by: string | null
          bot_id: string | null
          conversation_id: string | null
          created_at: string
          id: string
          org_id: string
          reason: string | null
          resolved_at: string | null
          status: Database["public"]["Enums"]["handoff_status"]
        }
        Insert: {
          accepted_at?: string | null
          accepted_by?: string | null
          bot_id?: string | null
          conversation_id?: string | null
          created_at?: string
          id?: string
          org_id: string
          reason?: string | null
          resolved_at?: string | null
          status?: Database["public"]["Enums"]["handoff_status"]
        }
        Update: {
          accepted_at?: string | null
          accepted_by?: string | null
          bot_id?: string | null
          conversation_id?: string | null
          created_at?: string
          id?: string
          org_id?: string
          reason?: string | null
          resolved_at?: string | null
          status?: Database["public"]["Enums"]["handoff_status"]
        }
        Relationships: [
          {
            foreignKeyName: "handoff_requests_bot_id_fkey"
            columns: ["bot_id"]
            isOneToOne: false
            referencedRelation: "bots"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "handoff_requests_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "bot_conversations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "handoff_requests_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      helpdesk_ticket_comments: {
        Row: {
          author_id: string
          content: string
          created_at: string
          id: string
          org_id: string
          ticket_id: string
        }
        Insert: {
          author_id: string
          content: string
          created_at?: string
          id?: string
          org_id: string
          ticket_id: string
        }
        Update: {
          author_id?: string
          content?: string
          created_at?: string
          id?: string
          org_id?: string
          ticket_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "helpdesk_ticket_comments_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "helpdesk_ticket_comments_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "helpdesk_ticket_comments_ticket_id_fkey"
            columns: ["ticket_id"]
            isOneToOne: false
            referencedRelation: "helpdesk_tickets"
            referencedColumns: ["id"]
          },
        ]
      }
      helpdesk_tickets: {
        Row: {
          assignee_id: string | null
          category: string | null
          created_at: string
          description: string | null
          id: string
          org_id: string
          priority: Database["public"]["Enums"]["task_priority"]
          reporter_id: string | null
          resolved_at: string | null
          status: string
          title: string
          updated_at: string
        }
        Insert: {
          assignee_id?: string | null
          category?: string | null
          created_at?: string
          description?: string | null
          id?: string
          org_id: string
          priority?: Database["public"]["Enums"]["task_priority"]
          reporter_id?: string | null
          resolved_at?: string | null
          status?: string
          title: string
          updated_at?: string
        }
        Update: {
          assignee_id?: string | null
          category?: string | null
          created_at?: string
          description?: string | null
          id?: string
          org_id?: string
          priority?: Database["public"]["Enums"]["task_priority"]
          reporter_id?: string | null
          resolved_at?: string | null
          status?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "helpdesk_tickets_assignee_id_fkey"
            columns: ["assignee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "helpdesk_tickets_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "helpdesk_tickets_reporter_id_fkey"
            columns: ["reporter_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
        ]
      }
      keyword_mentions: {
        Row: {
          count: number
          created_at: string
          date: string
          id: string
          keyword_id: string | null
          keyword_term: string
          org_id: string
          platform: Database["public"]["Enums"]["social_platform"] | null
          sample_post_id: string | null
          url: string | null
        }
        Insert: {
          count?: number
          created_at?: string
          date?: string
          id?: string
          keyword_id?: string | null
          keyword_term: string
          org_id: string
          platform?: Database["public"]["Enums"]["social_platform"] | null
          sample_post_id?: string | null
          url?: string | null
        }
        Update: {
          count?: number
          created_at?: string
          date?: string
          id?: string
          keyword_id?: string | null
          keyword_term?: string
          org_id?: string
          platform?: Database["public"]["Enums"]["social_platform"] | null
          sample_post_id?: string | null
          url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "keyword_mentions_keyword_id_fkey"
            columns: ["keyword_id"]
            isOneToOne: false
            referencedRelation: "monitoring_keywords"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "keyword_mentions_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "keyword_mentions_sample_post_id_fkey"
            columns: ["sample_post_id"]
            isOneToOne: false
            referencedRelation: "monitoring_posts"
            referencedColumns: ["id"]
          },
        ]
      }
      knowledge_base_items: {
        Row: {
          answer: string | null
          category: string | null
          created_at: string
          embedding_status: string | null
          id: string
          org_id: string
          question: string | null
          source_id: string | null
          tags: string[] | null
          title: string | null
          updated_at: string
        }
        Insert: {
          answer?: string | null
          category?: string | null
          created_at?: string
          embedding_status?: string | null
          id?: string
          org_id: string
          question?: string | null
          source_id?: string | null
          tags?: string[] | null
          title?: string | null
          updated_at?: string
        }
        Update: {
          answer?: string | null
          category?: string | null
          created_at?: string
          embedding_status?: string | null
          id?: string
          org_id?: string
          question?: string | null
          source_id?: string | null
          tags?: string[] | null
          title?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "knowledge_base_items_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "knowledge_base_items_source_id_fkey"
            columns: ["source_id"]
            isOneToOne: false
            referencedRelation: "knowledge_base_sources"
            referencedColumns: ["id"]
          },
        ]
      }
      knowledge_base_sources: {
        Row: {
          bot_id: string | null
          created_at: string
          id: string
          item_count: number | null
          name: string
          org_id: string
          source_type: string
          status: string | null
          updated_at: string
          url: string | null
        }
        Insert: {
          bot_id?: string | null
          created_at?: string
          id?: string
          item_count?: number | null
          name: string
          org_id: string
          source_type: string
          status?: string | null
          updated_at?: string
          url?: string | null
        }
        Update: {
          bot_id?: string | null
          created_at?: string
          id?: string
          item_count?: number | null
          name?: string
          org_id?: string
          source_type?: string
          status?: string | null
          updated_at?: string
          url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "knowledge_base_sources_bot_id_fkey"
            columns: ["bot_id"]
            isOneToOne: false
            referencedRelation: "bots"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "knowledge_base_sources_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      kpi_records: {
        Row: {
          category: string | null
          created_at: string
          created_by: string | null
          current_value: number
          employee_id: string
          id: string
          metric_name: string
          notes: string | null
          org_id: string
          period_end: string
          period_start: string
          target_value: number
          unit: string | null
          updated_at: string
        }
        Insert: {
          category?: string | null
          created_at?: string
          created_by?: string | null
          current_value?: number
          employee_id: string
          id?: string
          metric_name: string
          notes?: string | null
          org_id: string
          period_end: string
          period_start: string
          target_value?: number
          unit?: string | null
          updated_at?: string
        }
        Update: {
          category?: string | null
          created_at?: string
          created_by?: string | null
          current_value?: number
          employee_id?: string
          id?: string
          metric_name?: string
          notes?: string | null
          org_id?: string
          period_end?: string
          period_start?: string
          target_value?: number
          unit?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "kpi_records_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "kpi_records_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "kpi_records_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      kudos: {
        Row: {
          category: string
          created_at: string
          emoji: string | null
          id: string
          message: string
          org_id: string
          receiver_id: string
          sender_id: string
        }
        Insert: {
          category?: string
          created_at?: string
          emoji?: string | null
          id?: string
          message: string
          org_id: string
          receiver_id: string
          sender_id: string
        }
        Update: {
          category?: string
          created_at?: string
          emoji?: string | null
          id?: string
          message?: string
          org_id?: string
          receiver_id?: string
          sender_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "kudos_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "kudos_receiver_id_fkey"
            columns: ["receiver_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "kudos_sender_id_fkey"
            columns: ["sender_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
        ]
      }
      leave_balances: {
        Row: {
          created_at: string
          employee_id: string | null
          id: string
          leave_type: Database["public"]["Enums"]["leave_type"]
          org_id: string
          total_days: number
          updated_at: string
          used_days: number
          year: number
        }
        Insert: {
          created_at?: string
          employee_id?: string | null
          id?: string
          leave_type: Database["public"]["Enums"]["leave_type"]
          org_id: string
          total_days?: number
          updated_at?: string
          used_days?: number
          year?: number
        }
        Update: {
          created_at?: string
          employee_id?: string | null
          id?: string
          leave_type?: Database["public"]["Enums"]["leave_type"]
          org_id?: string
          total_days?: number
          updated_at?: string
          used_days?: number
          year?: number
        }
        Relationships: [
          {
            foreignKeyName: "leave_balances_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_balances_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      leave_requests: {
        Row: {
          created_at: string
          employee_id: string
          end_date: string
          id: string
          leave_type: Database["public"]["Enums"]["leave_type"]
          org_id: string
          reason: string | null
          review_notes: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          start_date: string
          status: Database["public"]["Enums"]["leave_status"]
          updated_at: string
        }
        Insert: {
          created_at?: string
          employee_id: string
          end_date: string
          id?: string
          leave_type: Database["public"]["Enums"]["leave_type"]
          org_id: string
          reason?: string | null
          review_notes?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          start_date: string
          status?: Database["public"]["Enums"]["leave_status"]
          updated_at?: string
        }
        Update: {
          created_at?: string
          employee_id?: string
          end_date?: string
          id?: string
          leave_type?: Database["public"]["Enums"]["leave_type"]
          org_id?: string
          reason?: string | null
          review_notes?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          start_date?: string
          status?: Database["public"]["Enums"]["leave_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "leave_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_requests_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_requests_reviewed_by_fkey"
            columns: ["reviewed_by"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
        ]
      }
      live_chat_sessions: {
        Row: {
          agent_id: string | null
          conversation_id: string | null
          created_at: string
          ended_at: string | null
          id: string
          org_id: string
          started_at: string
          status: string | null
        }
        Insert: {
          agent_id?: string | null
          conversation_id?: string | null
          created_at?: string
          ended_at?: string | null
          id?: string
          org_id: string
          started_at?: string
          status?: string | null
        }
        Update: {
          agent_id?: string | null
          conversation_id?: string | null
          created_at?: string
          ended_at?: string | null
          id?: string
          org_id?: string
          started_at?: string
          status?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "live_chat_sessions_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "bot_conversations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "live_chat_sessions_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      mn_bank_accounts: {
        Row: {
          account_last4: string | null
          account_name: string | null
          account_number: string
          bank_code: string | null
          bank_name: string
          created_at: string
          entity_id: string | null
          entity_type: string
          id: string
          is_primary: boolean
          org_id: string
          qpay_id: string | null
          updated_at: string
          verified: boolean
          verified_at: string | null
          verified_name: string | null
        }
        Insert: {
          account_last4?: string | null
          account_name?: string | null
          account_number: string
          bank_code?: string | null
          bank_name: string
          created_at?: string
          entity_id?: string | null
          entity_type: string
          id?: string
          is_primary?: boolean
          org_id: string
          qpay_id?: string | null
          updated_at?: string
          verified?: boolean
          verified_at?: string | null
          verified_name?: string | null
        }
        Update: {
          account_last4?: string | null
          account_name?: string | null
          account_number?: string
          bank_code?: string | null
          bank_name?: string
          created_at?: string
          entity_id?: string | null
          entity_type?: string
          id?: string
          is_primary?: boolean
          org_id?: string
          qpay_id?: string | null
          updated_at?: string
          verified?: boolean
          verified_at?: string | null
          verified_name?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "mn_bank_accounts_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      mn_payment_config: {
        Row: {
          active: boolean
          aml_daily_threshold: number
          aml_single_threshold: number
          created_at: string
          enabled_banks: string[]
          environment: string
          ewa_fee_percent: number
          ewa_limit_percent: number
          ewa_max_amount: number
          ewa_max_per_day: number
          ewa_max_per_month: number
          ewa_min_amount: number
          frc_license_expiry: string | null
          frc_license_number: string | null
          id: string
          khanbank_account_number: string | null
          merchant_id: string | null
          org_id: string
          provider: string
          qpay_invoice_code: string | null
          updated_at: string
        }
        Insert: {
          active?: boolean
          aml_daily_threshold?: number
          aml_single_threshold?: number
          created_at?: string
          enabled_banks?: string[]
          environment?: string
          ewa_fee_percent?: number
          ewa_limit_percent?: number
          ewa_max_amount?: number
          ewa_max_per_day?: number
          ewa_max_per_month?: number
          ewa_min_amount?: number
          frc_license_expiry?: string | null
          frc_license_number?: string | null
          id?: string
          khanbank_account_number?: string | null
          merchant_id?: string | null
          org_id: string
          provider?: string
          qpay_invoice_code?: string | null
          updated_at?: string
        }
        Update: {
          active?: boolean
          aml_daily_threshold?: number
          aml_single_threshold?: number
          created_at?: string
          enabled_banks?: string[]
          environment?: string
          ewa_fee_percent?: number
          ewa_limit_percent?: number
          ewa_max_amount?: number
          ewa_max_per_day?: number
          ewa_max_per_month?: number
          ewa_min_amount?: number
          frc_license_expiry?: string | null
          frc_license_number?: string | null
          id?: string
          khanbank_account_number?: string | null
          merchant_id?: string | null
          org_id?: string
          provider?: string
          qpay_invoice_code?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "mn_payment_config_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: true
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      monitoring_alerts: {
        Row: {
          created_at: string
          description: string | null
          id: string
          org_id: string
          resolution_hours: number | null
          resolved_at: string | null
          resolved_by: string | null
          sentiment_score: number | null
          severity: Database["public"]["Enums"]["alert_severity"]
          source_platform: Database["public"]["Enums"]["social_platform"] | null
          source_post_id: string | null
          source_url: string | null
          status: Database["public"]["Enums"]["alert_status"]
          title: string
          triggered_keyword: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          org_id: string
          resolution_hours?: number | null
          resolved_at?: string | null
          resolved_by?: string | null
          sentiment_score?: number | null
          severity?: Database["public"]["Enums"]["alert_severity"]
          source_platform?:
            | Database["public"]["Enums"]["social_platform"]
            | null
          source_post_id?: string | null
          source_url?: string | null
          status?: Database["public"]["Enums"]["alert_status"]
          title: string
          triggered_keyword?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          org_id?: string
          resolution_hours?: number | null
          resolved_at?: string | null
          resolved_by?: string | null
          sentiment_score?: number | null
          severity?: Database["public"]["Enums"]["alert_severity"]
          source_platform?:
            | Database["public"]["Enums"]["social_platform"]
            | null
          source_post_id?: string | null
          source_url?: string | null
          status?: Database["public"]["Enums"]["alert_status"]
          title?: string
          triggered_keyword?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "monitoring_alerts_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "monitoring_alerts_source_post_id_fkey"
            columns: ["source_post_id"]
            isOneToOne: false
            referencedRelation: "monitoring_posts"
            referencedColumns: ["id"]
          },
        ]
      }
      monitoring_competitors: {
        Row: {
          active: boolean
          created_at: string
          engagement_avg: number | null
          follower_count: number | null
          handle: string | null
          id: string
          last_post_at: string | null
          name: string
          notes: string | null
          org_id: string
          platform: Database["public"]["Enums"]["social_platform"] | null
          swot: Json | null
          updated_at: string
          url: string | null
        }
        Insert: {
          active?: boolean
          created_at?: string
          engagement_avg?: number | null
          follower_count?: number | null
          handle?: string | null
          id?: string
          last_post_at?: string | null
          name: string
          notes?: string | null
          org_id: string
          platform?: Database["public"]["Enums"]["social_platform"] | null
          swot?: Json | null
          updated_at?: string
          url?: string | null
        }
        Update: {
          active?: boolean
          created_at?: string
          engagement_avg?: number | null
          follower_count?: number | null
          handle?: string | null
          id?: string
          last_post_at?: string | null
          name?: string
          notes?: string | null
          org_id?: string
          platform?: Database["public"]["Enums"]["social_platform"] | null
          swot?: Json | null
          updated_at?: string
          url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "monitoring_competitors_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      monitoring_keywords: {
        Row: {
          category: string | null
          created_at: string
          created_by: string | null
          id: string
          is_active: boolean
          mention_count_total: number
          org_id: string
          term: string
          updated_at: string
          variations: string[] | null
        }
        Insert: {
          category?: string | null
          created_at?: string
          created_by?: string | null
          id?: string
          is_active?: boolean
          mention_count_total?: number
          org_id: string
          term: string
          updated_at?: string
          variations?: string[] | null
        }
        Update: {
          category?: string | null
          created_at?: string
          created_by?: string | null
          id?: string
          is_active?: boolean
          mention_count_total?: number
          org_id?: string
          term?: string
          updated_at?: string
          variations?: string[] | null
        }
        Relationships: [
          {
            foreignKeyName: "monitoring_keywords_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      monitoring_posts: {
        Row: {
          author: string | null
          content: string
          created_at: string
          engagement: number | null
          id: string
          matched_keyword: string | null
          matched_keyword_id: string | null
          org_id: string
          platform: Database["public"]["Enums"]["social_platform"]
          posted_at: string | null
          sentiment: Database["public"]["Enums"]["sentiment_label"] | null
          sentiment_score: number | null
          source_id: string | null
          source_name: string | null
          source_url: string | null
        }
        Insert: {
          author?: string | null
          content: string
          created_at?: string
          engagement?: number | null
          id?: string
          matched_keyword?: string | null
          matched_keyword_id?: string | null
          org_id: string
          platform: Database["public"]["Enums"]["social_platform"]
          posted_at?: string | null
          sentiment?: Database["public"]["Enums"]["sentiment_label"] | null
          sentiment_score?: number | null
          source_id?: string | null
          source_name?: string | null
          source_url?: string | null
        }
        Update: {
          author?: string | null
          content?: string
          created_at?: string
          engagement?: number | null
          id?: string
          matched_keyword?: string | null
          matched_keyword_id?: string | null
          org_id?: string
          platform?: Database["public"]["Enums"]["social_platform"]
          posted_at?: string | null
          sentiment?: Database["public"]["Enums"]["sentiment_label"] | null
          sentiment_score?: number | null
          source_id?: string | null
          source_name?: string | null
          source_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "monitoring_posts_matched_keyword_id_fkey"
            columns: ["matched_keyword_id"]
            isOneToOne: false
            referencedRelation: "monitoring_keywords"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "monitoring_posts_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "monitoring_posts_source_id_fkey"
            columns: ["source_id"]
            isOneToOne: false
            referencedRelation: "monitoring_sources"
            referencedColumns: ["id"]
          },
        ]
      }
      monitoring_reports: {
        Row: {
          created_at: string
          data: Json | null
          file_url: string | null
          generated_by: string | null
          id: string
          org_id: string
          period: string | null
          summary: string | null
          title: string
          type: string | null
        }
        Insert: {
          created_at?: string
          data?: Json | null
          file_url?: string | null
          generated_by?: string | null
          id?: string
          org_id: string
          period?: string | null
          summary?: string | null
          title: string
          type?: string | null
        }
        Update: {
          created_at?: string
          data?: Json | null
          file_url?: string | null
          generated_by?: string | null
          id?: string
          org_id?: string
          period?: string | null
          summary?: string | null
          title?: string
          type?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "monitoring_reports_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      monitoring_sources: {
        Row: {
          created_at: string
          display_name: string | null
          handle: string
          id: string
          is_active: boolean
          last_synced_at: string | null
          org_id: string
          platform: Database["public"]["Enums"]["social_platform"]
          updated_at: string
          url: string | null
        }
        Insert: {
          created_at?: string
          display_name?: string | null
          handle: string
          id?: string
          is_active?: boolean
          last_synced_at?: string | null
          org_id: string
          platform: Database["public"]["Enums"]["social_platform"]
          updated_at?: string
          url?: string | null
        }
        Update: {
          created_at?: string
          display_name?: string | null
          handle?: string
          id?: string
          is_active?: boolean
          last_synced_at?: string | null
          org_id?: string
          platform?: Database["public"]["Enums"]["social_platform"]
          updated_at?: string
          url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "monitoring_sources_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      mood_checkins: {
        Row: {
          created_at: string
          employee_id: string
          energy_level: number | null
          id: string
          is_anonymous: boolean | null
          mood_score: number
          notes: string | null
          org_id: string
          stress_level: number | null
        }
        Insert: {
          created_at?: string
          employee_id: string
          energy_level?: number | null
          id?: string
          is_anonymous?: boolean | null
          mood_score?: number
          notes?: string | null
          org_id: string
          stress_level?: number | null
        }
        Update: {
          created_at?: string
          employee_id?: string
          energy_level?: number | null
          id?: string
          is_anonymous?: boolean | null
          mood_score?: number
          notes?: string | null
          org_id?: string
          stress_level?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "mood_checkins_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "mood_checkins_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          body: string | null
          created_at: string
          id: string
          link: string | null
          org_id: string
          read: boolean
          source_module: Database["public"]["Enums"]["module_source"]
          title: string
          type: string
          user_id: string
        }
        Insert: {
          body?: string | null
          created_at?: string
          id?: string
          link?: string | null
          org_id: string
          read?: boolean
          source_module?: Database["public"]["Enums"]["module_source"]
          title: string
          type?: string
          user_id: string
        }
        Update: {
          body?: string | null
          created_at?: string
          id?: string
          link?: string | null
          org_id?: string
          read?: boolean
          source_module?: Database["public"]["Enums"]["module_source"]
          title?: string
          type?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "notifications_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      okr_goals: {
        Row: {
          created_at: string
          description: string | null
          id: string
          level: string
          org_id: string
          owner_id: string | null
          parent_id: string | null
          period: string | null
          progress: number
          status: string
          title: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          level?: string
          org_id: string
          owner_id?: string | null
          parent_id?: string | null
          period?: string | null
          progress?: number
          status?: string
          title: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          level?: string
          org_id?: string
          owner_id?: string | null
          parent_id?: string | null
          period?: string | null
          progress?: number
          status?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "okr_goals_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "okr_goals_owner_id_fkey"
            columns: ["owner_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "okr_goals_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "okr_goals"
            referencedColumns: ["id"]
          },
        ]
      }
      organizations: {
        Row: {
          created_at: string
          id: string
          name: string
          plan: string
          settings: Json
          slug: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          plan?: string
          settings?: Json
          slug: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          plan?: string
          settings?: Json
          slug?: string
          updated_at?: string
        }
        Relationships: []
      }
      page_analysis_results: {
        Row: {
          analyzed_by: string | null
          created_at: string
          id: string
          org_id: string
          overall_score: number | null
          page_name: string | null
          page_url: string
          raw_analysis: Json | null
          recommendations: Json | null
        }
        Insert: {
          analyzed_by?: string | null
          created_at?: string
          id?: string
          org_id: string
          overall_score?: number | null
          page_name?: string | null
          page_url: string
          raw_analysis?: Json | null
          recommendations?: Json | null
        }
        Update: {
          analyzed_by?: string | null
          created_at?: string
          id?: string
          org_id?: string
          overall_score?: number | null
          page_name?: string | null
          page_url?: string
          raw_analysis?: Json | null
          recommendations?: Json | null
        }
        Relationships: [
          {
            foreignKeyName: "page_analysis_results_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      payroll_items: {
        Row: {
          amount: number
          component_id: string | null
          created_at: string
          id: string
          item_type: string
          label: string
          org_id: string
          payroll_id: string
        }
        Insert: {
          amount?: number
          component_id?: string | null
          created_at?: string
          id?: string
          item_type?: string
          label: string
          org_id: string
          payroll_id: string
        }
        Update: {
          amount?: number
          component_id?: string | null
          created_at?: string
          id?: string
          item_type?: string
          label?: string
          org_id?: string
          payroll_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "payroll_items_component_id_fkey"
            columns: ["component_id"]
            isOneToOne: false
            referencedRelation: "salary_components"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payroll_items_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payroll_items_payroll_id_fkey"
            columns: ["payroll_id"]
            isOneToOne: false
            referencedRelation: "payroll_records"
            referencedColumns: ["id"]
          },
        ]
      }
      payroll_records: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          attendance_bonus: number | null
          base_salary: number | null
          created_at: string
          employee_id: string
          gross_salary: number | null
          id: string
          income_tax: number | null
          month: number
          net_salary: number | null
          notes: string | null
          org_id: string
          overtime_hours: number | null
          overtime_pay: number | null
          quality_bonus: number | null
          skill_bonus: number | null
          social_insurance: number | null
          status: string
          total_work_hours: number | null
          transport_bonus: number | null
          updated_at: string
          year: number
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          attendance_bonus?: number | null
          base_salary?: number | null
          created_at?: string
          employee_id: string
          gross_salary?: number | null
          id?: string
          income_tax?: number | null
          month: number
          net_salary?: number | null
          notes?: string | null
          org_id: string
          overtime_hours?: number | null
          overtime_pay?: number | null
          quality_bonus?: number | null
          skill_bonus?: number | null
          social_insurance?: number | null
          status?: string
          total_work_hours?: number | null
          transport_bonus?: number | null
          updated_at?: string
          year: number
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          attendance_bonus?: number | null
          base_salary?: number | null
          created_at?: string
          employee_id?: string
          gross_salary?: number | null
          id?: string
          income_tax?: number | null
          month?: number
          net_salary?: number | null
          notes?: string | null
          org_id?: string
          overtime_hours?: number | null
          overtime_pay?: number | null
          quality_bonus?: number | null
          skill_bonus?: number | null
          social_insurance?: number | null
          status?: string
          total_work_hours?: number | null
          transport_bonus?: number | null
          updated_at?: string
          year?: number
        }
        Relationships: [
          {
            foreignKeyName: "payroll_records_approved_by_fkey"
            columns: ["approved_by"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payroll_records_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payroll_records_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      performance_reviews: {
        Row: {
          comments: string | null
          created_at: string
          goals: string | null
          id: string
          improvements: string | null
          org_id: string
          overall_rating: number | null
          period: string
          review_type: string
          reviewee_id: string
          reviewer_id: string
          status: string
          strengths: string | null
          updated_at: string
        }
        Insert: {
          comments?: string | null
          created_at?: string
          goals?: string | null
          id?: string
          improvements?: string | null
          org_id: string
          overall_rating?: number | null
          period: string
          review_type?: string
          reviewee_id: string
          reviewer_id: string
          status?: string
          strengths?: string | null
          updated_at?: string
        }
        Update: {
          comments?: string | null
          created_at?: string
          goals?: string | null
          id?: string
          improvements?: string | null
          org_id?: string
          overall_rating?: number | null
          period?: string
          review_type?: string
          reviewee_id?: string
          reviewer_id?: string
          status?: string
          strengths?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "performance_reviews_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "performance_reviews_reviewee_id_fkey"
            columns: ["reviewee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "performance_reviews_reviewer_id_fkey"
            columns: ["reviewer_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
        ]
      }
      platform_events: {
        Row: {
          attempts: number
          event_type: string
          id: string
          last_error: string | null
          next_retry_at: string
          org_id: string
          payload: Json
          processed: boolean
          processed_at: string | null
          source_module: Database["public"]["Enums"]["module_source"]
          triggered_at: string
          triggered_by: string | null
        }
        Insert: {
          attempts?: number
          event_type: string
          id?: string
          last_error?: string | null
          next_retry_at?: string
          org_id: string
          payload?: Json
          processed?: boolean
          processed_at?: string | null
          source_module: Database["public"]["Enums"]["module_source"]
          triggered_at?: string
          triggered_by?: string | null
        }
        Update: {
          attempts?: number
          event_type?: string
          id?: string
          last_error?: string | null
          next_retry_at?: string
          org_id?: string
          payload?: Json
          processed?: boolean
          processed_at?: string | null
          source_module?: Database["public"]["Enums"]["module_source"]
          triggered_at?: string
          triggered_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "platform_events_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      poll_votes: {
        Row: {
          created_at: string
          id: string
          org_id: string
          poll_id: string
          selected_option: number
          voter_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          org_id: string
          poll_id: string
          selected_option: number
          voter_id: string
        }
        Update: {
          created_at?: string
          id?: string
          org_id?: string
          poll_id?: string
          selected_option?: number
          voter_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "poll_votes_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "poll_votes_poll_id_fkey"
            columns: ["poll_id"]
            isOneToOne: false
            referencedRelation: "polls"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "poll_votes_voter_id_fkey"
            columns: ["voter_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
        ]
      }
      polls: {
        Row: {
          created_at: string
          created_by: string
          expires_at: string | null
          id: string
          is_active: boolean
          options: Json
          org_id: string
          question: string
        }
        Insert: {
          created_at?: string
          created_by: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          options?: Json
          org_id: string
          question: string
        }
        Update: {
          created_at?: string
          created_by?: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          options?: Json
          org_id?: string
          question?: string
        }
        Relationships: [
          {
            foreignKeyName: "polls_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "polls_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          email: string
          full_name: string | null
          id: string
          language: string
          org_id: string | null
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          email: string
          full_name?: string | null
          id: string
          language?: string
          org_id?: string | null
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          email?: string
          full_name?: string | null
          id?: string
          language?: string
          org_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "profiles_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      research_projects: {
        Row: {
          created_at: string
          created_by: string | null
          data_sources: Json
          id: string
          org_id: string
          outline: Json
          status: string
          title: string
          type: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          data_sources?: Json
          id?: string
          org_id: string
          outline?: Json
          status?: string
          title: string
          type?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          data_sources?: Json
          id?: string
          org_id?: string
          outline?: Json
          status?: string
          title?: string
          type?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "research_projects_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      research_reports: {
        Row: {
          content: string
          created_at: string
          created_by: string | null
          file_url: string | null
          generated_at: string
          id: string
          org_id: string
          params: Json
          password_hash: string | null
          public_link: string | null
          title: string
          type: string
        }
        Insert: {
          content?: string
          created_at?: string
          created_by?: string | null
          file_url?: string | null
          generated_at?: string
          id?: string
          org_id: string
          params?: Json
          password_hash?: string | null
          public_link?: string | null
          title: string
          type: string
        }
        Update: {
          content?: string
          created_at?: string
          created_by?: string | null
          file_url?: string | null
          generated_at?: string
          id?: string
          org_id?: string
          params?: Json
          password_hash?: string | null
          public_link?: string | null
          title?: string
          type?: string
        }
        Relationships: [
          {
            foreignKeyName: "research_reports_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      research_sections: {
        Row: {
          content: string
          created_at: string
          id: string
          metadata: Json
          order_index: number
          org_id: string
          project_id: string
          title: string
          updated_at: string
        }
        Insert: {
          content?: string
          created_at?: string
          id?: string
          metadata?: Json
          order_index?: number
          org_id: string
          project_id: string
          title: string
          updated_at?: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          metadata?: Json
          order_index?: number
          org_id?: string
          project_id?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "research_sections_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "research_sections_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "research_projects"
            referencedColumns: ["id"]
          },
        ]
      }
      research_sources: {
        Row: {
          added_at: string
          content_summary: string | null
          id: string
          metadata: Json
          org_id: string
          project_id: string
          type: string
          url: string | null
        }
        Insert: {
          added_at?: string
          content_summary?: string | null
          id?: string
          metadata?: Json
          org_id: string
          project_id: string
          type: string
          url?: string | null
        }
        Update: {
          added_at?: string
          content_summary?: string | null
          id?: string
          metadata?: Json
          org_id?: string
          project_id?: string
          type?: string
          url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "research_sources_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "research_sources_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "research_projects"
            referencedColumns: ["id"]
          },
        ]
      }
      salary_components: {
        Row: {
          amount: number | null
          component_type: string
          created_at: string
          id: string
          is_active: boolean
          is_percentage: boolean | null
          name: string
          org_id: string
          updated_at: string
        }
        Insert: {
          amount?: number | null
          component_type?: string
          created_at?: string
          id?: string
          is_active?: boolean
          is_percentage?: boolean | null
          name: string
          org_id: string
          updated_at?: string
        }
        Update: {
          amount?: number | null
          component_type?: string
          created_at?: string
          id?: string
          is_active?: boolean
          is_percentage?: boolean | null
          name?: string
          org_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "salary_components_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      search_index: {
        Row: {
          created_at: string
          entity_id: string
          entity_type: string
          id: string
          keywords: string | null
          module: Database["public"]["Enums"]["module_source"]
          org_id: string
          subtitle: string | null
          title: string
          updated_at: string
          url: string
        }
        Insert: {
          created_at?: string
          entity_id: string
          entity_type: string
          id?: string
          keywords?: string | null
          module: Database["public"]["Enums"]["module_source"]
          org_id: string
          subtitle?: string | null
          title: string
          updated_at?: string
          url: string
        }
        Update: {
          created_at?: string
          entity_id?: string
          entity_type?: string
          id?: string
          keywords?: string | null
          module?: Database["public"]["Enums"]["module_source"]
          org_id?: string
          subtitle?: string | null
          title?: string
          updated_at?: string
          url?: string
        }
        Relationships: [
          {
            foreignKeyName: "search_index_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      sentiment_mentions: {
        Row: {
          content_preview: string | null
          created_at: string
          date: string
          id: string
          org_id: string
          post_id: string | null
          score: number | null
          sentiment: Database["public"]["Enums"]["sentiment_label"]
          source_platform: Database["public"]["Enums"]["social_platform"] | null
          source_url: string | null
        }
        Insert: {
          content_preview?: string | null
          created_at?: string
          date?: string
          id?: string
          org_id: string
          post_id?: string | null
          score?: number | null
          sentiment: Database["public"]["Enums"]["sentiment_label"]
          source_platform?:
            | Database["public"]["Enums"]["social_platform"]
            | null
          source_url?: string | null
        }
        Update: {
          content_preview?: string | null
          created_at?: string
          date?: string
          id?: string
          org_id?: string
          post_id?: string | null
          score?: number | null
          sentiment?: Database["public"]["Enums"]["sentiment_label"]
          source_platform?:
            | Database["public"]["Enums"]["social_platform"]
            | null
          source_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "sentiment_mentions_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sentiment_mentions_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "monitoring_posts"
            referencedColumns: ["id"]
          },
        ]
      }
      sentiment_scores: {
        Row: {
          created_at: string
          date: string
          id: string
          mention_count: number | null
          negative_count: number | null
          neutral_count: number | null
          org_id: string
          positive_count: number | null
          score: number
        }
        Insert: {
          created_at?: string
          date: string
          id?: string
          mention_count?: number | null
          negative_count?: number | null
          neutral_count?: number | null
          org_id: string
          positive_count?: number | null
          score?: number
        }
        Update: {
          created_at?: string
          date?: string
          id?: string
          mention_count?: number | null
          negative_count?: number | null
          neutral_count?: number | null
          org_id?: string
          positive_count?: number | null
          score?: number
        }
        Relationships: [
          {
            foreignKeyName: "sentiment_scores_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      shift_assignments: {
        Row: {
          created_at: string
          created_by: string | null
          employee_id: string
          id: string
          notes: string | null
          org_id: string
          shift_date: string
          shift_id: string
          status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          employee_id: string
          id?: string
          notes?: string | null
          org_id: string
          shift_date: string
          shift_id: string
          status?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          employee_id?: string
          id?: string
          notes?: string | null
          org_id?: string
          shift_date?: string
          shift_id?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "shift_assignments_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "shift_assignments_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "shift_assignments_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "shift_assignments_shift_id_fkey"
            columns: ["shift_id"]
            isOneToOne: false
            referencedRelation: "shifts"
            referencedColumns: ["id"]
          },
        ]
      }
      shifts: {
        Row: {
          created_at: string
          end_time: string
          id: string
          is_active: boolean
          name: string
          org_id: string
          shift_type: string
          start_time: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          end_time: string
          id?: string
          is_active?: boolean
          name: string
          org_id: string
          shift_type?: string
          start_time: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          end_time?: string
          id?: string
          is_active?: boolean
          name?: string
          org_id?: string
          shift_type?: string
          start_time?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "shifts_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      smm_clients: {
        Row: {
          account_manager: string | null
          company: string | null
          created_at: string
          created_by: string | null
          email: string | null
          id: string
          monthly_retainer: number | null
          name: string
          notes: string | null
          org_id: string
          phone: string | null
          status: Database["public"]["Enums"]["smm_client_status"]
          tags: string[] | null
          updated_at: string
          website: string | null
        }
        Insert: {
          account_manager?: string | null
          company?: string | null
          created_at?: string
          created_by?: string | null
          email?: string | null
          id?: string
          monthly_retainer?: number | null
          name: string
          notes?: string | null
          org_id: string
          phone?: string | null
          status?: Database["public"]["Enums"]["smm_client_status"]
          tags?: string[] | null
          updated_at?: string
          website?: string | null
        }
        Update: {
          account_manager?: string | null
          company?: string | null
          created_at?: string
          created_by?: string | null
          email?: string | null
          id?: string
          monthly_retainer?: number | null
          name?: string
          notes?: string | null
          org_id?: string
          phone?: string | null
          status?: Database["public"]["Enums"]["smm_client_status"]
          tags?: string[] | null
          updated_at?: string
          website?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "smm_clients_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      smm_invoices: {
        Row: {
          amount: number
          amount_paid: number
          client_id: string | null
          created_at: string
          created_by: string | null
          currency: string | null
          due_date: string | null
          id: string
          issue_date: string | null
          line_items: Json | null
          notes: string | null
          number: string
          org_id: string
          paid_at: string | null
          project_id: string | null
          status: Database["public"]["Enums"]["smm_invoice_status"]
          updated_at: string
        }
        Insert: {
          amount?: number
          amount_paid?: number
          client_id?: string | null
          created_at?: string
          created_by?: string | null
          currency?: string | null
          due_date?: string | null
          id?: string
          issue_date?: string | null
          line_items?: Json | null
          notes?: string | null
          number: string
          org_id: string
          paid_at?: string | null
          project_id?: string | null
          status?: Database["public"]["Enums"]["smm_invoice_status"]
          updated_at?: string
        }
        Update: {
          amount?: number
          amount_paid?: number
          client_id?: string | null
          created_at?: string
          created_by?: string | null
          currency?: string | null
          due_date?: string | null
          id?: string
          issue_date?: string | null
          line_items?: Json | null
          notes?: string | null
          number?: string
          org_id?: string
          paid_at?: string | null
          project_id?: string | null
          status?: Database["public"]["Enums"]["smm_invoice_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "smm_invoices_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "smm_clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "smm_invoices_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "smm_invoices_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "smm_projects"
            referencedColumns: ["id"]
          },
        ]
      }
      smm_payments: {
        Row: {
          amount: number
          created_at: string
          created_by: string | null
          id: string
          invoice_id: string
          method: string | null
          notes: string | null
          org_id: string
          paid_at: string
          reference: string | null
        }
        Insert: {
          amount: number
          created_at?: string
          created_by?: string | null
          id?: string
          invoice_id: string
          method?: string | null
          notes?: string | null
          org_id: string
          paid_at?: string
          reference?: string | null
        }
        Update: {
          amount?: number
          created_at?: string
          created_by?: string | null
          id?: string
          invoice_id?: string
          method?: string | null
          notes?: string | null
          org_id?: string
          paid_at?: string
          reference?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "smm_payments_invoice_id_fkey"
            columns: ["invoice_id"]
            isOneToOne: false
            referencedRelation: "smm_invoices"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "smm_payments_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      smm_posts: {
        Row: {
          approval_required: boolean | null
          approved_at: string | null
          approved_by: string | null
          assigned_to: string | null
          caption: string | null
          client_id: string | null
          created_at: string
          created_by: string | null
          external_post_id: string | null
          hashtags: string[] | null
          id: string
          media_urls: string[] | null
          metrics: Json | null
          org_id: string
          platform: Database["public"]["Enums"]["smm_post_platform"]
          project_id: string | null
          published_at: string | null
          scheduled_at: string | null
          status: Database["public"]["Enums"]["smm_post_status"]
          title: string | null
          updated_at: string
        }
        Insert: {
          approval_required?: boolean | null
          approved_at?: string | null
          approved_by?: string | null
          assigned_to?: string | null
          caption?: string | null
          client_id?: string | null
          created_at?: string
          created_by?: string | null
          external_post_id?: string | null
          hashtags?: string[] | null
          id?: string
          media_urls?: string[] | null
          metrics?: Json | null
          org_id: string
          platform?: Database["public"]["Enums"]["smm_post_platform"]
          project_id?: string | null
          published_at?: string | null
          scheduled_at?: string | null
          status?: Database["public"]["Enums"]["smm_post_status"]
          title?: string | null
          updated_at?: string
        }
        Update: {
          approval_required?: boolean | null
          approved_at?: string | null
          approved_by?: string | null
          assigned_to?: string | null
          caption?: string | null
          client_id?: string | null
          created_at?: string
          created_by?: string | null
          external_post_id?: string | null
          hashtags?: string[] | null
          id?: string
          media_urls?: string[] | null
          metrics?: Json | null
          org_id?: string
          platform?: Database["public"]["Enums"]["smm_post_platform"]
          project_id?: string | null
          published_at?: string | null
          scheduled_at?: string | null
          status?: Database["public"]["Enums"]["smm_post_status"]
          title?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "smm_posts_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "smm_clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "smm_posts_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "smm_posts_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "smm_projects"
            referencedColumns: ["id"]
          },
        ]
      }
      smm_projects: {
        Row: {
          budget: number | null
          client_id: string | null
          created_at: string
          created_by: string | null
          description: string | null
          end_date: string | null
          id: string
          name: string
          org_id: string
          start_date: string | null
          status: Database["public"]["Enums"]["smm_project_status"]
          updated_at: string
        }
        Insert: {
          budget?: number | null
          client_id?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          end_date?: string | null
          id?: string
          name: string
          org_id: string
          start_date?: string | null
          status?: Database["public"]["Enums"]["smm_project_status"]
          updated_at?: string
        }
        Update: {
          budget?: number | null
          client_id?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          end_date?: string | null
          id?: string
          name?: string
          org_id?: string
          start_date?: string | null
          status?: Database["public"]["Enums"]["smm_project_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "smm_projects_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "smm_clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "smm_projects_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      smm_proposals: {
        Row: {
          amount: number | null
          approval_token: string | null
          body: string | null
          client_id: string | null
          created_at: string
          created_by: string | null
          currency: string | null
          expires_at: string | null
          id: string
          org_id: string
          responded_at: string | null
          sent_at: string | null
          status: Database["public"]["Enums"]["smm_proposal_status"]
          title: string
          updated_at: string
          viewed_at: string | null
        }
        Insert: {
          amount?: number | null
          approval_token?: string | null
          body?: string | null
          client_id?: string | null
          created_at?: string
          created_by?: string | null
          currency?: string | null
          expires_at?: string | null
          id?: string
          org_id: string
          responded_at?: string | null
          sent_at?: string | null
          status?: Database["public"]["Enums"]["smm_proposal_status"]
          title: string
          updated_at?: string
          viewed_at?: string | null
        }
        Update: {
          amount?: number | null
          approval_token?: string | null
          body?: string | null
          client_id?: string | null
          created_at?: string
          created_by?: string | null
          currency?: string | null
          expires_at?: string | null
          id?: string
          org_id?: string
          responded_at?: string | null
          sent_at?: string | null
          status?: Database["public"]["Enums"]["smm_proposal_status"]
          title?: string
          updated_at?: string
          viewed_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "smm_proposals_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "smm_clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "smm_proposals_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      ulu_transactions: {
        Row: {
          amount: number
          approved_at: string | null
          created_at: string
          created_by: string | null
          currency: string
          description: string | null
          employee_id: string | null
          fee: number
          flag_reason: string | null
          id: string
          org_id: string
          payment_reference: string | null
          processed_at: string | null
          provider: string | null
          qpay_invoice_id: string | null
          qpay_qr_text: string | null
          requested_at: string
          status: string
          updated_at: string
        }
        Insert: {
          amount: number
          approved_at?: string | null
          created_at?: string
          created_by?: string | null
          currency?: string
          description?: string | null
          employee_id?: string | null
          fee?: number
          flag_reason?: string | null
          id?: string
          org_id: string
          payment_reference?: string | null
          processed_at?: string | null
          provider?: string | null
          qpay_invoice_id?: string | null
          qpay_qr_text?: string | null
          requested_at?: string
          status?: string
          updated_at?: string
        }
        Update: {
          amount?: number
          approved_at?: string | null
          created_at?: string
          created_by?: string | null
          currency?: string
          description?: string | null
          employee_id?: string | null
          fee?: number
          flag_reason?: string | null
          id?: string
          org_id?: string
          payment_reference?: string | null
          processed_at?: string | null
          provider?: string | null
          qpay_invoice_id?: string | null
          qpay_qr_text?: string | null
          requested_at?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "ulu_transactions_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ulu_transactions_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          org_id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          org_id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          org_id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_roles_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      webhook_endpoints: {
        Row: {
          active: boolean
          created_at: string
          event_types: string[]
          id: string
          last_delivery_at: string | null
          last_error: string | null
          last_status: number | null
          org_id: string
          secret: string
          updated_at: string
          url: string
        }
        Insert: {
          active?: boolean
          created_at?: string
          event_types?: string[]
          id?: string
          last_delivery_at?: string | null
          last_error?: string | null
          last_status?: number | null
          org_id: string
          secret?: string
          updated_at?: string
          url: string
        }
        Update: {
          active?: boolean
          created_at?: string
          event_types?: string[]
          id?: string
          last_delivery_at?: string | null
          last_error?: string | null
          last_status?: number | null
          org_id?: string
          secret?: string
          updated_at?: string
          url?: string
        }
        Relationships: [
          {
            foreignKeyName: "webhook_endpoints_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      webhook_logs: {
        Row: {
          channel_id: string | null
          created_at: string
          error_message: string | null
          id: string
          org_id: string
          platform: Database["public"]["Enums"]["bot_platform"] | null
          request_body: Json | null
          request_headers: Json | null
          request_method: string | null
          response_body: Json | null
          response_status: number | null
        }
        Insert: {
          channel_id?: string | null
          created_at?: string
          error_message?: string | null
          id?: string
          org_id: string
          platform?: Database["public"]["Enums"]["bot_platform"] | null
          request_body?: Json | null
          request_headers?: Json | null
          request_method?: string | null
          response_body?: Json | null
          response_status?: number | null
        }
        Update: {
          channel_id?: string | null
          created_at?: string
          error_message?: string | null
          id?: string
          org_id?: string
          platform?: Database["public"]["Enums"]["bot_platform"] | null
          request_body?: Json | null
          request_headers?: Json | null
          request_method?: string | null
          response_body?: Json | null
          response_status?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "webhook_logs_channel_id_fkey"
            columns: ["channel_id"]
            isOneToOne: false
            referencedRelation: "bot_channels"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "webhook_logs_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      work_sessions: {
        Row: {
          break_minutes: number | null
          clock_in: string
          clock_in_device_id: string | null
          clock_in_method:
            | Database["public"]["Enums"]["attendance_method"]
            | null
          clock_out: string | null
          clock_out_device_id: string | null
          clock_out_method:
            | Database["public"]["Enums"]["attendance_method"]
            | null
          created_at: string
          date: string
          employee_id: string
          id: string
          notes: string | null
          org_id: string
          overtime_minutes: number | null
          status: Database["public"]["Enums"]["session_status"]
          total_minutes: number | null
          updated_at: string
        }
        Insert: {
          break_minutes?: number | null
          clock_in: string
          clock_in_device_id?: string | null
          clock_in_method?:
            | Database["public"]["Enums"]["attendance_method"]
            | null
          clock_out?: string | null
          clock_out_device_id?: string | null
          clock_out_method?:
            | Database["public"]["Enums"]["attendance_method"]
            | null
          created_at?: string
          date?: string
          employee_id: string
          id?: string
          notes?: string | null
          org_id: string
          overtime_minutes?: number | null
          status?: Database["public"]["Enums"]["session_status"]
          total_minutes?: number | null
          updated_at?: string
        }
        Update: {
          break_minutes?: number | null
          clock_in?: string
          clock_in_device_id?: string | null
          clock_in_method?:
            | Database["public"]["Enums"]["attendance_method"]
            | null
          clock_out?: string | null
          clock_out_device_id?: string | null
          clock_out_method?:
            | Database["public"]["Enums"]["attendance_method"]
            | null
          created_at?: string
          date?: string
          employee_id?: string
          id?: string
          notes?: string | null
          org_id?: string
          overtime_minutes?: number | null
          status?: Database["public"]["Enums"]["session_status"]
          total_minutes?: number | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "work_sessions_clock_in_device_id_fkey"
            columns: ["clock_in_device_id"]
            isOneToOne: false
            referencedRelation: "device_keys"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "work_sessions_clock_out_device_id_fkey"
            columns: ["clock_out_device_id"]
            isOneToOne: false
            referencedRelation: "device_keys"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "work_sessions_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "work_sessions_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      workforce_approval_actions: {
        Row: {
          acted_by: string
          action: string
          comments: string | null
          created_at: string
          id: string
          org_id: string
          request_id: string
          step_name: string
          step_order: number
        }
        Insert: {
          acted_by: string
          action: string
          comments?: string | null
          created_at?: string
          id?: string
          org_id: string
          request_id: string
          step_name: string
          step_order: number
        }
        Update: {
          acted_by?: string
          action?: string
          comments?: string | null
          created_at?: string
          id?: string
          org_id?: string
          request_id?: string
          step_name?: string
          step_order?: number
        }
        Relationships: [
          {
            foreignKeyName: "workforce_approval_actions_acted_by_fkey"
            columns: ["acted_by"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workforce_approval_actions_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workforce_approval_actions_request_id_fkey"
            columns: ["request_id"]
            isOneToOne: false
            referencedRelation: "workforce_approval_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      workforce_approval_requests: {
        Row: {
          created_at: string
          current_step: number
          entity_id: string
          entity_type: string
          id: string
          org_id: string
          requester_id: string
          status: string
          total_steps: number
          updated_at: string
          workflow_id: string
        }
        Insert: {
          created_at?: string
          current_step?: number
          entity_id: string
          entity_type: string
          id?: string
          org_id: string
          requester_id: string
          status?: string
          total_steps: number
          updated_at?: string
          workflow_id: string
        }
        Update: {
          created_at?: string
          current_step?: number
          entity_id?: string
          entity_type?: string
          id?: string
          org_id?: string
          requester_id?: string
          status?: string
          total_steps?: number
          updated_at?: string
          workflow_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "workforce_approval_requests_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workforce_approval_requests_requester_id_fkey"
            columns: ["requester_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workforce_approval_requests_workflow_id_fkey"
            columns: ["workflow_id"]
            isOneToOne: false
            referencedRelation: "workforce_approval_workflows"
            referencedColumns: ["id"]
          },
        ]
      }
      workforce_approval_steps: {
        Row: {
          created_at: string
          id: string
          is_optional: boolean
          org_id: string
          required_role: Database["public"]["Enums"]["app_role"]
          step_name: string
          step_order: number
          workflow_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_optional?: boolean
          org_id: string
          required_role: Database["public"]["Enums"]["app_role"]
          step_name: string
          step_order: number
          workflow_id: string
        }
        Update: {
          created_at?: string
          id?: string
          is_optional?: boolean
          org_id?: string
          required_role?: Database["public"]["Enums"]["app_role"]
          step_name?: string
          step_order?: number
          workflow_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "workforce_approval_steps_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workforce_approval_steps_workflow_id_fkey"
            columns: ["workflow_id"]
            isOneToOne: false
            referencedRelation: "workforce_approval_workflows"
            referencedColumns: ["id"]
          },
        ]
      }
      workforce_approval_workflows: {
        Row: {
          created_at: string
          entity_type: string
          id: string
          is_active: boolean
          name: string
          org_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          entity_type: string
          id?: string
          is_active?: boolean
          name: string
          org_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          entity_type?: string
          id?: string
          is_active?: boolean
          name?: string
          org_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "workforce_approval_workflows_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      workforce_company_events: {
        Row: {
          created_at: string
          created_by: string | null
          department_id: string | null
          description: string | null
          end_date: string | null
          event_type: string | null
          id: string
          is_all_day: boolean | null
          location: string | null
          org_id: string
          start_date: string
          title: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          department_id?: string | null
          description?: string | null
          end_date?: string | null
          event_type?: string | null
          id?: string
          is_all_day?: boolean | null
          location?: string | null
          org_id: string
          start_date: string
          title: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          department_id?: string | null
          description?: string | null
          end_date?: string | null
          event_type?: string | null
          id?: string
          is_all_day?: boolean | null
          location?: string | null
          org_id?: string
          start_date?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "workforce_company_events_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workforce_company_events_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workforce_company_events_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      workforce_documents: {
        Row: {
          category: string | null
          created_at: string
          department_id: string | null
          description: string | null
          file_name: string
          file_path: string
          file_size: number | null
          id: string
          is_shared: boolean | null
          mime_type: string | null
          org_id: string
          title: string
          updated_at: string
          uploaded_by: string
        }
        Insert: {
          category?: string | null
          created_at?: string
          department_id?: string | null
          description?: string | null
          file_name: string
          file_path: string
          file_size?: number | null
          id?: string
          is_shared?: boolean | null
          mime_type?: string | null
          org_id: string
          title: string
          updated_at?: string
          uploaded_by: string
        }
        Update: {
          category?: string | null
          created_at?: string
          department_id?: string | null
          description?: string | null
          file_name?: string
          file_path?: string
          file_size?: number | null
          id?: string
          is_shared?: boolean | null
          mime_type?: string | null
          org_id?: string
          title?: string
          updated_at?: string
          uploaded_by?: string
        }
        Relationships: [
          {
            foreignKeyName: "workforce_documents_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workforce_documents_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workforce_documents_uploaded_by_fkey"
            columns: ["uploaded_by"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
        ]
      }
      workforce_expenses: {
        Row: {
          amount: number
          category: string
          created_at: string
          currency: string | null
          description: string | null
          employee_id: string
          expense_date: string
          id: string
          org_id: string
          receipt_url: string | null
          review_notes: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          updated_at: string
        }
        Insert: {
          amount: number
          category?: string
          created_at?: string
          currency?: string | null
          description?: string | null
          employee_id: string
          expense_date?: string
          id?: string
          org_id: string
          receipt_url?: string | null
          review_notes?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          amount?: number
          category?: string
          created_at?: string
          currency?: string | null
          description?: string | null
          employee_id?: string
          expense_date?: string
          id?: string
          org_id?: string
          receipt_url?: string | null
          review_notes?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "workforce_expenses_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workforce_expenses_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workforce_expenses_reviewed_by_fkey"
            columns: ["reviewed_by"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
        ]
      }
      workforce_meeting_rooms: {
        Row: {
          amenities: string[] | null
          capacity: number
          created_at: string
          floor: number | null
          id: string
          is_active: boolean
          location: string | null
          name: string
          org_id: string
          updated_at: string
        }
        Insert: {
          amenities?: string[] | null
          capacity?: number
          created_at?: string
          floor?: number | null
          id?: string
          is_active?: boolean
          location?: string | null
          name: string
          org_id: string
          updated_at?: string
        }
        Update: {
          amenities?: string[] | null
          capacity?: number
          created_at?: string
          floor?: number | null
          id?: string
          is_active?: boolean
          location?: string | null
          name?: string
          org_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "workforce_meeting_rooms_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      workforce_monthly_reports: {
        Row: {
          ai_analysis: string | null
          attendance_data: Json | null
          created_at: string
          employee_id: string
          generated_by: string | null
          id: string
          kpi_data: Json | null
          month: number
          org_id: string
          recommendations: string | null
          status: string
          summary: string | null
          task_data: Json | null
          updated_at: string
          year: number
        }
        Insert: {
          ai_analysis?: string | null
          attendance_data?: Json | null
          created_at?: string
          employee_id: string
          generated_by?: string | null
          id?: string
          kpi_data?: Json | null
          month: number
          org_id: string
          recommendations?: string | null
          status?: string
          summary?: string | null
          task_data?: Json | null
          updated_at?: string
          year: number
        }
        Update: {
          ai_analysis?: string | null
          attendance_data?: Json | null
          created_at?: string
          employee_id?: string
          generated_by?: string | null
          id?: string
          kpi_data?: Json | null
          month?: number
          org_id?: string
          recommendations?: string | null
          status?: string
          summary?: string | null
          task_data?: Json | null
          updated_at?: string
          year?: number
        }
        Relationships: [
          {
            foreignKeyName: "workforce_monthly_reports_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workforce_monthly_reports_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      workforce_onboarding_checklists: {
        Row: {
          assigned_by: string | null
          created_at: string
          due_date: string | null
          employee_id: string
          id: string
          org_id: string
          status: string
          title: string
          updated_at: string
        }
        Insert: {
          assigned_by?: string | null
          created_at?: string
          due_date?: string | null
          employee_id: string
          id?: string
          org_id: string
          status?: string
          title?: string
          updated_at?: string
        }
        Update: {
          assigned_by?: string | null
          created_at?: string
          due_date?: string | null
          employee_id?: string
          id?: string
          org_id?: string
          status?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "workforce_onboarding_checklists_assigned_by_fkey"
            columns: ["assigned_by"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workforce_onboarding_checklists_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workforce_onboarding_checklists_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      workforce_onboarding_items: {
        Row: {
          checklist_id: string
          completed_at: string | null
          created_at: string
          description: string | null
          id: string
          is_completed: boolean
          org_id: string
          sort_order: number | null
          title: string
        }
        Insert: {
          checklist_id: string
          completed_at?: string | null
          created_at?: string
          description?: string | null
          id?: string
          is_completed?: boolean
          org_id: string
          sort_order?: number | null
          title: string
        }
        Update: {
          checklist_id?: string
          completed_at?: string | null
          created_at?: string
          description?: string | null
          id?: string
          is_completed?: boolean
          org_id?: string
          sort_order?: number | null
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "workforce_onboarding_items_checklist_id_fkey"
            columns: ["checklist_id"]
            isOneToOne: false
            referencedRelation: "workforce_onboarding_checklists"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workforce_onboarding_items_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      workforce_project_members: {
        Row: {
          created_at: string
          employee_id: string
          id: string
          joined_at: string
          org_id: string
          project_id: string
          role: string | null
        }
        Insert: {
          created_at?: string
          employee_id: string
          id?: string
          joined_at?: string
          org_id: string
          project_id: string
          role?: string | null
        }
        Update: {
          created_at?: string
          employee_id?: string
          id?: string
          joined_at?: string
          org_id?: string
          project_id?: string
          role?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "workforce_project_members_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workforce_project_members_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workforce_project_members_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "workforce_projects"
            referencedColumns: ["id"]
          },
        ]
      }
      workforce_projects: {
        Row: {
          budget: number | null
          created_at: string
          department_id: string | null
          description: string | null
          end_date: string | null
          id: string
          manager_id: string | null
          name: string
          org_id: string
          start_date: string | null
          status: string
          updated_at: string
        }
        Insert: {
          budget?: number | null
          created_at?: string
          department_id?: string | null
          description?: string | null
          end_date?: string | null
          id?: string
          manager_id?: string | null
          name: string
          org_id: string
          start_date?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          budget?: number | null
          created_at?: string
          department_id?: string | null
          description?: string | null
          end_date?: string | null
          id?: string
          manager_id?: string | null
          name?: string
          org_id?: string
          start_date?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "workforce_projects_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workforce_projects_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workforce_projects_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      workforce_room_bookings: {
        Row: {
          attendees: number | null
          booked_by: string
          created_at: string
          end_time: string
          id: string
          notes: string | null
          org_id: string
          room_id: string
          start_time: string
          status: string
          title: string
        }
        Insert: {
          attendees?: number | null
          booked_by: string
          created_at?: string
          end_time: string
          id?: string
          notes?: string | null
          org_id: string
          room_id: string
          start_time: string
          status?: string
          title: string
        }
        Update: {
          attendees?: number | null
          booked_by?: string
          created_at?: string
          end_time?: string
          id?: string
          notes?: string | null
          org_id?: string
          room_id?: string
          start_time?: string
          status?: string
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "workforce_room_bookings_booked_by_fkey"
            columns: ["booked_by"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workforce_room_bookings_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workforce_room_bookings_room_id_fkey"
            columns: ["room_id"]
            isOneToOne: false
            referencedRelation: "workforce_meeting_rooms"
            referencedColumns: ["id"]
          },
        ]
      }
      workforce_task_comments: {
        Row: {
          author_id: string
          content: string
          created_at: string
          id: string
          org_id: string
          task_id: string
        }
        Insert: {
          author_id: string
          content: string
          created_at?: string
          id?: string
          org_id: string
          task_id: string
        }
        Update: {
          author_id?: string
          content?: string
          created_at?: string
          id?: string
          org_id?: string
          task_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "workforce_task_comments_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workforce_task_comments_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workforce_task_comments_task_id_fkey"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "workforce_tasks"
            referencedColumns: ["id"]
          },
        ]
      }
      workforce_tasks: {
        Row: {
          actual_hours: number | null
          assigned_by: string | null
          assigned_to: string | null
          category: string | null
          completed_at: string | null
          completion_percentage: number | null
          created_at: string
          department_id: string | null
          description: string | null
          due_date: string | null
          estimated_hours: number | null
          id: string
          org_id: string
          parent_task_id: string | null
          priority: Database["public"]["Enums"]["task_priority"]
          project_id: string | null
          started_at: string | null
          status: Database["public"]["Enums"]["task_status"]
          title: string
          updated_at: string
        }
        Insert: {
          actual_hours?: number | null
          assigned_by?: string | null
          assigned_to?: string | null
          category?: string | null
          completed_at?: string | null
          completion_percentage?: number | null
          created_at?: string
          department_id?: string | null
          description?: string | null
          due_date?: string | null
          estimated_hours?: number | null
          id?: string
          org_id: string
          parent_task_id?: string | null
          priority?: Database["public"]["Enums"]["task_priority"]
          project_id?: string | null
          started_at?: string | null
          status?: Database["public"]["Enums"]["task_status"]
          title: string
          updated_at?: string
        }
        Update: {
          actual_hours?: number | null
          assigned_by?: string | null
          assigned_to?: string | null
          category?: string | null
          completed_at?: string | null
          completion_percentage?: number | null
          created_at?: string
          department_id?: string | null
          description?: string | null
          due_date?: string | null
          estimated_hours?: number | null
          id?: string
          org_id?: string
          parent_task_id?: string | null
          priority?: Database["public"]["Enums"]["task_priority"]
          project_id?: string | null
          started_at?: string | null
          status?: Database["public"]["Enums"]["task_status"]
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "workforce_tasks_assigned_by_fkey"
            columns: ["assigned_by"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workforce_tasks_assigned_to_fkey"
            columns: ["assigned_to"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workforce_tasks_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workforce_tasks_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workforce_tasks_parent_task_id_fkey"
            columns: ["parent_task_id"]
            isOneToOne: false
            referencedRelation: "workforce_tasks"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workforce_tasks_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "workforce_projects"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      current_org_id: { Args: never; Returns: string }
      get_employee_id: {
        Args: { _org_id: string; _user_id: string }
        Returns: string
      }
      has_role: {
        Args: {
          _org_id: string
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_chat_member: {
        Args: { _channel_id: string; _org_id: string; _user_id: string }
        Returns: boolean
      }
      is_org_member: {
        Args: { _org_id: string; _user_id: string }
        Returns: boolean
      }
      is_workforce_admin: {
        Args: { _org_id: string; _user_id: string }
        Returns: boolean
      }
    }
    Enums: {
      alert_severity: "low" | "medium" | "high" | "critical"
      alert_status: "active" | "acknowledged" | "resolved" | "dismissed"
      app_role:
        | "employee"
        | "agent"
        | "manager"
        | "admin"
        | "ceo"
        | "project_manager"
      attendance_method: "nfc" | "wifi" | "manual" | "gps" | "qr"
      bot_msg_direction: "in" | "out"
      bot_platform:
        | "telegram"
        | "whatsapp"
        | "messenger"
        | "instagram"
        | "facebook"
        | "web"
        | "sms"
      bot_resolution: "ai" | "human" | "unresolved"
      bot_status: "draft" | "active" | "paused" | "archived"
      broadcast_status: "draft" | "scheduled" | "sending" | "sent" | "failed"
      device_type: "nfc_reader" | "wifi_router" | "qr_station"
      event_type: "clock_in" | "clock_out" | "break_start" | "break_end"
      handoff_status: "pending" | "accepted" | "resolved" | "cancelled"
      leave_status: "pending" | "approved" | "rejected" | "cancelled"
      leave_type:
        | "annual"
        | "sick"
        | "personal"
        | "maternity"
        | "paternity"
        | "unpaid"
        | "public_holiday"
        | "other"
      module_source:
        | "timeflow"
        | "omnisight"
        | "smm"
        | "flowbot"
        | "core"
        | "bots"
        | "workforce"
        | "monitor"
        | "content"
      sentiment_label: "positive" | "neutral" | "negative"
      session_status: "active" | "completed" | "incomplete"
      smm_client_status: "active" | "paused" | "churned" | "prospect"
      smm_invoice_status:
        | "draft"
        | "sent"
        | "viewed"
        | "partial"
        | "paid"
        | "overdue"
        | "cancelled"
      smm_post_platform:
        | "facebook"
        | "instagram"
        | "twitter"
        | "linkedin"
        | "tiktok"
        | "youtube"
        | "telegram"
        | "threads"
        | "other"
      smm_post_status:
        | "draft"
        | "review"
        | "approved"
        | "scheduled"
        | "published"
        | "failed"
      smm_project_status:
        | "planning"
        | "active"
        | "on_hold"
        | "completed"
        | "cancelled"
      smm_proposal_status:
        | "draft"
        | "sent"
        | "viewed"
        | "accepted"
        | "rejected"
        | "expired"
      social_platform:
        | "facebook"
        | "instagram"
        | "twitter"
        | "tiktok"
        | "youtube"
        | "linkedin"
        | "web"
        | "news"
        | "other"
      task_priority: "low" | "medium" | "high" | "urgent"
      task_status:
        | "todo"
        | "in_progress"
        | "in_review"
        | "completed"
        | "cancelled"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      alert_severity: ["low", "medium", "high", "critical"],
      alert_status: ["active", "acknowledged", "resolved", "dismissed"],
      app_role: [
        "employee",
        "agent",
        "manager",
        "admin",
        "ceo",
        "project_manager",
      ],
      attendance_method: ["nfc", "wifi", "manual", "gps", "qr"],
      bot_msg_direction: ["in", "out"],
      bot_platform: [
        "telegram",
        "whatsapp",
        "messenger",
        "instagram",
        "facebook",
        "web",
        "sms",
      ],
      bot_resolution: ["ai", "human", "unresolved"],
      bot_status: ["draft", "active", "paused", "archived"],
      broadcast_status: ["draft", "scheduled", "sending", "sent", "failed"],
      device_type: ["nfc_reader", "wifi_router", "qr_station"],
      event_type: ["clock_in", "clock_out", "break_start", "break_end"],
      handoff_status: ["pending", "accepted", "resolved", "cancelled"],
      leave_status: ["pending", "approved", "rejected", "cancelled"],
      leave_type: [
        "annual",
        "sick",
        "personal",
        "maternity",
        "paternity",
        "unpaid",
        "public_holiday",
        "other",
      ],
      module_source: [
        "timeflow",
        "omnisight",
        "smm",
        "flowbot",
        "core",
        "bots",
        "workforce",
        "monitor",
        "content",
      ],
      sentiment_label: ["positive", "neutral", "negative"],
      session_status: ["active", "completed", "incomplete"],
      smm_client_status: ["active", "paused", "churned", "prospect"],
      smm_invoice_status: [
        "draft",
        "sent",
        "viewed",
        "partial",
        "paid",
        "overdue",
        "cancelled",
      ],
      smm_post_platform: [
        "facebook",
        "instagram",
        "twitter",
        "linkedin",
        "tiktok",
        "youtube",
        "telegram",
        "threads",
        "other",
      ],
      smm_post_status: [
        "draft",
        "review",
        "approved",
        "scheduled",
        "published",
        "failed",
      ],
      smm_project_status: [
        "planning",
        "active",
        "on_hold",
        "completed",
        "cancelled",
      ],
      smm_proposal_status: [
        "draft",
        "sent",
        "viewed",
        "accepted",
        "rejected",
        "expired",
      ],
      social_platform: [
        "facebook",
        "instagram",
        "twitter",
        "tiktok",
        "youtube",
        "linkedin",
        "web",
        "news",
        "other",
      ],
      task_priority: ["low", "medium", "high", "urgent"],
      task_status: [
        "todo",
        "in_progress",
        "in_review",
        "completed",
        "cancelled",
      ],
    },
  },
} as const
